//! C-compatible FFI exports for mid-ecs.
//!
//! Scope for this pass: `World` lifecycle only — `new`/`free`/`spawn`/
//! `despawn`/`is_alive`/`entity_count`. Genuinely useful right now on its
//! own: a non-Rust caller can already create a world and manage entity
//! lifetimes, with real generational safety, before any component data
//! can cross the boundary at all. Component data access (reading a
//! `Position` column from C, for instance) needs the FFI-span design
//! this crate's `docs/mid-ecs.md` calls out as the next real FFI piece —
//! deliberately not attempted here in the same pass, since it has a
//! genuinely harder safety story (a raw pointer into a `Vec<T>` that a
//! later `insert`/`remove`/migration call can reallocate or move out
//! from under, unlike anything in this file, where every value crosses
//! by-value or through an opaque handle with no live pointers into
//! mutable interior storage). Built incrementally, tested as it's
//! built — the same conclusion `mid-net-transport-quinn`/`-wasm` reached
//! for network code applies here too: get one real, working, tested
//! slice of FFI surface out before reaching for the harder piece.
//!
//! ## Conventions — copied directly from `mid-net`'s real `ffi.rs`, not
//! reinvented
//! - Every function checks its pointer arguments for null before
//!   dereferencing and returns a defined error code (or a safe default:
//!   `false` for `is_alive`, `0` for `entity_count`) instead of
//!   dereferencing a null pointer.
//! - Every function's body runs inside [`std::panic::catch_unwind`] via
//!   `ffi_guard` — unwinding across an `extern "C"` boundary is
//!   undefined behavior, so a panic here becomes
//!   `MidEcsStatus::InternalPanic` instead.
//! - Every function taking a raw pointer is `unsafe fn` with a `# Safety`
//!   doc comment, matching `clippy::not_unsafe_ptr_arg_deref`'s
//!   requirement (deny-by-default on real CI, same MSRV-gap pattern
//!   already documented in `mid-net`'s own `ffi.rs`).
//! - `World` is not `repr(C)` (it owns `SparseSet`s, `HashMap`s, `Vec`s —
//!   nothing about it is C-representable), so it crosses the boundary as
//!   an opaque heap-allocated handle (`Box::into_raw`/`Box::from_raw`),
//!   matching `mid-net`'s own `MidNetPlayerEvent` handle pattern exactly.
//!
//! ## The one genuinely new piece: packing `Entity` as a plain `u64`
//! `Entity` itself can't cross the boundary as a Rust value (its inner
//! `GenerationalIndex` fields are private, deliberately — an `Entity`
//! should only ever come from a real `World::spawn`), and a two-field
//! `repr(C)` struct would make every FFI caller's language agree on a
//! struct layout for no real benefit. `Entity::as_ffi`/`from_ffi` (thin
//! wrappers over `mid_collections::GenerationalIndex::as_ffi`/
//! `from_ffi`, which do the real packing) give one plain `u64` instead —
//! directly grounded in `slotmap::KeyData::as_ffi`/`from_ffi`'s real,
//! shipped design (checked directly, not assumed), including its
//! critical safety property: a `u64` that never actually came from a
//! real `as_ffi()` call is still safe to pass to `from_ffi` and every
//! `World` method — it can only ever produce *some* valid-shaped
//! `Entity`, and every real operation re-validates its generation
//! against the slot's current one regardless of where the value came
//! from. A bogus handle just reads back as not alive; it can never
//! alias a real, live entity it wasn't actually issued for.

use std::ffi::CStr;
use std::os::raw::c_char;
use std::panic::{catch_unwind, AssertUnwindSafe};
use std::any::TypeId;
use std::ptr;
use std::slice;

use crate::archetype::{ArchetypeId, ComponentFfiError, FfiSpanMut};
use crate::commands::CommandQueue;
use crate::component::ComponentId;
use crate::resource::{ResourceFfiError, ResourceId};
use crate::tick::Tick;
use crate::world::{Entity, World};
use mid_collections::FfiSpan;

/// Status codes. `is_alive` returns a plain `bool` (a pure query, not an
/// operation with distinct failure reasons) and `entity_count` returns
/// `usize` directly — everything else that can fail returns one of
/// these (`MidEcsStatus::Ok` is always `0`), matching `mid-net`'s own
/// `MidNetStatus` convention.
#[repr(i32)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MidEcsStatus {
    Ok = 0,
    NullPointer = -1,
    /// The entity wasn't alive — either never spawned through this
    /// `World`, already despawned, or a stale handle whose slot has
    /// since been reused by a different entity.
    NotAlive = -2,
    /// Something inside this crate panicked. Should never happen for
    /// well-formed input per each function's documented contract —
    /// exists so a caller gets a defined code instead of UB from an
    /// unwind crossing the FFI boundary.
    InternalPanic = -3,
    /// A `component_id`/`archetype_id` (or the `(archetype_id,
    /// component_id)` pair) doesn't resolve to real, currently-valid
    /// data — never registered via the matching Rust-side
    /// `register_ffi_*` call, or (for the Archetype Core pair) a
    /// structurally real archetype whose signature just doesn't
    /// include that component. Mirrors `World::component_raw_span`'s
    /// own `None` case at the Rust level — see that method's doc
    /// comment for the full reasoning.
    NotFound = -4,
    /// A non-null output buffer was too small for the real element
    /// count. Matches `mid-net`'s own `MidNetStatus::BufferTooSmall`
    /// convention exactly: pass a NULL buffer first to query the real
    /// count via this function's own return value, then call again
    /// with a buffer sized to hold at least that many elements.
    BufferTooSmall = -5,
    /// A write's byte length isn't exactly the size of the registered
    /// resource or component type. Nothing was written.
    SizeMismatch = -6,
    /// The component is registered for FFI, but read-only: only a type
    /// registered with `register_ffi_static_component_writable` (which
    /// requires `zerocopy::FromBytes`, so no byte pattern C writes can be
    /// an invalid value) can be written from C. Nothing was written or
    /// stamped.
    NotWritable = -7,
    /// An insert onto an entity that already has the component. Nothing
    /// was written: `World::insert_static` is a no-op there too, and this
    /// says so, because a caller who handed over bytes would otherwise
    /// assume they were stored. Use `mid_ecs_world_static_component_write`
    /// to overwrite.
    AlreadyPresent = -8,
    /// A list of components (a bundle insert or removal) names the same
    /// component twice. The whole list is rejected before any entity is
    /// looked at, and nothing changes.
    Duplicate = -9,
    /// `removed_since` for a component whose removals nobody asked to
    /// track (`mid_ecs_world_*_track_removals` was never called for it):
    /// nothing was ever recorded, so an empty list would be a silent
    /// lie. The Rust `World::removed_since` panics in the same case.
    NotTracked = -10,
    /// An argument combination that cannot mean anything: a filtered
    /// change query with no change term (nothing to read rows through).
    InvalidArgument = -11,
    /// A parent link that would make an entity its own ancestor.
    Cycle = -12,
}

fn ffi_guard(f: impl FnOnce() -> i32) -> i32 {
    catch_unwind(AssertUnwindSafe(f)).unwrap_or(MidEcsStatus::InternalPanic as i32)
}

/// Opaque handle to a `World`. Always heap-allocated by this crate;
/// every handle returned by `mid_ecs_world_new` must be freed with
/// `mid_ecs_world_free` exactly once.
pub struct MidEcsWorld(World);

impl MidEcsWorld {
    /// Wraps an already-built Rust `World` in a heap handle, the same
    /// allocation `mid_ecs_world_new` makes. `#[doc(hidden)]` and `pub`
    /// (not `pub(crate)`) for the same reason as every other hook of
    /// this kind in this crate: `benches/ffi_overhead.rs` is an external
    /// crate, and needs to populate a world through the typed Rust API
    /// before driving the very same world through the `extern "C"`
    /// functions below. Free the result with `mid_ecs_world_free`.
    #[doc(hidden)]
    pub fn from_world(world: World) -> *mut MidEcsWorld {
        Box::into_raw(Box::new(MidEcsWorld(world)))
    }

    /// The wrapped world, for the Rust-side half of an FFI-vs-Rust
    /// comparison. See [`Self::from_world`].
    #[doc(hidden)]
    pub fn world(&self) -> &World {
        &self.0
    }

    /// See [`Self::from_world`].
    #[doc(hidden)]
    pub fn world_mut(&mut self) -> &mut World {
        &mut self.0
    }
}

/// Creates a new, empty `World`. Never returns NULL — allocation failure
/// aborts the process the same way any other Rust `Box` allocation
/// failure would, not a documented error path here.
#[no_mangle]
pub extern "C" fn mid_ecs_world_new() -> *mut MidEcsWorld {
    Box::into_raw(Box::new(MidEcsWorld(World::new())))
}

/// Frees a handle returned by `mid_ecs_world_new`. NULL is a safe
/// no-op.
///
/// # Safety
/// `world` must either be NULL or a handle previously returned by
/// `mid_ecs_world_new` that hasn't been freed yet.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_free(world: *mut MidEcsWorld) {
    if world.is_null() {
        return;
    }
    drop(unsafe { Box::from_raw(world) });
}

/// Spawns a new, live entity, packed as a `u64` — see this module's doc
/// comment for the packing scheme. Returns `0` (index `0`, generation
/// `0`) on a null `world` or an internal panic — **not** a valid "empty"
/// sentinel to check against, since index/generation `0` could
/// theoretically also be a real packed value in a future allocator
/// state; check `world` for null yourself before calling if that
/// distinction matters to the caller.
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_spawn(world: *mut MidEcsWorld) -> u64 {
    if world.is_null() {
        return 0;
    }
    let result = catch_unwind(AssertUnwindSafe(|| {
        let world = unsafe { &mut *world };
        world.0.spawn().as_ffi()
    }));
    result.unwrap_or(0)
}

/// Despawns the entity packed in `entity`. Returns `MidEcsStatus::Ok` if
/// it was actually alive, `MidEcsStatus::NotAlive` otherwise (never
/// spawned, already despawned, or a stale handle) — both are safe,
/// defined outcomes, never a panic.
///
/// With the hierarchy enabled ([`mid_ecs_world_enable_hierarchy`], or any
/// of the parent/child functions below) this also despawns everything
/// below the entity.
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_despawn(world: *mut MidEcsWorld, entity: u64) -> i32 {
    ffi_guard(|| {
        if world.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let world = unsafe { &mut *world };
        if world.0.despawn(Entity::from_ffi(entity)) {
            MidEcsStatus::Ok as i32
        } else {
            MidEcsStatus::NotAlive as i32
        }
    })
}

/// Whether the entity packed in `entity` is currently alive. `false` on
/// a null `world` — matching `mid-net`'s own "null handle getters return
/// safe defaults, not crash" convention.
///
/// # Safety
/// `world` must either be NULL or a valid handle from
/// `mid_ecs_world_new`.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_is_alive(world: *const MidEcsWorld, entity: u64) -> bool {
    if world.is_null() {
        return false;
    }
    let result = catch_unwind(AssertUnwindSafe(|| {
        let world = unsafe { &*world };
        world.0.is_alive(Entity::from_ffi(entity))
    }));
    result.unwrap_or(false)
}

/// Turns on the entity hierarchy for `world`: from then on a parent link
/// keeps the parent's child list in step, and despawning a parent despawns
/// everything below it. Idempotent. The other parent/child functions call
/// it themselves, so it only matters when links are made some other way.
///
/// Returns `MidEcsStatus::Ok`, or `NullPointer`.
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_enable_hierarchy(world: *mut MidEcsWorld) -> i32 {
    ffi_guard(|| {
        if world.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        unsafe { &mut *world }.0.enable_hierarchy();
        MidEcsStatus::Ok as i32
    })
}

/// Makes `parent` the parent of `child`, last in its child list. A child
/// that already has a different parent is moved; one that already has this
/// parent is left where it is. Enables the hierarchy.
///
/// Returns `MidEcsStatus::Ok`, or `NullPointer`, `NotAlive` (either entity
/// is not alive), `InvalidArgument` (`child == parent`) or `Cycle` (`parent`
/// is `child` or one of its descendants). Nothing changes on an error.
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_set_parent(
    world: *mut MidEcsWorld,
    child: u64,
    parent: u64,
) -> i32 {
    ffi_guard(|| {
        if world.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let world = unsafe { &mut *world };
        match world.0.set_parent(Entity::from_ffi(child), Entity::from_ffi(parent)) {
            Ok(()) => MidEcsStatus::Ok as i32,
            Err(crate::hierarchy::HierarchyError::NotAlive(_)) => MidEcsStatus::NotAlive as i32,
            Err(crate::hierarchy::HierarchyError::SelfParent(_)) => MidEcsStatus::InvalidArgument as i32,
            Err(crate::hierarchy::HierarchyError::Cycle { .. }) => MidEcsStatus::Cycle as i32,
        }
    })
}

/// Detaches `child` from its parent, leaving it alive.
///
/// Returns `MidEcsStatus::Ok`, or `NullPointer`, `NotAlive` (`child` is not
/// alive) or `NotFound` (`child` has no parent).
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_remove_parent(world: *mut MidEcsWorld, child: u64) -> i32 {
    ffi_guard(|| {
        if world.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let world = unsafe { &mut *world };
        let child = Entity::from_ffi(child);
        if !world.0.is_alive(child) {
            return MidEcsStatus::NotAlive as i32;
        }
        if world.0.remove_parent(child) {
            MidEcsStatus::Ok as i32
        } else {
            MidEcsStatus::NotFound as i32
        }
    })
}

/// Writes the parent of `child`, packed as `uint64_t`, to `*out_parent`.
///
/// Returns `MidEcsStatus::Ok`, or `NullPointer` (null `world` or
/// `out_parent`), `NotAlive` (`child` is not alive) or `NotFound` (`child`
/// has no parent; `*out_parent` is left untouched).
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`, and
/// `out_parent` valid for one `uint64_t`.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_parent(
    world: *const MidEcsWorld,
    child: u64,
    out_parent: *mut u64,
) -> i32 {
    ffi_guard(|| {
        if world.is_null() || out_parent.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let world = unsafe { &*world };
        let child = Entity::from_ffi(child);
        if !world.0.is_alive(child) {
            return MidEcsStatus::NotAlive as i32;
        }
        match world.0.parent(child) {
            Some(parent) => {
                unsafe { *out_parent = parent.as_ffi() };
                MidEcsStatus::Ok as i32
            }
            None => MidEcsStatus::NotFound as i32,
        }
    })
}

/// Copies the children of `parent`, in order, into `out_buf` as
/// `uint64_t`. Same "NULL buffer queries the count" idiom as
/// [`mid_ecs_world_component_entity_ids`]: pass `out_buf = NULL` to learn
/// the count from the return value, then call again with room for at least
/// that many. `out_buf_capacity` counts **elements, not bytes**.
///
/// Returns the child count (`>= 0`), or a negative `MidEcsStatus`:
/// `NullPointer` (null `world`), `NotAlive` (`parent` is not alive) or
/// `BufferTooSmall` (non-null `out_buf` too small; nothing is written).
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`. If
/// `out_buf` is non-null it must be valid for `out_buf_capacity`
/// `uint64_t` elements.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_children(
    world: *const MidEcsWorld,
    parent: u64,
    out_buf: *mut u64,
    out_buf_capacity: usize,
) -> i32 {
    ffi_guard(|| {
        if world.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let world = unsafe { &*world };
        let parent = Entity::from_ffi(parent);
        if !world.0.is_alive(parent) {
            return MidEcsStatus::NotAlive as i32;
        }
        let children = world.0.children(parent);
        if out_buf.is_null() {
            return children.len() as i32;
        }
        if children.len() > out_buf_capacity {
            return MidEcsStatus::BufferTooSmall as i32;
        }
        let out = unsafe { slice::from_raw_parts_mut(out_buf, out_buf_capacity) };
        for (slot, child) in out.iter_mut().zip(children) {
            *slot = child.as_ffi();
        }
        children.len() as i32
    })
}

/// Detaches every child of `parent`, leaving them alive.
///
/// Returns how many children it detached (`>= 0`), or a negative
/// `MidEcsStatus`: `NullPointer` or `NotAlive` (`parent` is not alive).
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_clear_children(world: *mut MidEcsWorld, parent: u64) -> i32 {
    ffi_guard(|| {
        if world.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let world = unsafe { &mut *world };
        let parent = Entity::from_ffi(parent);
        if !world.0.is_alive(parent) {
            return MidEcsStatus::NotAlive as i32;
        }
        world.0.clear_children(parent) as i32
    })
}

/// Despawns everything below `parent` (children, their children, and so
/// on), keeping `parent` itself.
///
/// Returns how many entities it despawned (`>= 0`), or a negative
/// `MidEcsStatus`: `NullPointer` or `NotAlive` (`parent` is not alive).
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_despawn_children(world: *mut MidEcsWorld, parent: u64) -> i32 {
    ffi_guard(|| {
        if world.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let world = unsafe { &mut *world };
        let parent = Entity::from_ffi(parent);
        if !world.0.is_alive(parent) {
            return MidEcsStatus::NotAlive as i32;
        }
        world.0.despawn_children(parent) as i32
    })
}

/// Number of currently-live entities. `0` on a null `world`.
///
/// # Safety
/// `world` must either be NULL or a valid handle from
/// `mid_ecs_world_new`.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_entity_count(world: *const MidEcsWorld) -> usize {
    if world.is_null() {
        return 0;
    }
    let result = catch_unwind(AssertUnwindSafe(|| {
        let world = unsafe { &*world };
        world.0.entity_count()
    }));
    result.unwrap_or(0)
}

/// Opaque handle to a deferred-change queue ([`CommandQueue`]). Same
/// boxed-opaque-handle pattern as [`MidEcsWorld`].
///
/// Record spawns, despawns and component inserts and removals with the
/// `mid_ecs_commands_*` functions below, then run them against a world
/// with [`mid_ecs_commands_apply`]. Nothing touches the world until
/// `apply`. A queued insert
/// ([`mid_ecs_commands_static_component_insert`], or
/// [`mid_ecs_commands_static_component_insert_spawned`] for an entity a
/// queued spawn will produce) is a byte copy for a component registered
/// writable; a queued removal is
/// [`mid_ecs_commands_static_component_remove`]. See `docs/mid-ecs.md`,
/// "Inserting a component from C" and "Removing a component from C".
pub struct MidEcsCommands(CommandQueue);

/// Creates an empty command queue. Never returns NULL. Free it with
/// [`mid_ecs_commands_free`].
#[no_mangle]
pub extern "C" fn mid_ecs_commands_new() -> *mut MidEcsCommands {
    Box::into_raw(Box::new(MidEcsCommands(CommandQueue::new())))
}

/// Frees a queue. Anything still queued is dropped unapplied. Safe on
/// NULL.
///
/// # Safety
/// `commands` must be NULL or a handle from `mid_ecs_commands_new` not
/// already freed.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_commands_free(commands: *mut MidEcsCommands) {
    if commands.is_null() {
        return;
    }
    drop(unsafe { Box::from_raw(commands) });
}

/// Number of commands waiting. `0` on a null `commands`.
///
/// # Safety
/// `commands` must be NULL or a valid handle from
/// `mid_ecs_commands_new`.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_commands_len(commands: *const MidEcsCommands) -> usize {
    if commands.is_null() {
        return 0;
    }
    let result = catch_unwind(AssertUnwindSafe(|| unsafe { &*commands }.0.len()));
    result.unwrap_or(0)
}

/// Number of spawn commands waiting: how many entities the next
/// [`mid_ecs_commands_apply`] will return, so the size of the buffer to
/// give it. `0` on a null `commands`.
///
/// # Safety
/// `commands` must be NULL or a valid handle from
/// `mid_ecs_commands_new`.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_commands_spawn_count(commands: *const MidEcsCommands) -> usize {
    if commands.is_null() {
        return 0;
    }
    let result = catch_unwind(AssertUnwindSafe(|| unsafe { &*commands }.0.spawn_count()));
    result.unwrap_or(0)
}

/// Drops every waiting command without running it.
/// `MidEcsStatus::NullPointer` on a null `commands`, else `Ok`.
///
/// # Safety
/// `commands` must be NULL or a valid handle from
/// `mid_ecs_commands_new`.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_commands_clear(commands: *mut MidEcsCommands) -> i32 {
    ffi_guard(|| {
        if commands.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        unsafe { &mut *commands }.0.clear();
        MidEcsStatus::Ok as i32
    })
}

/// Queues a spawn. The entity does not exist until
/// [`mid_ecs_commands_apply`], which returns the spawned entities in the
/// order their spawns were queued. `MidEcsStatus::NullPointer` on a null
/// `commands`, else `Ok`.
///
/// # Safety
/// `commands` must be NULL or a valid handle from
/// `mid_ecs_commands_new`.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_commands_spawn(commands: *mut MidEcsCommands) -> i32 {
    ffi_guard(|| {
        if commands.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        unsafe { &mut *commands }.0.commands().spawn();
        MidEcsStatus::Ok as i32
    })
}

/// Queues a despawn of the entity packed in `entity`. Whether it is
/// alive is not checked now, only when the command runs: a dead, stale or
/// bogus value is then a safe no-op, exactly like
/// [`mid_ecs_world_despawn`] on one, and never touches a different
/// entity that has since reused the slot. `MidEcsStatus::NullPointer` on
/// a null `commands`, else `Ok`.
///
/// # Safety
/// `commands` must be NULL or a valid handle from
/// `mid_ecs_commands_new`.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_commands_despawn(
    commands: *mut MidEcsCommands,
    entity: u64,
) -> i32 {
    ffi_guard(|| {
        if commands.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        unsafe { &mut *commands }
            .0
            .commands()
            .despawn(Entity::from_ffi(entity));
        MidEcsStatus::Ok as i32
    })
}

/// What a queued insert can be checked for *now*: that `component_id` is
/// registered writable in `world` and `len` is its size. The queue itself
/// has no world, so this is the only way to hand a caller these errors at
/// the call that caused them rather than silently when the command runs.
fn check_queued_insert(
    world: &World,
    component_id: ComponentId,
    len: usize,
) -> Result<(), ComponentFfiError> {
    if len != world.static_component_write_size(component_id)? {
        return Err(ComponentFfiError::SizeMismatch);
    }
    Ok(())
}

/// Queues an insert of a `component_id` component, built from a *copy* of
/// `len` bytes at `bytes`, onto the existing entity packed in `entity`: the
/// queued form of [`mid_ecs_world_static_component_insert`], for a
/// component registered *writable*.
///
/// `world` is read only to check, now, that `component_id` is registered
/// writable and `len` is the registered size; it is not retained, and
/// nothing in it changes. Whether `entity` is alive is not checked now,
/// only when the command runs (as for [`mid_ecs_commands_despawn`]): a
/// dead or stale entity, an entity that already has the component (the
/// first value stays), or a world that does not know the component, makes
/// the command a no-op then, and it never reaches a different entity that
/// reused the slot.
///
/// Returns `MidEcsStatus::Ok` (queued), `NullPointer`, `NotFound`
/// (component id never registered for FFI), `NotWritable` or
/// `SizeMismatch`. Nothing is queued on an error.
///
/// # Safety
/// `commands` must be a valid handle from `mid_ecs_commands_new` and
/// `world` a valid handle from `mid_ecs_world_new`, both non-null.
/// `bytes` must be NULL only if `len` is 0, otherwise valid for reading
/// `len` bytes.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_commands_static_component_insert(
    commands: *mut MidEcsCommands,
    world: *const MidEcsWorld,
    entity: u64,
    component_id: u32,
    bytes: *const u8,
    len: usize,
) -> i32 {
    ffi_guard(|| {
        if commands.is_null() || world.is_null() || (bytes.is_null() && len > 0) {
            return MidEcsStatus::NullPointer as i32;
        }
        let commands = unsafe { &mut *commands };
        let world = unsafe { &*world };
        let component = ComponentId::from_u32(component_id);
        if let Err(error) = check_queued_insert(&world.0, component, len) {
            return component_status(error);
        }
        let bytes: &[u8] = if len == 0 {
            &[]
        } else {
            unsafe { slice::from_raw_parts(bytes, len) }
        };
        commands
            .0
            .commands()
            .entity(Entity::from_ffi(entity))
            .insert_static_bytes(component, bytes);
        MidEcsStatus::Ok as i32
    })
}

/// As [`mid_ecs_commands_static_component_insert`], onto the entity the
/// `spawn_index`th queued spawn will produce (counting from 0, in the
/// order [`mid_ecs_commands_spawn`] was called since the last apply or
/// clear; [`mid_ecs_commands_spawn_count`] is how many there are), so one
/// apply can create an entity *and* give it components. The inserts run
/// after that spawn, in the order they were queued.
///
/// Returns the same statuses, plus `NotFound` for a `spawn_index` that is
/// not below the number of spawns queued so far (checked after the
/// component checks). Nothing is queued on an error.
///
/// # Safety
/// As [`mid_ecs_commands_static_component_insert`].
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_commands_static_component_insert_spawned(
    commands: *mut MidEcsCommands,
    world: *const MidEcsWorld,
    spawn_index: usize,
    component_id: u32,
    bytes: *const u8,
    len: usize,
) -> i32 {
    ffi_guard(|| {
        if commands.is_null() || world.is_null() || (bytes.is_null() && len > 0) {
            return MidEcsStatus::NullPointer as i32;
        }
        let commands = unsafe { &mut *commands };
        let world = unsafe { &*world };
        let component = ComponentId::from_u32(component_id);
        if let Err(error) = check_queued_insert(&world.0, component, len) {
            return component_status(error);
        }
        let bytes: &[u8] = if len == 0 {
            &[]
        } else {
            unsafe { slice::from_raw_parts(bytes, len) }
        };
        let mut queue = commands.0.commands();
        match queue.queued_spawn(spawn_index) {
            Some(mut target) => {
                target.insert_static_bytes(component, bytes);
                MidEcsStatus::Ok as i32
            }
            None => MidEcsStatus::NotFound as i32,
        }
    })
}

/// Queues a removal of `component_id` from the existing entity packed in
/// `entity`: the queued form of [`mid_ecs_world_static_component_remove`],
/// for a component registered *writable*.
///
/// `world` is read only to check, now, that `component_id` is registered
/// writable; it is not retained and nothing in it changes. Whether `entity`
/// is alive, and still has the component, is checked when the command runs:
/// a dead or stale entity (which never reaches a different entity that
/// reused the slot), an entity without the component, or a world that does
/// not know it, makes the command a no-op then. There is no `_spawned`
/// form: a freshly spawned entity has nothing to remove until an insert
/// has run.
///
/// Returns `MidEcsStatus::Ok` (queued), `NullPointer`, `NotFound`
/// (component id never registered for FFI) or `NotWritable`. Nothing is
/// queued on an error.
///
/// # Safety
/// `commands` must be a valid handle from `mid_ecs_commands_new` and
/// `world` a valid handle from `mid_ecs_world_new`, both non-null.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_commands_static_component_remove(
    commands: *mut MidEcsCommands,
    world: *const MidEcsWorld,
    entity: u64,
    component_id: u32,
) -> i32 {
    ffi_guard(|| {
        if commands.is_null() || world.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let commands = unsafe { &mut *commands };
        let world = unsafe { &*world };
        let component = ComponentId::from_u32(component_id);
        if let Err(error) = world.0.static_component_write_size(component) {
            return component_status(error);
        }
        commands
            .0
            .commands()
            .entity(Entity::from_ffi(entity))
            .remove_static_by_id(component);
        MidEcsStatus::Ok as i32
    })
}

/// One entry of a bundle insert: a component id and the bytes of its value.
/// `len` must be exactly the registered type's size (the span's `stride`);
/// `bytes` may be NULL only if `len` is 0.
#[repr(C)]
#[derive(Debug, Clone, Copy)]
pub struct FfiComponentValue {
    /// The registered component id.
    pub component_id: u32,
    /// The value's bytes, copied.
    pub bytes: *const u8,
    /// Length of `bytes`.
    pub len: usize,
}

/// The `(component, bytes)` list behind a `values`/`count` pair, or the
/// `NullPointer` status if `values` is NULL with a non-zero count or any
/// entry has NULL `bytes` with a non-zero `len`.
///
/// # Safety
/// `values` must be valid for reading `count` entries, and every entry's
/// `bytes` valid for `len` bytes, for the returned lifetime.
unsafe fn values_from_c<'a>(
    values: *const FfiComponentValue,
    count: usize,
) -> Result<Vec<(ComponentId, &'a [u8])>, i32> {
    if count == 0 {
        return Ok(Vec::new());
    }
    if values.is_null() {
        return Err(MidEcsStatus::NullPointer as i32);
    }
    let values = unsafe { slice::from_raw_parts(values, count) };
    let mut entries = Vec::with_capacity(count);
    for value in values {
        if value.bytes.is_null() && value.len > 0 {
            return Err(MidEcsStatus::NullPointer as i32);
        }
        let bytes: &[u8] = if value.len == 0 {
            &[]
        } else {
            unsafe { slice::from_raw_parts(value.bytes, value.len) }
        };
        entries.push((ComponentId::from_u32(value.component_id), bytes));
    }
    Ok(entries)
}

/// The component ids behind an `ids`/`count` pair, or `NullPointer` if
/// `ids` is NULL with a non-zero count.
///
/// # Safety
/// `ids` must be valid for reading `count` entries.
unsafe fn ids_from_c(ids: *const u32, count: usize) -> Result<Vec<ComponentId>, i32> {
    if count == 0 {
        return Ok(Vec::new());
    }
    if ids.is_null() {
        return Err(MidEcsStatus::NullPointer as i32);
    }
    Ok(unsafe { slice::from_raw_parts(ids, count) }
        .iter()
        .map(|&id| ComponentId::from_u32(id))
        .collect())
}

/// What a queued bundle can be checked for *now*: every listed component
/// registered writable in `world`, each length its size, and no repeats.
fn check_queued_values(
    world: &World,
    entries: &[(ComponentId, &[u8])],
) -> Result<(), ComponentFfiError> {
    let list: Vec<(ComponentId, Option<usize>)> = entries
        .iter()
        .map(|(id, bytes)| (*id, Some(bytes.len())))
        .collect();
    world.check_static_component_list(&list)
}

/// Attaches `count` components to `entity` in *one* structural change: the
/// bundle form of [`mid_ecs_world_static_component_insert`] (Rust's
/// `insert_bundle`), so the entity migrates once, not once per component.
/// Each `values[i]` gives a component id and its value's bytes. Every new
/// value is stamped both *added* and *changed* at the current tick; the
/// entity's existing values and their stamps come across untouched.
///
/// **All or nothing.** The list is validated as a unit before anything
/// moves. Returns `MidEcsStatus::Ok`; `NullPointer` (`world` NULL,
/// `values` NULL with a non-zero `count`, or an entry with NULL `bytes` and
/// a non-zero `len`); `NotAlive`; then, for each entry in list order,
/// `NotFound` (never registered for FFI), `NotWritable` (registered
/// read-only) or `SizeMismatch`; then `Duplicate` (a component listed
/// twice); then `AlreadyPresent` (the entity already has *any* of them),
/// checked in that order. Nothing is inserted on an error. `count == 0` is
/// `Ok` and changes nothing.
///
/// A structural change: every span previously handed out for the entity's
/// old and new archetype is invalidated.
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`.
/// `values` must be valid for reading `count` entries (NULL only if
/// `count` is 0), each entry's `bytes` valid for `len` bytes.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_static_component_insert_many(
    world: *mut MidEcsWorld,
    entity: u64,
    values: *const FfiComponentValue,
    count: usize,
) -> i32 {
    ffi_guard(|| {
        if world.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let entries = match unsafe { values_from_c(values, count) } {
            Ok(entries) => entries,
            Err(status) => return status,
        };
        let world = unsafe { &mut *world };
        match world
            .0
            .insert_static_bytes_many(Entity::from_ffi(entity), &entries)
        {
            Ok(()) => MidEcsStatus::Ok as i32,
            Err(error) => component_status(error),
        }
    })
}

/// Detaches `count` components from `entity` in *one* structural change,
/// dropping their values: the bundle form of
/// [`mid_ecs_world_static_component_remove`] (Rust's `remove_bundle`). The
/// entity's other values and their stamps come across untouched; nothing is
/// stamped.
///
/// **All or nothing.** Returns `MidEcsStatus::Ok`; `NullPointer` (`world`
/// NULL, or `component_ids` NULL with a non-zero `count`); `NotAlive`; then,
/// for each id in list order, `NotFound` (never registered for FFI) or
/// `NotWritable`; then `Duplicate`; then `NotFound` again if the entity
/// lacks *any* of them. Nothing is removed on an error. `count == 0` is
/// `Ok` and changes nothing. A structural change, as for the single form.
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`.
/// `component_ids` must be valid for reading `count` entries (NULL only if
/// `count` is 0).
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_static_component_remove_many(
    world: *mut MidEcsWorld,
    entity: u64,
    component_ids: *const u32,
    count: usize,
) -> i32 {
    ffi_guard(|| {
        if world.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let ids = match unsafe { ids_from_c(component_ids, count) } {
            Ok(ids) => ids,
            Err(status) => return status,
        };
        let world = unsafe { &mut *world };
        match world.0.remove_static_by_ids(Entity::from_ffi(entity), &ids) {
            Ok(()) => MidEcsStatus::Ok as i32,
            Err(error) => component_status(error),
        }
    })
}

/// Queues a bundle insert onto the existing entity packed in `entity`: the
/// queued form of [`mid_ecs_world_static_component_insert_many`]. `world`
/// is read only to check, now, that every listed component is registered
/// writable, each length is its size, and none repeats (the list-level
/// checks of the direct form); it is not retained. Bytes are copied now.
/// Whether the entity is alive, and has none of the components yet, is
/// checked when the command runs, all or nothing: any miss makes the whole
/// command a no-op then.
///
/// Returns `MidEcsStatus::Ok` (queued), `NullPointer`, `NotFound`,
/// `NotWritable`, `SizeMismatch` or `Duplicate`. Nothing is queued on an
/// error, and `count == 0` is `Ok` and queues nothing.
///
/// # Safety
/// As [`mid_ecs_world_static_component_insert_many`], plus `commands` a
/// valid handle from `mid_ecs_commands_new` and `world` non-null.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_commands_static_component_insert_many(
    commands: *mut MidEcsCommands,
    world: *const MidEcsWorld,
    entity: u64,
    values: *const FfiComponentValue,
    count: usize,
) -> i32 {
    ffi_guard(|| {
        if commands.is_null() || world.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let entries = match unsafe { values_from_c(values, count) } {
            Ok(entries) => entries,
            Err(status) => return status,
        };
        let commands = unsafe { &mut *commands };
        let world = unsafe { &*world };
        if let Err(error) = check_queued_values(&world.0, &entries) {
            return component_status(error);
        }
        if !entries.is_empty() {
            commands
                .0
                .commands()
                .entity(Entity::from_ffi(entity))
                .insert_static_bytes_many(&entries);
        }
        MidEcsStatus::Ok as i32
    })
}

/// As [`mid_ecs_commands_static_component_insert_many`], onto the entity
/// the `spawn_index`th queued spawn will produce (see
/// [`mid_ecs_commands_static_component_insert_spawned`]): one apply can
/// create an entity and give it a whole bundle. Same statuses, plus
/// `NotFound` for a `spawn_index` not below the number of spawns queued so
/// far (checked after the list checks).
///
/// # Safety
/// As [`mid_ecs_commands_static_component_insert_many`].
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_commands_static_component_insert_many_spawned(
    commands: *mut MidEcsCommands,
    world: *const MidEcsWorld,
    spawn_index: usize,
    values: *const FfiComponentValue,
    count: usize,
) -> i32 {
    ffi_guard(|| {
        if commands.is_null() || world.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let entries = match unsafe { values_from_c(values, count) } {
            Ok(entries) => entries,
            Err(status) => return status,
        };
        let commands = unsafe { &mut *commands };
        let world = unsafe { &*world };
        if let Err(error) = check_queued_values(&world.0, &entries) {
            return component_status(error);
        }
        let mut queue = commands.0.commands();
        match queue.queued_spawn(spawn_index) {
            Some(mut target) => {
                if !entries.is_empty() {
                    target.insert_static_bytes_many(&entries);
                }
                MidEcsStatus::Ok as i32
            }
            None => MidEcsStatus::NotFound as i32,
        }
    })
}

/// Queues a bundle removal from the existing entity packed in `entity`:
/// the queued form of [`mid_ecs_world_static_component_remove_many`].
/// `world` is read only to check, now, that every id is registered writable
/// and none repeats; it is not retained. Whether the entity is alive and has
/// *all* of the components is checked when the command runs, all or
/// nothing: any miss makes the whole command a no-op then.
///
/// Returns `MidEcsStatus::Ok` (queued), `NullPointer`, `NotFound`,
/// `NotWritable` or `Duplicate`. Nothing is queued on an error, and
/// `count == 0` is `Ok` and queues nothing.
///
/// # Safety
/// `commands` must be a valid handle from `mid_ecs_commands_new` and `world`
/// a valid handle from `mid_ecs_world_new`, both non-null. `component_ids`
/// must be valid for reading `count` entries (NULL only if `count` is 0).
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_commands_static_component_remove_many(
    commands: *mut MidEcsCommands,
    world: *const MidEcsWorld,
    entity: u64,
    component_ids: *const u32,
    count: usize,
) -> i32 {
    ffi_guard(|| {
        if commands.is_null() || world.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let ids = match unsafe { ids_from_c(component_ids, count) } {
            Ok(ids) => ids,
            Err(status) => return status,
        };
        let commands = unsafe { &mut *commands };
        let world = unsafe { &*world };
        let list: Vec<(ComponentId, Option<usize>)> = ids.iter().map(|id| (*id, None)).collect();
        if let Err(error) = world.0.check_static_component_list(&list) {
            return component_status(error);
        }
        if !ids.is_empty() {
            commands
                .0
                .commands()
                .entity(Entity::from_ffi(entity))
                .remove_static_by_ids(&ids);
        }
        MidEcsStatus::Ok as i32
    })
}

/// Runs every queued command against `world`, in the order queued, and
/// leaves the queue empty and reusable. Writes the entities its spawns
/// produced, packed as `uint64_t`, into `out_entities` in spawn order.
///
/// `out_capacity` counts **elements, not bytes**. It must be at least
/// [`mid_ecs_commands_spawn_count`]. If it is not (or `out_entities` is
/// NULL while spawns are waiting) the result is
/// `MidEcsStatus::BufferTooSmall` and **nothing is applied**: the queue
/// and the world are exactly as they were, so call again with a bigger
/// buffer. This is the same "don't use a partial fill" shape as
/// [`mid_ecs_world_component_entity_ids`], except that here the call
/// cannot be repeated freely, so the size is checked before anything
/// runs. With no spawns waiting, `out_entities` may be NULL.
///
/// Returns the number of entities written (`>= 0`) on success, or a
/// negative `MidEcsStatus`: `NullPointer` (null `commands` or `world`) or
/// `BufferTooSmall`.
///
/// # Safety
/// `commands` and `world` must be valid, non-null handles from their
/// `_new` functions. If spawns are waiting, `out_entities` must be valid
/// for `out_capacity` `uint64_t` elements.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_commands_apply(
    commands: *mut MidEcsCommands,
    world: *mut MidEcsWorld,
    out_entities: *mut u64,
    out_capacity: usize,
) -> i32 {
    ffi_guard(|| {
        if commands.is_null() || world.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let commands = unsafe { &mut *commands };
        let world = unsafe { &mut *world };
        let needed = commands.0.spawn_count();
        if needed > 0 && (out_entities.is_null() || needed > out_capacity) {
            return MidEcsStatus::BufferTooSmall as i32;
        }
        let spawned = commands.0.apply(&mut world.0);
        if needed > 0 {
            let out = unsafe { slice::from_raw_parts_mut(out_entities, needed) };
            for (slot, entity) in out.iter_mut().zip(&spawned) {
                *slot = entity.as_ffi();
            }
        }
        spawned.len() as i32
    })
}

/// A fixed `#[repr(C)]` component type used only by
/// [`mid_ecs_test_fixture_world_new`] below — real code that's part of
/// the compiled library like everything else in this file (needed for
/// `ffi-smoke-test/test.c` to link against it), not `#[cfg(test)]`
/// Rust-only scaffolding. Kept distinct from this module's own
/// `#[cfg(test)]` `FfiHealth` (used by this file's *Rust*-level tests)
/// deliberately — that one only exists in `cargo test` builds, and
/// can't be what a separately-compiled C program links against.
///
/// Sparse Shell's own fixture type — see [`MidEcsTestHealthStatic`]
/// for why this isn't the *same* type shared across both storage
/// systems, the way an earlier version of this fixture actually did.
#[derive(zerocopy::IntoBytes, zerocopy::Immutable, zerocopy::KnownLayout)]
#[repr(C)]
pub struct MidEcsTestHealth {
    pub hp: u32,
}

/// The Archetype Core's own fixture type — deliberately a *distinct*
/// Rust type from [`MidEcsTestHealth`], even though both are
/// `{ hp: u32 }` and identical from C's side of the FFI boundary.
/// An earlier version of this fixture used the same Rust type for
/// both storage systems; `World`'s own `StorageClaims` guard (see
/// `world.rs`) correctly panicked on that — using one component type
/// with both storage systems is a real footgun it exists specifically
/// to catch, and the test fixture itself wasn't exempt from that just
/// because it's test-only code.
#[derive(zerocopy::FromBytes, zerocopy::IntoBytes, zerocopy::Immutable, zerocopy::KnownLayout)]
#[repr(C)]
pub struct MidEcsTestHealthStatic {
    pub hp: u32,
}

/// **Test-fixture only — not a real part of this library's intended
/// public API.** Exists for one specific, narrow reason: `register_ffi_component`/
/// `register_ffi_static_component`/`insert`/`insert_static` are all
/// generic over the Rust component type, so none of them can ever be
/// `extern "C"` — a real, permanent, unavoidable fact about what a C
/// ABI can express, not an oversight (see this module's own top-level
/// doc comment). That means a *pure* C program has no way to populate
/// any component data at all, which would otherwise leave
/// `ffi-smoke-test/test.c` unable to exercise the actual data
/// round-trip through the component-data functions below — only their
/// null-pointer and not-found paths, never real data through real
/// compiled C memory. This function does the necessary Rust-side setup
/// once, in Rust, and hands back an already-populated `World`:
/// registers [`MidEcsTestHealth`] with Sparse Shell (as `"FfiHealth"`)
/// and [`MidEcsTestHealthStatic`] with Archetype Core (as
/// `"FfiHealthStatic"`) — two distinct Rust types, not one shared
/// across both (see [`MidEcsTestHealthStatic`]'s own doc comment for
/// why), matching this file's own Rust-level test names, deliberately,
/// so the same fixture shape is verified from both directions. Spawns
/// two entities and inserts `{hp: 10}`/`{hp: 20}` (Sparse Shell) and
/// `{hp: 100}`/`{hp: 200}` (Archetype Core) on them respectively —
/// exactly the fixed values `test.c` asserts against. Never returns
/// NULL, matching `mid_ecs_world_new`'s own convention.
#[no_mangle]
pub extern "C" fn mid_ecs_test_fixture_world_new() -> *mut MidEcsWorld {
    let mut world = World::new();
    world.register_ffi_component::<MidEcsTestHealth>("FfiHealth");
    world.register_ffi_static_component::<MidEcsTestHealthStatic>("FfiHealthStatic");
    let e1 = world.spawn();
    let e2 = world.spawn();
    world.insert(e1, MidEcsTestHealth { hp: 10 });
    world.insert(e2, MidEcsTestHealth { hp: 20 });
    world.insert_static(e1, MidEcsTestHealthStatic { hp: 100 });
    world.insert_static(e2, MidEcsTestHealthStatic { hp: 200 });
    Box::into_raw(Box::new(MidEcsWorld(world)))
}

/// Extra Archetype Core fixture types, used only by
/// [`mid_ecs_test_filter_fixture_world_new`].
#[derive(zerocopy::IntoBytes, zerocopy::Immutable, zerocopy::KnownLayout)]
#[repr(C)]
pub struct MidEcsTestFlagA {
    pub v: u32,
}

/// See [`MidEcsTestFlagA`].
#[derive(zerocopy::FromBytes, zerocopy::IntoBytes, zerocopy::Immutable, zerocopy::KnownLayout)]
#[repr(C)]
pub struct MidEcsTestFlagB {
    pub v: u32,
}

/// **Test-fixture only, like [`mid_ecs_test_fixture_world_new`].**
/// Builds a world for exercising
/// [`mid_ecs_world_archetypes_matching_static`] from a pure C program:
/// `"FfiHealthStatic"`, `"FfiFlagA"` and `"FfiFlagB"` registered with the
/// Archetype Core, and three entities spread over distinct archetypes
/// (`hp` in parentheses):
///
/// - `e1`: `{Health}` (1)
/// - `e2`: `{Health, FlagA}` (2), built with `insert_bundle`
/// - `e3`: `{FlagB, Health, FlagA}` (3), built with `insert_bundle`
///
/// Building `e3` in that order deliberately leaves zero-row intermediate
/// archetypes `{FlagB}` and `{FlagB, Health}` behind, so every
/// enumeration a C caller runs also has to cope with archetypes that hold
/// the component in their signature but no rows. Never returns NULL.
#[no_mangle]
pub extern "C" fn mid_ecs_test_filter_fixture_world_new() -> *mut MidEcsWorld {
    let mut world = World::new();
    world.register_ffi_static_component::<MidEcsTestHealthStatic>("FfiHealthStatic");
    world.register_ffi_static_component::<MidEcsTestFlagA>("FfiFlagA");
    world.register_ffi_static_component::<MidEcsTestFlagB>("FfiFlagB");
    let e1 = world.spawn();
    let e2 = world.spawn();
    let e3 = world.spawn();
    world.insert_static(e1, MidEcsTestHealthStatic { hp: 1 });
    world.insert_bundle(
        e2,
        (MidEcsTestHealthStatic { hp: 2 }, MidEcsTestFlagA { v: 20 }),
    );
    world.insert_bundle(
        e3,
        (
            MidEcsTestFlagB { v: 300 },
            MidEcsTestHealthStatic { hp: 3 },
            MidEcsTestFlagA { v: 30 },
        ),
    );
    Box::into_raw(Box::new(MidEcsWorld(world)))
}

/// Resource fixture types, used only by
/// [`mid_ecs_test_resource_fixture_world_new`]. Resources must accept any
/// bit pattern (`FromBytes`), since C writes them as raw bytes.
#[derive(zerocopy::FromBytes, zerocopy::IntoBytes, zerocopy::Immutable, zerocopy::KnownLayout)]
#[repr(C)]
pub struct MidEcsTestTime {
    pub delta: f32,
    pub frame: u32,
}

/// See [`MidEcsTestTime`].
#[derive(zerocopy::FromBytes, zerocopy::IntoBytes, zerocopy::Immutable, zerocopy::KnownLayout)]
#[repr(C)]
pub struct MidEcsTestGravity {
    pub g: f32,
}

/// **Test-fixture only, like [`mid_ecs_test_fixture_world_new`].** A world
/// for exercising the resource functions from a pure C program (C cannot
/// call the generic `register_ffi_resource`/`insert_resource`):
/// `"FfiTime"` registered and inserted as `{ delta: 0.016, frame: 7 }`,
/// and `"FfiGravity"` registered but not inserted. Never returns NULL.
#[no_mangle]
pub extern "C" fn mid_ecs_test_resource_fixture_world_new() -> *mut MidEcsWorld {
    let mut world = World::new();
    world.register_ffi_resource::<MidEcsTestTime>("FfiTime");
    world.register_ffi_resource::<MidEcsTestGravity>("FfiGravity");
    world.insert_resource(MidEcsTestTime {
        delta: 0.016,
        frame: 7,
    });
    Box::into_raw(Box::new(MidEcsWorld(world)))
}

/// **Test-fixture only, like [`mid_ecs_test_fixture_world_new`].** A world
/// for exercising the change-detection functions
/// ([`mid_ecs_world_static_component_added_rows`] and friends) from a
/// pure C program: `"FfiHealthStatic"` registered with the Archetype
/// Core, and three entities `{Health}` with `hp` 1, 2, 3 (rows 0, 1, 2
/// of the one archetype holding them), all inserted at the world's
/// starting tick and then the tick advanced once, so a tracker at `0`
/// sees all three as added and changed and one that has just read the
/// tick sees none. See [`mid_ecs_test_change_fixture_mutate`] for the
/// scripted follow-up. Never returns NULL.
#[no_mangle]
pub extern "C" fn mid_ecs_test_change_fixture_world_new() -> *mut MidEcsWorld {
    let mut world = World::new();
    world.register_ffi_static_component::<MidEcsTestHealthStatic>("FfiHealthStatic");
    for hp in 1..=3u32 {
        let e = world.spawn();
        world.insert_static(e, MidEcsTestHealthStatic { hp });
    }
    world.increment_change_tick();
    Box::into_raw(Box::new(MidEcsWorld(world)))
}

/// **Test-fixture only.** The Rust-side "frame of game code" a C caller
/// cannot write itself (`get_static_mut` is generic): against a world
/// from [`mid_ecs_test_change_fixture_world_new`], mutates the entity
/// with `hp == 2` to `hp == 22` through `get_static_mut` (marking it
/// changed, not added) and inserts a new `{Health}` entity with
/// `hp == 4`, both at the world's *current* tick. Does not advance the
/// tick itself: the C caller does that with
/// [`mid_ecs_world_increment_change_tick`] first, which is what makes a
/// tracker taken before it see exactly these two rows. Returns
/// `MidEcsStatus::NotFound` if no entity has `hp == 2` (the world isn't
/// that fixture, or this already ran).
///
/// # Safety
/// `world` must be a valid, non-null handle from
/// [`mid_ecs_test_change_fixture_world_new`].
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_test_change_fixture_mutate(world: *mut MidEcsWorld) -> i32 {
    ffi_guard(|| {
        if world.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let world = unsafe { &mut *world };
        let target = world
            .0
            .query_static::<MidEcsTestHealthStatic>()
            .find(|(_, health)| health.hp == 2)
            .map(|(entity, _)| entity);
        let Some(target) = target else {
            return MidEcsStatus::NotFound as i32;
        };
        if let Some(health) = world.0.get_static_mut::<MidEcsTestHealthStatic>(target) {
            health.hp = 22;
        }
        let fresh = world.0.spawn();
        world
            .0
            .insert_static(fresh, MidEcsTestHealthStatic { hp: 4 });
        MidEcsStatus::Ok as i32
    })
}

/// **Test-fixture only, like [`mid_ecs_test_fixture_world_new`].** A world
/// for exercising writing component data from a pure C program (C cannot
/// call the generic `register_ffi_static_component_writable`):
/// `"FfiHealthStatic"` registered *writable*, `"FfiFlagA"` registered
/// *read-only*, and `"FfiFlagB"` registered writable but held by no
/// entity. Three entities, spawned in this order: `{Health 1}`,
/// `{Health 2, FlagA 20}`, `{Health 3}`. So two archetypes hold `Health`:
/// `{Health}` (the first and third entity, 2 rows) and `{Health, FlagA}`
/// (the second, 1 row). The change tick is advanced once after building,
/// so a tracker that has just read the tick sees nothing changed. Never
/// returns NULL.
#[no_mangle]
pub extern "C" fn mid_ecs_test_write_fixture_world_new() -> *mut MidEcsWorld {
    let mut world = World::new();
    world.register_ffi_static_component_writable::<MidEcsTestHealthStatic>("FfiHealthStatic");
    world.register_ffi_static_component::<MidEcsTestFlagA>("FfiFlagA");
    world.register_ffi_static_component_writable::<MidEcsTestFlagB>("FfiFlagB");
    let first = world.spawn();
    world.insert_static(first, MidEcsTestHealthStatic { hp: 1 });
    let second = world.spawn();
    world.insert_static(second, MidEcsTestHealthStatic { hp: 2 });
    world.insert_static(second, MidEcsTestFlagA { v: 20 });
    let third = world.spawn();
    world.insert_static(third, MidEcsTestHealthStatic { hp: 3 });
    world.increment_change_tick();
    Box::into_raw(Box::new(MidEcsWorld(world)))
}

/// A sentinel `component_id`/`archetype_id` value meaning "not found" —
/// returned by the `lookup_ffi_*` functions below on a null pointer,
/// invalid UTF-8, or a name that was never registered. Not `0`: `0` is
/// a real, valid id for whichever type happened to be registered
/// first, so it can't double as a not-found signal. Matches
/// `mid_collections::sparse_set`'s own `u32::MAX`-as-sentinel
/// precedent (real code in this workspace, not invented for this
/// function) — reaching the actual 4-billionth distinct registered
/// component type is not a real scenario this needs to guard against.
pub const MID_ECS_INVALID_ID: u32 = u32::MAX;

/// Looks up the Sparse-Shell `component_id` a Rust type was registered
/// under via `World::register_ffi_component`, by the name given then.
/// Returns [`MID_ECS_INVALID_ID`] on a null `world`/`name`, invalid
/// UTF-8, an internal panic, or a name that was never registered — a C
/// caller can't distinguish those four cases from the return value
/// alone, matching `mid_net_player_event_new`'s own "collapse distinct
/// failure reasons to one sentinel for a getter-shaped function"
/// precedent (a status-code return doesn't fit a function whose whole
/// job is returning one value).
///
/// # Safety
/// `world` must either be NULL or a valid handle from
/// `mid_ecs_world_new`. If non-null, `name` must be a valid,
/// null-terminated C string.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_lookup_ffi_component_id(
    world: *const MidEcsWorld,
    name: *const c_char,
) -> u32 {
    if world.is_null() || name.is_null() {
        return MID_ECS_INVALID_ID;
    }
    let result = catch_unwind(AssertUnwindSafe(|| {
        let world = unsafe { &*world };
        let name = unsafe { CStr::from_ptr(name) }.to_str().ok()?;
        world.0.lookup_ffi_component_id(name)
    }));
    match result {
        Ok(Some(id)) => id.as_u32(),
        _ => MID_ECS_INVALID_ID,
    }
}

/// Non-generic, `component_id`-keyed raw span over every currently-
/// attached instance of a Sparse-Shell component type, written into
/// `*out_span` — thin FFI wrapper over `World::component_raw_span`.
/// Returns `MidEcsStatus::Ok` (`*out_span` written) or
/// `MidEcsStatus::NotFound` (`component_id` doesn't exist or was never
/// opted into FFI exposure) — never `MidEcsStatus::NotAlive`, this
/// isn't an entity-liveness operation.
///
/// `out_span`'s `ptr` is a live, zero-copy view into `world`'s own
/// storage — see `mid_collections::FfiSpan`'s own doc comment for the
/// exact invalidation contract: valid only until the next
/// `mid_ecs_world_*` call that mutates *this exact* component type on
/// this `world`.
///
/// # Safety
/// `world` and `out_span` must both be non-null; `world` a valid
/// handle from `mid_ecs_world_new`, `out_span` valid for one
/// `FfiSpan` write.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_component_raw_span(
    world: *const MidEcsWorld,
    component_id: u32,
    out_span: *mut FfiSpan,
) -> i32 {
    ffi_guard(|| {
        if world.is_null() || out_span.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let world = unsafe { &*world };
        match world
            .0
            .component_raw_span(ComponentId::from_u32(component_id))
        {
            Some(span) => {
                unsafe { ptr::write(out_span, span) };
                MidEcsStatus::Ok as i32
            }
            None => MidEcsStatus::NotFound as i32,
        }
    })
}

/// Entity-correlation counterpart to
/// [`mid_ecs_world_component_raw_span`]: `entity_ids[i]` (the packed
/// `u64` written to `out_buf[i]`, unpack with `Entity::from_ffi` on the
/// Rust side) is the entity that owns that same raw-span call's element
/// `i`, for every valid `i`.
///
/// Same "NULL buffer queries the required count" idiom as
/// `mid_net_player_state_encode`: pass `out_buf = NULL` to learn the
/// real element count from the return value alone, without writing
/// anything, then call again with a buffer sized to hold at least that
/// many `uint64_t`s. `out_buf_capacity` counts **elements, not
/// bytes** — unlike `mid-net`'s own byte-oriented buffers, since this
/// one is always exactly `uint64_t`-strided.
///
/// Returns the real element count (`>= 0`) on success (whether querying
/// or actually filling `out_buf`), or a negative `MidEcsStatus`:
/// `NullPointer` (null `world`), `NotFound` (`component_id` never
/// registered), or `BufferTooSmall` (non-null `out_buf` too small for
/// the real count — call again after querying, don't try to use a
/// partial fill).
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`.
/// If `out_buf` is non-null, it must be valid for `out_buf_capacity`
/// `uint64_t` elements.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_component_entity_ids(
    world: *const MidEcsWorld,
    component_id: u32,
    out_buf: *mut u64,
    out_buf_capacity: usize,
) -> i32 {
    ffi_guard(|| {
        if world.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let world = unsafe { &*world };
        let Some(ids) = world
            .0
            .component_entity_ids(ComponentId::from_u32(component_id))
        else {
            return MidEcsStatus::NotFound as i32;
        };
        if out_buf.is_null() {
            return ids.len() as i32;
        }
        if ids.len() > out_buf_capacity {
            return MidEcsStatus::BufferTooSmall as i32;
        }
        let out = unsafe { slice::from_raw_parts_mut(out_buf, out_buf_capacity) };
        out[..ids.len()].copy_from_slice(&ids);
        ids.len() as i32
    })
}

/// Looks up the Archetype-Core `component_id` a Rust type was
/// registered under via `World::register_ffi_static_component`, by
/// name. Same [`MID_ECS_INVALID_ID`] sentinel and collapsed-failure
/// shape as [`mid_ecs_world_lookup_ffi_component_id`] — see that
/// function's own doc comment. A **separate id namespace** from the
/// Sparse-Shell lookup above: the same `name` can resolve to a
/// different numeric id in each system, matching
/// `Archetypes`/`SparseShell`'s own already-independent `ComponentId`
/// registries at the Rust level.
///
/// # Safety
/// `world` must either be NULL or a valid handle from
/// `mid_ecs_world_new`. If non-null, `name` must be a valid,
/// null-terminated C string.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_lookup_ffi_static_component_id(
    world: *const MidEcsWorld,
    name: *const c_char,
) -> u32 {
    if world.is_null() || name.is_null() {
        return MID_ECS_INVALID_ID;
    }
    let result = catch_unwind(AssertUnwindSafe(|| {
        let world = unsafe { &*world };
        let name = unsafe { CStr::from_ptr(name) }.to_str().ok()?;
        world.0.lookup_ffi_static_component_id(name)
    }));
    match result {
        Ok(Some(id)) => id.as_u32(),
        _ => MID_ECS_INVALID_ID,
    }
}

/// Non-generic, per-archetype raw span over `component_id`'s column
/// within `archetype_id`'s table, written into `*out_span` — thin FFI
/// wrapper over `World::static_component_raw_span`. Returns
/// `MidEcsStatus::NotFound` if `component_id` was never registered,
/// `archetype_id` doesn't currently exist, or (a real, permanent
/// structural fact, not a transient one) `archetype_id`'s signature
/// simply doesn't include `component_id` — see that Rust method's own
/// doc comment for the full reasoning, including why an
/// empty-but-present column is `Ok` with `count == 0`, not
/// `NotFound`. Pair with
/// [`mid_ecs_world_archetypes_with_static_component`] to enumerate
/// every archetype currently containing a given component.
///
/// Same live, zero-copy `out_span` invalidation contract as
/// [`mid_ecs_world_component_raw_span`].
///
/// # Safety
/// `world` and `out_span` must both be non-null; `world` a valid
/// handle from `mid_ecs_world_new`, `out_span` valid for one
/// `FfiSpan` write.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_static_component_raw_span(
    world: *const MidEcsWorld,
    archetype_id: u32,
    component_id: u32,
    out_span: *mut FfiSpan,
) -> i32 {
    ffi_guard(|| {
        if world.is_null() || out_span.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let world = unsafe { &*world };
        match world.0.static_component_raw_span(
            ArchetypeId::from_u32(archetype_id),
            ComponentId::from_u32(component_id),
        ) {
            Some(span) => {
                unsafe { ptr::write(out_span, span) };
                MidEcsStatus::Ok as i32
            }
            None => MidEcsStatus::NotFound as i32,
        }
    })
}

/// Entity-correlation counterpart to
/// [`mid_ecs_world_static_component_raw_span`], for the same
/// `(archetype_id, component_id)` pair. Same NULL-buffer-queries-count
/// idiom, same element-count (not byte-count) `out_buf_capacity`, same
/// return-value shape as [`mid_ecs_world_component_entity_ids`] — see
/// that function's own doc comment.
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`.
/// If `out_buf` is non-null, it must be valid for `out_buf_capacity`
/// `uint64_t` elements.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_static_component_entity_ids(
    world: *const MidEcsWorld,
    archetype_id: u32,
    component_id: u32,
    out_buf: *mut u64,
    out_buf_capacity: usize,
) -> i32 {
    ffi_guard(|| {
        if world.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let world = unsafe { &*world };
        let Some(ids) = world.0.static_component_entity_ids(
            ArchetypeId::from_u32(archetype_id),
            ComponentId::from_u32(component_id),
        ) else {
            return MidEcsStatus::NotFound as i32;
        };
        if out_buf.is_null() {
            return ids.len() as i32;
        }
        if ids.len() > out_buf_capacity {
            return MidEcsStatus::BufferTooSmall as i32;
        }
        let out = unsafe { slice::from_raw_parts_mut(out_buf, out_buf_capacity) };
        out[..ids.len()].copy_from_slice(&ids);
        ids.len() as i32
    })
}

/// Enumerates every currently-existing archetype whose signature
/// includes `component_id`, writing each as a plain `u32` (unpack with
/// `mid_ecs_archetype_id_from_u32`-shaped logic on the Rust side, or
/// just pass it straight back into
/// [`mid_ecs_world_static_component_raw_span`]/
/// [`mid_ecs_world_static_component_entity_ids`] as-is — that's the
/// whole point of this function). Same NULL-buffer-queries-count idiom
/// as [`mid_ecs_world_component_entity_ids`]. **Not gated by FFI
/// registration** — matches `Archetypes::archetypes_with`'s own
/// Rust-level behavior exactly (a pure structural query; an
/// unregistered `component_id` just naturally matches zero archetypes,
/// not an error), so this never returns `MidEcsStatus::NotFound`,
/// only `NullPointer`/`BufferTooSmall`/`InternalPanic`.
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`.
/// If `out_buf` is non-null, it must be valid for `out_buf_capacity`
/// `uint32_t` elements.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_archetypes_with_static_component(
    world: *const MidEcsWorld,
    component_id: u32,
    out_buf: *mut u32,
    out_buf_capacity: usize,
) -> i32 {
    ffi_guard(|| {
        if world.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let world = unsafe { &*world };
        let ids: Vec<u32> = world
            .0
            .archetypes_with_static_component(ComponentId::from_u32(component_id))
            .map(|id| id.as_u32())
            .collect();
        if out_buf.is_null() {
            return ids.len() as i32;
        }
        if ids.len() > out_buf_capacity {
            return MidEcsStatus::BufferTooSmall as i32;
        }
        let out = unsafe { slice::from_raw_parts_mut(out_buf, out_buf_capacity) };
        out[..ids.len()].copy_from_slice(&ids);
        ids.len() as i32
    })
}

/// Enumerates every currently-existing archetype whose signature
/// contains *all* of `with_ids`, *none* of `without_ids`, and — if
/// `any_of_ids` is non-empty — *at least one* of `any_of_ids`, writing
/// each as a plain `u32` — the runtime counterpart to the typed
/// `With`/`Without`/`Or` query filters on the Rust side. Pass the ids
/// back into [`mid_ecs_world_static_component_raw_span`]/
/// [`mid_ecs_world_static_component_entity_ids`] as-is. Include the
/// component you intend to read in `with_ids`: an archetype that doesn't
/// hold it answers those two calls with `NotFound`.
///
/// Structural, like [`mid_ecs_world_archetypes_with_static_component`]:
/// archetypes with zero rows are included (their spans come back `Ok`
/// with `count == 0`), an id that names no registered component matches
/// nothing in `with_ids`/`any_of_ids` and is ignored in `without_ids`, an
/// id in both `with_ids` and `without_ids` matches nothing, and
/// `with_ids`/`without_ids` both empty with `any_of_ids` also empty
/// matches every archetype. An empty `any_of_ids` is "no `Or`
/// constraint", not "match nothing" — pass a zero length (the pointer
/// may then be NULL or dangling) when there's no `any_of` list. Never
/// returns `NotFound`. Same NULL-buffer-queries-count idiom as the other
/// enumerations.
///
/// **Signature change:** this function gained `any_of_ids`/`any_of_len`
/// (inserted before `out_buf`) when `Or` was added on the Rust side —
/// every existing call site needs those two arguments now, `NULL, 0` if
/// unused. See `docs/mid-ecs.md`, "filter.rs" (the `Or` section), for
/// why this signature was changed rather than adding a second function.
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`.
/// `with_ids` must be NULL only if `with_len` is 0, otherwise valid for
/// `with_len` `uint32_t` elements; likewise `without_ids`/`without_len`
/// and `any_of_ids`/`any_of_len`. If `out_buf` is non-null, it must be
/// valid for `out_buf_capacity` `uint32_t` elements.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_archetypes_matching_static(
    world: *const MidEcsWorld,
    with_ids: *const u32,
    with_len: usize,
    without_ids: *const u32,
    without_len: usize,
    any_of_ids: *const u32,
    any_of_len: usize,
    out_buf: *mut u32,
    out_buf_capacity: usize,
) -> i32 {
    ffi_guard(|| {
        if world.is_null()
            || (with_ids.is_null() && with_len > 0)
            || (without_ids.is_null() && without_len > 0)
            || (any_of_ids.is_null() && any_of_len > 0)
        {
            return MidEcsStatus::NullPointer as i32;
        }
        let world = unsafe { &*world };
        let read_ids = |ptr: *const u32, len: usize| -> Vec<ComponentId> {
            if len == 0 {
                return Vec::new();
            }
            unsafe { slice::from_raw_parts(ptr, len) }
                .iter()
                .map(|&id| ComponentId::from_u32(id))
                .collect()
        };
        let with = read_ids(with_ids, with_len);
        let without = read_ids(without_ids, without_len);
        let any_of = read_ids(any_of_ids, any_of_len);
        let ids: Vec<u32> = world
            .0
            .archetypes_matching_static(&with, &without, &any_of)
            .map(|id| id.as_u32())
            .collect();
        if out_buf.is_null() {
            return ids.len() as i32;
        }
        if ids.len() > out_buf_capacity {
            return MidEcsStatus::BufferTooSmall as i32;
        }
        let out = unsafe { slice::from_raw_parts_mut(out_buf, ids.len()) };
        out.copy_from_slice(&ids);
        ids.len() as i32
    })
}

/// The world's current change tick, for use as a tracker: hold a plain
/// `uint32_t last_run` starting at `0` (a fresh tracker sees everything
/// present), pass it to the `*_rows` functions below, and once you've
/// used their results set it to this function's return value. `0` on a
/// null `world` (a real world's tick starts at `1` and only ever
/// advances, so `0` is never a real reading short of a full `u32`
/// wrap).
///
/// # Safety
/// `world` must either be NULL or a valid handle from
/// `mid_ecs_world_new`.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_change_tick(world: *const MidEcsWorld) -> u32 {
    if world.is_null() {
        return 0;
    }
    let result = catch_unwind(AssertUnwindSafe(|| {
        let world = unsafe { &*world };
        world.0.change_tick().get()
    }));
    result.unwrap_or(0)
}

/// Advances the world's change tick by one and returns the new value.
/// Call once per step of the caller's own game loop, between the step's
/// mutations and the `*_rows` check that should see them: a value
/// touched in the same tick a tracker was last set to is not reported
/// (see `tick.rs`). `0` on a null `world`.
///
/// # Safety
/// `world` must either be NULL or a valid handle from
/// `mid_ecs_world_new`.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_increment_change_tick(world: *mut MidEcsWorld) -> u32 {
    if world.is_null() {
        return 0;
    }
    let result = catch_unwind(AssertUnwindSafe(|| {
        let world = unsafe { &mut *world };
        world.0.increment_change_tick().get()
    }));
    result.unwrap_or(0)
}

/// Shared body of [`mid_ecs_world_static_component_added_rows`] and
/// [`mid_ecs_world_static_component_changed_rows`].
///
/// # Safety
/// As those two functions.
unsafe fn static_component_change_rows(
    world: *const MidEcsWorld,
    archetype_id: u32,
    component_id: u32,
    last_run: u32,
    added_only: bool,
    out_rows: *mut u32,
    out_capacity: usize,
) -> i32 {
    ffi_guard(|| {
        if world.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let world = unsafe { &*world };
        let archetype = ArchetypeId::from_u32(archetype_id);
        let component = ComponentId::from_u32(component_id);
        let last_run = Tick::new(last_run);
        let rows = if added_only {
            world
                .0
                .static_component_added_rows(archetype, component, last_run)
        } else {
            world
                .0
                .static_component_changed_rows(archetype, component, last_run)
        };
        let Some(rows) = rows else {
            return MidEcsStatus::NotFound as i32;
        };
        if out_rows.is_null() {
            return rows.len() as i32;
        }
        if rows.len() > out_capacity {
            return MidEcsStatus::BufferTooSmall as i32;
        }
        let out = unsafe { slice::from_raw_parts_mut(out_rows, rows.len()) };
        out.copy_from_slice(&rows);
        rows.len() as i32
    })
}

/// The rows of one `(archetype_id, component_id)` pair whose value was
/// inserted after `last_run` (the C counterpart of Rust's
/// `World::query_added`), as ascending `uint32_t` row indices written
/// into `out_rows`. Row `i` is element `i` of
/// [`mid_ecs_world_static_component_raw_span`] and
/// [`mid_ecs_world_static_component_entity_ids`] for the same pair, so
/// the row list picks the added elements out of the span it was built
/// against. Walk archetypes with
/// [`mid_ecs_world_archetypes_matching_static`] and call this per
/// archetype. Only the Archetype Core tracks ticks; there is no
/// Sparse-Shell counterpart.
///
/// Same NULL-buffer-queries-count idiom as the other enumerations: a
/// NULL `out_rows` returns the row count, a too-small buffer returns
/// `MidEcsStatus::BufferTooSmall` and writes nothing. `NotFound` under
/// exactly the conditions [`mid_ecs_world_static_component_raw_span`]
/// returns it (component never registered for FFI, unknown archetype,
/// or an archetype whose signature lacks the component); an archetype
/// holding no rows is `0`, not an error.
///
/// Row indices are valid against the span only until the next call that
/// changes this component's storage, the same contract as the span.
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`.
/// If `out_rows` is non-null, it must be valid for `out_capacity`
/// `uint32_t` elements.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_static_component_added_rows(
    world: *const MidEcsWorld,
    archetype_id: u32,
    component_id: u32,
    last_run: u32,
    out_rows: *mut u32,
    out_capacity: usize,
) -> i32 {
    unsafe {
        static_component_change_rows(
            world,
            archetype_id,
            component_id,
            last_run,
            true,
            out_rows,
            out_capacity,
        )
    }
}

/// As [`mid_ecs_world_static_component_added_rows`], for rows whose
/// value was inserted *or* last mutated through Rust's
/// `World::get_static_mut` after `last_run` (the C counterpart of
/// `World::query_changed`). It reports changes made by the Rust side of a
/// mixed-language program and by C itself, through
/// [`mid_ecs_world_static_component_raw_span_mut`] and
/// [`mid_ecs_world_static_component_write`].
///
/// # Safety
/// As [`mid_ecs_world_static_component_added_rows`].
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_static_component_changed_rows(
    world: *const MidEcsWorld,
    archetype_id: u32,
    component_id: u32,
    last_run: u32,
    out_rows: *mut u32,
    out_capacity: usize,
) -> i32 {
    unsafe {
        static_component_change_rows(
            world,
            archetype_id,
            component_id,
            last_run,
            false,
            out_rows,
            out_capacity,
        )
    }
}

// ── Filtered change queries ──────────────────────────────────────────
//
// The C counterpart of Rust's `query_data_filtered_since` with
// `Added`/`Changed` filters composed with `With`/`Without`/`Or` (see
// `data_filter.rs`). It is not a new query engine: it asks the existing
// per-archetype row functions (`static_component_added_rows` /
// `static_component_changed_rows`, the ones behind
// `mid_ecs_world_static_component_added_rows` / `_changed_rows`) and
// combines their ascending row lists, so a row means exactly what it
// means there.

/// The filter of [`mid_ecs_world_static_query_since`]: seven `(pointer,
/// length)` lists of Archetype-Core component ids. A list of length `0`
/// is empty (its pointer may then be NULL); a NULL pointer with a nonzero
/// length is a `NullPointer` error.
///
/// Structural, the same three lists as
/// [`mid_ecs_world_archetypes_matching_static`] (archetype-level, decided
/// once per archetype): `with` (all present), `without` (none present),
/// `any_of` (at least one present, when non-empty).
///
/// Row-level, at least one id in total across these four lists:
/// - `all_added`: the row's value of *every* listed component was inserted
///   after `last_run` (Rust: a tuple of `Added<T>`).
/// - `all_changed`: every listed component's value was inserted or
///   mutated after `last_run` (a tuple of `Changed<T>`).
/// - `any_added` and `any_changed`, together: *at least one* listed
///   component qualifies (Rust: `Or<(Added<A>, Changed<B>, ...)>`). A
///   member whose component the archetype lacks counts as not qualifying;
///   an archetype holding none of the listed components has no matching
///   row.
///
/// A row must satisfy the structural lists, every `all_*` id, and, if
/// either `any_*` list is non-empty, at least one `any_*` id.
#[repr(C)]
#[derive(Clone, Copy)]
pub struct MidEcsRowFilter {
    pub with_ids: *const u32,
    pub with_len: usize,
    pub without_ids: *const u32,
    pub without_len: usize,
    pub any_of_ids: *const u32,
    pub any_of_len: usize,
    pub all_added_ids: *const u32,
    pub all_added_len: usize,
    pub all_changed_ids: *const u32,
    pub all_changed_len: usize,
    pub any_added_ids: *const u32,
    pub any_added_len: usize,
    pub any_changed_ids: *const u32,
    pub any_changed_len: usize,
}

/// One row found by [`mid_ecs_world_static_query_since`]: the entity, and
/// where it sits. `row` is element `row` of
/// [`mid_ecs_world_static_component_raw_span`] and
/// [`mid_ecs_world_static_component_entity_ids`] for `archetype_id` and any
/// component that archetype holds.
#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct MidEcsMatchedRow {
    pub entity: u64,
    pub archetype_id: u32,
    pub row: u32,
}

/// Reads one `(pointer, length)` id list out of a C filter: `None` for a
/// NULL pointer with a nonzero length.
///
/// # Safety
/// A non-null `ptr` must be valid for `len` `u32` elements.
unsafe fn filter_ids(ptr: *const u32, len: usize) -> Option<Vec<ComponentId>> {
    if len == 0 {
        return Some(Vec::new());
    }
    if ptr.is_null() {
        return None;
    }
    Some(
        unsafe { slice::from_raw_parts(ptr, len) }
            .iter()
            .map(|&id| ComponentId::from_u32(id))
            .collect(),
    )
}

/// The intersection of two strictly ascending row lists.
fn rows_intersect(a: &[u32], b: &[u32]) -> Vec<u32> {
    let (mut i, mut j) = (0, 0);
    let mut out = Vec::new();
    while i < a.len() && j < b.len() {
        match a[i].cmp(&b[j]) {
            std::cmp::Ordering::Less => i += 1,
            std::cmp::Ordering::Greater => j += 1,
            std::cmp::Ordering::Equal => {
                out.push(a[i]);
                i += 1;
                j += 1;
            }
        }
    }
    out
}

/// The union of two strictly ascending row lists.
fn rows_union(a: &[u32], b: &[u32]) -> Vec<u32> {
    let (mut i, mut j) = (0, 0);
    let mut out = Vec::with_capacity(a.len() + b.len());
    while i < a.len() && j < b.len() {
        match a[i].cmp(&b[j]) {
            std::cmp::Ordering::Less => {
                out.push(a[i]);
                i += 1;
            }
            std::cmp::Ordering::Greater => {
                out.push(b[j]);
                j += 1;
            }
            std::cmp::Ordering::Equal => {
                out.push(a[i]);
                i += 1;
                j += 1;
            }
        }
    }
    out.extend_from_slice(&a[i..]);
    out.extend_from_slice(&b[j..]);
    out
}

/// Narrows `rows` to its intersection with `found` (`None` is "no
/// constraint yet": `found` becomes the list).
fn narrow_rows(rows: &mut Option<Vec<u32>>, found: Vec<u32>) {
    *rows = Some(match rows.take() {
        None => found,
        Some(current) => rows_intersect(&current, &found),
    });
}

/// The row-level part of a filter, for one archetype: the component to
/// read entity ids through, and the surviving rows (possibly none). `None`
/// if the archetype lacks an `all_*` component, or holds none of the listed
/// components at all (so there is nothing to read rows or entities through).
fn matched_rows_in(
    world: &World,
    archetype: ArchetypeId,
    last_run: Tick,
    all_added: &[ComponentId],
    all_changed: &[ComponentId],
    any_added: &[ComponentId],
    any_changed: &[ComponentId],
) -> Option<(ComponentId, Vec<u32>)> {
    let mut source: Option<ComponentId> = None;
    let mut rows: Option<Vec<u32>> = None;
    for &id in all_added {
        let found = world.static_component_added_rows(archetype, id, last_run)?;
        source.get_or_insert(id);
        narrow_rows(&mut rows, found);
    }
    for &id in all_changed {
        let found = world.static_component_changed_rows(archetype, id, last_run)?;
        source.get_or_insert(id);
        narrow_rows(&mut rows, found);
    }
    if !any_added.is_empty() || !any_changed.is_empty() {
        let mut union: Vec<u32> = Vec::new();
        for &id in any_added {
            if let Some(found) = world.static_component_added_rows(archetype, id, last_run) {
                source.get_or_insert(id);
                union = rows_union(&union, &found);
            }
        }
        for &id in any_changed {
            if let Some(found) = world.static_component_changed_rows(archetype, id, last_run) {
                source.get_or_insert(id);
                union = rows_union(&union, &found);
            }
        }
        narrow_rows(&mut rows, union);
    }
    Some((source?, rows?))
}

/// The rows, across every archetype that matches the structural part of
/// `filter`, whose component values were added or changed after `last_run`
/// as the row-level part of `filter` demands (the C counterpart of Rust's
/// `query_data_filtered_since` with `Added`/`Changed` filters, composed
/// with `With`/`Without`/`Or`). One call replaces the loop a C caller
/// otherwise writes: enumerate archetypes with
/// [`mid_ecs_world_archetypes_matching_static`], ask
/// [`mid_ecs_world_static_component_added_rows`] /
/// [`mid_ecs_world_static_component_changed_rows`] for each, and intersect
/// or union the row lists. See [`MidEcsRowFilter`] for what each list
/// means.
///
/// Results are written into `out_rows`, archetypes in the order
/// [`mid_ecs_world_archetypes_matching_static`] yields them and rows
/// ascending within one. Each [`MidEcsMatchedRow`] names the entity and its
/// `(archetype_id, row)`; the row indexes the spans a C caller reads, with
/// the same validity contract as the `*_rows` functions (until the next
/// call that changes that archetype's storage).
///
/// `last_run` is a change tick the caller kept, exactly as for the `*_rows`
/// functions.
///
/// Same NULL-buffer-queries-count idiom as the other enumerations: a NULL
/// `out_rows` returns the count, a too-small buffer returns
/// `MidEcsStatus::BufferTooSmall` and writes nothing.
///
/// Returns the count (`>= 0`), or a negative `MidEcsStatus`:
/// - `NullPointer`: a null `world` or `filter`, or a list with a NULL
///   pointer and a nonzero length.
/// - `InvalidArgument`: the four change lists are all empty. With no
///   component to read the rows through there is nothing to ask; use
///   [`mid_ecs_world_archetypes_matching_static`] for a purely structural
///   query.
/// - `NotFound`: an id in a change list was never registered for FFI in the
///   Archetype Core (the condition under which the `*_rows` functions say
///   `NotFound`). Checked up front, before anything is written. A typo'd id
///   would otherwise read as "nothing changed". The structural lists keep
///   their own lenient rule: an unknown id there matches nothing (`with`,
///   `any_of`) or is ignored (`without`).
/// - `BufferTooSmall`.
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`.
/// `filter` must point to a valid [`MidEcsRowFilter`] whose non-null
/// pointers are each valid for their length in `uint32_t` elements. If
/// `out_rows` is non-null, it must be valid for `out_capacity`
/// [`MidEcsMatchedRow`] elements.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_static_query_since(
    world: *const MidEcsWorld,
    last_run: u32,
    filter: *const MidEcsRowFilter,
    out_rows: *mut MidEcsMatchedRow,
    out_capacity: usize,
) -> i32 {
    ffi_guard(|| {
        if world.is_null() || filter.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let world = unsafe { &*world };
        let f = unsafe { &*filter };
        let lists = unsafe {
            (
                filter_ids(f.with_ids, f.with_len),
                filter_ids(f.without_ids, f.without_len),
                filter_ids(f.any_of_ids, f.any_of_len),
                filter_ids(f.all_added_ids, f.all_added_len),
                filter_ids(f.all_changed_ids, f.all_changed_len),
                filter_ids(f.any_added_ids, f.any_added_len),
                filter_ids(f.any_changed_ids, f.any_changed_len),
            )
        };
        let (
            Some(with),
            Some(without),
            Some(any_of),
            Some(all_added),
            Some(all_changed),
            Some(any_added),
            Some(any_changed),
        ) = lists
        else {
            return MidEcsStatus::NullPointer as i32;
        };
        if all_added.is_empty()
            && all_changed.is_empty()
            && any_added.is_empty()
            && any_changed.is_empty()
        {
            return MidEcsStatus::InvalidArgument as i32;
        }
        let terms = all_added
            .iter()
            .chain(&all_changed)
            .chain(&any_added)
            .chain(&any_changed);
        for &id in terms {
            if !world.0.archetypes.is_ffi_registered(id) {
                return MidEcsStatus::NotFound as i32;
            }
        }

        let last_run = Tick::new(last_run);
        let mut matched: Vec<MidEcsMatchedRow> = Vec::new();
        for archetype in world.0.archetypes_matching_static(&with, &without, &any_of) {
            let Some((source, rows)) = matched_rows_in(
                &world.0,
                archetype,
                last_run,
                &all_added,
                &all_changed,
                &any_added,
                &any_changed,
            ) else {
                continue;
            };
            if rows.is_empty() {
                continue;
            }
            let entities = world
                .0
                .static_component_entity_ids(archetype, source)
                .unwrap_or_default();
            for row in rows {
                matched.push(MidEcsMatchedRow {
                    entity: entities[row as usize],
                    archetype_id: archetype.as_u32(),
                    row,
                });
            }
        }
        if out_rows.is_null() {
            return matched.len() as i32;
        }
        if matched.len() > out_capacity {
            return MidEcsStatus::BufferTooSmall as i32;
        }
        let out = unsafe { slice::from_raw_parts_mut(out_rows, matched.len()) };
        out.copy_from_slice(&matched);
        matched.len() as i32
    })
}

// ── Removal tracking ─────────────────────────────────────────────────
//
// The C counterpart of `World::track_removals` / `removed_since` /
// `removal_count` / `trim_removals` / `clear_removals` (`removal.rs`).
// Every function is a thin wrapper: it resolves the caller's numeric
// component id to the `TypeId` the log is keyed by, then calls the same
// `RemovalLog` the Rust API uses, so the two views cannot disagree.

/// Which of the two independent `ComponentId` spaces a removal-tracking
/// call's id belongs to. The Archetype Core and the Sparse Shell number
/// their components separately (both start at 0), so the same integer can
/// name a different component in each.
#[derive(Clone, Copy)]
enum IdSpace {
    /// Archetype Core: the `mid_ecs_world_static_component_*` functions.
    Static,
    /// Sparse Shell: the `mid_ecs_world_component_*` functions.
    Sparse,
}

/// The type `component_id` was issued for in `space`, or `None` if this
/// world never issued that id there.
fn removal_type_id(world: &World, space: IdSpace, component_id: u32) -> Option<TypeId> {
    let id = ComponentId::from_u32(component_id);
    match space {
        IdSpace::Static => world.archetypes.type_id_of(id),
        IdSpace::Sparse => world.components.type_id_of(id),
    }
}

/// Shared body of the two `*_track_removals` functions.
///
/// # Safety
/// As those two functions.
unsafe fn removal_track(world: *mut MidEcsWorld, space: IdSpace, component_id: u32) -> i32 {
    ffi_guard(|| {
        if world.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let world = unsafe { &mut *world };
        let Some(type_id) = removal_type_id(&world.0, space, component_id) else {
            return MidEcsStatus::NotFound as i32;
        };
        world.0.removals.track(type_id);
        MidEcsStatus::Ok as i32
    })
}

/// Shared body of the two `*_tracks_removals` functions.
///
/// # Safety
/// As those two functions.
unsafe fn removal_tracks(world: *const MidEcsWorld, space: IdSpace, component_id: u32) -> i32 {
    ffi_guard(|| {
        if world.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let world = unsafe { &*world };
        let Some(type_id) = removal_type_id(&world.0, space, component_id) else {
            return MidEcsStatus::NotFound as i32;
        };
        i32::from(world.0.removals.is_tracked(type_id))
    })
}

/// Shared body of the two `*_removal_count` functions.
///
/// # Safety
/// As those two functions.
unsafe fn removal_count(world: *const MidEcsWorld, space: IdSpace, component_id: u32) -> i32 {
    ffi_guard(|| {
        if world.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let world = unsafe { &*world };
        let Some(type_id) = removal_type_id(&world.0, space, component_id) else {
            return MidEcsStatus::NotFound as i32;
        };
        world.0.removals.len(type_id) as i32
    })
}

/// Shared body of the two `*_removed_since` functions.
///
/// # Safety
/// As those two functions.
unsafe fn removal_since(
    world: *const MidEcsWorld,
    space: IdSpace,
    component_id: u32,
    last_run: u32,
    out_entities: *mut u64,
    out_capacity: usize,
) -> i32 {
    ffi_guard(|| {
        if world.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let world = unsafe { &*world };
        let Some(type_id) = removal_type_id(&world.0, space, component_id) else {
            return MidEcsStatus::NotFound as i32;
        };
        if !world.0.removals.is_tracked(type_id) {
            return MidEcsStatus::NotTracked as i32;
        }
        let removed = world
            .0
            .removals
            .since(type_id, Tick::new(last_run), world.0.change_tick());
        if out_entities.is_null() {
            return removed.count() as i32;
        }
        let entities: Vec<u64> = removed.map(Entity::as_ffi).collect();
        if entities.len() > out_capacity {
            return MidEcsStatus::BufferTooSmall as i32;
        }
        let out = unsafe { slice::from_raw_parts_mut(out_entities, entities.len()) };
        out.copy_from_slice(&entities);
        entities.len() as i32
    })
}

/// Starts recording removals of the Archetype-Core component
/// `component_id` (the C counterpart of `World::track_removals`): from
/// now on, every time an entity loses that component (through any of the
/// removal functions, a queued removal, or its own despawn) the entity
/// and the world's change tick are logged, and
/// [`mid_ecs_world_static_component_removed_since`] reports them.
/// Idempotent. Removals before the first call are not recorded. Replacing
/// a value (`mid_ecs_world_static_component_write`) is not a removal, and
/// a refused removal (`NotFound`, `NotWritable`, `NotAlive`, ...) records
/// nothing.
///
/// Tracking needs only that the id is one this world issued; the
/// component need not be registered writable.
///
/// Returns `MidEcsStatus::Ok`, `NullPointer` (null `world`), or
/// `NotFound` (this world never issued `component_id` in the Archetype
/// Core).
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_static_component_track_removals(
    world: *mut MidEcsWorld,
    component_id: u32,
) -> i32 {
    unsafe { removal_track(world, IdSpace::Static, component_id) }
}

/// Whether removals of the Archetype-Core component `component_id` are
/// being recorded: `1` if so, `0` if not. A negative `MidEcsStatus`
/// (`NullPointer`, `NotFound`) otherwise, as for
/// [`mid_ecs_world_static_component_track_removals`].
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_static_component_tracks_removals(
    world: *const MidEcsWorld,
    component_id: u32,
) -> i32 {
    unsafe { removal_tracks(world, IdSpace::Static, component_id) }
}

/// How many removals of the Archetype-Core component `component_id` the
/// log currently holds: `0` for a component nobody tracks. A negative
/// `MidEcsStatus` (`NullPointer`, `NotFound`) otherwise, as for
/// [`mid_ecs_world_static_component_track_removals`].
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_static_component_removal_count(
    world: *const MidEcsWorld,
    component_id: u32,
) -> i32 {
    unsafe { removal_count(world, IdSpace::Static, component_id) }
}

/// The entities that lost the Archetype-Core component `component_id`
/// after `last_run` (the C counterpart of `World::removed_since`), as
/// packed `uint64_t` entity handles written into `out_entities`, oldest
/// first. An entity removed, given the component again and removed again
/// appears once per removal. The entity may since have been despawned or
/// its slot reused: check `mid_ecs_world_is_alive` if it matters.
///
/// `last_run` is a change tick the caller kept, exactly as for
/// [`mid_ecs_world_static_component_added_rows`]: a removal is reported
/// if it happened in a tick newer than `last_run`, so read
/// [`mid_ecs_world_change_tick`] after handling one batch and pass it next
/// time, and call [`mid_ecs_world_increment_change_tick`] once per step of
/// the caller's loop (a removal in the same tick as `last_run` is not
/// reported). `0` reports every removal still in the log.
///
/// Same NULL-buffer-queries-count idiom as the other enumerations: a NULL
/// `out_entities` returns the count, a too-small buffer returns
/// `MidEcsStatus::BufferTooSmall` and writes nothing.
///
/// Returns the count (`>= 0`), or a negative `MidEcsStatus`: `NullPointer`,
/// `NotFound` (this world never issued `component_id` in the Archetype
/// Core), `NotTracked` (nobody called
/// [`mid_ecs_world_static_component_track_removals`] for it: nothing was
/// ever recorded, and an empty list would hide that), or `BufferTooSmall`.
///
/// The log is never trimmed on its own: see [`mid_ecs_world_trim_removals`].
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`. If
/// `out_entities` is non-null, it must be valid for `out_capacity`
/// `uint64_t` elements.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_static_component_removed_since(
    world: *const MidEcsWorld,
    component_id: u32,
    last_run: u32,
    out_entities: *mut u64,
    out_capacity: usize,
) -> i32 {
    unsafe {
        removal_since(
            world,
            IdSpace::Static,
            component_id,
            last_run,
            out_entities,
            out_capacity,
        )
    }
}

/// As [`mid_ecs_world_static_component_track_removals`], for a
/// Sparse-Shell component id (the id space of
/// [`mid_ecs_world_lookup_ffi_component_id`]). The two spaces are
/// independent: tracking Archetype-Core id `0` does not track Sparse-Shell
/// id `0`.
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_component_track_removals(
    world: *mut MidEcsWorld,
    component_id: u32,
) -> i32 {
    unsafe { removal_track(world, IdSpace::Sparse, component_id) }
}

/// As [`mid_ecs_world_static_component_tracks_removals`], for a
/// Sparse-Shell component id.
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_component_tracks_removals(
    world: *const MidEcsWorld,
    component_id: u32,
) -> i32 {
    unsafe { removal_tracks(world, IdSpace::Sparse, component_id) }
}

/// As [`mid_ecs_world_static_component_removal_count`], for a
/// Sparse-Shell component id.
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_component_removal_count(
    world: *const MidEcsWorld,
    component_id: u32,
) -> i32 {
    unsafe { removal_count(world, IdSpace::Sparse, component_id) }
}

/// As [`mid_ecs_world_static_component_removed_since`], for a
/// Sparse-Shell component id. The Sparse Shell keeps no per-value ticks,
/// so this is the only change-detection-style query it has from C; the
/// removal ticks are the world's own, shared with the Archetype Core.
///
/// # Safety
/// As [`mid_ecs_world_static_component_removed_since`].
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_component_removed_since(
    world: *const MidEcsWorld,
    component_id: u32,
    last_run: u32,
    out_entities: *mut u64,
    out_capacity: usize,
) -> i32 {
    unsafe {
        removal_since(
            world,
            IdSpace::Sparse,
            component_id,
            last_run,
            out_entities,
            out_capacity,
        )
    }
}

/// Drops every logged removal, of every tracked component, that a reader
/// whose last run was `at_or_before` (or later) could no longer see anyway
/// (the C counterpart of `World::trim_removals`). Nothing trims the log
/// automatically, because only whoever owns *all* the readers knows the
/// oldest `last_run` any of them still holds: pass that. Without
/// trimming, the log of a component removed often grows without bound.
/// Tracked components stay tracked.
///
/// Returns `MidEcsStatus::Ok`, or `NullPointer`.
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_trim_removals(
    world: *mut MidEcsWorld,
    at_or_before: u32,
) -> i32 {
    ffi_guard(|| {
        if world.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let world = unsafe { &mut *world };
        world.0.trim_removals(Tick::new(at_or_before));
        MidEcsStatus::Ok as i32
    })
}

/// Drops every logged removal (the C counterpart of
/// `World::clear_removals`). Tracked components stay tracked.
///
/// Returns `MidEcsStatus::Ok`, or `NullPointer`.
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_clear_removals(world: *mut MidEcsWorld) -> i32 {
    ffi_guard(|| {
        if world.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let world = unsafe { &mut *world };
        world.0.clear_removals();
        MidEcsStatus::Ok as i32
    })
}

fn component_status(error: ComponentFfiError) -> i32 {
    match error {
        ComponentFfiError::UnknownId | ComponentFfiError::Absent => MidEcsStatus::NotFound as i32,
        ComponentFfiError::NotWritable => MidEcsStatus::NotWritable as i32,
        ComponentFfiError::NotAlive => MidEcsStatus::NotAlive as i32,
        ComponentFfiError::SizeMismatch => MidEcsStatus::SizeMismatch as i32,
        ComponentFfiError::AlreadyPresent => MidEcsStatus::AlreadyPresent as i32,
        ComponentFfiError::Duplicate => MidEcsStatus::Duplicate as i32,
    }
}

/// Writable counterpart of [`mid_ecs_world_static_component_raw_span`]:
/// writes a span over `component_id`'s column within `archetype_id`'s
/// table into `*out_span`, with a non-const `ptr`, so C can write the
/// values in place. Only components registered *writable* on the Rust side
/// (`World::register_ffi_static_component_writable`, which requires the
/// type to accept any bit pattern) can be handed out this way.
///
/// **Change stamping.** Every row of that column is stamped *changed* (not
/// added) at the world's current tick at the moment this call returns, the
/// same moment `World::get_static_mut` stamps. C cannot say which rows it
/// then writes through a raw pointer, so this can over-report (a `Changed`
/// consumer sees rows you left alone) and can never miss a write. To write
/// a few rows and mark only those, use
/// [`mid_ecs_world_static_component_write`]. Do the writes in the same
/// tick: a write made after `mid_ecs_world_increment_change_tick` is not
/// stamped with the new tick.
///
/// Returns `MidEcsStatus::Ok`, `NullPointer`, `NotFound` under exactly the
/// conditions [`mid_ecs_world_static_component_raw_span`] returns it, or
/// `NotWritable` for a component registered read-only. Nothing is stamped
/// on an error. A real archetype with no rows is `Ok` with `count == 0`
/// and a NULL `ptr`.
///
/// Same invalidation contract as the read-only span: valid until the next
/// call that changes that archetype's storage (spawn, despawn, an insert
/// or remove, applying a command queue). Never write past `count` elements
/// of `stride` bytes, and never keep the pointer across such a call.
///
/// # Safety
/// `world` and `out_span` must both be non-null; `world` a valid handle
/// from `mid_ecs_world_new`, `out_span` valid for one `FfiSpanMut` write.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_static_component_raw_span_mut(
    world: *mut MidEcsWorld,
    archetype_id: u32,
    component_id: u32,
    out_span: *mut FfiSpanMut,
) -> i32 {
    ffi_guard(|| {
        if world.is_null() || out_span.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let world = unsafe { &mut *world };
        match world.0.static_component_raw_span_mut(
            ArchetypeId::from_u32(archetype_id),
            ComponentId::from_u32(component_id),
        ) {
            Ok(span) => {
                unsafe { ptr::write(out_span, span) };
                MidEcsStatus::Ok as i32
            }
            Err(error) => component_status(error),
        }
    })
}

/// A writable span over one entity's `component_id` value, with exactly
/// that row stamped *changed* (not added) at the world's current tick: the
/// in-place form of [`mid_ecs_world_static_component_write`], and the
/// C counterpart of Rust's `get_static_mut` (stamped when the span is
/// handed out, not when it is written). It is the precise way to mutate
/// a filtered subset in place: take the rows from
/// [`mid_ecs_world_static_query_since`] (or the `*_rows` functions), then
/// call this for each one you actually mean to write, so a `Changed`
/// consumer sees those rows and no others. To touch every row of an
/// archetype, [`mid_ecs_world_static_component_raw_span_mut`] is the bulk
/// form (it stamps them all in one call).
///
/// On success `*out_span` is a span with `count == 1` and `stride` the
/// component's size; write `stride` bytes at `ptr`. Do the write in the
/// same tick (a write after `mid_ecs_world_increment_change_tick` is not
/// stamped with the new tick), and it is valid until the next call that
/// changes that archetype's storage (spawn, despawn, an insert or remove,
/// applying a command queue). Asking twice for the same row hands out the
/// same pointer and stamps it again. No component hook fires: this is a
/// mutation, not an insert.
///
/// Returns `MidEcsStatus::Ok`, `NullPointer`, `NotAlive` (a dead or stale
/// entity; it never reaches a different entity that reused the slot),
/// `NotFound` (the component id was never registered for FFI, or the
/// entity is alive but does not have it), or `NotWritable` (registered
/// read-only), checked in that order. `*out_span` is untouched and nothing
/// is stamped on an error.
///
/// # Safety
/// `world` and `out_span` must both be non-null; `world` a valid handle
/// from `mid_ecs_world_new`, `out_span` valid for one `FfiSpanMut` write.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_static_component_row_mut(
    world: *mut MidEcsWorld,
    entity: u64,
    component_id: u32,
    out_span: *mut FfiSpanMut,
) -> i32 {
    ffi_guard(|| {
        if world.is_null() || out_span.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let world = unsafe { &mut *world };
        match world.0.static_component_row_mut(
            Entity::from_ffi(entity),
            ComponentId::from_u32(component_id),
        ) {
            Ok(span) => {
                unsafe { ptr::write(out_span, span) };
                MidEcsStatus::Ok as i32
            }
            Err(error) => component_status(error),
        }
    })
}

/// Copies `len` bytes from `bytes` in as `entity`'s `component_id` value
/// and stamps exactly that row *changed* (not added) at the world's
/// current tick: the precise counterpart of
/// [`mid_ecs_world_static_component_raw_span_mut`], for writing a few rows
/// without marking the rest. `len` must be exactly the registered type's
/// size (the span's `stride`). Bytes are copied, so `bytes` needs no
/// particular alignment and is not retained. Works on components
/// registered *writable* on the Rust side only.
///
/// Returns `MidEcsStatus::Ok`, `NullPointer`, `NotAlive` (a dead or stale
/// entity; it never reaches a different entity that reused the slot),
/// `NotFound` (the component id was never registered for FFI, or the
/// entity is alive but does not have it), `NotWritable` (registered
/// read-only), or `SizeMismatch`, checked in that order. Nothing is
/// written or stamped on an error.
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`.
/// `bytes` must be NULL only if `len` is 0, otherwise valid for reading
/// `len` bytes.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_static_component_write(
    world: *mut MidEcsWorld,
    entity: u64,
    component_id: u32,
    bytes: *const u8,
    len: usize,
) -> i32 {
    ffi_guard(|| {
        if world.is_null() || (bytes.is_null() && len > 0) {
            return MidEcsStatus::NullPointer as i32;
        }
        let world = unsafe { &mut *world };
        let bytes: &[u8] = if len == 0 {
            &[]
        } else {
            unsafe { slice::from_raw_parts(bytes, len) }
        };
        match world.0.write_static_component_bytes(
            Entity::from_ffi(entity),
            ComponentId::from_u32(component_id),
            bytes,
        ) {
            Ok(()) => MidEcsStatus::Ok as i32,
            Err(error) => component_status(error),
        }
    })
}

/// Attaches a `component_id` component, built from `len` bytes at `bytes`,
/// to `entity`: the byte-driven `World::insert_static` for a component
/// registered *writable* on the Rust side. The entity moves into the
/// archetype for its larger component set, and the new value is stamped
/// both *added* and *changed* at the world's current tick. `len` must be
/// exactly the registered type's size (the span's `stride`). Bytes are
/// copied, so `bytes` needs no particular alignment and is not retained.
///
/// This is a structural change: every span previously handed out for the
/// entity's old and new archetype is invalidated.
///
/// Returns `MidEcsStatus::Ok`, `NullPointer`, `NotAlive` (a dead or stale
/// entity), `NotFound` (the component id was never registered for FFI),
/// `NotWritable` (registered read-only), `SizeMismatch`, or
/// `AlreadyPresent` (the entity already has the component, which is left
/// untouched: use [`mid_ecs_world_static_component_write`] to overwrite),
/// checked in that order. Nothing is written or stamped on an error.
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`.
/// `bytes` must be NULL only if `len` is 0, otherwise valid for reading
/// `len` bytes.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_static_component_insert(
    world: *mut MidEcsWorld,
    entity: u64,
    component_id: u32,
    bytes: *const u8,
    len: usize,
) -> i32 {
    ffi_guard(|| {
        if world.is_null() || (bytes.is_null() && len > 0) {
            return MidEcsStatus::NullPointer as i32;
        }
        let world = unsafe { &mut *world };
        let bytes: &[u8] = if len == 0 {
            &[]
        } else {
            unsafe { slice::from_raw_parts(bytes, len) }
        };
        match world.0.insert_static_bytes(
            Entity::from_ffi(entity),
            ComponentId::from_u32(component_id),
            bytes,
        ) {
            Ok(()) => MidEcsStatus::Ok as i32,
            Err(error) => component_status(error),
        }
    })
}

/// Detaches `component_id` from `entity` and drops its value: the
/// id-driven `World::remove_static`, for a component registered *writable*
/// on the Rust side ("writable" means C may write, insert and remove it).
/// The entity moves into the archetype for its smaller component set; its
/// other values, and their change stamps, come across untouched. Nothing is
/// stamped by a removal: there is no change notification for them.
///
/// This is a structural change: every span previously handed out for the
/// entity's old and new archetype is invalidated.
///
/// Returns `MidEcsStatus::Ok`, `NullPointer`, `NotAlive` (a dead or stale
/// entity), `NotFound` (the component id was never registered for FFI, or
/// the entity is alive but does not have the component) or `NotWritable`
/// (registered read-only), checked in that order. Nothing changes on an
/// error.
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_static_component_remove(
    world: *mut MidEcsWorld,
    entity: u64,
    component_id: u32,
) -> i32 {
    ffi_guard(|| {
        if world.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let world = unsafe { &mut *world };
        match world.0.remove_static_by_id(
            Entity::from_ffi(entity),
            ComponentId::from_u32(component_id),
        ) {
            Ok(()) => MidEcsStatus::Ok as i32,
            Err(error) => component_status(error),
        }
    })
}

fn resource_status(error: ResourceFfiError) -> i32 {
    match error {
        ResourceFfiError::UnknownId | ResourceFfiError::Absent => MidEcsStatus::NotFound as i32,
        ResourceFfiError::SizeMismatch => MidEcsStatus::SizeMismatch as i32,
    }
}

/// Looks up the `resource_id` a resource type was registered under via
/// `World::register_ffi_resource`, by name. Returns [`MID_ECS_INVALID_ID`]
/// on a null `world`/`name`, invalid UTF-8, an internal panic, or a name
/// that was never registered, the same collapse to one sentinel as
/// [`mid_ecs_world_lookup_ffi_component_id`]. Resource ids are their own
/// namespace, separate from component ids.
///
/// # Safety
/// `world` must either be NULL or a valid handle from `mid_ecs_world_new`.
/// If non-null, `name` must be a valid, null-terminated C string.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_lookup_ffi_resource_id(
    world: *const MidEcsWorld,
    name: *const c_char,
) -> u32 {
    if world.is_null() || name.is_null() {
        return MID_ECS_INVALID_ID;
    }
    let result = catch_unwind(AssertUnwindSafe(|| {
        let world = unsafe { &*world };
        let name = unsafe { CStr::from_ptr(name) }.to_str().ok()?;
        world.0.lookup_ffi_resource_id(name)
    }));
    match result {
        Ok(Some(id)) => id.as_u32(),
        _ => MID_ECS_INVALID_ID,
    }
}

/// A view of the registered resource's current value, written into
/// `*out_span`: one element (`count == 1`, `stride` the type's size), or
/// the empty span (`count == 0`) if the resource is registered but not
/// currently inserted. Returns `MidEcsStatus::NotFound` if `resource_id`
/// was never issued.
///
/// The span points into the live value. It stays valid across
/// [`mid_ecs_world_resource_write`] (which updates an existing value in
/// place) and is invalidated by [`mid_ecs_world_resource_remove`], by a
/// Rust-side `insert_resource`/`remove_resource` of the same type, and by
/// freeing the world.
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`.
/// `out_span` must be valid for writing one `MidEcsFfiSpan`.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_resource_raw_span(
    world: *const MidEcsWorld,
    resource_id: u32,
    out_span: *mut FfiSpan,
) -> i32 {
    ffi_guard(|| {
        if world.is_null() || out_span.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let world = unsafe { &*world };
        match world.0.resource_raw_span(ResourceId::from_u32(resource_id)) {
            Some(span) => {
                unsafe { ptr::write(out_span, span) };
                MidEcsStatus::Ok as i32
            }
            None => MidEcsStatus::NotFound as i32,
        }
    })
}

/// Copies `len` bytes from `bytes` in as the registered resource's new
/// value, inserting it if it isn't currently inserted. `len` must be
/// exactly the registered type's size (`stride` in the span), otherwise
/// nothing is written and the result is `MidEcsStatus::SizeMismatch`.
/// `MidEcsStatus::NotFound` if `resource_id` was never issued. Bytes are
/// copied, so `bytes` needs no particular alignment and is not retained;
/// registration requires the type to accept any bit pattern.
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`.
/// `bytes` must be NULL only if `len` is 0, otherwise valid for reading
/// `len` bytes.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_resource_write(
    world: *mut MidEcsWorld,
    resource_id: u32,
    bytes: *const u8,
    len: usize,
) -> i32 {
    ffi_guard(|| {
        if world.is_null() || (bytes.is_null() && len > 0) {
            return MidEcsStatus::NullPointer as i32;
        }
        let world = unsafe { &mut *world };
        let bytes: &[u8] = if len == 0 {
            &[]
        } else {
            unsafe { slice::from_raw_parts(bytes, len) }
        };
        match world
            .0
            .write_resource_bytes(ResourceId::from_u32(resource_id), bytes)
        {
            Ok(()) => MidEcsStatus::Ok as i32,
            Err(error) => resource_status(error),
        }
    })
}

/// Removes the registered resource's value. `MidEcsStatus::NotFound` if
/// `resource_id` was never issued or the resource isn't currently
/// inserted (nothing was removed either way). Invalidates any span
/// previously obtained for it.
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_resource_remove(
    world: *mut MidEcsWorld,
    resource_id: u32,
) -> i32 {
    ffi_guard(|| {
        if world.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let world = unsafe { &mut *world };
        match world
            .0
            .remove_ffi_resource(ResourceId::from_u32(resource_id))
        {
            Ok(()) => MidEcsStatus::Ok as i32,
            Err(error) => resource_status(error),
        }
    })
}

/// Whether the registered resource was *inserted* after `last_run`: `1` if
/// so, `0` if not (also `0` if it is registered but not currently
/// inserted). `last_run` is a change tick the caller kept, exactly as for
/// the `*_rows` functions: read [`mid_ecs_world_change_tick`] after handling
/// a batch, pass it next time, and call
/// [`mid_ecs_world_increment_change_tick`] once per step (a change in the
/// same tick as `last_run` is not reported). `0` for `last_run` reports
/// anything inserted since the world began. A resource that is removed and
/// inserted again counts as a new addition.
///
/// Returns `1` or `0`, or a negative `MidEcsStatus`: `NullPointer` (null
/// `world`) or `NotFound` (`resource_id` was never issued).
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_resource_added_since(
    world: *const MidEcsWorld,
    resource_id: u32,
    last_run: u32,
) -> i32 {
    ffi_guard(|| {
        if world.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let world = unsafe { &*world };
        match world
            .0
            .resource_added_since(ResourceId::from_u32(resource_id), Tick::new(last_run))
        {
            Ok(added) => i32::from(added),
            Err(error) => resource_status(error),
        }
    })
}

/// Whether the registered resource was inserted, replaced, or written
/// (through [`mid_ecs_world_resource_write`], or by Rust code handing out
/// mutable access to it) after `last_run`: `1` if so, `0` if not (also `0`
/// if it is registered but not currently inserted). Same `last_run`
/// convention and returns as [`mid_ecs_world_resource_added_since`]. Reading
/// a resource, including through [`mid_ecs_world_resource_raw_span`], is
/// not a change; a write through a span from `raw_span` is invisible, as
/// the span is read-only.
///
/// # Safety
/// `world` must be a valid, non-null handle from `mid_ecs_world_new`.
#[no_mangle]
pub unsafe extern "C" fn mid_ecs_world_resource_changed_since(
    world: *const MidEcsWorld,
    resource_id: u32,
    last_run: u32,
) -> i32 {
    ffi_guard(|| {
        if world.is_null() {
            return MidEcsStatus::NullPointer as i32;
        }
        let world = unsafe { &*world };
        match world
            .0
            .resource_changed_since(ResourceId::from_u32(resource_id), Tick::new(last_run))
        {
            Ok(changed) => i32::from(changed),
            Err(error) => resource_status(error),
        }
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use zerocopy::{Immutable, IntoBytes, KnownLayout};

    #[derive(Debug, Clone, Copy, PartialEq, IntoBytes, KnownLayout, Immutable)]
    #[repr(C)]
    struct FfiHealth {
        hp: u32,
    }

    #[derive(Debug, Clone, Copy, PartialEq, IntoBytes, KnownLayout, Immutable)]
    #[repr(C)]
    struct FfiStamina {
        stamina: u32,
    }

    #[test]
    fn world_new_free_round_trips() {
        let world = mid_ecs_world_new();
        assert!(!world.is_null());
        // SAFETY: `world` is non-null, just created, not yet freed.
        unsafe { mid_ecs_world_free(world) };
    }

    #[test]
    fn free_null_is_a_safe_no_op() {
        // SAFETY: NULL is the documented safe-no-op case.
        unsafe { mid_ecs_world_free(std::ptr::null_mut()) };
    }

    #[test]
    fn spawn_despawn_is_alive_round_trip_through_ffi() {
        let world = mid_ecs_world_new();
        // SAFETY: `world` non-null and not yet freed for this whole block.
        unsafe {
            let entity = mid_ecs_world_spawn(world);
            assert!(mid_ecs_world_is_alive(world, entity));
            assert_eq!(mid_ecs_world_entity_count(world), 1);

            let status = mid_ecs_world_despawn(world, entity);
            assert_eq!(status, MidEcsStatus::Ok as i32);
            assert!(!mid_ecs_world_is_alive(world, entity));
            assert_eq!(mid_ecs_world_entity_count(world), 0);

            mid_ecs_world_free(world);
        }
    }

    #[test]
    fn despawn_already_dead_returns_not_alive_not_panic() {
        let world = mid_ecs_world_new();
        // SAFETY: `world` non-null and not yet freed for this whole block.
        unsafe {
            let entity = mid_ecs_world_spawn(world);
            mid_ecs_world_despawn(world, entity);
            let second = mid_ecs_world_despawn(world, entity);
            assert_eq!(second, MidEcsStatus::NotAlive as i32);
            mid_ecs_world_free(world);
        }
    }

    #[test]
    fn stale_packed_entity_after_reuse_correctly_reads_as_not_alive() {
        let world = mid_ecs_world_new();
        // SAFETY: `world` non-null and not yet freed for this whole block.
        unsafe {
            let e1 = mid_ecs_world_spawn(world);
            mid_ecs_world_despawn(world, e1);
            let e2 = mid_ecs_world_spawn(world); // reuses e1's slot

            assert!(
                !mid_ecs_world_is_alive(world, e1),
                "the stale packed handle must not read as alive"
            );
            assert!(mid_ecs_world_is_alive(world, e2));

            mid_ecs_world_free(world);
        }
    }

    #[test]
    fn bogus_packed_entity_is_safe_and_reads_as_not_alive() {
        let world = mid_ecs_world_new();
        // SAFETY: `world` non-null and not yet freed for this whole block.
        unsafe {
            mid_ecs_world_spawn(world);
            let bogus: u64 = 0xFFFF_FFFF_FFFF_FFFF;
            assert!(!mid_ecs_world_is_alive(world, bogus));
            let status = mid_ecs_world_despawn(world, bogus);
            assert_eq!(status, MidEcsStatus::NotAlive as i32);
            mid_ecs_world_free(world);
        }
    }

    #[test]
    fn null_world_functions_return_safe_defaults_not_crash() {
        let null_world: *mut MidEcsWorld = std::ptr::null_mut();
        // SAFETY: every one of these has a documented, tested NULL-handle path.
        unsafe {
            assert_eq!(mid_ecs_world_spawn(null_world), 0);
            assert!(!mid_ecs_world_is_alive(null_world, 0));
            assert_eq!(mid_ecs_world_entity_count(null_world), 0);
            assert_eq!(
                mid_ecs_world_despawn(null_world, 0),
                MidEcsStatus::NullPointer as i32
            );
        }
    }

    // --- Sparse Shell component-data C surface ---

    #[test]
    fn lookup_ffi_component_id_resolves_a_registered_name() {
        let world_ptr = mid_ecs_world_new();
        let world = unsafe { &mut *world_ptr };
        let id = world.0.register_ffi_component::<FfiHealth>("FfiHealth");

        let name = std::ffi::CString::new("FfiHealth").unwrap();
        // SAFETY: world_ptr non-null and not yet freed; name is a real,
        // null-terminated C string.
        let looked_up = unsafe { mid_ecs_world_lookup_ffi_component_id(world_ptr, name.as_ptr()) };
        assert_eq!(looked_up, id.as_u32());

        unsafe { mid_ecs_world_free(world_ptr) };
    }

    #[test]
    fn lookup_ffi_component_id_on_unregistered_name_is_invalid_sentinel() {
        let world_ptr = mid_ecs_world_new();
        let name = std::ffi::CString::new("NeverRegistered").unwrap();
        // SAFETY: world_ptr non-null and not yet freed.
        let looked_up = unsafe { mid_ecs_world_lookup_ffi_component_id(world_ptr, name.as_ptr()) };
        assert_eq!(looked_up, MID_ECS_INVALID_ID);
        unsafe { mid_ecs_world_free(world_ptr) };
    }

    #[test]
    fn lookup_ffi_component_id_on_null_world_or_name_is_invalid_sentinel() {
        let world_ptr = mid_ecs_world_new();
        let name = std::ffi::CString::new("FfiHealth").unwrap();
        // SAFETY: NULL world and NULL name are both documented safe cases.
        unsafe {
            assert_eq!(
                mid_ecs_world_lookup_ffi_component_id(std::ptr::null(), name.as_ptr()),
                MID_ECS_INVALID_ID
            );
            assert_eq!(
                mid_ecs_world_lookup_ffi_component_id(world_ptr, std::ptr::null()),
                MID_ECS_INVALID_ID
            );
            mid_ecs_world_free(world_ptr);
        }
    }

    #[test]
    fn component_raw_span_and_entity_ids_correlate_through_the_c_surface() {
        let world_ptr = mid_ecs_world_new();
        let world = unsafe { &mut *world_ptr };
        let id = world.0.register_ffi_component::<FfiHealth>("FfiHealth");
        let e1 = world.0.spawn();
        let e2 = world.0.spawn();
        world.0.insert(e1, FfiHealth { hp: 10 });
        world.0.insert(e2, FfiHealth { hp: 20 });

        let mut span = FfiSpan {
            ptr: std::ptr::null(),
            stride: 0,
            count: 0,
        };
        // SAFETY: world_ptr and &mut span both non-null and valid.
        let status = unsafe { mid_ecs_world_component_raw_span(world_ptr, id.as_u32(), &mut span) };
        assert_eq!(status, MidEcsStatus::Ok as i32);
        assert_eq!(span.count, 2);

        // Query mode: NULL buffer returns the real count, writes nothing.
        let queried = unsafe {
            mid_ecs_world_component_entity_ids(world_ptr, id.as_u32(), std::ptr::null_mut(), 0)
        };
        assert_eq!(queried, 2);

        let mut ids = [0u64; 2];
        // SAFETY: world_ptr valid; ids valid for 2 elements.
        let written = unsafe {
            mid_ecs_world_component_entity_ids(world_ptr, id.as_u32(), ids.as_mut_ptr(), ids.len())
        };
        assert_eq!(written, 2);

        // SAFETY: span.ptr points at world's own live storage, unmutated
        // since the calls above.
        let values =
            unsafe { std::slice::from_raw_parts(span.ptr.cast::<FfiHealth>(), span.count) };
        assert_eq!(Entity::from_ffi(ids[0]), e1);
        assert_eq!(Entity::from_ffi(ids[1]), e2);
        assert_eq!(values[0], FfiHealth { hp: 10 });
        assert_eq!(values[1], FfiHealth { hp: 20 });

        unsafe { mid_ecs_world_free(world_ptr) };
    }

    #[test]
    fn component_entity_ids_buffer_too_small_is_a_real_error_not_a_partial_fill() {
        let world_ptr = mid_ecs_world_new();
        let world = unsafe { &mut *world_ptr };
        let id = world.0.register_ffi_component::<FfiHealth>("FfiHealth");
        let e1 = world.0.spawn();
        let e2 = world.0.spawn();
        world.0.insert(e1, FfiHealth { hp: 1 });
        world.0.insert(e2, FfiHealth { hp: 2 });

        let mut too_small = [0u64; 1];
        // SAFETY: world_ptr valid; too_small valid for its own length (1).
        let status = unsafe {
            mid_ecs_world_component_entity_ids(
                world_ptr,
                id.as_u32(),
                too_small.as_mut_ptr(),
                too_small.len(),
            )
        };
        assert_eq!(status, MidEcsStatus::BufferTooSmall as i32);

        unsafe { mid_ecs_world_free(world_ptr) };
    }

    #[test]
    fn component_raw_span_and_entity_ids_on_never_registered_id_is_not_found() {
        let world_ptr = mid_ecs_world_new();
        let mut span = FfiSpan {
            ptr: std::ptr::null(),
            stride: 0,
            count: 0,
        };
        // SAFETY: world_ptr non-null; &mut span valid.
        unsafe {
            assert_eq!(
                mid_ecs_world_component_raw_span(world_ptr, MID_ECS_INVALID_ID, &mut span),
                MidEcsStatus::NotFound as i32
            );
            assert_eq!(
                mid_ecs_world_component_entity_ids(
                    world_ptr,
                    MID_ECS_INVALID_ID,
                    std::ptr::null_mut(),
                    0
                ),
                MidEcsStatus::NotFound as i32
            );
            mid_ecs_world_free(world_ptr);
        }
    }

    #[test]
    fn component_raw_span_null_pointer_cases() {
        let world_ptr = mid_ecs_world_new();
        let mut span = FfiSpan {
            ptr: std::ptr::null(),
            stride: 0,
            count: 0,
        };
        // SAFETY: exercising the documented NULL-pointer error paths.
        unsafe {
            assert_eq!(
                mid_ecs_world_component_raw_span(std::ptr::null(), 0, &mut span),
                MidEcsStatus::NullPointer as i32
            );
            assert_eq!(
                mid_ecs_world_component_raw_span(world_ptr, 0, std::ptr::null_mut()),
                MidEcsStatus::NullPointer as i32
            );
            mid_ecs_world_free(world_ptr);
        }
    }

    // --- Archetype Core component-data C surface ---

    #[test]
    fn static_component_raw_span_and_entity_ids_correlate_through_the_c_surface() {
        let world_ptr = mid_ecs_world_new();
        let world = unsafe { &mut *world_ptr };
        let id = world
            .0
            .register_ffi_static_component::<FfiHealth>("FfiHealthStatic");
        let e1 = world.0.spawn();
        let e2 = world.0.spawn();
        world.0.insert_static(e1, FfiHealth { hp: 100 });
        world.0.insert_static(e2, FfiHealth { hp: 200 });

        let archetype_id = world
            .0
            .archetypes_with_static_component(id)
            .next()
            .expect("both entities share one archetype")
            .as_u32();

        let mut span = FfiSpan {
            ptr: std::ptr::null(),
            stride: 0,
            count: 0,
        };
        // SAFETY: world_ptr and &mut span both valid.
        let status = unsafe {
            mid_ecs_world_static_component_raw_span(world_ptr, archetype_id, id.as_u32(), &mut span)
        };
        assert_eq!(status, MidEcsStatus::Ok as i32);
        assert_eq!(span.count, 2);

        let mut ids = [0u64; 2];
        // SAFETY: world_ptr valid; ids valid for 2 elements.
        let written = unsafe {
            mid_ecs_world_static_component_entity_ids(
                world_ptr,
                archetype_id,
                id.as_u32(),
                ids.as_mut_ptr(),
                ids.len(),
            )
        };
        assert_eq!(written, 2);

        // SAFETY: span.ptr points at world's own live storage, unmutated
        // since the calls above.
        let values =
            unsafe { std::slice::from_raw_parts(span.ptr.cast::<FfiHealth>(), span.count) };
        assert_eq!(Entity::from_ffi(ids[0]), e1);
        assert_eq!(Entity::from_ffi(ids[1]), e2);
        assert_eq!(values[0], FfiHealth { hp: 100 });
        assert_eq!(values[1], FfiHealth { hp: 200 });

        unsafe { mid_ecs_world_free(world_ptr) };
    }

    #[test]
    fn lookup_ffi_static_component_id_uses_an_independent_namespace_from_sparse_shell() {
        let world_ptr = mid_ecs_world_new();
        let world = unsafe { &mut *world_ptr };
        // Same name, two different types, one per storage system -- real
        // proof the two id namespaces are independent, matching
        // Archetypes/SparseShell's own separate registries. Two distinct
        // types deliberately, not the same type reused across both
        // systems -- World's own StorageClaims guard now forbids exactly
        // that (see world.rs's own doc comment on it).
        let sparse_id = world.0.register_ffi_component::<FfiHealth>("FfiHealth");
        let static_id = world
            .0
            .register_ffi_static_component::<FfiStamina>("FfiHealth");

        let name = std::ffi::CString::new("FfiHealth").unwrap();
        // SAFETY: world_ptr non-null; name is a real C string.
        unsafe {
            assert_eq!(
                mid_ecs_world_lookup_ffi_component_id(world_ptr, name.as_ptr()),
                sparse_id.as_u32()
            );
            assert_eq!(
                mid_ecs_world_lookup_ffi_static_component_id(world_ptr, name.as_ptr()),
                static_id.as_u32()
            );
            mid_ecs_world_free(world_ptr);
        }
    }

    #[test]
    fn archetypes_with_static_component_query_then_fill_through_the_c_surface() {
        let world_ptr = mid_ecs_world_new();
        let world = unsafe { &mut *world_ptr };
        let health_id = world
            .0
            .register_ffi_static_component::<FfiHealth>("FfiHealthStatic");
        let e1 = world.0.spawn();
        let e2 = world.0.spawn();
        world.0.insert_static(e1, FfiHealth { hp: 1 });
        world.0.insert_static(e2, FfiHealth { hp: 2 });

        // SAFETY: world_ptr valid; NULL buffer is the documented query mode.
        let queried = unsafe {
            mid_ecs_world_archetypes_with_static_component(
                world_ptr,
                health_id.as_u32(),
                std::ptr::null_mut(),
                0,
            )
        };
        assert_eq!(queried, 1, "e1 and e2 share one archetype");

        let mut buf = [0u32; 1];
        // SAFETY: world_ptr valid; buf valid for 1 element.
        let written = unsafe {
            mid_ecs_world_archetypes_with_static_component(
                world_ptr,
                health_id.as_u32(),
                buf.as_mut_ptr(),
                buf.len(),
            )
        };
        assert_eq!(written, 1);

        // SAFETY: world_ptr and &mut span both valid.
        let mut span = FfiSpan {
            ptr: std::ptr::null(),
            stride: 0,
            count: 0,
        };
        let status = unsafe {
            mid_ecs_world_static_component_raw_span(
                world_ptr,
                buf[0],
                health_id.as_u32(),
                &mut span,
            )
        };
        assert_eq!(
            status,
            MidEcsStatus::Ok as i32,
            "the archetype id this function handed back must be immediately usable"
        );
        assert_eq!(span.count, 2);

        unsafe { mid_ecs_world_free(world_ptr) };
    }

    #[test]
    fn archetypes_with_static_component_on_unregistered_id_is_zero_not_an_error() {
        let world_ptr = mid_ecs_world_new();
        // SAFETY: world_ptr non-null; NULL buffer is the documented query mode.
        let count = unsafe {
            mid_ecs_world_archetypes_with_static_component(
                world_ptr,
                MID_ECS_INVALID_ID,
                std::ptr::null_mut(),
                0,
            )
        };
        assert_eq!(
            count, 0,
            "matches Archetypes::archetypes_with's own not-gated-by-registration behavior"
        );
        unsafe { mid_ecs_world_free(world_ptr) };
    }

    #[test]
    fn static_component_raw_span_and_entity_ids_on_never_registered_id_is_not_found() {
        let world_ptr = mid_ecs_world_new();
        let mut span = FfiSpan {
            ptr: std::ptr::null(),
            stride: 0,
            count: 0,
        };
        // SAFETY: world_ptr non-null; &mut span valid.
        unsafe {
            assert_eq!(
                mid_ecs_world_static_component_raw_span(
                    world_ptr,
                    0,
                    MID_ECS_INVALID_ID,
                    &mut span
                ),
                MidEcsStatus::NotFound as i32
            );
            assert_eq!(
                mid_ecs_world_static_component_entity_ids(
                    world_ptr,
                    0,
                    MID_ECS_INVALID_ID,
                    std::ptr::null_mut(),
                    0
                ),
                MidEcsStatus::NotFound as i32
            );
            mid_ecs_world_free(world_ptr);
        }
    }

    // ── archetypes_matching_static ──────────────────────────────────

    use crate::filter::{Or, QueryFilter, With, Without};

    fn empty_span() -> FfiSpan {
        FfiSpan {
            ptr: std::ptr::null(),
            stride: 0,
            count: 0,
        }
    }

    fn static_id(world: *const MidEcsWorld, name: &str) -> u32 {
        let name = std::ffi::CString::new(name).unwrap();
        // SAFETY: `world` is a live handle and `name` a valid C string.
        let id = unsafe { mid_ecs_world_lookup_ffi_static_component_id(world, name.as_ptr()) };
        assert_ne!(id, MID_ECS_INVALID_ID);
        id
    }

    /// Runs the count-then-fill idiom the C header documents, with no
    /// `any_of` constraint. See [`matching_ids_any`] for the `Or` form.
    fn matching_ids(world: *const MidEcsWorld, with: &[u32], without: &[u32]) -> Vec<u32> {
        matching_ids_any(world, with, without, &[])
    }

    /// [`matching_ids`], with an explicit `any_of` (`Or`) list.
    fn matching_ids_any(
        world: *const MidEcsWorld,
        with: &[u32],
        without: &[u32],
        any_of: &[u32],
    ) -> Vec<u32> {
        // SAFETY: `world` is a live handle; the id slices outlive the call.
        let count = unsafe {
            mid_ecs_world_archetypes_matching_static(
                world,
                with.as_ptr(),
                with.len(),
                without.as_ptr(),
                without.len(),
                any_of.as_ptr(),
                any_of.len(),
                std::ptr::null_mut(),
                0,
            )
        };
        assert!(count >= 0, "count query failed with status {count}");
        let mut buf = vec![0u32; count as usize];
        // SAFETY: as above; `buf` is valid for `buf.len()` elements.
        let written = unsafe {
            mid_ecs_world_archetypes_matching_static(
                world,
                with.as_ptr(),
                with.len(),
                without.as_ptr(),
                without.len(),
                any_of.as_ptr(),
                any_of.len(),
                buf.as_mut_ptr(),
                buf.len(),
            )
        };
        assert_eq!(written, count);
        buf
    }

    /// Every entity found by walking the matching archetypes the way a C
    /// caller would. Asserts that each archetype the enumeration hands
    /// out resolves through both per-archetype calls.
    fn entities_via_ffi(
        world: *const MidEcsWorld,
        read: u32,
        with: &[u32],
        without: &[u32],
        any_of: &[u32],
    ) -> Vec<u64> {
        let mut out = Vec::new();
        for archetype in matching_ids_any(world, with, without, any_of) {
            let mut span = empty_span();
            // SAFETY: `world` is a live handle, `span` is valid.
            let status = unsafe {
                mid_ecs_world_static_component_raw_span(world, archetype, read, &mut span)
            };
            assert_eq!(
                status,
                MidEcsStatus::Ok as i32,
                "archetype {archetype} was enumerated, so raw_span must resolve it"
            );
            // SAFETY: as above; NULL buffer asks for the count.
            let n = unsafe {
                mid_ecs_world_static_component_entity_ids(
                    world,
                    archetype,
                    read,
                    std::ptr::null_mut(),
                    0,
                )
            };
            assert_eq!(n as usize, span.count);
            let mut ids = vec![0u64; n as usize];
            // SAFETY: `ids` is valid for `ids.len()` elements.
            let written = unsafe {
                mid_ecs_world_static_component_entity_ids(
                    world,
                    archetype,
                    read,
                    ids.as_mut_ptr(),
                    ids.len(),
                )
            };
            assert_eq!(written, n);
            out.extend(ids);
        }
        out.sort_unstable();
        out
    }

    fn typed_entities<F: QueryFilter>(world: &World) -> Vec<u64> {
        let mut v: Vec<u64> = world
            .query_static_filtered::<MidEcsTestHealthStatic, F>()
            .map(|(e, _)| e.as_ffi())
            .collect();
        v.sort_unstable();
        v
    }

    #[test]
    fn matching_static_enumerates_the_expected_archetypes() {
        let world = mid_ecs_test_filter_fixture_world_new();
        let h = static_id(world, "FfiHealthStatic");
        let a = static_id(world, "FfiFlagA");
        let b = static_id(world, "FfiFlagB");

        // Health: {H}, {H,A}, the zero-row {B,H}, and {B,H,A}.
        assert_eq!(matching_ids(world, &[h], &[]).len(), 4);
        assert_eq!(matching_ids(world, &[h], &[a]).len(), 2); // {H}, {B,H}
        assert_eq!(matching_ids(world, &[h, a], &[]).len(), 2);
        assert_eq!(matching_ids(world, &[h], &[a, b]).len(), 1);
        assert_eq!(matching_ids(world, &[h, a, b], &[]).len(), 1);
        // Two empty lists: every archetype, the empty one and the
        // zero-row intermediates included.
        assert_eq!(matching_ids(world, &[], &[]).len(), 6);

        // SAFETY: `world` is a live handle, freed exactly once.
        unsafe { mid_ecs_world_free(world) };
    }

    #[test]
    fn every_enumerated_archetype_resolves_including_zero_row_intermediates() {
        let world = mid_ecs_test_filter_fixture_world_new();
        let h = static_id(world, "FfiHealthStatic");

        // `entities_via_ffi` asserts `Ok` from raw_span on all four
        // archetypes, one of which never held a row.
        let found = entities_via_ffi(world, h, &[h], &[], &[]);
        assert_eq!(found.len(), 3);

        // SAFETY: as above.
        unsafe { mid_ecs_world_free(world) };
    }

    #[test]
    fn ffi_enumeration_matches_the_typed_filtered_queries() {
        let world_ptr = mid_ecs_test_filter_fixture_world_new();
        let h = static_id(world_ptr, "FfiHealthStatic");
        let a = static_id(world_ptr, "FfiFlagA");
        let b = static_id(world_ptr, "FfiFlagB");
        // SAFETY: `world_ptr` is a live handle for this whole test.
        let world = unsafe { &(*world_ptr).0 };

        let check = |typed: Vec<u64>, with: &[u32], without: &[u32], expected_len: usize| {
            let via_ffi = entities_via_ffi(world_ptr, h, with, without, &[]);
            assert_eq!(via_ffi, typed, "with {with:?} without {without:?}");
            assert_eq!(
                typed.len(),
                expected_len,
                "with {with:?} without {without:?}"
            );
        };

        check(typed_entities::<()>(world), &[h], &[], 3);
        check(
            typed_entities::<With<MidEcsTestFlagA>>(world),
            &[h, a],
            &[],
            2,
        );
        check(
            typed_entities::<Without<MidEcsTestFlagA>>(world),
            &[h],
            &[a],
            1,
        );
        check(
            typed_entities::<With<MidEcsTestFlagB>>(world),
            &[h, b],
            &[],
            1,
        );
        check(
            typed_entities::<Without<MidEcsTestFlagB>>(world),
            &[h],
            &[b],
            2,
        );
        check(
            typed_entities::<(With<MidEcsTestFlagA>, Without<MidEcsTestFlagB>)>(world),
            &[h, a],
            &[b],
            1,
        );
        check(
            typed_entities::<(With<MidEcsTestFlagA>, With<MidEcsTestFlagB>)>(world),
            &[h, a, b],
            &[],
            1,
        );
        check(
            typed_entities::<(Without<MidEcsTestFlagA>, Without<MidEcsTestFlagB>)>(world),
            &[h],
            &[a, b],
            1,
        );

        // SAFETY: freed exactly once.
        unsafe { mid_ecs_world_free(world_ptr) };
    }

    #[test]
    fn matching_static_buffer_idiom() {
        let world = mid_ecs_test_filter_fixture_world_new();
        let h = static_id(world, "FfiHealthStatic");
        let with = [h];
        let call = |buf: *mut u32, cap: usize| unsafe {
            // SAFETY: `world` is live; `with` outlives the call; callers
            // pass a buffer valid for `cap` elements (or NULL).
            mid_ecs_world_archetypes_matching_static(
                world,
                with.as_ptr(),
                with.len(),
                std::ptr::null(),
                0,
                std::ptr::null(),
                0,
                buf,
                cap,
            )
        };

        assert_eq!(
            call(std::ptr::null_mut(), 0),
            4,
            "NULL buffer asks for the count"
        );

        let mut small = [0u32; 3];
        assert_eq!(
            call(small.as_mut_ptr(), small.len()),
            MidEcsStatus::BufferTooSmall as i32,
            "too small is an error, not a partial fill"
        );
        assert_eq!(small, [0, 0, 0], "and nothing was written");

        let mut exact = [0u32; 4];
        assert_eq!(call(exact.as_mut_ptr(), exact.len()), 4);
        let mut roomy = [u32::MAX; 8];
        assert_eq!(call(roomy.as_mut_ptr(), roomy.len()), 4);
        assert_eq!(&roomy[..4], &exact[..]);
        assert!(
            roomy[4..].iter().all(|&x| x == u32::MAX),
            "spare capacity untouched"
        );

        // SAFETY: freed exactly once.
        unsafe { mid_ecs_world_free(world) };
    }

    #[test]
    fn matching_static_null_pointer_cases() {
        let world = mid_ecs_test_filter_fixture_world_new();
        let h = static_id(world, "FfiHealthStatic");
        let ids = [h];
        let np = MidEcsStatus::NullPointer as i32;

        // SAFETY: every pointer passed is either NULL (the case under
        // test) or valid for the stated length.
        unsafe {
            assert_eq!(
                mid_ecs_world_archetypes_matching_static(
                    std::ptr::null(),
                    ids.as_ptr(),
                    1,
                    std::ptr::null(),
                    0,
                    std::ptr::null(),
                    0,
                    std::ptr::null_mut(),
                    0
                ),
                np,
                "NULL world"
            );
            assert_eq!(
                mid_ecs_world_archetypes_matching_static(
                    world,
                    std::ptr::null(),
                    1,
                    std::ptr::null(),
                    0,
                    std::ptr::null(),
                    0,
                    std::ptr::null_mut(),
                    0
                ),
                np,
                "NULL with_ids with a non-zero length"
            );
            assert_eq!(
                mid_ecs_world_archetypes_matching_static(
                    world,
                    ids.as_ptr(),
                    1,
                    std::ptr::null(),
                    2,
                    std::ptr::null(),
                    0,
                    std::ptr::null_mut(),
                    0
                ),
                np,
                "NULL without_ids with a non-zero length"
            );
            assert_eq!(
                mid_ecs_world_archetypes_matching_static(
                    world,
                    std::ptr::null(),
                    0,
                    std::ptr::null(),
                    0,
                    std::ptr::null(),
                    0,
                    std::ptr::null_mut(),
                    0
                ),
                6,
                "(NULL, 0) is a valid empty list: every archetype matches"
            );
            assert_eq!(
                mid_ecs_world_archetypes_matching_static(
                    world,
                    ids.as_ptr(),
                    1,
                    std::ptr::null(),
                    0,
                    std::ptr::null(),
                    1,
                    std::ptr::null_mut(),
                    0
                ),
                np,
                "NULL any_of_ids with a non-zero length"
            );
            mid_ecs_world_free(world);
        }
    }

    #[test]
    fn matching_static_any_of_matches_the_typed_or_filter() {
        let world_ptr = mid_ecs_test_filter_fixture_world_new();
        let h = static_id(world_ptr, "FfiHealthStatic");
        let a = static_id(world_ptr, "FfiFlagA");
        let b = static_id(world_ptr, "FfiFlagB");
        // SAFETY: `world_ptr` is a live handle for this whole test.
        let world = unsafe { &(*world_ptr).0 };

        // any_of {A, B}: e2 (A) and e3 (A and B), not e1 (neither).
        let via_ffi = entities_via_ffi(world_ptr, h, &[h], &[], &[a, b]);
        let via_typed = typed_entities::<Or<(With<MidEcsTestFlagA>, With<MidEcsTestFlagB>)>>(world);
        assert_eq!(via_ffi, via_typed);
        assert_eq!(via_ffi.len(), 2);

        // Empty any_of is "no constraint", matching the plain with/without
        // case exactly.
        assert_eq!(
            matching_ids_any(world_ptr, &[h], &[], &[]),
            matching_ids(world_ptr, &[h], &[])
        );

        // any_of naming only an id nothing has matches nothing, even
        // though with_ids alone would have matched.
        assert!(matching_ids_any(world_ptr, &[h], &[], &[MID_ECS_INVALID_ID]).is_empty());

        // SAFETY: freed exactly once.
        unsafe { mid_ecs_world_free(world_ptr) };
    }

    #[test]
    fn matching_static_bogus_and_contradictory_ids_are_empty_not_errors() {
        let world = mid_ecs_test_filter_fixture_world_new();
        let h = static_id(world, "FfiHealthStatic");

        assert!(matching_ids(world, &[MID_ECS_INVALID_ID], &[]).is_empty());
        assert!(matching_ids(world, &[h], &[h]).is_empty());
        assert_eq!(
            matching_ids(world, &[h], &[MID_ECS_INVALID_ID]),
            matching_ids(world, &[h], &[]),
            "an id nothing has registered excludes nothing"
        );

        // SAFETY: freed exactly once.
        unsafe { mid_ecs_world_free(world) };
    }

    // ── Resources through the C surface ─────────────────────────────

    fn resource_id(world: *const MidEcsWorld, name: &str) -> u32 {
        let name = std::ffi::CString::new(name).unwrap();
        // SAFETY: `world` is a live handle and `name` a valid C string.
        unsafe { mid_ecs_world_lookup_ffi_resource_id(world, name.as_ptr()) }
    }

    fn resource_span(world: *const MidEcsWorld, id: u32) -> (i32, FfiSpan) {
        let mut span = empty_span();
        // SAFETY: `world` is a live handle and `span` is valid.
        let status = unsafe { mid_ecs_world_resource_raw_span(world, id, &mut span) };
        (status, span)
    }

    fn write_time(world: *mut MidEcsWorld, id: u32, delta: f32, frame: u32) -> i32 {
        let value = MidEcsTestTime { delta, frame };
        let bytes = zerocopy::IntoBytes::as_bytes(&value);
        // SAFETY: `world` is a live handle; `bytes` is valid for its length.
        unsafe { mid_ecs_world_resource_write(world, id, bytes.as_ptr(), bytes.len()) }
    }

    #[test]
    fn resource_lookup_resolves_registered_names_and_rejects_the_rest() {
        let world = mid_ecs_test_resource_fixture_world_new();
        assert_ne!(resource_id(world, "FfiTime"), MID_ECS_INVALID_ID);
        assert_ne!(resource_id(world, "FfiGravity"), MID_ECS_INVALID_ID);
        assert_ne!(
            resource_id(world, "FfiTime"),
            resource_id(world, "FfiGravity")
        );
        assert_eq!(resource_id(world, "Nope"), MID_ECS_INVALID_ID);
        assert_eq!(resource_id(std::ptr::null(), "FfiTime"), MID_ECS_INVALID_ID);
        // SAFETY: freed exactly once; NULL name is the case under test.
        unsafe {
            assert_eq!(
                mid_ecs_world_lookup_ffi_resource_id(world, std::ptr::null()),
                MID_ECS_INVALID_ID
            );
            mid_ecs_world_free(world);
        }
    }

    #[test]
    fn resource_span_reads_the_inserted_value_and_is_empty_for_an_absent_one() {
        let world = mid_ecs_test_resource_fixture_world_new();
        let time = resource_id(world, "FfiTime");
        let gravity = resource_id(world, "FfiGravity");

        let (status, span) = resource_span(world, time);
        assert_eq!(status, MidEcsStatus::Ok as i32);
        assert_eq!(
            (span.count, span.stride),
            (1, std::mem::size_of::<MidEcsTestTime>())
        );
        // SAFETY: the span points at the live value; nothing has changed it.
        let seen = unsafe { &*(span.ptr as *const MidEcsTestTime) };
        assert_eq!((seen.delta, seen.frame), (0.016, 7));

        let (status, span) = resource_span(world, gravity);
        assert_eq!(status, MidEcsStatus::Ok as i32, "registered, not inserted");
        assert_eq!(span.count, 0);

        assert_eq!(
            resource_span(world, 999).0,
            MidEcsStatus::NotFound as i32,
            "an id that was never issued"
        );
        // SAFETY: freed exactly once.
        unsafe { mid_ecs_world_free(world) };
    }

    #[test]
    fn resource_write_updates_in_place_and_the_old_span_sees_it() {
        let world = mid_ecs_test_resource_fixture_world_new();
        let time = resource_id(world, "FfiTime");
        let (_, before) = resource_span(world, time);

        assert_eq!(write_time(world, time, 0.033, 8), MidEcsStatus::Ok as i32);

        let (_, after) = resource_span(world, time);
        assert_eq!(before.ptr, after.ptr, "written in place, same address");
        // SAFETY: `before.ptr` is the live value's address.
        let seen = unsafe { &*(before.ptr as *const MidEcsTestTime) };
        assert_eq!((seen.delta, seen.frame), (0.033, 8));
        // SAFETY: `world` is live; the typed API agrees.
        let typed = unsafe { (*world).0.get_resource::<MidEcsTestTime>().unwrap() };
        assert_eq!((typed.delta, typed.frame), (0.033, 8));

        // SAFETY: freed exactly once.
        unsafe { mid_ecs_world_free(world) };
    }

    #[test]
    fn resource_write_inserts_an_absent_resource() {
        let world = mid_ecs_test_resource_fixture_world_new();
        let gravity = resource_id(world, "FfiGravity");
        let bytes = 9.8f32.to_ne_bytes();
        // SAFETY: `world` is live; `bytes` is valid for 4 bytes.
        let status =
            unsafe { mid_ecs_world_resource_write(world, gravity, bytes.as_ptr(), bytes.len()) };
        assert_eq!(status, MidEcsStatus::Ok as i32);

        let (_, span) = resource_span(world, gravity);
        assert_eq!(span.count, 1);
        // SAFETY: `world` is live.
        let typed = unsafe { (*world).0.get_resource::<MidEcsTestGravity>().unwrap() };
        assert_eq!(typed.g, 9.8);
        // SAFETY: freed exactly once.
        unsafe { mid_ecs_world_free(world) };
    }

    #[test]
    fn resource_write_size_mismatch_changes_nothing() {
        let world = mid_ecs_test_resource_fixture_world_new();
        let time = resource_id(world, "FfiTime");
        let bytes = [0u8; 12];
        // SAFETY: `world` is live; `bytes` is valid for the lengths passed.
        unsafe {
            for len in [0usize, 4, 7, 9, 12] {
                assert_eq!(
                    mid_ecs_world_resource_write(world, time, bytes.as_ptr(), len),
                    MidEcsStatus::SizeMismatch as i32,
                    "len {len}"
                );
            }
            assert_eq!(MidEcsStatus::SizeMismatch as i32, -6);
            let typed = (*world).0.get_resource::<MidEcsTestTime>().unwrap();
            assert_eq!((typed.delta, typed.frame), (0.016, 7));
            mid_ecs_world_free(world);
        }
    }

    #[test]
    fn resource_remove_then_span_and_second_remove() {
        let world = mid_ecs_test_resource_fixture_world_new();
        let time = resource_id(world, "FfiTime");

        // SAFETY: `world` is live.
        unsafe {
            assert_eq!(
                mid_ecs_world_resource_remove(world, time),
                MidEcsStatus::Ok as i32
            );
            assert_eq!(resource_span(world, time).1.count, 0);
            assert!((*world).0.get_resource::<MidEcsTestTime>().is_none());
            assert_eq!(
                mid_ecs_world_resource_remove(world, time),
                MidEcsStatus::NotFound as i32,
                "already absent"
            );
            assert_eq!(
                mid_ecs_world_resource_remove(world, 999),
                MidEcsStatus::NotFound as i32,
                "never issued"
            );
            // Writing again brings it back.
            assert_eq!(write_time(world, time, 1.0, 1), MidEcsStatus::Ok as i32);
            assert_eq!(resource_span(world, time).1.count, 1);
            mid_ecs_world_free(world);
        }
    }

    #[test]
    fn resource_functions_null_and_unknown_id_cases() {
        let world = mid_ecs_test_resource_fixture_world_new();
        let time = resource_id(world, "FfiTime");
        let np = MidEcsStatus::NullPointer as i32;
        let byte = [0u8; 8];

        // SAFETY: every pointer is valid for what the callee may do with
        // it, or NULL where that's the case under test.
        unsafe {
            assert_eq!(resource_span(std::ptr::null(), time).0, np);
            assert_eq!(
                mid_ecs_world_resource_raw_span(world, time, std::ptr::null_mut()),
                np
            );
            assert_eq!(
                mid_ecs_world_resource_write(std::ptr::null_mut(), time, byte.as_ptr(), 8),
                np
            );
            assert_eq!(
                mid_ecs_world_resource_write(world, time, std::ptr::null(), 8),
                np,
                "NULL bytes with a non-zero length"
            );
            assert_eq!(
                mid_ecs_world_resource_remove(std::ptr::null_mut(), time),
                np
            );
            assert_eq!(
                mid_ecs_world_resource_write(world, 999, byte.as_ptr(), 8),
                MidEcsStatus::NotFound as i32
            );
            mid_ecs_world_free(world);
        }
    }

    // ── Change-detection FFI: added/changed rows ────────────────────

    /// The count-then-fill idiom for one `(archetype, component)` pair.
    fn change_rows(
        world: *const MidEcsWorld,
        archetype: u32,
        component: u32,
        last_run: u32,
        added: bool,
    ) -> Vec<u32> {
        let call = |buf: *mut u32, cap: usize| -> i32 {
            // SAFETY: `world` is a live handle; `buf` is NULL or valid
            // for `cap` elements.
            unsafe {
                if added {
                    mid_ecs_world_static_component_added_rows(
                        world, archetype, component, last_run, buf, cap,
                    )
                } else {
                    mid_ecs_world_static_component_changed_rows(
                        world, archetype, component, last_run, buf, cap,
                    )
                }
            }
        };
        let count = call(std::ptr::null_mut(), 0);
        assert!(count >= 0, "count query failed with status {count}");
        let mut rows = vec![u32::MAX; count as usize];
        let written = call(rows.as_mut_ptr(), rows.len());
        assert_eq!(written, count);
        rows
    }

    fn entity_ids_of(world: *const MidEcsWorld, archetype: u32, component: u32) -> Vec<u64> {
        // SAFETY: `world` is a live handle; NULL buffer asks for the count.
        let n = unsafe {
            mid_ecs_world_static_component_entity_ids(
                world,
                archetype,
                component,
                std::ptr::null_mut(),
                0,
            )
        };
        assert!(n >= 0, "entity id count failed with status {n}");
        let mut ids = vec![0u64; n as usize];
        // SAFETY: `ids` is valid for `ids.len()` elements.
        let written = unsafe {
            mid_ecs_world_static_component_entity_ids(
                world,
                archetype,
                component,
                ids.as_mut_ptr(),
                ids.len(),
            )
        };
        assert_eq!(written, n);
        ids
    }

    /// Every entity the change rows pick out, found the way a C caller
    /// would: enumerate archetypes holding `component`, take each one's
    /// row list, map the rows through `entity_ids`. Sorted.
    fn changed_entities_via_ffi(
        world: *const MidEcsWorld,
        component: u32,
        last_run: u32,
        added: bool,
    ) -> Vec<u64> {
        let mut out = Vec::new();
        for archetype in matching_ids(world, &[component], &[]) {
            let ids = entity_ids_of(world, archetype, component);
            for row in change_rows(world, archetype, component, last_run, added) {
                out.push(ids[row as usize]);
            }
        }
        out.sort_unstable();
        out
    }

    fn typed_changed_entities(w: &World, tracker: &crate::ChangeTracker, added: bool) -> Vec<u64> {
        let mut v: Vec<u64> = if added {
            w.query_added::<MidEcsTestHealthStatic>(tracker)
                .map(|(e, _)| e.as_ffi())
                .collect()
        } else {
            w.query_changed::<MidEcsTestHealthStatic>(tracker)
                .map(|(e, _)| e.as_ffi())
                .collect()
        };
        v.sort_unstable();
        v
    }

    fn health_world(n: u32) -> (*mut MidEcsWorld, Vec<crate::Entity>) {
        let mut w = World::new();
        w.register_ffi_static_component::<MidEcsTestHealthStatic>("FfiHealthStatic");
        let entities: Vec<_> = (0..n)
            .map(|hp| {
                let e = w.spawn();
                w.insert_static(e, MidEcsTestHealthStatic { hp });
                e
            })
            .collect();
        w.increment_change_tick();
        (MidEcsWorld::from_world(w), entities)
    }

    fn rust_side<'a>(handle: *mut MidEcsWorld) -> &'a mut World {
        // SAFETY: every caller passes a live handle and drops the
        // reference before the next FFI call.
        unsafe { &mut *handle }.world_mut()
    }

    #[test]
    fn change_tick_functions_round_trip_and_handle_null() {
        let world = mid_ecs_world_new();
        // SAFETY: `world` is a live handle, freed exactly once below.
        unsafe {
            assert_eq!(mid_ecs_world_change_tick(world), 1);
            assert_eq!(mid_ecs_world_increment_change_tick(world), 2);
            assert_eq!(mid_ecs_world_increment_change_tick(world), 3);
            assert_eq!(mid_ecs_world_change_tick(world), 3);
            assert_eq!(mid_ecs_world_change_tick(std::ptr::null()), 0);
            assert_eq!(mid_ecs_world_increment_change_tick(std::ptr::null_mut()), 0);
            mid_ecs_world_free(world);
        }
    }

    #[test]
    fn added_and_changed_rows_match_the_typed_queries_step_by_step() {
        let (handle, es) = health_world(6);
        let h = static_id(handle, "FfiHealthStatic");
        let mut tracker = crate::ChangeTracker::new();
        let mut last_run = 0u32;

        // A fresh tracker (and `last_run == 0`) sees every entity.
        let all: Vec<u64> = {
            let mut v: Vec<u64> = es.iter().map(|e| e.as_ffi()).collect();
            v.sort_unstable();
            v
        };
        for added in [true, false] {
            assert_eq!(changed_entities_via_ffi(handle, h, last_run, added), all);
            assert_eq!(
                changed_entities_via_ffi(handle, h, last_run, added),
                typed_changed_entities(rust_side(handle), &tracker, added)
            );
        }

        // Having read the tick, nothing is new.
        tracker.update(rust_side(handle));
        // SAFETY: `handle` is live.
        last_run = unsafe { mid_ecs_world_change_tick(handle) };
        for added in [true, false] {
            assert!(changed_entities_via_ffi(handle, h, last_run, added).is_empty());
        }

        // A step: mutate two, add one.
        // SAFETY: `handle` is live.
        unsafe { mid_ecs_world_increment_change_tick(handle) };
        let fresh = {
            let w = rust_side(handle);
            w.get_static_mut::<MidEcsTestHealthStatic>(es[1])
                .unwrap()
                .hp = 100;
            w.get_static_mut::<MidEcsTestHealthStatic>(es[4])
                .unwrap()
                .hp = 400;
            let fresh = w.spawn();
            w.insert_static(fresh, MidEcsTestHealthStatic { hp: 6 });
            fresh
        };
        assert_eq!(
            changed_entities_via_ffi(handle, h, last_run, true),
            vec![fresh.as_ffi()],
            "a mutation is not an addition"
        );
        let mut want_changed = vec![es[1].as_ffi(), es[4].as_ffi(), fresh.as_ffi()];
        want_changed.sort_unstable();
        assert_eq!(
            changed_entities_via_ffi(handle, h, last_run, false),
            want_changed
        );
        for added in [true, false] {
            assert_eq!(
                changed_entities_via_ffi(handle, h, last_run, added),
                typed_changed_entities(rust_side(handle), &tracker, added)
            );
        }

        // SAFETY: freed exactly once.
        unsafe { mid_ecs_world_free(handle) };
    }

    #[test]
    fn change_rows_stay_aligned_with_entity_ids_after_a_swap_remove() {
        // Despawning row 0 moves the table's last row into it. The
        // entity now living in row 0 must carry *its own* ticks, not the
        // despawned entity's. Mutate exactly the entity that ends up in
        // the freed slot, so a misaligned tick column reports the wrong
        // entity (or none).
        let (handle, es) = health_world(4);
        let h = static_id(handle, "FfiHealthStatic");
        // SAFETY: `handle` is live.
        let last_run = unsafe { mid_ecs_world_change_tick(handle) };
        // SAFETY: `handle` is live.
        unsafe { mid_ecs_world_increment_change_tick(handle) };
        {
            let w = rust_side(handle);
            w.get_static_mut::<MidEcsTestHealthStatic>(es[3])
                .unwrap()
                .hp = 333;
            assert!(w.despawn(es[0]));
        }
        let archetype = matching_ids(handle, &[h], &[])
            .into_iter()
            .find(|&a| !entity_ids_of(handle, a, h).is_empty())
            .expect("one populated archetype");
        let ids = entity_ids_of(handle, archetype, h);
        assert_eq!(ids.len(), 3);
        assert_eq!(ids[0], es[3].as_ffi(), "es[3] was swapped into row 0");
        assert_eq!(
            change_rows(handle, archetype, h, last_run, false),
            vec![0],
            "only the mutated entity, now at row 0"
        );
        assert!(change_rows(handle, archetype, h, last_run, true).is_empty());
        // SAFETY: freed exactly once.
        unsafe { mid_ecs_world_free(handle) };
    }

    #[test]
    fn change_rows_survive_migration_into_another_archetype() {
        let (handle, es) = health_world(3);
        let h = static_id(handle, "FfiHealthStatic");
        // SAFETY: `handle` is live.
        let last_run = unsafe { mid_ecs_world_change_tick(handle) };
        // SAFETY: `handle` is live.
        unsafe { mid_ecs_world_increment_change_tick(handle) };
        {
            let w = rust_side(handle);
            // Gaining an unrelated component migrates es[1]; Health's
            // ticks must move with it unchanged.
            assert!(w.insert_static(es[1], MidEcsTestFlagA { v: 1 }));
            w.get_static_mut::<MidEcsTestHealthStatic>(es[2])
                .unwrap()
                .hp = 9;
        }
        for added in [true, false] {
            assert_eq!(
                changed_entities_via_ffi(handle, h, last_run, added).contains(&es[1].as_ffi()),
                false,
                "an unrelated structural change is neither added nor changed"
            );
        }
        assert_eq!(
            changed_entities_via_ffi(handle, h, last_run, false),
            vec![es[2].as_ffi()]
        );
        // SAFETY: freed exactly once.
        unsafe { mid_ecs_world_free(handle) };
    }

    #[test]
    fn change_rows_buffer_idiom() {
        let (handle, _es) = health_world(5);
        let h = static_id(handle, "FfiHealthStatic");
        let archetype = matching_ids(handle, &[h], &[])
            .into_iter()
            .find(|&a| !entity_ids_of(handle, a, h).is_empty())
            .unwrap();
        // SAFETY (all calls below): `handle` is live, buffers valid for
        // the capacity passed.
        unsafe {
            assert_eq!(
                mid_ecs_world_static_component_added_rows(
                    handle,
                    archetype,
                    h,
                    0,
                    std::ptr::null_mut(),
                    0
                ),
                5,
                "NULL buffer queries the count"
            );
            let mut small = [0xDEADu32; 2];
            assert_eq!(
                mid_ecs_world_static_component_added_rows(
                    handle,
                    archetype,
                    h,
                    0,
                    small.as_mut_ptr(),
                    small.len()
                ),
                MidEcsStatus::BufferTooSmall as i32
            );
            assert_eq!(small, [0xDEAD, 0xDEAD], "nothing written on BufferTooSmall");
            let mut exact = [0u32; 5];
            assert_eq!(
                mid_ecs_world_static_component_added_rows(
                    handle,
                    archetype,
                    h,
                    0,
                    exact.as_mut_ptr(),
                    exact.len()
                ),
                5
            );
            assert_eq!(exact, [0, 1, 2, 3, 4], "ascending row order");
            mid_ecs_world_free(handle);
        }
    }

    #[test]
    fn change_rows_not_found_and_zero_row_cases() {
        let mut w = World::new();
        w.register_ffi_static_component::<MidEcsTestHealthStatic>("FfiHealthStatic");
        w.register_ffi_static_component::<MidEcsTestFlagA>("FfiFlagA");
        w.register_ffi_static_component::<MidEcsTestFlagB>("FfiFlagB");
        let e = w.spawn();
        // Leaves the zero-row intermediate {FlagB} behind.
        w.insert_bundle(
            e,
            (MidEcsTestFlagB { v: 1 }, MidEcsTestHealthStatic { hp: 1 }),
        );
        let handle = MidEcsWorld::from_world(w);
        let health = static_id(handle, "FfiHealthStatic");
        let flag_b = static_id(handle, "FfiFlagB");
        let flag_a = static_id(handle, "FfiFlagA");

        let mut zero_row = None;
        let mut populated = None;
        for a in matching_ids(handle, &[flag_b], &[]) {
            if entity_ids_of(handle, a, flag_b).is_empty() {
                zero_row = Some(a);
            } else {
                populated = Some(a);
            }
        }
        let zero_row = zero_row.expect("insert_bundle leaves {FlagB} behind");
        let populated = populated.unwrap();

        // The zero-row archetype's signature holds FlagB: Ok, empty.
        assert!(change_rows(handle, zero_row, flag_b, 0, true).is_empty());
        assert!(change_rows(handle, zero_row, flag_b, 0, false).is_empty());

        let nf = MidEcsStatus::NotFound as i32;
        // SAFETY: `handle` is live; every pointer is NULL or valid.
        unsafe {
            // Health is not in the zero-row archetype's signature.
            assert_eq!(
                mid_ecs_world_static_component_changed_rows(
                    handle,
                    zero_row,
                    health,
                    0,
                    std::ptr::null_mut(),
                    0
                ),
                nf
            );
            // FlagA is registered but in no archetype's signature here.
            assert_eq!(
                mid_ecs_world_static_component_added_rows(
                    handle,
                    populated,
                    flag_a,
                    0,
                    std::ptr::null_mut(),
                    0
                ),
                nf
            );
            // An id that was never registered, and an archetype that
            // never existed.
            assert_eq!(
                mid_ecs_world_static_component_added_rows(
                    handle,
                    populated,
                    9999,
                    0,
                    std::ptr::null_mut(),
                    0
                ),
                nf
            );
            assert_eq!(
                mid_ecs_world_static_component_added_rows(
                    handle,
                    9999,
                    health,
                    0,
                    std::ptr::null_mut(),
                    0
                ),
                nf
            );
            mid_ecs_world_free(handle);
        }
    }

    #[test]
    fn change_rows_null_world_is_a_null_pointer_error() {
        // SAFETY: NULL world is the documented error case.
        unsafe {
            assert_eq!(
                mid_ecs_world_static_component_added_rows(
                    std::ptr::null(),
                    0,
                    0,
                    0,
                    std::ptr::null_mut(),
                    0
                ),
                MidEcsStatus::NullPointer as i32
            );
            assert_eq!(
                mid_ecs_world_static_component_changed_rows(
                    std::ptr::null(),
                    0,
                    0,
                    0,
                    std::ptr::null_mut(),
                    0
                ),
                MidEcsStatus::NullPointer as i32
            );
            assert_eq!(
                mid_ecs_test_change_fixture_mutate(std::ptr::null_mut()),
                MidEcsStatus::NullPointer as i32
            );
        }
    }

    #[test]
    fn change_fixture_scripted_sequence_matches_what_test_c_asserts() {
        let world = mid_ecs_test_change_fixture_world_new();
        let h = static_id(world, "FfiHealthStatic");
        let archetype = matching_ids(world, &[h], &[])
            .into_iter()
            .find(|&a| !entity_ids_of(world, a, h).is_empty())
            .expect("one populated archetype");

        assert_eq!(change_rows(world, archetype, h, 0, true), vec![0, 1, 2]);
        assert_eq!(change_rows(world, archetype, h, 0, false), vec![0, 1, 2]);

        // SAFETY: `world` is live.
        let last_run = unsafe { mid_ecs_world_change_tick(world) };
        assert_eq!(last_run, 2);
        assert!(change_rows(world, archetype, h, last_run, true).is_empty());
        assert!(change_rows(world, archetype, h, last_run, false).is_empty());

        // SAFETY: `world` is live, and is the fixture world.
        unsafe {
            assert_eq!(mid_ecs_world_increment_change_tick(world), 3);
            assert_eq!(
                mid_ecs_test_change_fixture_mutate(world),
                MidEcsStatus::Ok as i32
            );
        }
        assert_eq!(change_rows(world, archetype, h, last_run, true), vec![3]);
        assert_eq!(
            change_rows(world, archetype, h, last_run, false),
            vec![1, 3]
        );

        // The rows index the span the same call sequence would read.
        let mut span = empty_span();
        // SAFETY: `world` is live, `span` is valid.
        let status =
            unsafe { mid_ecs_world_static_component_raw_span(world, archetype, h, &mut span) };
        assert_eq!(status, MidEcsStatus::Ok as i32);
        assert_eq!(span.count, 4);
        let hp = |row: usize| {
            // SAFETY: `row < span.count`, the span points at
            // `MidEcsTestHealthStatic` elements `stride` bytes apart.
            unsafe { (*(span.ptr.add(row * span.stride) as *const MidEcsTestHealthStatic)).hp }
        };
        assert_eq!((hp(1), hp(3)), (22, 4));

        // A second mutate finds no `hp == 2` any more.
        // SAFETY: `world` is live.
        unsafe {
            assert_eq!(
                mid_ecs_test_change_fixture_mutate(world),
                MidEcsStatus::NotFound as i32
            );
            mid_ecs_world_free(world);
        }
    }

    #[test]
    fn bulk_mut_query_writes_are_visible_to_the_c_changed_rows() {
        // The reason `Mut` exists: before it, only `get_static_mut` could
        // mark a value changed, so a bulk write was invisible to Changed
        // from C as well as from Rust.
        let (handle, es) = health_world(6);
        let h = static_id(handle, "FfiHealthStatic");
        // SAFETY: `handle` is live.
        let last_run = unsafe { mid_ecs_world_change_tick(handle) };
        // SAFETY: `handle` is live.
        unsafe { mid_ecs_world_increment_change_tick(handle) };
        {
            let w = rust_side(handle);
            for (e, mut hp) in w.query_static_mut::<MidEcsTestHealthStatic>() {
                if e == es[1] || e == es[4] {
                    hp.hp += 1000;
                }
            }
        }
        let mut want = vec![es[1].as_ffi(), es[4].as_ffi()];
        want.sort_unstable();
        assert_eq!(changed_entities_via_ffi(handle, h, last_run, false), want);
        assert!(changed_entities_via_ffi(handle, h, last_run, true).is_empty());
        // SAFETY: freed exactly once.
        unsafe { mid_ecs_world_free(handle) };
    }

    // ---- command queue ----

    #[test]
    fn commands_new_free_round_trips_and_free_null_is_a_no_op() {
        let commands = mid_ecs_commands_new();
        assert!(!commands.is_null());
        // SAFETY: `commands` is non-null, just created, not yet freed;
        // NULL is the documented safe-no-op case.
        unsafe {
            assert_eq!(mid_ecs_commands_len(commands), 0);
            assert_eq!(mid_ecs_commands_spawn_count(commands), 0);
            mid_ecs_commands_free(commands);
            mid_ecs_commands_free(std::ptr::null_mut());
        }
    }

    #[test]
    fn commands_spawn_applies_only_at_apply_and_returns_the_entities() {
        let world = mid_ecs_world_new();
        let commands = mid_ecs_commands_new();
        // SAFETY: both handles non-null and not freed for this block; `out`
        // is valid for the 3 elements the apply may write.
        unsafe {
            for _ in 0..3 {
                assert_eq!(mid_ecs_commands_spawn(commands), MidEcsStatus::Ok as i32);
            }
            assert_eq!(mid_ecs_commands_len(commands), 3);
            assert_eq!(mid_ecs_commands_spawn_count(commands), 3);
            assert_eq!(mid_ecs_world_entity_count(world), 0, "nothing before apply");

            let mut out = [0u64; 3];
            assert_eq!(
                mid_ecs_commands_apply(commands, world, out.as_mut_ptr(), 3),
                3
            );
            assert_eq!(mid_ecs_world_entity_count(world), 3);
            for e in out {
                assert!(mid_ecs_world_is_alive(world, e));
            }
            assert!(out[0] != out[1] && out[1] != out[2] && out[0] != out[2]);
            assert_eq!(mid_ecs_commands_len(commands), 0);
            assert_eq!(mid_ecs_commands_spawn_count(commands), 0);

            mid_ecs_commands_free(commands);
            mid_ecs_world_free(world);
        }
    }

    #[test]
    fn commands_apply_writes_only_the_spawned_prefix_of_a_roomy_buffer() {
        let world = mid_ecs_world_new();
        let commands = mid_ecs_commands_new();
        // SAFETY: handles non-null and live; `out` valid for 5 elements.
        unsafe {
            mid_ecs_commands_spawn(commands);
            mid_ecs_commands_spawn(commands);
            let mut out = [u64::MAX; 5];
            assert_eq!(
                mid_ecs_commands_apply(commands, world, out.as_mut_ptr(), 5),
                2
            );
            assert!(mid_ecs_world_is_alive(world, out[0]));
            assert!(mid_ecs_world_is_alive(world, out[1]));
            assert_eq!(&out[2..], &[u64::MAX; 3], "the rest is untouched");
            mid_ecs_commands_free(commands);
            mid_ecs_world_free(world);
        }
    }

    #[test]
    fn commands_apply_with_a_too_small_buffer_applies_nothing_and_a_retry_works() {
        let world = mid_ecs_world_new();
        let commands = mid_ecs_commands_new();
        // SAFETY: handles non-null and live; `out` valid for 5 elements, of
        // which the calls below are told 2, then 3.
        unsafe {
            let victim = mid_ecs_world_spawn(world);
            for _ in 0..3 {
                mid_ecs_commands_spawn(commands);
            }
            mid_ecs_commands_despawn(commands, victim);
            assert_eq!(mid_ecs_commands_len(commands), 4);
            assert_eq!(
                mid_ecs_commands_spawn_count(commands),
                3,
                "spawn_count is the spawns only, not every command"
            );
            let mut out = [u64::MAX; 5];

            let status = mid_ecs_commands_apply(commands, world, out.as_mut_ptr(), 2);
            assert_eq!(status, MidEcsStatus::BufferTooSmall as i32);
            assert_eq!(mid_ecs_world_entity_count(world), 1, "world untouched");
            assert!(mid_ecs_world_is_alive(world, victim), "despawn not run");
            assert_eq!(mid_ecs_commands_len(commands), 4, "queue untouched");
            assert_eq!(out, [u64::MAX; 5], "buffer untouched");

            assert_eq!(
                mid_ecs_commands_apply(commands, world, out.as_mut_ptr(), 3),
                3
            );
            assert!(!mid_ecs_world_is_alive(world, victim));
            assert_eq!(mid_ecs_world_entity_count(world), 3);

            mid_ecs_commands_free(commands);
            mid_ecs_world_free(world);
        }
    }

    #[test]
    fn commands_apply_null_buffer_is_too_small_with_spawns_and_fine_without() {
        let world = mid_ecs_world_new();
        let commands = mid_ecs_commands_new();
        // SAFETY: handles non-null and live; NULL `out_entities` is the case
        // under test and is documented as allowed only with no spawns.
        unsafe {
            let victim = mid_ecs_world_spawn(world);
            mid_ecs_commands_spawn(commands);
            let status = mid_ecs_commands_apply(commands, world, std::ptr::null_mut(), 0);
            assert_eq!(status, MidEcsStatus::BufferTooSmall as i32);
            assert_eq!(mid_ecs_world_entity_count(world), 1);
            // A NULL buffer is never written through, whatever capacity the
            // caller claims for it.
            let status = mid_ecs_commands_apply(commands, world, std::ptr::null_mut(), 4);
            assert_eq!(status, MidEcsStatus::BufferTooSmall as i32);
            assert_eq!(mid_ecs_world_entity_count(world), 1);
            assert_eq!(mid_ecs_commands_len(commands), 1, "still queued");

            mid_ecs_commands_clear(commands);
            mid_ecs_commands_despawn(commands, victim);
            assert_eq!(
                mid_ecs_commands_apply(commands, world, std::ptr::null_mut(), 0),
                0
            );
            assert!(!mid_ecs_world_is_alive(world, victim));

            mid_ecs_commands_free(commands);
            mid_ecs_world_free(world);
        }
    }

    #[test]
    fn commands_despawn_runs_at_apply_and_dead_or_bogus_values_are_a_no_op() {
        let world = mid_ecs_world_new();
        let commands = mid_ecs_commands_new();
        // SAFETY: handles non-null and live for this block.
        unsafe {
            let live = mid_ecs_world_spawn(world);
            let dead = mid_ecs_world_spawn(world);
            mid_ecs_world_despawn(world, dead);
            // Queuing is always Ok: liveness is checked when the command runs.
            assert_eq!(
                mid_ecs_commands_despawn(commands, live),
                MidEcsStatus::Ok as i32
            );
            assert_eq!(
                mid_ecs_commands_despawn(commands, dead),
                MidEcsStatus::Ok as i32
            );
            assert_eq!(
                mid_ecs_commands_despawn(commands, u64::MAX),
                MidEcsStatus::Ok as i32
            );
            assert!(mid_ecs_world_is_alive(world, live), "not before apply");
            assert_eq!(
                mid_ecs_commands_apply(commands, world, std::ptr::null_mut(), 0),
                0
            );
            assert!(!mid_ecs_world_is_alive(world, live));
            assert_eq!(mid_ecs_world_entity_count(world), 0);
            mid_ecs_commands_free(commands);
            mid_ecs_world_free(world);
        }
    }

    #[test]
    fn commands_despawn_of_a_stale_handle_spares_the_entity_that_reused_the_slot() {
        let world = mid_ecs_world_new();
        let commands = mid_ecs_commands_new();
        // SAFETY: handles non-null and live for this block.
        unsafe {
            let stale = mid_ecs_world_spawn(world);
            mid_ecs_world_despawn(world, stale);
            let reuser = mid_ecs_world_spawn(world);
            assert_ne!(stale, reuser);
            mid_ecs_commands_despawn(commands, stale);
            mid_ecs_commands_apply(commands, world, std::ptr::null_mut(), 0);
            assert!(mid_ecs_world_is_alive(world, reuser));
            mid_ecs_commands_free(commands);
            mid_ecs_world_free(world);
        }
    }

    #[test]
    fn commands_apply_returns_the_entities_a_direct_spawn_would_have_made() {
        // Two identical worlds, each with two freed slots. Applying two
        // queued spawns to one must hand back the same values as spawning
        // twice directly in the other: the queue adds no allocator behaviour
        // of its own, and the buffer is in spawn order.
        let queued = mid_ecs_world_new();
        let direct = mid_ecs_world_new();
        let commands = mid_ecs_commands_new();
        // SAFETY: handles non-null and live; `out` valid for 2 elements.
        unsafe {
            for w in [queued, direct] {
                let a = mid_ecs_world_spawn(w);
                let b = mid_ecs_world_spawn(w);
                mid_ecs_world_despawn(w, a);
                mid_ecs_world_despawn(w, b);
            }
            mid_ecs_commands_spawn(commands);
            mid_ecs_commands_spawn(commands);
            let mut out = [0u64; 2];
            mid_ecs_commands_apply(commands, queued, out.as_mut_ptr(), 2);
            let first = mid_ecs_world_spawn(direct);
            let second = mid_ecs_world_spawn(direct);
            assert_eq!(out, [first, second]);
            mid_ecs_commands_free(commands);
            mid_ecs_world_free(queued);
            mid_ecs_world_free(direct);
        }
    }

    #[test]
    fn commands_clear_drops_pending_unrun_and_a_second_apply_is_empty() {
        let world = mid_ecs_world_new();
        let commands = mid_ecs_commands_new();
        // SAFETY: handles non-null and live for this block.
        unsafe {
            mid_ecs_commands_spawn(commands);
            mid_ecs_commands_spawn(commands);
            assert_eq!(mid_ecs_commands_clear(commands), MidEcsStatus::Ok as i32);
            assert_eq!(mid_ecs_commands_len(commands), 0);
            assert_eq!(mid_ecs_commands_spawn_count(commands), 0);
            assert_eq!(
                mid_ecs_commands_apply(commands, world, std::ptr::null_mut(), 0),
                0
            );
            assert_eq!(mid_ecs_world_entity_count(world), 0);

            mid_ecs_commands_spawn(commands);
            let mut out = [0u64; 1];
            assert_eq!(
                mid_ecs_commands_apply(commands, world, out.as_mut_ptr(), 1),
                1
            );
            assert!(
                mid_ecs_world_is_alive(world, out[0]),
                "a single spawn is written out too"
            );
            assert_eq!(
                mid_ecs_commands_apply(commands, world, std::ptr::null_mut(), 0),
                0,
                "a second apply has nothing left to run"
            );
            assert_eq!(mid_ecs_world_entity_count(world), 1);
            mid_ecs_commands_free(commands);
            mid_ecs_world_free(world);
        }
    }

    #[test]
    fn commands_null_arguments_are_safe_everywhere() {
        let null_cmds: *mut MidEcsCommands = std::ptr::null_mut();
        let null_world: *mut MidEcsWorld = std::ptr::null_mut();
        let world = mid_ecs_world_new();
        let commands = mid_ecs_commands_new();
        let null = MidEcsStatus::NullPointer as i32;
        // SAFETY: NULL is the documented case for each call; the live
        // handles are valid and freed at the end.
        unsafe {
            assert_eq!(mid_ecs_commands_len(null_cmds), 0);
            assert_eq!(mid_ecs_commands_spawn_count(null_cmds), 0);
            assert_eq!(mid_ecs_commands_clear(null_cmds), null);
            assert_eq!(mid_ecs_commands_spawn(null_cmds), null);
            assert_eq!(mid_ecs_commands_despawn(null_cmds, 1), null);
            assert_eq!(
                mid_ecs_commands_apply(null_cmds, world, std::ptr::null_mut(), 0),
                null
            );
            assert_eq!(
                mid_ecs_commands_apply(commands, null_world, std::ptr::null_mut(), 0),
                null
            );
            mid_ecs_commands_free(commands);
            mid_ecs_world_free(world);
        }
    }

    // ---- writing component data from C ----

    /// The write fixture, decoded the way a C caller would: component ids by
    /// name, its two `Health` archetypes told apart by row count, and the
    /// entities in each.
    struct WriteFixture {
        world: *mut MidEcsWorld,
        health: u32,
        flag_a: u32,
        flag_b: u32,
        /// `{Health}`: two rows.
        plain: u32,
        plain_entities: Vec<u64>,
        /// `{Health, FlagA}`: one row.
        flagged: u32,
        flagged_entity: u64,
    }

    fn write_fixture() -> WriteFixture {
        let world = mid_ecs_test_write_fixture_world_new();
        let health = static_id(world, "FfiHealthStatic");
        let flag_a = static_id(world, "FfiFlagA");
        let flag_b = static_id(world, "FfiFlagB");
        let archetypes = matching_ids(world, &[health], &[]);
        assert_eq!(archetypes.len(), 2);
        let (mut plain, mut flagged) = (None, None);
        for archetype in archetypes {
            let mut span = empty_span();
            // SAFETY: `world` is live, `span` is valid.
            let status = unsafe {
                mid_ecs_world_static_component_raw_span(world, archetype, health, &mut span)
            };
            assert_eq!(status, MidEcsStatus::Ok as i32);
            match span.count {
                2 => plain = Some(archetype),
                1 => flagged = Some(archetype),
                other => panic!("unexpected row count {other}"),
            }
        }
        let (plain, flagged) = (plain.unwrap(), flagged.unwrap());
        WriteFixture {
            world,
            health,
            flag_a,
            flag_b,
            plain,
            plain_entities: entity_ids_of(world, plain, health),
            flagged,
            flagged_entity: entity_ids_of(world, flagged, health)[0],
        }
    }

    fn hp_values(world: *mut MidEcsWorld) -> Vec<u32> {
        let mut v: Vec<u32> = rust_side(world)
            .query_static::<MidEcsTestHealthStatic>()
            .map(|(_, h)| h.hp)
            .collect();
        v.sort_unstable();
        v
    }

    fn sorted(mut v: Vec<u64>) -> Vec<u64> {
        v.sort_unstable();
        v
    }

    fn tick_now_and_advance(world: *mut MidEcsWorld) -> u32 {
        // SAFETY: `world` is a live handle.
        let last_run = unsafe { mid_ecs_world_change_tick(world) };
        // SAFETY: `world` is a live handle.
        unsafe { mid_ecs_world_increment_change_tick(world) };
        last_run
    }

    #[test]
    fn raw_span_mut_writes_land_and_stamp_exactly_the_acquired_column() {
        let f = write_fixture();
        let last_run = tick_now_and_advance(f.world);
        assert!(changed_entities_via_ffi(f.world, f.health, last_run, false).is_empty());

        let mut span = FfiSpanMut::empty();
        // SAFETY: `f.world` is live, `span` is valid for one write.
        let status = unsafe {
            mid_ecs_world_static_component_raw_span_mut(f.world, f.plain, f.health, &mut span)
        };
        assert_eq!(status, MidEcsStatus::Ok as i32);
        assert_eq!((span.stride, span.count), (4, 2));
        assert!(!span.ptr.is_null());
        for row in 0..span.count {
            // SAFETY: `row < span.count`; the span points at
            // `MidEcsTestHealthStatic` elements `stride` bytes apart, a
            // type registered writable because every bit pattern is valid.
            unsafe {
                (*(span.ptr.add(row * span.stride) as *mut MidEcsTestHealthStatic)).hp += 100;
            }
        }
        // The two `{Health}` rows (1 and 3) changed; the `{Health, FlagA}`
        // row (2) did not.
        assert_eq!(hp_values(f.world), vec![2, 101, 103]);
        assert_eq!(
            changed_entities_via_ffi(f.world, f.health, last_run, false),
            sorted(f.plain_entities.clone())
        );
        // Stamped changed, not added.
        assert!(changed_entities_via_ffi(f.world, f.health, last_run, true).is_empty());
        // SAFETY: freed exactly once.
        unsafe { mid_ecs_world_free(f.world) };
    }

    #[test]
    fn raw_span_mut_and_the_read_only_span_point_at_the_same_memory() {
        let f = write_fixture();
        let mut shared = empty_span();
        let mut exclusive = FfiSpanMut::empty();
        // SAFETY: `f.world` is live, both spans are valid for one write.
        unsafe {
            assert_eq!(
                mid_ecs_world_static_component_raw_span(f.world, f.plain, f.health, &mut shared),
                MidEcsStatus::Ok as i32
            );
            assert_eq!(
                mid_ecs_world_static_component_raw_span_mut(
                    f.world,
                    f.plain,
                    f.health,
                    &mut exclusive
                ),
                MidEcsStatus::Ok as i32
            );
            mid_ecs_world_free(f.world);
        }
        assert_eq!(exclusive.ptr as *const u8, shared.ptr);
        assert_eq!(
            (exclusive.stride, exclusive.count),
            (shared.stride, shared.count)
        );
    }

    #[test]
    fn raw_span_mut_statuses_and_nothing_stamped_on_an_error() {
        let f = write_fixture();
        let last_run = tick_now_and_advance(f.world);
        let mut span = FfiSpanMut::empty();
        let mut call = |archetype: u32, component: u32| -> i32 {
            // SAFETY: `f.world` is live, `span` is valid for one write.
            unsafe {
                mid_ecs_world_static_component_raw_span_mut(
                    f.world, archetype, component, &mut span,
                )
            }
        };
        let ok = MidEcsStatus::Ok as i32;
        let not_found = MidEcsStatus::NotFound as i32;
        // Registered read-only: not writable, wherever it is.
        assert_eq!(call(f.flagged, f.flag_a), MidEcsStatus::NotWritable as i32);
        assert_eq!(call(f.plain, f.flag_a), MidEcsStatus::NotWritable as i32);
        // Never registered / no such archetype / signature lacks it.
        assert_eq!(call(f.plain, 9999), not_found);
        assert_eq!(call(9999, f.health), not_found);
        assert_eq!(call(0, f.health), not_found);
        // Registered writable, but held by no entity anywhere.
        assert_eq!(call(f.plain, f.flag_b), not_found);
        // Nothing was stamped by any of that.
        assert!(changed_entities_via_ffi(f.world, f.health, last_run, false).is_empty());
        // Null handle / null out-pointer.
        let mut other = FfiSpanMut::empty();
        // SAFETY: NULL is the documented rejected case for each.
        unsafe {
            assert_eq!(
                mid_ecs_world_static_component_raw_span_mut(
                    std::ptr::null_mut(),
                    f.plain,
                    f.health,
                    &mut other
                ),
                MidEcsStatus::NullPointer as i32
            );
            assert_eq!(
                mid_ecs_world_static_component_raw_span_mut(
                    f.world,
                    f.plain,
                    f.health,
                    std::ptr::null_mut()
                ),
                MidEcsStatus::NullPointer as i32
            );
        }
        // And a good call still works afterwards.
        assert_eq!(call(f.plain, f.health), ok);
        // SAFETY: freed exactly once.
        unsafe { mid_ecs_world_free(f.world) };
    }

    #[test]
    fn write_copies_a_value_in_and_stamps_exactly_that_row() {
        let f = write_fixture();
        let last_run = tick_now_and_advance(f.world);

        // From a deliberately unaligned buffer: the bytes are copied.
        let buf = [0u8, 222, 0, 0, 0, 0];
        // SAFETY: `f.world` is live; `buf[1..5]` is valid for 4 bytes.
        let status = unsafe {
            mid_ecs_world_static_component_write(
                f.world,
                f.flagged_entity,
                f.health,
                buf[1..5].as_ptr(),
                4,
            )
        };
        assert_eq!(status, MidEcsStatus::Ok as i32);
        assert_eq!(hp_values(f.world), vec![1, 3, 222]);
        assert_eq!(
            changed_entities_via_ffi(f.world, f.health, last_run, false),
            vec![f.flagged_entity]
        );
        assert!(changed_entities_via_ffi(f.world, f.health, last_run, true).is_empty());
        // SAFETY: freed exactly once.
        unsafe { mid_ecs_world_free(f.world) };
    }

    #[test]
    fn write_statuses_and_nothing_written_or_stamped_on_an_error() {
        let f = write_fixture();
        let last_run = tick_now_and_advance(f.world);
        let value = 77u32.to_ne_bytes();
        let write = |entity: u64, component: u32, bytes: *const u8, len: usize| -> i32 {
            // SAFETY: `f.world` is live; `bytes` is NULL only with `len == 0`
            // or valid for `len` bytes at every call site below.
            unsafe { mid_ecs_world_static_component_write(f.world, entity, component, bytes, len) }
        };
        let victim = f.plain_entities[0];

        // Read-only component, even on an entity that has it.
        assert_eq!(
            write(f.flagged_entity, f.flag_a, value.as_ptr(), 4),
            MidEcsStatus::NotWritable as i32
        );
        // Never registered; alive but without the (writable) component.
        assert_eq!(
            write(victim, 9999, value.as_ptr(), 4),
            MidEcsStatus::NotFound as i32
        );
        assert_eq!(
            write(victim, f.flag_b, value.as_ptr(), 4),
            MidEcsStatus::NotFound as i32
        );
        // Wrong lengths, including NULL with 0.
        for len in [3usize, 5] {
            assert_eq!(
                write(victim, f.health, value.as_ptr(), len),
                MidEcsStatus::SizeMismatch as i32
            );
        }
        assert_eq!(
            write(victim, f.health, std::ptr::null(), 0),
            MidEcsStatus::SizeMismatch as i32
        );
        // A bogus handle that never came from a real spawn.
        assert_eq!(
            write(u64::MAX, f.health, value.as_ptr(), 4),
            MidEcsStatus::NotAlive as i32
        );
        // NULL bytes with a non-zero length, and a NULL world.
        assert_eq!(
            write(victim, f.health, std::ptr::null(), 4),
            MidEcsStatus::NullPointer as i32
        );
        // SAFETY: NULL world is the documented rejected case.
        unsafe {
            assert_eq!(
                mid_ecs_world_static_component_write(
                    std::ptr::null_mut(),
                    victim,
                    f.health,
                    value.as_ptr(),
                    4
                ),
                MidEcsStatus::NullPointer as i32
            );
        }
        assert_eq!(hp_values(f.world), vec![1, 2, 3]);
        assert!(changed_entities_via_ffi(f.world, f.health, last_run, false).is_empty());
        // SAFETY: freed exactly once.
        unsafe { mid_ecs_world_free(f.world) };
    }

    #[test]
    fn write_to_a_dead_or_stale_entity_is_not_alive_and_never_reaches_the_slot_reuser() {
        let f = write_fixture();
        let doomed = f.plain_entities[0];
        // SAFETY: `f.world` is live.
        let (despawn, reused) = unsafe {
            let despawn = mid_ecs_world_despawn(f.world, doomed);
            (despawn, mid_ecs_world_spawn(f.world))
        };
        assert_eq!(despawn, MidEcsStatus::Ok as i32);
        assert_ne!(reused, doomed);
        rust_side(f.world)
            .insert_static(Entity::from_ffi(reused), MidEcsTestHealthStatic { hp: 50 });
        let last_run = tick_now_and_advance(f.world);

        let value = 9u32.to_ne_bytes();
        // SAFETY: `f.world` is live, `value` is valid for 4 bytes.
        let status = unsafe {
            mid_ecs_world_static_component_write(f.world, doomed, f.health, value.as_ptr(), 4)
        };
        assert_eq!(status, MidEcsStatus::NotAlive as i32);
        // The entity that took the slot is untouched and unstamped.
        assert_eq!(
            rust_side(f.world)
                .get_static::<MidEcsTestHealthStatic>(Entity::from_ffi(reused))
                .map(|h| h.hp),
            Some(50)
        );
        assert!(changed_entities_via_ffi(f.world, f.health, last_run, false).is_empty());
        // SAFETY: freed exactly once.
        unsafe { mid_ecs_world_free(f.world) };
    }

    #[test]
    fn component_status_maps_every_error() {
        let ok = |e| component_status(e);
        assert_eq!(
            ok(ComponentFfiError::UnknownId),
            MidEcsStatus::NotFound as i32
        );
        assert_eq!(ok(ComponentFfiError::Absent), MidEcsStatus::NotFound as i32);
        assert_eq!(
            ok(ComponentFfiError::NotWritable),
            MidEcsStatus::NotWritable as i32
        );
        assert_eq!(
            ok(ComponentFfiError::NotAlive),
            MidEcsStatus::NotAlive as i32
        );
        assert_eq!(
            ok(ComponentFfiError::SizeMismatch),
            MidEcsStatus::SizeMismatch as i32
        );
        assert_eq!(MidEcsStatus::NotWritable as i32, -7);
        assert_eq!(
            ok(ComponentFfiError::AlreadyPresent),
            MidEcsStatus::AlreadyPresent as i32
        );
        assert_eq!(MidEcsStatus::AlreadyPresent as i32, -8);
        assert_eq!(
            ok(ComponentFfiError::Duplicate),
            MidEcsStatus::Duplicate as i32
        );
        assert_eq!(MidEcsStatus::Duplicate as i32, -9);
    }

    // ---- inserting a component from C ----

    fn flag_b_of(world: *mut MidEcsWorld, entity: u64) -> Option<u32> {
        rust_side(world)
            .get_static::<MidEcsTestFlagB>(Entity::from_ffi(entity))
            .map(|f| f.v)
    }

    #[test]
    fn insert_attaches_a_missing_component_stamped_added_and_changed() {
        let f = write_fixture();
        let last_run = tick_now_and_advance(f.world);
        let victim = f.plain_entities[0];
        let bytes = 41u32.to_ne_bytes();
        // SAFETY: `f.world` is live; `bytes` is valid for 4 bytes.
        let status = unsafe {
            mid_ecs_world_static_component_insert(f.world, victim, f.flag_b, bytes.as_ptr(), 4)
        };
        assert_eq!(status, MidEcsStatus::Ok as i32);
        assert_eq!(flag_b_of(f.world, victim), Some(41));
        // The entity kept its Health and nothing else was touched.
        assert_eq!(hp_values(f.world), vec![1, 2, 3]);
        // The new value is both added and changed; the migrated Health
        // value was moved, not re-stamped.
        assert_eq!(
            changed_entities_via_ffi(f.world, f.flag_b, last_run, false),
            vec![victim]
        );
        assert_eq!(
            changed_entities_via_ffi(f.world, f.flag_b, last_run, true),
            vec![victim]
        );
        assert!(changed_entities_via_ffi(f.world, f.health, last_run, false).is_empty());
        // SAFETY: freed exactly once.
        unsafe { mid_ecs_world_free(f.world) };
    }

    #[test]
    fn insert_statuses_and_nothing_inserted_on_an_error() {
        let f = write_fixture();
        let victim = f.plain_entities[0];
        let value = 77u32.to_ne_bytes();
        let insert = |entity: u64, component: u32, bytes: *const u8, len: usize| -> i32 {
            // SAFETY: `f.world` is live; `bytes` is NULL only with `len == 0`
            // or valid for `len` bytes at every call site below.
            unsafe { mid_ecs_world_static_component_insert(f.world, entity, component, bytes, len) }
        };
        // Already has it: reported, and the first value stays.
        assert_eq!(
            insert(victim, f.health, value.as_ptr(), 4),
            MidEcsStatus::AlreadyPresent as i32
        );
        // Registered read-only; never registered.
        assert_eq!(
            insert(victim, f.flag_a, value.as_ptr(), 4),
            MidEcsStatus::NotWritable as i32
        );
        assert_eq!(
            insert(victim, 9999, value.as_ptr(), 4),
            MidEcsStatus::NotFound as i32
        );
        // Wrong lengths, including NULL with 0.
        for len in [3usize, 5] {
            assert_eq!(
                insert(victim, f.flag_b, value.as_ptr(), len),
                MidEcsStatus::SizeMismatch as i32
            );
        }
        assert_eq!(
            insert(victim, f.flag_b, std::ptr::null(), 0),
            MidEcsStatus::SizeMismatch as i32
        );
        // A bogus entity, a NULL buffer with a length, and a NULL world.
        assert_eq!(
            insert(u64::MAX, f.flag_b, value.as_ptr(), 4),
            MidEcsStatus::NotAlive as i32
        );
        assert_eq!(
            insert(victim, f.flag_b, std::ptr::null(), 4),
            MidEcsStatus::NullPointer as i32
        );
        // SAFETY: NULL world is the documented rejected case.
        unsafe {
            assert_eq!(
                mid_ecs_world_static_component_insert(
                    std::ptr::null_mut(),
                    victim,
                    f.flag_b,
                    value.as_ptr(),
                    4
                ),
                MidEcsStatus::NullPointer as i32
            );
        }
        // Nothing attached anywhere: no archetype holds a FlagB.
        assert!(matching_ids(f.world, &[f.flag_b], &[]).is_empty());
        assert_eq!(hp_values(f.world), vec![1, 2, 3]);
        // SAFETY: freed exactly once.
        unsafe { mid_ecs_world_free(f.world) };
    }

    #[test]
    fn insert_onto_a_stale_handle_is_not_alive_and_never_reaches_the_slot_reuser() {
        let f = write_fixture();
        let doomed = f.plain_entities[0];
        // SAFETY: `f.world` is live.
        let reused = unsafe {
            assert_eq!(
                mid_ecs_world_despawn(f.world, doomed),
                MidEcsStatus::Ok as i32
            );
            mid_ecs_world_spawn(f.world)
        };
        assert_ne!(reused, doomed);
        let value = 9u32.to_ne_bytes();
        // SAFETY: `f.world` is live; `value` is valid for 4 bytes.
        let status = unsafe {
            mid_ecs_world_static_component_insert(f.world, doomed, f.flag_b, value.as_ptr(), 4)
        };
        assert_eq!(status, MidEcsStatus::NotAlive as i32);
        assert_eq!(flag_b_of(f.world, reused), None);
        // SAFETY: freed exactly once.
        unsafe { mid_ecs_world_free(f.world) };
    }

    #[test]
    fn queued_inserts_apply_in_order_onto_spawned_and_existing_entities() {
        let f = write_fixture();
        let victim = f.plain_entities[0];
        let (v10, v20, v99) = (
            10u32.to_ne_bytes(),
            20u32.to_ne_bytes(),
            99u32.to_ne_bytes(),
        );
        let commands = mid_ecs_commands_new();
        // SAFETY: both handles are live; every buffer is valid for 4 bytes.
        unsafe {
            assert_eq!(mid_ecs_commands_spawn(commands), MidEcsStatus::Ok as i32);
            assert_eq!(mid_ecs_commands_spawn(commands), MidEcsStatus::Ok as i32);
            assert_eq!(mid_ecs_commands_spawn_count(commands), 2);
            // Out of order on purpose: slot 1 first.
            assert_eq!(
                mid_ecs_commands_static_component_insert_spawned(
                    commands,
                    f.world,
                    1,
                    f.flag_b,
                    v20.as_ptr(),
                    4
                ),
                MidEcsStatus::Ok as i32
            );
            assert_eq!(
                mid_ecs_commands_static_component_insert_spawned(
                    commands,
                    f.world,
                    0,
                    f.flag_b,
                    v10.as_ptr(),
                    4
                ),
                MidEcsStatus::Ok as i32
            );
            assert_eq!(
                mid_ecs_commands_static_component_insert(
                    commands,
                    f.world,
                    victim,
                    f.flag_b,
                    v99.as_ptr(),
                    4
                ),
                MidEcsStatus::Ok as i32
            );
            assert_eq!(mid_ecs_commands_len(commands), 5);
            // Nothing has happened to the world yet.
            assert_eq!(flag_b_of(f.world, victim), None);
            assert_eq!(rust_side(f.world).entity_count(), 3);

            let mut out = [0u64; 2];
            assert_eq!(
                mid_ecs_commands_apply(commands, f.world, out.as_mut_ptr(), 2),
                2
            );
            assert_eq!(flag_b_of(f.world, out[0]), Some(10));
            assert_eq!(flag_b_of(f.world, out[1]), Some(20));
            assert_eq!(flag_b_of(f.world, victim), Some(99));
            assert_eq!(mid_ecs_commands_len(commands), 0);
            mid_ecs_commands_free(commands);
            mid_ecs_world_free(f.world);
        }
    }

    #[test]
    fn queued_insert_statuses_and_nothing_queued_on_an_error() {
        let f = write_fixture();
        let victim = f.plain_entities[0];
        let value = 5u32.to_ne_bytes();
        let commands = mid_ecs_commands_new();
        // SAFETY: both handles are live; `value` is valid for 4 bytes.
        unsafe {
            assert_eq!(mid_ecs_commands_spawn(commands), MidEcsStatus::Ok as i32);
            let before = mid_ecs_commands_len(commands);
            let ok = MidEcsStatus::Ok as i32;
            let not_found = MidEcsStatus::NotFound as i32;
            let insert = |component: u32, bytes: *const u8, len: usize| {
                mid_ecs_commands_static_component_insert(
                    commands, f.world, victim, component, bytes, len,
                )
            };
            let spawned = |index: usize, component: u32, bytes: *const u8, len: usize| {
                mid_ecs_commands_static_component_insert_spawned(
                    commands, f.world, index, component, bytes, len,
                )
            };
            // Component-level errors, for both forms.
            assert_eq!(
                insert(f.flag_a, value.as_ptr(), 4),
                MidEcsStatus::NotWritable as i32
            );
            assert_eq!(
                spawned(0, f.flag_a, value.as_ptr(), 4),
                MidEcsStatus::NotWritable as i32
            );
            assert_eq!(insert(9999, value.as_ptr(), 4), not_found);
            assert_eq!(spawned(0, 9999, value.as_ptr(), 4), not_found);
            for len in [3usize, 5] {
                assert_eq!(
                    insert(f.flag_b, value.as_ptr(), len),
                    MidEcsStatus::SizeMismatch as i32
                );
                assert_eq!(
                    spawned(0, f.flag_b, value.as_ptr(), len),
                    MidEcsStatus::SizeMismatch as i32
                );
            }
            assert_eq!(
                insert(f.flag_b, std::ptr::null(), 0),
                MidEcsStatus::SizeMismatch as i32
            );
            // A spawn slot that is not queued (yet): one past the end, and huge.
            assert_eq!(spawned(1, f.flag_b, value.as_ptr(), 4), not_found);
            assert_eq!(spawned(usize::MAX, f.flag_b, value.as_ptr(), 4), not_found);
            // NULLs.
            assert_eq!(
                insert(f.flag_b, std::ptr::null(), 4),
                MidEcsStatus::NullPointer as i32
            );
            assert_eq!(
                spawned(0, f.flag_b, std::ptr::null(), 4),
                MidEcsStatus::NullPointer as i32
            );
            assert_eq!(
                mid_ecs_commands_static_component_insert(
                    std::ptr::null_mut(),
                    f.world,
                    victim,
                    f.flag_b,
                    value.as_ptr(),
                    4
                ),
                MidEcsStatus::NullPointer as i32
            );
            assert_eq!(
                mid_ecs_commands_static_component_insert(
                    commands,
                    std::ptr::null(),
                    victim,
                    f.flag_b,
                    value.as_ptr(),
                    4
                ),
                MidEcsStatus::NullPointer as i32
            );
            assert_eq!(
                mid_ecs_commands_static_component_insert_spawned(
                    commands,
                    std::ptr::null(),
                    0,
                    f.flag_b,
                    value.as_ptr(),
                    4
                ),
                MidEcsStatus::NullPointer as i32
            );
            // None of that queued anything, and good calls still work.
            assert_eq!(mid_ecs_commands_len(commands), before);
            assert_eq!(insert(f.flag_b, value.as_ptr(), 4), ok);
            assert_eq!(spawned(0, f.flag_b, value.as_ptr(), 4), ok);
            assert_eq!(mid_ecs_commands_len(commands), before + 2);
            mid_ecs_commands_free(commands);
            mid_ecs_world_free(f.world);
        }
    }

    #[test]
    fn queued_inserts_that_no_longer_apply_are_no_ops_at_apply() {
        let f = write_fixture();
        let (dead, present) = (f.plain_entities[0], f.plain_entities[1]);
        let value = 7u32.to_ne_bytes();
        let commands = mid_ecs_commands_new();
        // SAFETY: all handles are live; `value` is valid for 4 bytes.
        unsafe {
            // Valid when queued: a live entity, and one that has Health already.
            assert_eq!(
                mid_ecs_commands_static_component_insert(
                    commands,
                    f.world,
                    dead,
                    f.flag_b,
                    value.as_ptr(),
                    4
                ),
                MidEcsStatus::Ok as i32
            );
            assert_eq!(
                mid_ecs_commands_static_component_insert(
                    commands,
                    f.world,
                    present,
                    f.health,
                    value.as_ptr(),
                    4
                ),
                MidEcsStatus::Ok as i32
            );
            // ...then the first entity dies before apply.
            assert_eq!(
                mid_ecs_world_despawn(f.world, dead),
                MidEcsStatus::Ok as i32
            );
            assert_eq!(
                mid_ecs_commands_apply(commands, f.world, std::ptr::null_mut(), 0),
                0
            );
            assert!(!mid_ecs_world_is_alive(f.world, dead));
            assert_eq!(flag_b_of(f.world, dead), None);
            // The entity that already had Health kept its first value.
            assert_eq!(hp_values(f.world), vec![2, 3]);
            mid_ecs_commands_free(commands);
            mid_ecs_world_free(f.world);
        }
    }

    #[test]
    fn a_queue_applied_to_a_world_that_does_not_know_the_component_is_a_no_op_not_a_panic() {
        let f = write_fixture();
        let other = mid_ecs_world_new();
        let value = 7u32.to_ne_bytes();
        let commands = mid_ecs_commands_new();
        // SAFETY: all handles are live; `value` is valid for 4 bytes.
        unsafe {
            assert_eq!(mid_ecs_commands_spawn(commands), MidEcsStatus::Ok as i32);
            // Validated against `f.world`, which knows FlagB...
            assert_eq!(
                mid_ecs_commands_static_component_insert_spawned(
                    commands,
                    f.world,
                    0,
                    f.flag_b,
                    value.as_ptr(),
                    4
                ),
                MidEcsStatus::Ok as i32
            );
            // ...but applied to a world that has never heard of it.
            let mut out = [0u64; 1];
            assert_eq!(
                mid_ecs_commands_apply(commands, other, out.as_mut_ptr(), 1),
                1
            );
            assert!(mid_ecs_world_is_alive(other, out[0]));
            assert_eq!(
                rust_side(other)
                    .archetypes_with_static_component(ComponentId::from_u32(f.flag_b))
                    .count(),
                0
            );
            mid_ecs_commands_free(commands);
            mid_ecs_world_free(other);
            mid_ecs_world_free(f.world);
        }
    }

    // ---- removing a component from C ----

    #[test]
    fn remove_detaches_a_component_and_leaves_everything_else_intact() {
        let f = write_fixture();
        let last_run = tick_now_and_advance(f.world);
        let victim = f.plain_entities[0];
        // SAFETY: `f.world` is live.
        let status = unsafe { mid_ecs_world_static_component_remove(f.world, victim, f.health) };
        assert_eq!(status, MidEcsStatus::Ok as i32);
        // Its Health is gone, the entity is not, and nobody else changed.
        assert!(rust_side(f.world)
            .get_static::<MidEcsTestHealthStatic>(Entity::from_ffi(victim))
            .is_none());
        // SAFETY: `f.world` is live.
        assert!(unsafe { mid_ecs_world_is_alive(f.world, victim) });
        assert_eq!(hp_values(f.world), vec![2, 3]);
        // A removal stamps nothing, and the survivors were moved, not re-stamped.
        assert!(changed_entities_via_ffi(f.world, f.health, last_run, false).is_empty());
        // SAFETY: freed exactly once.
        unsafe { mid_ecs_world_free(f.world) };
    }

    #[test]
    fn remove_statuses_and_nothing_removed_on_an_error() {
        let f = write_fixture();
        let victim = f.plain_entities[0];
        let remove = |entity: u64, component: u32| -> i32 {
            // SAFETY: `f.world` is live.
            unsafe { mid_ecs_world_static_component_remove(f.world, entity, component) }
        };
        // Read-only, even on the entity that has it; never registered;
        // registered writable but this entity does not have it.
        assert_eq!(
            remove(f.flagged_entity, f.flag_a),
            MidEcsStatus::NotWritable as i32
        );
        assert_eq!(remove(victim, 9999), MidEcsStatus::NotFound as i32);
        assert_eq!(remove(victim, f.flag_b), MidEcsStatus::NotFound as i32);
        // A bogus handle.
        assert_eq!(remove(u64::MAX, f.health), MidEcsStatus::NotAlive as i32);
        // A NULL world.
        // SAFETY: NULL is the documented rejected case.
        unsafe {
            assert_eq!(
                mid_ecs_world_static_component_remove(std::ptr::null_mut(), victim, f.health),
                MidEcsStatus::NullPointer as i32
            );
        }
        // Nothing was removed by any of that.
        assert_eq!(hp_values(f.world), vec![1, 2, 3]);
        assert!(rust_side(f.world)
            .get_static::<MidEcsTestFlagA>(Entity::from_ffi(f.flagged_entity))
            .is_some());
        // Removing it twice: the second time there is nothing to remove.
        assert_eq!(remove(victim, f.health), MidEcsStatus::Ok as i32);
        assert_eq!(remove(victim, f.health), MidEcsStatus::NotFound as i32);
        // SAFETY: freed exactly once.
        unsafe { mid_ecs_world_free(f.world) };
    }

    #[test]
    fn remove_from_a_stale_handle_is_not_alive_and_never_reaches_the_slot_reuser() {
        let f = write_fixture();
        let doomed = f.plain_entities[0];
        // SAFETY: `f.world` is live.
        let reused = unsafe {
            assert_eq!(
                mid_ecs_world_despawn(f.world, doomed),
                MidEcsStatus::Ok as i32
            );
            mid_ecs_world_spawn(f.world)
        };
        rust_side(f.world)
            .insert_static(Entity::from_ffi(reused), MidEcsTestHealthStatic { hp: 50 });
        // SAFETY: `f.world` is live.
        let status = unsafe { mid_ecs_world_static_component_remove(f.world, doomed, f.health) };
        assert_eq!(status, MidEcsStatus::NotAlive as i32);
        assert_eq!(
            rust_side(f.world)
                .get_static::<MidEcsTestHealthStatic>(Entity::from_ffi(reused))
                .map(|h| h.hp),
            Some(50)
        );
        // SAFETY: freed exactly once.
        unsafe { mid_ecs_world_free(f.world) };
    }

    #[test]
    fn queued_remove_applies_in_order_with_inserts_and_validates_when_queued() {
        let f = write_fixture();
        let victim = f.plain_entities[0];
        let value = 5u32.to_ne_bytes();
        let commands = mid_ecs_commands_new();
        // SAFETY: both handles are live; `value` is valid for 4 bytes.
        unsafe {
            // Remove Health, then give the same entity a FlagB, in order.
            assert_eq!(
                mid_ecs_commands_static_component_remove(commands, f.world, victim, f.health),
                MidEcsStatus::Ok as i32
            );
            assert_eq!(
                mid_ecs_commands_static_component_insert(
                    commands,
                    f.world,
                    victim,
                    f.flag_b,
                    value.as_ptr(),
                    4
                ),
                MidEcsStatus::Ok as i32
            );
            assert_eq!(mid_ecs_commands_len(commands), 2);
            // Nothing has happened yet.
            assert_eq!(hp_values(f.world), vec![1, 2, 3]);
            assert_eq!(flag_b_of(f.world, victim), None);
            assert_eq!(
                mid_ecs_commands_apply(commands, f.world, std::ptr::null_mut(), 0),
                0
            );
            assert_eq!(hp_values(f.world), vec![2, 3]);
            assert_eq!(flag_b_of(f.world, victim), Some(5));

            // Queue-time errors, each queueing nothing.
            let before = mid_ecs_commands_len(commands);
            assert_eq!(
                mid_ecs_commands_static_component_remove(commands, f.world, victim, f.flag_a),
                MidEcsStatus::NotWritable as i32
            );
            assert_eq!(
                mid_ecs_commands_static_component_remove(commands, f.world, victim, 9999),
                MidEcsStatus::NotFound as i32
            );
            assert_eq!(
                mid_ecs_commands_static_component_remove(
                    std::ptr::null_mut(),
                    f.world,
                    victim,
                    f.health
                ),
                MidEcsStatus::NullPointer as i32
            );
            assert_eq!(
                mid_ecs_commands_static_component_remove(
                    commands,
                    std::ptr::null(),
                    victim,
                    f.health
                ),
                MidEcsStatus::NullPointer as i32
            );
            assert_eq!(mid_ecs_commands_len(commands), before);
            mid_ecs_commands_free(commands);
            mid_ecs_world_free(f.world);
        }
    }

    #[test]
    fn queued_removes_that_no_longer_apply_are_no_ops_at_apply() {
        let f = write_fixture();
        let (dead, lacks) = (f.plain_entities[0], f.plain_entities[1]);
        let commands = mid_ecs_commands_new();
        // SAFETY: all handles are live.
        unsafe {
            // Valid when queued: a live entity, and a writable component the
            // other entity does not have.
            assert_eq!(
                mid_ecs_commands_static_component_remove(commands, f.world, dead, f.health),
                MidEcsStatus::Ok as i32
            );
            assert_eq!(
                mid_ecs_commands_static_component_remove(commands, f.world, lacks, f.flag_b),
                MidEcsStatus::Ok as i32
            );
            // ...then the first entity dies before apply.
            assert_eq!(
                mid_ecs_world_despawn(f.world, dead),
                MidEcsStatus::Ok as i32
            );
            assert_eq!(
                mid_ecs_commands_apply(commands, f.world, std::ptr::null_mut(), 0),
                0
            );
            assert!(!mid_ecs_world_is_alive(f.world, dead));
            // The entity without FlagB kept everything it had.
            assert_eq!(hp_values(f.world), vec![2, 3]);

            // A queue validated against this world, applied to one that has
            // never heard of the component: a no-op, not a panic.
            let other = mid_ecs_world_new();
            let victim = mid_ecs_world_spawn(other);
            assert_eq!(
                mid_ecs_commands_static_component_remove(commands, f.world, victim, f.health),
                MidEcsStatus::Ok as i32
            );
            assert_eq!(
                mid_ecs_commands_apply(commands, other, std::ptr::null_mut(), 0),
                0
            );
            assert!(mid_ecs_world_is_alive(other, victim));
            mid_ecs_commands_free(commands);
            mid_ecs_world_free(other);
            mid_ecs_world_free(f.world);
        }
    }

    // ---- bundles from C: insert_many / remove_many ----

    fn value(component_id: u32, bytes: &[u8]) -> FfiComponentValue {
        FfiComponentValue {
            component_id,
            bytes: bytes.as_ptr(),
            len: bytes.len(),
        }
    }

    /// A bare entity (no components) in the fixture's world.
    fn bare(world: *mut MidEcsWorld) -> u64 {
        // SAFETY: `world` is a live handle.
        unsafe { mid_ecs_world_spawn(world) }
    }

    #[test]
    fn insert_many_attaches_a_bundle_in_one_call_stamped_added_and_changed() {
        let f = write_fixture();
        let last_run = tick_now_and_advance(f.world);
        let e = bare(f.world);
        let (hp, fb) = (7u32.to_ne_bytes(), 8u32.to_ne_bytes());
        let values = [value(f.health, &hp), value(f.flag_b, &fb)];
        // SAFETY: `f.world` is live; `values` and its buffers outlive the call.
        let status =
            unsafe { mid_ecs_world_static_component_insert_many(f.world, e, values.as_ptr(), 2) };
        assert_eq!(status, MidEcsStatus::Ok as i32);
        assert_eq!(hp_values(f.world), vec![1, 2, 3, 7]);
        assert_eq!(flag_b_of(f.world, e), Some(8));
        for component in [f.health, f.flag_b] {
            assert_eq!(
                changed_entities_via_ffi(f.world, component, last_run, false),
                vec![e]
            );
            assert_eq!(
                changed_entities_via_ffi(f.world, component, last_run, true),
                vec![e]
            );
        }
        // SAFETY: freed exactly once.
        unsafe { mid_ecs_world_free(f.world) };
    }

    #[test]
    fn insert_many_statuses_are_all_or_nothing_and_change_nothing() {
        let f = write_fixture();
        let has_health = f.plain_entities[0];
        let fresh = bare(f.world);
        let (a, b, bad) = (1u32.to_ne_bytes(), 2u32.to_ne_bytes(), [9u8; 3]);
        let insert = |entity: u64, values: &[FfiComponentValue]| -> i32 {
            // SAFETY: `f.world` is live; `values` and its buffers outlive the call.
            unsafe {
                mid_ecs_world_static_component_insert_many(
                    f.world,
                    entity,
                    values.as_ptr(),
                    values.len(),
                )
            }
        };
        let none_attached = || {
            matching_ids(f.world, &[f.flag_b], &[]).is_empty()
                && flag_b_of(f.world, fresh).is_none()
                && hp_values(f.world) == vec![1, 2, 3]
        };

        // The entity already has one of them: the other must not be attached.
        assert_eq!(
            insert(has_health, &[value(f.flag_b, &a), value(f.health, &b)]),
            MidEcsStatus::AlreadyPresent as i32
        );
        // Per-entry errors, then a repeat.
        assert_eq!(
            insert(fresh, &[value(f.flag_b, &a), value(f.flag_a, &b)]),
            MidEcsStatus::NotWritable as i32
        );
        assert_eq!(
            insert(fresh, &[value(f.flag_b, &a), value(9999, &b)]),
            MidEcsStatus::NotFound as i32
        );
        assert_eq!(
            insert(fresh, &[value(f.flag_b, &a), value(f.health, &bad)]),
            MidEcsStatus::SizeMismatch as i32
        );
        assert_eq!(
            insert(fresh, &[value(f.flag_b, &a), value(f.flag_b, &b)]),
            MidEcsStatus::Duplicate as i32
        );
        assert_eq!(
            insert(u64::MAX, &[value(f.flag_b, &a)]),
            MidEcsStatus::NotAlive as i32
        );
        assert!(none_attached());

        // NULLs: world, the list itself, and an entry's bytes.
        let values = [value(f.flag_b, &a)];
        // SAFETY: NULL is the documented rejected case for each.
        unsafe {
            assert_eq!(
                mid_ecs_world_static_component_insert_many(
                    std::ptr::null_mut(),
                    fresh,
                    values.as_ptr(),
                    1
                ),
                MidEcsStatus::NullPointer as i32
            );
            assert_eq!(
                mid_ecs_world_static_component_insert_many(f.world, fresh, std::ptr::null(), 1),
                MidEcsStatus::NullPointer as i32
            );
            let null_bytes = [FfiComponentValue {
                component_id: f.flag_b,
                bytes: std::ptr::null(),
                len: 4,
            }];
            assert_eq!(
                mid_ecs_world_static_component_insert_many(f.world, fresh, null_bytes.as_ptr(), 1),
                MidEcsStatus::NullPointer as i32
            );
            // An empty list is fine, even with a NULL pointer.
            assert_eq!(
                mid_ecs_world_static_component_insert_many(f.world, fresh, std::ptr::null(), 0),
                MidEcsStatus::Ok as i32
            );
        }
        assert!(none_attached());
        // SAFETY: freed exactly once.
        unsafe { mid_ecs_world_free(f.world) };
    }

    #[test]
    fn remove_many_detaches_a_bundle_and_is_all_or_nothing() {
        let f = write_fixture();
        let e = bare(f.world);
        let (a, b) = (3u32.to_ne_bytes(), 4u32.to_ne_bytes());
        let remove = |entity: u64, ids: &[u32]| -> i32 {
            // SAFETY: `f.world` is live; `ids` outlives the call.
            unsafe {
                mid_ecs_world_static_component_remove_many(f.world, entity, ids.as_ptr(), ids.len())
            }
        };
        let values = [value(f.health, &a), value(f.flag_b, &b)];
        // SAFETY: `f.world` is live; `values` and its buffers outlive the call.
        assert_eq!(
            unsafe { mid_ecs_world_static_component_insert_many(f.world, e, values.as_ptr(), 2) },
            MidEcsStatus::Ok as i32
        );

        // Lacks one of them: nothing is removed.
        let lacks_flag_b = f.plain_entities[0];
        assert_eq!(
            remove(lacks_flag_b, &[f.health, f.flag_b]),
            MidEcsStatus::NotFound as i32
        );
        assert_eq!(hp_values(f.world), vec![1, 2, 3, 3]);
        // A read-only component in the list, on the entity that has it.
        assert_eq!(
            remove(f.flagged_entity, &[f.health, f.flag_a]),
            MidEcsStatus::NotWritable as i32
        );
        assert_eq!(remove(e, &[f.health, 9999]), MidEcsStatus::NotFound as i32);
        assert_eq!(
            remove(e, &[f.health, f.health]),
            MidEcsStatus::Duplicate as i32
        );
        assert_eq!(remove(u64::MAX, &[f.health]), MidEcsStatus::NotAlive as i32);
        assert_eq!(flag_b_of(f.world, e), Some(4));
        assert_eq!(hp_values(f.world), vec![1, 2, 3, 3]);
        // NULLs, and the empty list.
        // SAFETY: NULL is the documented rejected case for each.
        unsafe {
            assert_eq!(
                mid_ecs_world_static_component_remove_many(
                    std::ptr::null_mut(),
                    e,
                    [f.health].as_ptr(),
                    1
                ),
                MidEcsStatus::NullPointer as i32
            );
            assert_eq!(
                mid_ecs_world_static_component_remove_many(f.world, e, std::ptr::null(), 1),
                MidEcsStatus::NullPointer as i32
            );
            assert_eq!(
                mid_ecs_world_static_component_remove_many(f.world, e, std::ptr::null(), 0),
                MidEcsStatus::Ok as i32
            );
        }
        // Now the real thing: both go, the entity stays.
        assert_eq!(remove(e, &[f.health, f.flag_b]), MidEcsStatus::Ok as i32);
        assert_eq!(hp_values(f.world), vec![1, 2, 3]);
        assert_eq!(flag_b_of(f.world, e), None);
        // SAFETY: `f.world` is live; freed exactly once.
        unsafe {
            assert!(mid_ecs_world_is_alive(f.world, e));
            mid_ecs_world_free(f.world);
        }
    }

    #[test]
    fn queued_bundles_apply_in_order_and_validate_when_queued() {
        let f = write_fixture();
        let existing = bare(f.world);
        let (a, b, c) = (
            10u32.to_ne_bytes(),
            11u32.to_ne_bytes(),
            21u32.to_ne_bytes(),
        );
        let commands = mid_ecs_commands_new();
        // SAFETY: both handles are live; every buffer outlives its call.
        unsafe {
            assert_eq!(mid_ecs_commands_spawn(commands), MidEcsStatus::Ok as i32);
            assert_eq!(mid_ecs_commands_spawn(commands), MidEcsStatus::Ok as i32);
            let slot0 = [value(f.health, &a), value(f.flag_b, &b)];
            let slot1 = [value(f.flag_b, &c)];
            assert_eq!(
                mid_ecs_commands_static_component_insert_many_spawned(
                    commands,
                    f.world,
                    1,
                    slot1.as_ptr(),
                    1
                ),
                MidEcsStatus::Ok as i32
            );
            assert_eq!(
                mid_ecs_commands_static_component_insert_many_spawned(
                    commands,
                    f.world,
                    0,
                    slot0.as_ptr(),
                    2
                ),
                MidEcsStatus::Ok as i32
            );
            // On an existing entity: attach a bundle, then detach it again.
            assert_eq!(
                mid_ecs_commands_static_component_insert_many(
                    commands,
                    f.world,
                    existing,
                    slot0.as_ptr(),
                    2
                ),
                MidEcsStatus::Ok as i32
            );
            assert_eq!(
                mid_ecs_commands_static_component_remove_many(
                    commands,
                    f.world,
                    existing,
                    [f.flag_b, f.health].as_ptr(),
                    2
                ),
                MidEcsStatus::Ok as i32
            );
            assert_eq!(mid_ecs_commands_len(commands), 6);
            assert_eq!(hp_values(f.world), vec![1, 2, 3], "nothing before apply");

            let mut out = [0u64; 2];
            assert_eq!(
                mid_ecs_commands_apply(commands, f.world, out.as_mut_ptr(), 2),
                2
            );
            assert_eq!(flag_b_of(f.world, out[0]), Some(11));
            assert_eq!(flag_b_of(f.world, out[1]), Some(21));
            assert_eq!(hp_values(f.world), vec![1, 2, 3, 10]);
            assert_eq!(flag_b_of(f.world, existing), None);
            mid_ecs_commands_free(commands);
            mid_ecs_world_free(f.world);
        }
    }

    #[test]
    fn queued_bundle_statuses_queue_nothing_and_misses_at_apply_are_whole_no_ops() {
        let f = write_fixture();
        let victim = f.plain_entities[0];
        let (a, bad) = (5u32.to_ne_bytes(), [1u8; 3]);
        let commands = mid_ecs_commands_new();
        // SAFETY: both handles are live; every buffer outlives its call.
        unsafe {
            assert_eq!(mid_ecs_commands_spawn(commands), MidEcsStatus::Ok as i32);
            let before = mid_ecs_commands_len(commands);
            let insert = |values: &[FfiComponentValue]| {
                mid_ecs_commands_static_component_insert_many(
                    commands,
                    f.world,
                    victim,
                    values.as_ptr(),
                    values.len(),
                )
            };
            let spawned = |index: usize, values: &[FfiComponentValue]| {
                mid_ecs_commands_static_component_insert_many_spawned(
                    commands,
                    f.world,
                    index,
                    values.as_ptr(),
                    values.len(),
                )
            };
            let remove = |ids: &[u32]| {
                mid_ecs_commands_static_component_remove_many(
                    commands,
                    f.world,
                    victim,
                    ids.as_ptr(),
                    ids.len(),
                )
            };
            let good = [value(f.flag_b, &a)];
            // List-level errors, for each form.
            assert_eq!(
                insert(&[value(f.flag_a, &a)]),
                MidEcsStatus::NotWritable as i32
            );
            assert_eq!(insert(&[value(9999, &a)]), MidEcsStatus::NotFound as i32);
            assert_eq!(
                insert(&[value(f.flag_b, &bad)]),
                MidEcsStatus::SizeMismatch as i32
            );
            assert_eq!(
                insert(&[value(f.flag_b, &a), value(f.flag_b, &a)]),
                MidEcsStatus::Duplicate as i32
            );
            assert_eq!(
                spawned(0, &[value(f.flag_a, &a)]),
                MidEcsStatus::NotWritable as i32
            );
            assert_eq!(remove(&[f.flag_a]), MidEcsStatus::NotWritable as i32);
            assert_eq!(remove(&[9999]), MidEcsStatus::NotFound as i32);
            assert_eq!(
                remove(&[f.health, f.health]),
                MidEcsStatus::Duplicate as i32
            );
            // A spawn slot that is not queued, after the list checks pass.
            assert_eq!(spawned(1, &good), MidEcsStatus::NotFound as i32);
            assert_eq!(spawned(usize::MAX, &good), MidEcsStatus::NotFound as i32);
            // NULLs.
            assert_eq!(
                mid_ecs_commands_static_component_insert_many(
                    commands,
                    f.world,
                    victim,
                    std::ptr::null(),
                    1
                ),
                MidEcsStatus::NullPointer as i32
            );
            assert_eq!(
                mid_ecs_commands_static_component_remove_many(
                    commands,
                    f.world,
                    victim,
                    std::ptr::null(),
                    1
                ),
                MidEcsStatus::NullPointer as i32
            );
            assert_eq!(
                mid_ecs_commands_static_component_insert_many(
                    commands,
                    std::ptr::null(),
                    victim,
                    good.as_ptr(),
                    1
                ),
                MidEcsStatus::NullPointer as i32
            );
            // None of that queued anything; empty lists are Ok and queue nothing.
            assert_eq!(mid_ecs_commands_len(commands), before);
            assert_eq!(insert(&[]), MidEcsStatus::Ok as i32);
            assert_eq!(remove(&[]), MidEcsStatus::Ok as i32);
            assert_eq!(mid_ecs_commands_len(commands), before);

            // Valid when queued, but at apply the entity already has Health
            // (so the whole bundle is refused) and lacks FlagB (so the whole
            // removal is refused).
            let mixed = [value(f.flag_b, &a), value(f.health, &a)];
            assert_eq!(insert(&mixed), MidEcsStatus::Ok as i32);
            assert_eq!(remove(&[f.health, f.flag_b]), MidEcsStatus::Ok as i32);
            // The queue still holds the one spawn from above, so apply needs
            // a buffer (a NULL one with a spawn waiting is BufferTooSmall).
            let mut spawned_out = [0u64; 1];
            assert_eq!(
                mid_ecs_commands_apply(commands, f.world, spawned_out.as_mut_ptr(), 1),
                1
            );
            assert_eq!(hp_values(f.world), vec![1, 2, 3]);
            assert!(matching_ids(f.world, &[f.flag_b], &[]).is_empty());
            mid_ecs_commands_free(commands);
            mid_ecs_world_free(f.world);
        }
    }

    // ── removal tracking (C API) ─────────────────────────────────────

    const OK: i32 = MidEcsStatus::Ok as i32;
    const NULL_POINTER: i32 = MidEcsStatus::NullPointer as i32;
    const NOT_ALIVE: i32 = MidEcsStatus::NotAlive as i32;
    const NOT_FOUND: i32 = MidEcsStatus::NotFound as i32;
    const BUFFER_TOO_SMALL: i32 = MidEcsStatus::BufferTooSmall as i32;
    const NOT_WRITABLE: i32 = MidEcsStatus::NotWritable as i32;
    const ALREADY_PRESENT: i32 = MidEcsStatus::AlreadyPresent as i32;
    const NOT_TRACKED: i32 = MidEcsStatus::NotTracked as i32;

    /// Archetype-Core components for the removal tests: `RmHp` and `RmMp`
    /// writable, `RmRo` read-only. `RmCn` lives in the Sparse Shell.
    #[derive(
        Debug, Clone, Copy, PartialEq, zerocopy::FromBytes, IntoBytes, KnownLayout, Immutable,
    )]
    #[repr(C)]
    struct RmHp {
        v: u32,
    }

    #[derive(
        Debug, Clone, Copy, PartialEq, zerocopy::FromBytes, IntoBytes, KnownLayout, Immutable,
    )]
    #[repr(C)]
    struct RmMp {
        v: u32,
    }

    #[derive(Debug, Clone, Copy, PartialEq, IntoBytes, KnownLayout, Immutable)]
    #[repr(C)]
    struct RmRo {
        v: u32,
    }

    #[derive(Debug, Clone, Copy, PartialEq, IntoBytes, KnownLayout, Immutable)]
    #[repr(C)]
    struct RmCn {
        v: u32,
    }

    /// A world for the removal tests. Three entities:
    /// `e[0]` = {Hp, Mp, Ro, Cn}, `e[1]` = {Hp, Cn}, `e[2]` = {Hp}.
    /// The Archetype-Core ids are `hp = 0`, `mp = 1`, `ro = 2` and the
    /// only Sparse-Shell id is `cn = 0`: the two spaces deliberately
    /// collide numerically.
    struct RmWorld {
        ptr: *mut MidEcsWorld,
        hp: u32,
        mp: u32,
        ro: u32,
        cn: u32,
        e: [u64; 3],
    }

    impl RmWorld {
        fn new() -> Self {
            let ptr = mid_ecs_world_new();
            // SAFETY: `ptr` is non-null, just created, freed in `Drop`.
            let w = unsafe { &mut (*ptr).0 };
            let hp = w
                .register_ffi_static_component_writable::<RmHp>("RmHp")
                .as_u32();
            let mp = w
                .register_ffi_static_component_writable::<RmMp>("RmMp")
                .as_u32();
            let ro = w.register_ffi_static_component::<RmRo>("RmRo").as_u32();
            let cn = w.register_ffi_component::<RmCn>("RmCn").as_u32();
            let e0 = w.spawn();
            let e1 = w.spawn();
            let e2 = w.spawn();
            w.insert_static(e0, RmHp { v: 1 });
            w.insert_static(e0, RmMp { v: 1 });
            w.insert_static(e0, RmRo { v: 1 });
            w.insert(e0, RmCn { v: 1 });
            w.insert_static(e1, RmHp { v: 2 });
            w.insert(e1, RmCn { v: 2 });
            w.insert_static(e2, RmHp { v: 3 });
            assert_eq!((hp, mp, ro, cn), (0, 1, 2, 0));
            Self {
                ptr,
                hp,
                mp,
                ro,
                cn,
                e: [e0.as_ffi(), e1.as_ffi(), e2.as_ffi()],
            }
        }

        fn rust(&mut self) -> &mut World {
            // SAFETY: `ptr` is a live handle owned by `self`.
            unsafe { &mut (*self.ptr).0 }
        }

        fn tick(&self) -> u32 {
            // SAFETY: `ptr` is a live handle owned by `self`.
            unsafe { mid_ecs_world_change_tick(self.ptr) }
        }

        fn advance(&self) -> u32 {
            // SAFETY: `ptr` is a live handle owned by `self`.
            unsafe { mid_ecs_world_increment_change_tick(self.ptr) }
        }

        fn track_static(&self, id: u32) {
            // SAFETY: `ptr` is a live handle owned by `self`.
            assert_eq!(
                unsafe { mid_ecs_world_static_component_track_removals(self.ptr, id) },
                OK
            );
        }

        fn track_sparse(&self, id: u32) {
            // SAFETY: `ptr` is a live handle owned by `self`.
            assert_eq!(
                unsafe { mid_ecs_world_component_track_removals(self.ptr, id) },
                OK
            );
        }

        fn remove(&self, entity: u64, id: u32) -> i32 {
            // SAFETY: `ptr` is a live handle owned by `self`.
            unsafe { mid_ecs_world_static_component_remove(self.ptr, entity, id) }
        }

        fn despawn(&self, entity: u64) {
            // SAFETY: `ptr` is a live handle owned by `self`.
            assert_eq!(unsafe { mid_ecs_world_despawn(self.ptr, entity) }, OK);
        }

        fn static_count(&self, id: u32) -> i32 {
            // SAFETY: `ptr` is a live handle owned by `self`.
            unsafe { mid_ecs_world_static_component_removal_count(self.ptr, id) }
        }

        fn sparse_count(&self, id: u32) -> i32 {
            // SAFETY: `ptr` is a live handle owned by `self`.
            unsafe { mid_ecs_world_component_removal_count(self.ptr, id) }
        }

        /// `removed_since` the way a C caller drives it: count with a NULL
        /// buffer, then fill a buffer of exactly that size, and check the
        /// two calls agree.
        fn since(&self, sparse: bool, id: u32, last_run: u32) -> Vec<u64> {
            let call = |out: *mut u64, cap: usize| {
                // SAFETY: `ptr` is a live handle; `out` is NULL or valid
                // for `cap` elements (the caller below guarantees it).
                unsafe {
                    if sparse {
                        mid_ecs_world_component_removed_since(self.ptr, id, last_run, out, cap)
                    } else {
                        mid_ecs_world_static_component_removed_since(
                            self.ptr, id, last_run, out, cap,
                        )
                    }
                }
            };
            let n = call(ptr::null_mut(), 0);
            assert!(n >= 0, "removed_since returned status {n}");
            let mut buf = vec![u64::MAX; n as usize];
            assert_eq!(call(buf.as_mut_ptr(), buf.len()), n);
            buf
        }
    }

    impl Drop for RmWorld {
        fn drop(&mut self) {
            // SAFETY: `ptr` is the live handle `new` created, freed once.
            unsafe { mid_ecs_world_free(self.ptr) };
        }
    }

    #[test]
    fn removal_tracking_is_per_component_idempotent_and_keeps_the_id_spaces_apart() {
        let w = RmWorld::new();
        // SAFETY: `w.ptr` is a live handle for this whole block.
        unsafe {
            for id in [w.hp, w.mp, w.ro] {
                assert_eq!(mid_ecs_world_static_component_tracks_removals(w.ptr, id), 0);
            }
            assert_eq!(mid_ecs_world_component_tracks_removals(w.ptr, w.cn), 0);

            assert_eq!(mid_ecs_world_static_component_track_removals(w.ptr, w.hp), OK);
            assert_eq!(mid_ecs_world_static_component_tracks_removals(w.ptr, w.hp), 1);
            assert_eq!(
                mid_ecs_world_static_component_tracks_removals(w.ptr, w.mp),
                0,
                "tracking one component does not track another"
            );
            assert_eq!(
                mid_ecs_world_component_tracks_removals(w.ptr, w.cn),
                0,
                "Archetype-Core id 0 is tracked; Sparse-Shell id 0 is a different component"
            );

            // Idempotent, and nothing logged yet.
            assert_eq!(mid_ecs_world_static_component_track_removals(w.ptr, w.hp), OK);
            assert_eq!(w.static_count(w.hp), 0);

            // Tracking needs no writable registration: Ro is read-only.
            assert_eq!(mid_ecs_world_static_component_track_removals(w.ptr, w.ro), OK);
            assert_eq!(mid_ecs_world_static_component_tracks_removals(w.ptr, w.ro), 1);

            assert_eq!(mid_ecs_world_component_track_removals(w.ptr, w.cn), OK);
            assert_eq!(mid_ecs_world_component_tracks_removals(w.ptr, w.cn), 1);
            assert_eq!(
                mid_ecs_world_static_component_tracks_removals(w.ptr, w.mp),
                0,
                "tracking a Sparse-Shell id leaves the Archetype Core alone"
            );
        }
    }

    #[test]
    fn removal_queries_distinguish_untracked_unknown_and_null() {
        let w = RmWorld::new();
        let mut buf = [u64::MAX; 4];
        // SAFETY: `w.ptr` is a live handle; `buf` is valid for 4 elements.
        unsafe {
            // Registered but untracked: a count of 0, and a loud NotTracked
            // for the list (nothing was ever recorded).
            assert_eq!(w.static_count(w.mp), 0);
            assert_eq!(
                mid_ecs_world_static_component_removed_since(
                    w.ptr,
                    w.mp,
                    0,
                    buf.as_mut_ptr(),
                    4
                ),
                NOT_TRACKED
            );
            assert_eq!(
                mid_ecs_world_static_component_removed_since(w.ptr, w.mp, 0, ptr::null_mut(), 0),
                NOT_TRACKED
            );
            assert_eq!(
                mid_ecs_world_component_removed_since(w.ptr, w.cn, 0, buf.as_mut_ptr(), 4),
                NOT_TRACKED
            );
            assert_eq!(buf, [u64::MAX; 4], "nothing written on NotTracked");

            // An id this world never issued, in either space. `w.ro` (2) is
            // a real Archetype-Core id but not a Sparse-Shell one.
            for id in [9999, MID_ECS_INVALID_ID] {
                assert_eq!(mid_ecs_world_static_component_track_removals(w.ptr, id), NOT_FOUND);
                assert_eq!(mid_ecs_world_static_component_tracks_removals(w.ptr, id), NOT_FOUND);
                assert_eq!(mid_ecs_world_static_component_removal_count(w.ptr, id), NOT_FOUND);
                assert_eq!(
                    mid_ecs_world_static_component_removed_since(
                        w.ptr,
                        id,
                        0,
                        ptr::null_mut(),
                        0
                    ),
                    NOT_FOUND
                );
                assert_eq!(mid_ecs_world_component_track_removals(w.ptr, id), NOT_FOUND);
                assert_eq!(mid_ecs_world_component_tracks_removals(w.ptr, id), NOT_FOUND);
                assert_eq!(mid_ecs_world_component_removal_count(w.ptr, id), NOT_FOUND);
                assert_eq!(
                    mid_ecs_world_component_removed_since(w.ptr, id, 0, ptr::null_mut(), 0),
                    NOT_FOUND
                );
            }
            assert_eq!(mid_ecs_world_component_track_removals(w.ptr, w.ro), NOT_FOUND);
            assert_eq!(mid_ecs_world_component_tracks_removals(w.ptr, w.ro), NOT_FOUND);

            // A NULL world, for every function.
            let null_w = ptr::null_mut::<MidEcsWorld>();
            assert_eq!(mid_ecs_world_static_component_track_removals(null_w, 0), NULL_POINTER);
            assert_eq!(mid_ecs_world_static_component_tracks_removals(null_w, 0), NULL_POINTER);
            assert_eq!(mid_ecs_world_static_component_removal_count(null_w, 0), NULL_POINTER);
            assert_eq!(
                mid_ecs_world_static_component_removed_since(null_w, 0, 0, ptr::null_mut(), 0),
                NULL_POINTER
            );
            assert_eq!(mid_ecs_world_component_track_removals(null_w, 0), NULL_POINTER);
            assert_eq!(mid_ecs_world_component_tracks_removals(null_w, 0), NULL_POINTER);
            assert_eq!(mid_ecs_world_component_removal_count(null_w, 0), NULL_POINTER);
            assert_eq!(
                mid_ecs_world_component_removed_since(null_w, 0, 0, ptr::null_mut(), 0),
                NULL_POINTER
            );
            assert_eq!(mid_ecs_world_trim_removals(null_w, 0), NULL_POINTER);
            assert_eq!(mid_ecs_world_clear_removals(null_w), NULL_POINTER);
        }
    }

    #[test]
    fn removals_are_recorded_from_every_c_removal_path_and_match_the_rust_view() {
        let mut w = RmWorld::new();
        w.track_static(w.hp);
        w.track_static(w.mp);
        w.track_sparse(w.cn);
        let t0 = w.tick();
        w.advance();
        let [e0, e1, e2] = w.e;

        // A direct removal.
        assert_eq!(w.remove(e0, w.hp), OK);
        assert_eq!(w.since(false, w.hp, t0), vec![e0]);

        // A queued removal records when it runs, not when it is queued.
        // SAFETY: `w.ptr` is live; `q` is a fresh queue freed below.
        unsafe {
            let q = mid_ecs_commands_new();
            assert_eq!(mid_ecs_commands_static_component_remove(q, w.ptr, e1, w.hp), OK);
            assert_eq!(w.since(false, w.hp, t0), vec![e0], "queued, not yet run");
            assert_eq!(mid_ecs_commands_apply(q, w.ptr, ptr::null_mut(), 0), 0);
            mid_ecs_commands_free(q);
        }
        assert_eq!(w.since(false, w.hp, t0), vec![e0, e1]);

        // A list removal records each member.
        let ids = [w.mp];
        // SAFETY: `w.ptr` is live; `ids` is valid for 1 element.
        assert_eq!(
            unsafe { mid_ecs_world_static_component_remove_many(w.ptr, e0, ids.as_ptr(), 1) },
            OK
        );
        assert_eq!(w.since(false, w.mp, t0), vec![e0]);

        // A despawn records the components the entity still had, in both
        // storages: e2's Hp, and e1's Cn (e1's Hp is already gone, so no
        // second Hp record for it).
        w.despawn(e2);
        w.despawn(e1);
        assert_eq!(w.since(false, w.hp, t0), vec![e0, e1, e2]);
        assert_eq!(w.since(true, w.cn, t0), vec![e1]);

        // The Rust API reads the very same log.
        let rust: Vec<u64> = w
            .rust()
            .removed_since::<RmHp>(&crate::tick::ChangeTracker::new())
            .map(Entity::as_ffi)
            .collect();
        assert_eq!(rust, w.since(false, w.hp, 0));
        assert_eq!(w.rust().removal_count::<RmHp>() as i32, w.static_count(w.hp));
        assert_eq!(w.rust().removal_count::<RmCn>() as i32, w.sparse_count(w.cn));
    }

    #[test]
    fn refused_and_no_op_removals_record_nothing() {
        let mut w = RmWorld::new();
        for id in [w.hp, w.mp, w.ro] {
            w.track_static(id);
        }
        w.track_sparse(w.cn);
        w.advance();
        let [e0, e1, e2] = w.e;

        // SAFETY: `w.ptr` is live; every pointer below is valid for its length.
        unsafe {
            // The entity lacks the component.
            assert_eq!(w.remove(e2, w.mp), NOT_FOUND);
            // A component registered read-only cannot be removed from C.
            assert_eq!(w.remove(e0, w.ro), NOT_WRITABLE);
            // An id this world never issued.
            assert_eq!(w.remove(e0, 9999), NOT_FOUND);
            // A handle that is not alive.
            assert_eq!(w.remove(u64::MAX, w.hp), NOT_ALIVE);

            // All-or-nothing lists: one bad member refuses the whole list,
            // so the good members record nothing either.
            let with_read_only = [w.hp, w.mp, w.ro];
            assert_eq!(
                mid_ecs_world_static_component_remove_many(w.ptr, e0, with_read_only.as_ptr(), 3),
                NOT_WRITABLE
            );
            let with_absent = [w.hp, w.mp];
            assert!(
                mid_ecs_world_static_component_remove_many(w.ptr, e1, with_absent.as_ptr(), 2) < 0,
                "e1 has no Mp"
            );
            let duplicate = [w.hp, w.hp];
            assert!(
                mid_ecs_world_static_component_remove_many(w.ptr, e0, duplicate.as_ptr(), 2) < 0
            );

            // Replacing a value, and a refused insert, are not removals.
            let bytes = 7u32.to_ne_bytes();
            assert_eq!(
                mid_ecs_world_static_component_write(w.ptr, e0, w.hp, bytes.as_ptr(), 4),
                OK
            );
            assert_eq!(
                mid_ecs_world_static_component_insert(w.ptr, e0, w.hp, bytes.as_ptr(), 4),
                ALREADY_PRESENT
            );
        }
        for id in [w.hp, w.mp, w.ro] {
            assert_eq!(w.static_count(id), 0, "static component {id}");
        }
        assert_eq!(w.sparse_count(w.cn), 0);
        // And the refused ones really left the data alone.
        assert!(w.rust().has_static::<RmMp>(crate::world::Entity::from_ffi(e0)));
        assert!(w.rust().has_static::<RmHp>(crate::world::Entity::from_ffi(e1)));
    }

    #[test]
    fn removed_since_windows_by_last_run_and_reports_each_removal_of_a_reused_entity() {
        let mut w = RmWorld::new();
        w.track_static(w.hp);
        let t0 = w.tick();
        let e0 = w.e[0];

        let t_first = w.advance();
        assert_eq!(w.remove(e0, w.hp), OK);
        w.advance();
        w.rust()
            .insert_static(crate::world::Entity::from_ffi(e0), RmHp { v: 9 });
        let t_second = w.advance();
        assert_eq!(w.remove(e0, w.hp), OK);

        assert_eq!(w.since(false, w.hp, 0), vec![e0, e0], "once per removal");
        assert_eq!(w.since(false, w.hp, t0), vec![e0, e0]);
        assert_eq!(
            w.since(false, w.hp, t_first),
            vec![e0],
            "a removal in the same tick as last_run is not newer"
        );
        assert_eq!(w.since(false, w.hp, t_first + 1), vec![e0]);
        assert_eq!(w.since(false, w.hp, t_second), Vec::<u64>::new());
        assert_eq!(w.since(false, w.hp, w.tick()), Vec::<u64>::new());
    }

    #[test]
    fn trim_and_clear_drop_entries_but_keep_components_tracked() {
        let mut w = RmWorld::new();
        w.track_static(w.hp);
        w.track_static(w.mp);
        let [e0, e1, e2] = w.e;
        let ids = [w.mp];

        w.advance(); // tick 2
        assert_eq!(w.remove(e0, w.hp), OK);
        let t3 = w.advance(); // tick 3
        assert_eq!(w.remove(e1, w.hp), OK);
        // SAFETY: `w.ptr` is live; `ids` is valid for 1 element.
        assert_eq!(
            unsafe { mid_ecs_world_static_component_remove_many(w.ptr, e0, ids.as_ptr(), 1) },
            OK
        );
        w.advance(); // tick 4
        w.despawn(e2);
        assert_eq!((w.static_count(w.hp), w.static_count(w.mp)), (3, 1));

        // Trim as of tick 3: everything not newer than 3 goes, in every
        // tracked component's log.
        // SAFETY: `w.ptr` is a live handle.
        assert_eq!(unsafe { mid_ecs_world_trim_removals(w.ptr, t3) }, OK);
        assert_eq!((w.static_count(w.hp), w.static_count(w.mp)), (1, 0));
        assert_eq!(w.since(false, w.hp, 0), vec![e2]);

        // SAFETY: `w.ptr` is a live handle.
        assert_eq!(unsafe { mid_ecs_world_clear_removals(w.ptr) }, OK);
        assert_eq!((w.static_count(w.hp), w.static_count(w.mp)), (0, 0));
        // SAFETY: `w.ptr` is a live handle.
        unsafe {
            assert_eq!(mid_ecs_world_static_component_tracks_removals(w.ptr, w.hp), 1);
            assert_eq!(mid_ecs_world_static_component_tracks_removals(w.ptr, w.mp), 1);
        }
        // Still recording after a clear.
        w.rust()
            .insert_static(crate::world::Entity::from_ffi(e1), RmHp { v: 5 });
        w.advance();
        assert_eq!(w.remove(e1, w.hp), OK);
        assert_eq!(w.since(false, w.hp, 0), vec![e1]);
    }

    #[test]
    fn removed_since_follows_the_buffer_conventions() {
        let w = RmWorld::new();
        w.track_static(w.hp);
        w.advance();
        let [e0, e1, e2] = w.e;
        assert_eq!(w.remove(e0, w.hp), OK);
        assert_eq!(w.remove(e1, w.hp), OK);
        w.despawn(e2);

        // SAFETY: `w.ptr` is live; every buffer is valid for its capacity.
        unsafe {
            assert_eq!(
                mid_ecs_world_static_component_removed_since(w.ptr, w.hp, 0, ptr::null_mut(), 0),
                3,
                "a NULL buffer queries the count"
            );

            let mut small = [u64::MAX; 2];
            assert_eq!(
                mid_ecs_world_static_component_removed_since(
                    w.ptr,
                    w.hp,
                    0,
                    small.as_mut_ptr(),
                    2
                ),
                BUFFER_TOO_SMALL
            );
            assert_eq!(small, [u64::MAX; 2], "no partial fill");

            let mut exact = [u64::MAX; 3];
            assert_eq!(
                mid_ecs_world_static_component_removed_since(
                    w.ptr,
                    w.hp,
                    0,
                    exact.as_mut_ptr(),
                    3
                ),
                3
            );
            assert_eq!(exact, [e0, e1, e2], "oldest first");

            let mut roomy = [u64::MAX; 5];
            assert_eq!(
                mid_ecs_world_static_component_removed_since(
                    w.ptr,
                    w.hp,
                    0,
                    roomy.as_mut_ptr(),
                    5
                ),
                3
            );
            assert_eq!(&roomy[..3], &[e0, e1, e2]);
            assert_eq!(&roomy[3..], &[u64::MAX; 2], "only the count is written");

            // An empty answer is 0, with a zero-capacity buffer too.
            let after = w.tick();
            let mut none = [u64::MAX; 1];
            assert_eq!(
                mid_ecs_world_static_component_removed_since(
                    w.ptr,
                    w.hp,
                    after,
                    none.as_mut_ptr(),
                    0
                ),
                0
            );
            assert_eq!(none, [u64::MAX]);
        }
    }

    #[test]
    fn sparse_shell_removals_are_tracked_apart_from_the_archetype_core() {
        let mut w = RmWorld::new();
        w.track_sparse(w.cn);
        w.advance();
        let [e0, e1, _] = w.e;

        // A Sparse-Shell removal through the Rust API shows up in C...
        assert!(w
            .rust()
            .remove::<RmCn>(crate::world::Entity::from_ffi(e0))
            .is_some());
        assert_eq!(w.since(true, w.cn, 0), vec![e0]);
        // ...and does not leak into the Archetype-Core component that
        // happens to share the numeric id.
        assert_eq!(w.static_count(w.hp), 0);
        // SAFETY: `w.ptr` is a live handle.
        assert_eq!(
            unsafe { mid_ecs_world_static_component_tracks_removals(w.ptr, w.hp) },
            0
        );

        // Track the Archetype-Core side too; each log keeps its own entries.
        w.track_static(w.hp);
        w.advance();
        assert!(w
            .rust()
            .remove_static::<RmHp>(crate::world::Entity::from_ffi(e1))
            .is_some());
        assert_eq!(w.since(false, w.hp, 0), vec![e1]);
        assert_eq!(w.since(true, w.cn, 0), vec![e0]);
    }

    // ── filtered change queries (C API) ──────────────────────────────

    use std::collections::HashSet;

    use crate::data_filter::DataFilter;
    use crate::query_data::{Added, Changed};
    use crate::tick::ChangeTracker;

    const INVALID_ARGUMENT: i32 = MidEcsStatus::InvalidArgument as i32;

    #[derive(
        Debug, Clone, Copy, PartialEq, zerocopy::FromBytes, IntoBytes, KnownLayout, Immutable,
    )]
    #[repr(C)]
    struct QA {
        v: u32,
    }

    #[derive(
        Debug, Clone, Copy, PartialEq, zerocopy::FromBytes, IntoBytes, KnownLayout, Immutable,
    )]
    #[repr(C)]
    struct QB {
        v: u32,
    }

    #[derive(
        Debug, Clone, Copy, PartialEq, zerocopy::FromBytes, IntoBytes, KnownLayout, Immutable,
    )]
    #[repr(C)]
    struct QC {
        v: u32,
    }

    /// Used only through the typed API: never registered for FFI.
    #[derive(Debug, Clone, Copy, PartialEq)]
    struct QD(u32);

    /// A filter described with owned lists, so the raw `MidEcsRowFilter`
    /// can borrow from it for one call.
    #[derive(Default, Clone)]
    struct Q {
        with: Vec<u32>,
        without: Vec<u32>,
        any_of: Vec<u32>,
        all_added: Vec<u32>,
        all_changed: Vec<u32>,
        any_added: Vec<u32>,
        any_changed: Vec<u32>,
    }

    impl Q {
        fn raw(&self) -> MidEcsRowFilter {
            MidEcsRowFilter {
                with_ids: self.with.as_ptr(),
                with_len: self.with.len(),
                without_ids: self.without.as_ptr(),
                without_len: self.without.len(),
                any_of_ids: self.any_of.as_ptr(),
                any_of_len: self.any_of.len(),
                all_added_ids: self.all_added.as_ptr(),
                all_added_len: self.all_added.len(),
                all_changed_ids: self.all_changed.as_ptr(),
                all_changed_len: self.all_changed.len(),
                any_added_ids: self.any_added.as_ptr(),
                any_added_len: self.any_added.len(),
                any_changed_ids: self.any_changed.as_ptr(),
                any_changed_len: self.any_changed.len(),
            }
        }
    }

    const SENTINEL: MidEcsMatchedRow = MidEcsMatchedRow {
        entity: u64::MAX,
        archetype_id: u32::MAX,
        row: u32::MAX,
    };

    /// A world with `QA`, `QB`, `QC` registered for FFI. `with_entities`
    /// builds six entities (`e[0]`, `e[1]` in `{A}`, `e[2]`, `e[3]` in
    /// `{A, B}`, `e[4]` in `{B}`, `e[5]` in `{A, B, C}`) and then advances
    /// the tick, so a tracker that reads `now()` afterwards sees nothing.
    struct QWorld {
        ptr: *mut MidEcsWorld,
        a: u32,
        b: u32,
        c: u32,
        e: Vec<Entity>,
    }

    impl QWorld {
        fn new(with_entities: bool) -> Self {
            let ptr = mid_ecs_world_new();
            // SAFETY: `ptr` is non-null, just created, freed in `Drop`.
            let w = unsafe { &mut (*ptr).0 };
            let a = w.register_ffi_static_component::<QA>("QA").as_u32();
            let b = w.register_ffi_static_component::<QB>("QB").as_u32();
            let c = w.register_ffi_static_component::<QC>("QC").as_u32();
            let mut e = Vec::new();
            if with_entities {
                for i in 0..6u32 {
                    let en = w.spawn();
                    if i != 4 {
                        w.insert_static(en, QA { v: i });
                    }
                    if i >= 2 {
                        w.insert_static(en, QB { v: i });
                    }
                    if i == 5 {
                        w.insert_static(en, QC { v: i });
                    }
                    e.push(en);
                }
                w.increment_change_tick();
            }
            Self { ptr, a, b, c, e }
        }

        fn rust(&mut self) -> &mut World {
            // SAFETY: `ptr` is a live handle owned by `self`.
            unsafe { &mut (*self.ptr).0 }
        }

        fn now(&self) -> u32 {
            // SAFETY: `ptr` is a live handle owned by `self`.
            unsafe { mid_ecs_world_change_tick(self.ptr) }
        }

        fn advance(&self) -> u32 {
            // SAFETY: `ptr` is a live handle owned by `self`.
            unsafe { mid_ecs_world_increment_change_tick(self.ptr) }
        }

        fn write_a(&mut self, i: usize, v: u32) {
            let e = self.e[i];
            self.rust().get_static_mut::<QA>(e).expect("has QA").v = v;
        }

        fn write_b(&mut self, i: usize, v: u32) {
            let e = self.e[i];
            self.rust().get_static_mut::<QB>(e).expect("has QB").v = v;
        }

        fn write_c(&mut self, i: usize, v: u32) {
            let e = self.e[i];
            self.rust().get_static_mut::<QC>(e).expect("has QC").v = v;
        }

        /// Runs the C query the way a C caller does (count with a NULL
        /// buffer, then fill one of exactly that size) and checks the
        /// two calls agree and that every row names the entity that
        /// really sits there.
        fn query(&self, last_run: u32, q: &Q) -> Vec<MidEcsMatchedRow> {
            let f = q.raw();
            // SAFETY: `ptr` is live; `f` borrows from `q`, which outlives the call.
            let n = unsafe {
                mid_ecs_world_static_query_since(self.ptr, last_run, &f, ptr::null_mut(), 0)
            };
            assert!(n >= 0, "query_since returned status {n}");
            let mut buf = vec![SENTINEL; n as usize];
            // SAFETY: as above; `buf` is valid for `n` elements.
            let got = unsafe {
                mid_ecs_world_static_query_since(self.ptr, last_run, &f, buf.as_mut_ptr(), buf.len())
            };
            assert_eq!(got, n);
            for pair in buf.windows(2) {
                assert!(
                    pair[0].archetype_id < pair[1].archetype_id
                        || (pair[0].archetype_id == pair[1].archetype_id
                            && pair[0].row < pair[1].row),
                    "rows must be ordered by archetype, then ascending row: {pair:?}"
                );
            }
            for m in &buf {
                assert_eq!(self.entity_at(m.archetype_id, m.row), m.entity, "{m:?}");
            }
            buf
        }

        /// The entity at `(archetype, row)`, read through whichever of the
        /// three components that archetype holds.
        fn entity_at(&self, archetype: u32, row: u32) -> u64 {
            for id in [self.a, self.b, self.c] {
                // SAFETY: `ptr` is live; a NULL buffer queries the count.
                let n = unsafe {
                    mid_ecs_world_static_component_entity_ids(
                        self.ptr,
                        archetype,
                        id,
                        ptr::null_mut(),
                        0,
                    )
                };
                if n >= 0 {
                    let mut ids = vec![0u64; n as usize];
                    // SAFETY: `ids` is valid for `n` elements.
                    let got = unsafe {
                        mid_ecs_world_static_component_entity_ids(
                            self.ptr,
                            archetype,
                            id,
                            ids.as_mut_ptr(),
                            ids.len(),
                        )
                    };
                    assert_eq!(got, n);
                    return ids[row as usize];
                }
            }
            panic!("no component of archetype {archetype} found");
        }

        fn entities(&self, last_run: u32, q: &Q) -> Vec<u64> {
            let mut v: Vec<u64> = self.query(last_run, q).iter().map(|m| m.entity).collect();
            v.sort_unstable();
            v
        }
    }

    impl Drop for QWorld {
        fn drop(&mut self) {
            // SAFETY: `ptr` is the live handle `new` created, freed once.
            unsafe { mid_ecs_world_free(self.ptr) };
        }
    }

    fn ffi_set(entities: &[Entity]) -> Vec<u64> {
        let mut v: Vec<u64> = entities.iter().map(|e| e.as_ffi()).collect();
        v.sort_unstable();
        v
    }

    #[test]
    fn since_added_finds_new_entities_across_archetypes_with_aligned_rows() {
        let mut w = QWorld::new(true);
        let t0 = w.now();
        w.advance();
        let n1 = w.rust().spawn();
        w.rust().insert_static(n1, QA { v: 70 });
        let n2 = w.rust().spawn();
        w.rust().insert_static(n2, QA { v: 71 });
        w.rust().insert_static(n2, QB { v: 72 });

        let added_a = Q {
            all_added: vec![w.a],
            ..Q::default()
        };
        let rows = w.query(t0, &added_a);
        assert_eq!(rows.len(), 2);
        let archetypes: HashSet<u32> = rows.iter().map(|m| m.archetype_id).collect();
        assert_eq!(archetypes.len(), 2, "one row in {{A}}, one in {{A, B}}");
        for m in &rows {
            let value = w
                .rust()
                .get_static::<QA>(Entity::from_ffi(m.entity))
                .expect("has QA")
                .v;
            assert!(value == 70 || value == 71, "row {m:?} holds {value}");
        }
        assert_eq!(w.entities(t0, &added_a), ffi_set(&[n1, n2]));

        let added_b = Q {
            all_added: vec![w.b],
            ..Q::default()
        };
        assert_eq!(w.entities(t0, &added_b), ffi_set(&[n2]));
        assert_eq!(w.entities(w.now(), &added_a), Vec::<u64>::new());
    }

    #[test]
    fn since_changed_includes_inserts_and_mutations_but_added_only_inserts() {
        let mut w = QWorld::new(true);
        let t0 = w.now();
        w.advance();
        w.write_a(1, 100);
        w.write_a(2, 101);
        let n = w.rust().spawn();
        w.rust().insert_static(n, QA { v: 5 });
        let e = w.e.clone();

        let changed = Q {
            all_changed: vec![w.a],
            ..Q::default()
        };
        assert_eq!(w.entities(t0, &changed), ffi_set(&[e[1], e[2], n]));
        let added = Q {
            all_added: vec![w.a],
            ..Q::default()
        };
        assert_eq!(
            w.entities(t0, &added),
            ffi_set(&[n]),
            "a mutation is not an addition"
        );
    }

    #[test]
    fn all_terms_intersect_and_rule_out_archetypes_lacking_a_component() {
        let mut w = QWorld::new(true);
        let t0 = w.now();
        w.advance();
        w.write_a(2, 1);
        w.write_b(2, 1); // e[2] {A, B}: both changed
        w.write_a(3, 1); // e[3] {A, B}: only A
        w.write_a(1, 1); // e[1] {A}: A changed, no B at all
        let e = w.e.clone();

        let both = Q {
            all_changed: vec![w.a, w.b],
            ..Q::default()
        };
        assert_eq!(w.entities(t0, &both), ffi_set(&[e[2]]));

        // Added and Changed combine: everything here was inserted before t0,
        // so nothing is Added, however much changed.
        let mixed = Q {
            all_added: vec![w.a],
            all_changed: vec![w.b],
            ..Q::default()
        };
        assert_eq!(w.entities(t0, &mixed), Vec::<u64>::new());
        let n = w.rust().spawn();
        w.rust().insert_static(n, QA { v: 1 });
        w.rust().insert_static(n, QB { v: 1 });
        assert_eq!(w.entities(t0, &mixed), ffi_set(&[n]));
    }

    #[test]
    fn any_terms_union_and_a_member_the_archetype_lacks_counts_as_false() {
        let mut w = QWorld::new(true);
        let t0 = w.now();
        w.advance();
        w.write_a(1, 1); // {A}
        w.write_b(4, 1); // {B}
        w.write_b(3, 1); // {A, B}, via B
        let e = w.e.clone();

        let either = Q {
            any_changed: vec![w.a, w.b],
            ..Q::default()
        };
        assert_eq!(w.entities(t0, &either), ffi_set(&[e[1], e[3], e[4]]));

        // An archetype holding none of the listed components has no row.
        let only_c = Q {
            any_changed: vec![w.c],
            ..Q::default()
        };
        assert_eq!(w.entities(t0, &only_c), Vec::<u64>::new());
        w.write_c(5, 1);
        assert_eq!(w.entities(t0, &only_c), ffi_set(&[e[5]]));

        // any_added and any_changed form ONE group.
        let n = w.rust().spawn();
        w.rust().insert_static(n, QA { v: 9 });
        let mixed = Q {
            any_added: vec![w.a],
            any_changed: vec![w.b],
            ..Q::default()
        };
        // n is Added in A; e[3] and e[4] have a changed B. e[1] has a changed A
        // that is not an Added one, and e[5] has only a changed C.
        assert_eq!(w.entities(t0, &mixed), ffi_set(&[n, e[3], e[4]]));

        // Two members of the same any_added list both count, including when
        // they qualify different rows of one archetype: e[4] ({B}) gains an A
        // and e[0] ({A}) gains a B, so both land in {A, B}, each with exactly
        // one Added member.
        let m = w.rust().spawn();
        w.rust().insert_static(m, QB { v: 9 });
        w.rust().insert_static(e[4], QA { v: 9 });
        w.rust().insert_static(e[0], QB { v: 9 });
        let two_added = Q {
            any_added: vec![w.a, w.b],
            ..Q::default()
        };
        assert_eq!(w.entities(t0, &two_added), ffi_set(&[n, m, e[4], e[0]]));
    }

    #[test]
    fn the_all_and_any_groups_combine() {
        let mut w = QWorld::new(true);
        let t0 = w.now();
        w.advance();
        w.write_a(2, 1);
        w.write_b(2, 1); // {A, B}: A and B changed
        w.write_a(3, 1); // {A, B}: A changed, neither B nor C
        w.write_a(5, 1);
        w.write_c(5, 1); // {A, B, C}: A and C changed
        w.write_a(0, 1); // {A}: A changed, but the archetype holds no B or C
        w.write_b(4, 1); // {B}: B changed, but no A
        let e = w.e.clone();
        let q = Q {
            all_changed: vec![w.a],
            any_changed: vec![w.b, w.c],
            ..Q::default()
        };
        assert_eq!(w.entities(t0, &q), ffi_set(&[e[2], e[5]]));
    }

    #[test]
    fn structural_lists_compose_with_the_change_terms() {
        let mut w = QWorld::new(true);
        let t0 = w.now();
        w.advance();
        for i in [0, 2, 5] {
            w.write_a(i, 1);
        }
        let e = w.e.clone();
        let base = Q {
            all_changed: vec![w.a],
            ..Q::default()
        };
        assert_eq!(w.entities(t0, &base), ffi_set(&[e[0], e[2], e[5]]));
        let q = |f: &dyn Fn(&mut Q)| {
            let mut q = base.clone();
            f(&mut q);
            q
        };
        assert_eq!(
            w.entities(t0, &q(&|q| q.with = vec![w.b])),
            ffi_set(&[e[2], e[5]])
        );
        assert_eq!(
            w.entities(t0, &q(&|q| q.without = vec![w.b])),
            ffi_set(&[e[0]])
        );
        assert_eq!(
            w.entities(t0, &q(&|q| {
                q.with = vec![w.b];
                q.without = vec![w.c];
            })),
            ffi_set(&[e[2]])
        );
        assert_eq!(
            w.entities(t0, &q(&|q| q.any_of = vec![w.c])),
            ffi_set(&[e[5]])
        );
        // The structural lists keep their lenient rule for unknown ids.
        assert_eq!(
            w.entities(t0, &q(&|q| q.with = vec![9999])),
            Vec::<u64>::new()
        );
        assert_eq!(
            w.entities(t0, &q(&|q| q.without = vec![9999])),
            ffi_set(&[e[0], e[2], e[5]])
        );
    }

    #[test]
    fn the_window_follows_last_run_and_zero_sees_everything() {
        let mut w = QWorld::new(true);
        let t0 = w.now();
        let t1 = w.advance();
        w.write_a(1, 1);
        let q = Q {
            all_changed: vec![w.a],
            ..Q::default()
        };
        let e1 = w.e[1].as_ffi();
        assert_eq!(w.entities(t0, &q), vec![e1]);
        assert_eq!(
            w.entities(t1, &q),
            Vec::<u64>::new(),
            "a change in the same tick as last_run is not newer"
        );
        assert_eq!(w.entities(0, &q).len(), 5, "a fresh tracker sees every A row");
    }

    #[test]
    fn errors_are_reported_before_anything_is_written() {
        let mut w = QWorld::new(true);
        // An id that exists in the Archetype Core but was never registered
        // for FFI: only the typed API has seen `QD`.
        let n = w.rust().spawn();
        w.rust().insert_static(n, QD(1));
        let qd_id = (0..16u32)
            .find(|&i| {
                w.rust()
                    .archetypes
                    .type_id_of(ComponentId::from_u32(i))
                    == Some(std::any::TypeId::of::<QD>())
            })
            .expect("QD was issued an id");
        assert!(!w.rust().archetypes.is_ffi_registered(ComponentId::from_u32(qd_id)));

        let ok = Q {
            all_changed: vec![w.a],
            ..Q::default()
        };
        let mut out = [SENTINEL; 4];
        let mut call = |last_run: u32, q: &Q| {
            let f = q.raw();
            // SAFETY: `w.ptr` is live; `f` borrows from `q`; `out` is valid for 4.
            unsafe {
                mid_ecs_world_static_query_since(w.ptr, last_run, &f, out.as_mut_ptr(), 4)
            }
        };

        // NotFound: an id in any of the four change lists.
        for id in [9999, MID_ECS_INVALID_ID, qd_id] {
            for q in [
                Q { all_added: vec![id], ..ok.clone() },
                Q { all_changed: vec![w.a, id], ..Q::default() },
                Q { any_added: vec![id], ..ok.clone() },
                Q { any_changed: vec![w.a, id], ..ok.clone() },
            ] {
                assert_eq!(call(0, &q), NOT_FOUND, "id {id}");
            }
        }
        // InvalidArgument: no change term, even with structural lists.
        assert_eq!(call(0, &Q::default()), INVALID_ARGUMENT);
        assert_eq!(
            call(0, &Q { with: vec![w.a], without: vec![w.b], any_of: vec![w.c], ..Q::default() }),
            INVALID_ARGUMENT
        );
        assert_eq!(out, [SENTINEL; 4], "nothing written on an error");

        // NullPointer: world, filter, and a NULL list with a nonzero length.
        let f = ok.raw();
        // SAFETY: the NULL cases are the documented ones; `f` is valid.
        unsafe {
            assert_eq!(
                mid_ecs_world_static_query_since(ptr::null(), 0, &f, ptr::null_mut(), 0),
                NULL_POINTER
            );
            assert_eq!(
                mid_ecs_world_static_query_since(w.ptr, 0, ptr::null(), ptr::null_mut(), 0),
                NULL_POINTER
            );
            for broken in 0..7 {
                let mut g = f;
                match broken {
                    0 => (g.with_ids, g.with_len) = (ptr::null(), 1),
                    1 => (g.without_ids, g.without_len) = (ptr::null(), 1),
                    2 => (g.any_of_ids, g.any_of_len) = (ptr::null(), 1),
                    3 => (g.all_added_ids, g.all_added_len) = (ptr::null(), 1),
                    4 => (g.all_changed_ids, g.all_changed_len) = (ptr::null(), 1),
                    5 => (g.any_added_ids, g.any_added_len) = (ptr::null(), 1),
                    _ => (g.any_changed_ids, g.any_changed_len) = (ptr::null(), 1),
                }
                assert_eq!(
                    mid_ecs_world_static_query_since(w.ptr, 0, &g, ptr::null_mut(), 0),
                    NULL_POINTER,
                    "list {broken}"
                );
            }
            // NULL with length 0 is an empty list, not an error.
            let mut g = f;
            g.with_ids = ptr::null();
            g.with_len = 0;
            assert!(mid_ecs_world_static_query_since(w.ptr, 0, &g, ptr::null_mut(), 0) >= 0);
        }
    }

    #[test]
    fn query_since_follows_the_buffer_conventions() {
        let mut w = QWorld::new(true);
        let t0 = w.now();
        w.advance();
        for i in [0, 1, 2] {
            w.write_a(i, 1);
        }
        let q = Q {
            all_changed: vec![w.a],
            ..Q::default()
        };
        let f = q.raw();
        // SAFETY: `w.ptr` is live; `f` borrows from `q`; every buffer is valid for its capacity.
        unsafe {
            assert_eq!(
                mid_ecs_world_static_query_since(w.ptr, t0, &f, ptr::null_mut(), 0),
                3,
                "a NULL buffer queries the count"
            );
            let mut small = [SENTINEL; 2];
            assert_eq!(
                mid_ecs_world_static_query_since(w.ptr, t0, &f, small.as_mut_ptr(), 2),
                BUFFER_TOO_SMALL
            );
            assert_eq!(small, [SENTINEL; 2], "no partial fill");
            let mut roomy = [SENTINEL; 5];
            assert_eq!(
                mid_ecs_world_static_query_since(w.ptr, t0, &f, roomy.as_mut_ptr(), 5),
                3
            );
            assert!(roomy[..3].iter().all(|m| *m != SENTINEL));
            assert_eq!(&roomy[3..], &[SENTINEL; 2], "only the count is written");
            // An empty answer is 0, even into a zero-capacity buffer.
            let mut none = [SENTINEL; 1];
            assert_eq!(
                mid_ecs_world_static_query_since(w.ptr, w.now(), &f, none.as_mut_ptr(), 0),
                0
            );
            assert_eq!(none, [SENTINEL]);
        }
    }

    #[test]
    fn a_component_listed_twice_does_not_duplicate_rows() {
        let mut w = QWorld::new(true);
        let t0 = w.now();
        w.advance();
        w.write_a(2, 1);
        let q = Q {
            all_changed: vec![w.a, w.a],
            any_changed: vec![w.a, w.a, w.b],
            ..Q::default()
        };
        assert_eq!(w.query(t0, &q).len(), 1);
    }

    /// xorshift64: enough randomness for a history generator.
    struct Xs(u64);

    impl Xs {
        fn next(&mut self, n: usize) -> usize {
            self.0 ^= self.0 << 13;
            self.0 ^= self.0 >> 7;
            self.0 ^= self.0 << 17;
            (self.0 % n as u64) as usize
        }
    }

    #[test]
    fn the_c_query_matches_the_typed_rust_queries_over_a_random_history() {
        let mut w = QWorld::new(false);
        let (a, b, c) = (w.a, w.b, w.c);
        let mut tracker = ChangeTracker::new();
        let mut last_run = 0u32;
        let mut alive: Vec<Entity> = Vec::new();
        let mut rng = Xs(0x9E37_79B9_7F4A_7C15);
        let mut non_empty = [0usize; 10];
        let mut empty = [0usize; 10];

        for step in 0..500u32 {
            for _ in 0..1 + rng.next(4) {
                let pick = if alive.is_empty() { 0 } else { rng.next(alive.len()) };
                match rng.next(12) {
                    0 | 1 => {
                        let e = w.rust().spawn();
                        w.rust().insert_static(e, QA { v: step });
                        if rng.next(2) == 0 {
                            w.rust().insert_static(e, QB { v: step });
                        }
                        if rng.next(4) == 0 {
                            w.rust().insert_static(e, QC { v: step });
                        }
                        alive.push(e);
                    }
                    2 if !alive.is_empty() => {
                        let e = alive.swap_remove(pick);
                        w.rust().despawn(e);
                    }
                    3 if !alive.is_empty() => {
                        w.rust().insert_static(alive[pick], QB { v: step });
                    }
                    4 if !alive.is_empty() => {
                        w.rust().remove_static::<QB>(alive[pick]);
                    }
                    5 if !alive.is_empty() => {
                        w.rust().remove_static::<QA>(alive[pick]);
                    }
                    6 if !alive.is_empty() => {
                        w.rust().insert_static(alive[pick], QC { v: step });
                    }
                    7 if !alive.is_empty() => {
                        w.rust().remove_static::<QC>(alive[pick]);
                    }
                    8 | 9 if !alive.is_empty() => {
                        if let Some(x) = w.rust().get_static_mut::<QA>(alive[pick]) {
                            x.v += 1;
                        }
                    }
                    10 if !alive.is_empty() => {
                        if let Some(x) = w.rust().get_static_mut::<QB>(alive[pick]) {
                            x.v += 1;
                        }
                    }
                    11 if !alive.is_empty() => {
                        if let Some(x) = w.rust().get_static_mut::<QC>(alive[pick]) {
                            x.v += 1;
                        }
                    }
                    _ => {}
                }
            }
            if rng.next(3) == 0 {
                w.advance();
            }
            if rng.next(4) == 0 {
                tracker.update(w.rust());
                last_run = tracker.last_run().get();
                w.advance();
            }
            assert_eq!(tracker.last_run().get(), last_run);

            fn typed<F: DataFilter + 'static>(
                w: &mut QWorld,
                tracker: &ChangeTracker,
            ) -> HashSet<u64> {
                w.rust()
                    .query_data_filtered_since::<Entity, F>(tracker)
                    .map(|e| e.as_ffi())
                    .collect()
            }
            let cases: [(HashSet<u64>, Q); 10] = [
                (
                    typed::<Changed<QA>>(&mut w, &tracker),
                    Q { all_changed: vec![a], ..Q::default() },
                ),
                (
                    typed::<Added<QA>>(&mut w, &tracker),
                    Q { all_added: vec![a], ..Q::default() },
                ),
                (
                    typed::<Or<(Changed<QA>, Changed<QB>)>>(&mut w, &tracker),
                    Q { any_changed: vec![a, b], ..Q::default() },
                ),
                (
                    typed::<(Changed<QA>, Changed<QB>)>(&mut w, &tracker),
                    Q { all_changed: vec![a, b], ..Q::default() },
                ),
                (
                    typed::<(Added<QA>, Changed<QB>)>(&mut w, &tracker),
                    Q { all_added: vec![a], all_changed: vec![b], ..Q::default() },
                ),
                (
                    typed::<(Changed<QA>, With<QB>)>(&mut w, &tracker),
                    Q { all_changed: vec![a], with: vec![b], ..Q::default() },
                ),
                (
                    typed::<(Changed<QA>, Without<QB>)>(&mut w, &tracker),
                    Q { all_changed: vec![a], without: vec![b], ..Q::default() },
                ),
                (
                    typed::<Or<(Added<QA>, Changed<QC>)>>(&mut w, &tracker),
                    Q { any_added: vec![a], any_changed: vec![c], ..Q::default() },
                ),
                (
                    typed::<(Or<(Changed<QB>, Changed<QC>)>, With<QA>)>(&mut w, &tracker),
                    Q { any_changed: vec![b, c], with: vec![a], ..Q::default() },
                ),
                (
                    typed::<(Changed<QA>, Or<(Changed<QB>, Changed<QC>)>)>(&mut w, &tracker),
                    Q { all_changed: vec![a], any_changed: vec![b, c], ..Q::default() },
                ),
            ];
            for (k, (expected, q)) in cases.iter().enumerate() {
                let rows = w.query(last_run, q);
                let got: HashSet<u64> = rows.iter().map(|m| m.entity).collect();
                assert_eq!(got.len(), rows.len(), "step {step}, case {k}: an entity twice");
                assert_eq!(&got, expected, "step {step}, case {k}");
                if expected.is_empty() {
                    empty[k] += 1;
                } else {
                    non_empty[k] += 1;
                }
            }
        }
        // The history must have produced both kinds of answer for every
        // shape, or the comparison proves little.
        for k in 0..10 {
            assert!(non_empty[k] >= 10, "case {k}: only {} non-empty steps", non_empty[k]);
            assert!(empty[k] >= 10, "case {k}: only {} empty steps", empty[k]);
        }
    }

    // ── in-place mutable rows (C API) ────────────────────────────────

    use std::sync::atomic::{AtomicUsize, Ordering as AtomicOrdering};

    #[derive(
        Debug, Clone, Copy, PartialEq, zerocopy::FromBytes, IntoBytes, KnownLayout, Immutable,
    )]
    #[repr(C)]
    struct MwA {
        v: u32,
    }

    #[derive(
        Debug, Clone, Copy, PartialEq, zerocopy::FromBytes, IntoBytes, KnownLayout, Immutable,
    )]
    #[repr(C)]
    struct MwB {
        v: u32,
    }

    /// Registered read-only: it can be tracked and read, never written.
    #[derive(Debug, Clone, Copy, PartialEq, IntoBytes, KnownLayout, Immutable)]
    #[repr(C)]
    struct MwRo {
        v: u32,
    }

    const SPAN_SENTINEL: FfiSpanMut = FfiSpanMut {
        ptr: 0xDEAD as *mut u8,
        stride: 7,
        count: 9,
    };

    /// `MwA`, `MwB` writable and `MwRo` read-only. Five entities:
    /// `e[0]` = {A, B, Ro}, `e[1]`, `e[2]`, `e[4]` = {A}, `e[3]` = {A, B},
    /// with `A.v == 10 + index`; the tick is advanced once after building.
    struct MwWorld {
        ptr: *mut MidEcsWorld,
        a: u32,
        b: u32,
        ro: u32,
        e: Vec<Entity>,
    }

    impl MwWorld {
        fn new() -> Self {
            let ptr = mid_ecs_world_new();
            // SAFETY: `ptr` is non-null, just created, freed in `Drop`.
            let w = unsafe { &mut (*ptr).0 };
            let a = w
                .register_ffi_static_component_writable::<MwA>("MwA")
                .as_u32();
            let b = w
                .register_ffi_static_component_writable::<MwB>("MwB")
                .as_u32();
            let ro = w.register_ffi_static_component::<MwRo>("MwRo").as_u32();
            let mut e = Vec::new();
            for i in 0..5u32 {
                let en = w.spawn();
                w.insert_static(en, MwA { v: 10 + i });
                if i == 0 || i == 3 {
                    w.insert_static(en, MwB { v: 20 + i });
                }
                if i == 0 {
                    w.insert_static(en, MwRo { v: 30 });
                }
                e.push(en);
            }
            w.increment_change_tick();
            Self { ptr, a, b, ro, e }
        }

        fn rust(&mut self) -> &mut World {
            // SAFETY: `ptr` is a live handle owned by `self`.
            unsafe { &mut (*self.ptr).0 }
        }

        fn now(&self) -> u32 {
            // SAFETY: `ptr` is a live handle owned by `self`.
            unsafe { mid_ecs_world_change_tick(self.ptr) }
        }

        fn advance(&self) -> u32 {
            // SAFETY: `ptr` is a live handle owned by `self`.
            unsafe { mid_ecs_world_increment_change_tick(self.ptr) }
        }

        /// `row_mut` on a fresh sentinel span; returns the status and the
        /// span (still the sentinel on an error).
        fn row_mut(&self, entity: u64, id: u32) -> (i32, FfiSpanMut) {
            let mut span = SPAN_SENTINEL;
            // SAFETY: `ptr` is live; `span` is valid for one write.
            let status = unsafe {
                mid_ecs_world_static_component_row_mut(self.ptr, entity, id, &mut span)
            };
            (status, span)
        }

        /// Entities of every row of `id` changed after `last_run`, through
        /// the C filtered query, sorted.
        fn changed(&self, last_run: u32, id: u32) -> Vec<u64> {
            let ids = [id];
            let f = MidEcsRowFilter {
                with_ids: ptr::null(),
                with_len: 0,
                without_ids: ptr::null(),
                without_len: 0,
                any_of_ids: ptr::null(),
                any_of_len: 0,
                all_added_ids: ptr::null(),
                all_added_len: 0,
                all_changed_ids: ids.as_ptr(),
                all_changed_len: 1,
                any_added_ids: ptr::null(),
                any_added_len: 0,
                any_changed_ids: ptr::null(),
                any_changed_len: 0,
            };
            let mut buf = vec![SENTINEL; 16];
            // SAFETY: `ptr` is live; `f` borrows `ids`; `buf` is valid for 16.
            let n = unsafe {
                mid_ecs_world_static_query_since(self.ptr, last_run, &f, buf.as_mut_ptr(), 16)
            };
            assert!(n >= 0, "query_since returned {n}");
            let mut v: Vec<u64> = buf[..n as usize].iter().map(|m| m.entity).collect();
            v.sort_unstable();
            v
        }
    }

    impl Drop for MwWorld {
        fn drop(&mut self) {
            // SAFETY: `ptr` is the live handle `new` created, freed once.
            unsafe { mid_ecs_world_free(self.ptr) };
        }
    }

    #[test]
    fn row_mut_hands_out_one_writable_row_and_stamps_only_it() {
        let mut w = MwWorld::new();
        let t0 = w.now();
        w.advance();
        let e = w.e.clone();

        let (status, span) = w.row_mut(e[2].as_ffi(), w.a);
        assert_eq!(status, OK);
        assert_eq!((span.count, span.stride), (1, 4));
        assert!(!span.ptr.is_null());
        // SAFETY: the span is one live, 4-byte, writable `MwA` slot; no
        // structural change has happened since it was handed out.
        unsafe { ptr::write_unaligned(span.ptr as *mut u32, 77) };

        assert_eq!(w.rust().get_static::<MwA>(e[2]).unwrap().v, 77);
        for i in [0, 1, 3, 4] {
            assert_eq!(
                w.rust().get_static::<MwA>(e[i]).unwrap().v,
                10 + i as u32,
                "entity {i} must be untouched"
            );
        }
        assert_eq!(w.changed(t0, w.a), vec![e[2].as_ffi()], "exactly that row");
        // A mutation is not an insert: nothing is Added.
        let a_id = [w.a];
        let added = MidEcsRowFilter {
            all_added_ids: a_id.as_ptr(),
            all_added_len: 1,
            with_ids: ptr::null(),
            with_len: 0,
            without_ids: ptr::null(),
            without_len: 0,
            any_of_ids: ptr::null(),
            any_of_len: 0,
            all_changed_ids: ptr::null(),
            all_changed_len: 0,
            any_added_ids: ptr::null(),
            any_added_len: 0,
            any_changed_ids: ptr::null(),
            any_changed_len: 0,
        };
        // SAFETY: `w.ptr` is live; `added` borrows `a_id`.
        assert_eq!(
            unsafe { mid_ecs_world_static_query_since(w.ptr, t0, &added, ptr::null_mut(), 0) },
            0
        );

        // The pointer is the row: read-only span base + row * stride.
        let mut rows = [SENTINEL; 4];
        let ids = [w.a];
        let f = MidEcsRowFilter {
            all_changed_ids: ids.as_ptr(),
            all_changed_len: 1,
            ..added
        };
        let f = MidEcsRowFilter {
            all_added_ids: ptr::null(),
            all_added_len: 0,
            ..f
        };
        // SAFETY: `w.ptr` is live; `f` borrows `ids`; `rows` is valid for 4.
        let n = unsafe {
            mid_ecs_world_static_query_since(w.ptr, t0, &f, rows.as_mut_ptr(), 4)
        };
        assert_eq!(n, 1);
        let mut ro = FfiSpan {
            ptr: ptr::null(),
            stride: 0,
            count: 0,
        };
        // SAFETY: `w.ptr` is live; `ro` is valid for one write.
        assert_eq!(
            unsafe {
                mid_ecs_world_static_component_raw_span(w.ptr, rows[0].archetype_id, w.a, &mut ro)
            },
            OK
        );
        assert_eq!(
            span.ptr as usize,
            ro.ptr as usize + rows[0].row as usize * ro.stride
        );

        // Contrast: the bulk form stamps every row of the archetype.
        let mut bulk = SPAN_SENTINEL;
        // SAFETY: `w.ptr` is live; `bulk` is valid for one write.
        assert_eq!(
            unsafe {
                mid_ecs_world_static_component_raw_span_mut(
                    w.ptr,
                    rows[0].archetype_id,
                    w.a,
                    &mut bulk,
                )
            },
            OK
        );
        assert_eq!(
            w.changed(t0, w.a),
            {
                let mut v = vec![e[1].as_ffi(), e[2].as_ffi(), e[4].as_ffi()];
                v.sort_unstable();
                v
            },
            "raw_span_mut over-reports the whole {{A}} archetype"
        );
    }

    #[test]
    fn row_mut_errors_come_in_order_and_touch_nothing() {
        let mut w = MwWorld::new();
        let t0 = w.now();
        w.advance();
        let e = w.e.clone();
        w.rust().despawn(e[4]);
        let dead = e[4].as_ffi();

        // NotAlive first, whatever else is wrong.
        for id in [w.a, 9999, w.ro] {
            assert_eq!(w.row_mut(dead, id).0, NOT_ALIVE, "id {id}");
        }
        // Then UnknownId, then NotWritable, then Absent.
        assert_eq!(w.row_mut(e[1].as_ffi(), 9999).0, NOT_FOUND);
        assert_eq!(w.row_mut(e[0].as_ffi(), w.ro).0, NOT_WRITABLE);
        assert_eq!(
            w.row_mut(e[1].as_ffi(), w.ro).0,
            NOT_WRITABLE,
            "read-only is decided before absence"
        );
        assert_eq!(w.row_mut(e[1].as_ffi(), w.b).0, NOT_FOUND, "alive, no B");

        for (status, span) in [
            w.row_mut(dead, w.a),
            w.row_mut(e[1].as_ffi(), 9999),
            w.row_mut(e[0].as_ffi(), w.ro),
            w.row_mut(e[1].as_ffi(), w.b),
        ] {
            assert!(status < 0);
            assert_eq!(span, SPAN_SENTINEL, "out_span untouched on an error");
        }
        assert_eq!(w.changed(t0, w.a), Vec::<u64>::new(), "nothing stamped");
        assert_eq!(w.changed(t0, w.b), Vec::<u64>::new(), "nothing stamped");

        // NULL pointers.
        let mut span = SPAN_SENTINEL;
        // SAFETY: the NULL cases are the documented ones.
        unsafe {
            assert_eq!(
                mid_ecs_world_static_component_row_mut(ptr::null_mut(), e[1].as_ffi(), w.a, &mut span),
                NULL_POINTER
            );
            assert_eq!(
                mid_ecs_world_static_component_row_mut(w.ptr, e[1].as_ffi(), w.a, ptr::null_mut()),
                NULL_POINTER
            );
        }
        assert_eq!(w.changed(t0, w.a), Vec::<u64>::new());
    }

    #[test]
    fn row_mut_never_reaches_the_new_occupant_of_a_reused_slot() {
        let mut w = MwWorld::new();
        let stale = w.e[1];
        w.rust().despawn(stale);
        let n = w.rust().spawn();
        w.rust().insert_static(n, MwA { v: 5 });
        w.advance();
        let t1 = w.now();
        w.advance();

        assert_eq!(w.row_mut(stale.as_ffi(), w.a).0, NOT_ALIVE);
        assert_eq!(
            w.changed(t1, w.a),
            Vec::<u64>::new(),
            "the stale handle stamped nobody"
        );
        // Sensitivity: the live handle does work.
        assert_eq!(w.row_mut(n.as_ffi(), w.a).0, OK);
        assert_eq!(w.changed(t1, w.a), vec![n.as_ffi()]);
    }

    #[test]
    fn row_mut_stamps_exactly_what_get_static_mut_stamps() {
        // Two identical worlds, driven by the same random accesses: one
        // through the C `row_mut`, the other through `get_static_mut`.
        let mut c = MwWorld::new();
        let mut r = MwWorld::new();
        let mut tracker_c = ChangeTracker::new();
        let mut tracker_r = ChangeTracker::new();
        let mut rng = Xs(0xC0FF_EE12_3456_789B);
        let (mut touched, mut skipped) = (0usize, 0usize);

        for step in 0..300u32 {
            for _ in 0..1 + rng.next(3) {
                let i = rng.next(5);
                let on_b = rng.next(2) == 0;
                let value = step + 1000;
                let (ce, re) = (c.e[i], r.e[i]);
                let (status, span) = c.row_mut(ce.as_ffi(), if on_b { c.b } else { c.a });
                let got_r = if on_b {
                    r.rust().get_static_mut::<MwB>(re).map(|x| x.v = value)
                } else {
                    r.rust().get_static_mut::<MwA>(re).map(|x| x.v = value)
                };
                assert_eq!(status == OK, got_r.is_some(), "step {step}: both or neither");
                if status == OK {
                    touched += 1;
                    // SAFETY: the span is one live writable `u32` slot.
                    unsafe { ptr::write_unaligned(span.ptr as *mut u32, value) };
                } else {
                    skipped += 1;
                }
            }
            if rng.next(3) == 0 {
                c.advance();
                r.advance();
            }
            if rng.next(4) == 0 {
                tracker_c.update(c.rust());
                tracker_r.update(r.rust());
                c.advance();
                r.advance();
            }
            let changed = |w: &mut MwWorld, t: &ChangeTracker| -> (HashSet<usize>, HashSet<usize>) {
                let es = w.e.clone();
                let pos = |ids: HashSet<Entity>| -> HashSet<usize> {
                    ids.iter()
                        .map(|x| es.iter().position(|y| y == x).expect("known entity"))
                        .collect()
                };
                let a: HashSet<Entity> = w
                    .rust()
                    .query_data_filtered_since::<Entity, Changed<MwA>>(t)
                    .collect();
                let b: HashSet<Entity> = w
                    .rust()
                    .query_data_filtered_since::<Entity, Changed<MwB>>(t)
                    .collect();
                (pos(a), pos(b))
            };
            assert_eq!(
                changed(&mut c, &tracker_c),
                changed(&mut r, &tracker_r),
                "step {step}"
            );
        }
        assert!(touched > 100 && skipped > 20, "touched {touched}, skipped {skipped}");
        for i in 0..5 {
            let (ce, re) = (c.e[i], r.e[i]);
            assert_eq!(
                c.rust().get_static::<MwA>(ce).map(|x| x.v),
                r.rust().get_static::<MwA>(re).map(|x| x.v)
            );
        }
    }

    static MW_INSERT_HOOK_CALLS: AtomicUsize = AtomicUsize::new(0);

    #[test]
    fn row_mut_fires_no_component_hook() {
        let mut w = MwWorld::new();
        w.rust()
            .register_component_hooks::<MwA>()
            .on_insert(|_, _| {
                MW_INSERT_HOOK_CALLS.fetch_add(1, AtomicOrdering::SeqCst);
            });
        let before = MW_INSERT_HOOK_CALLS.load(AtomicOrdering::SeqCst);
        assert_eq!(w.row_mut(w.e[2].as_ffi(), w.a).0, OK);
        assert_eq!(
            MW_INSERT_HOOK_CALLS.load(AtomicOrdering::SeqCst),
            before,
            "a mutation is not an insert"
        );
        // Sensitivity: a real insert does fire it.
        let n = w.rust().spawn();
        w.rust().insert_static(n, MwA { v: 1 });
        assert_eq!(MW_INSERT_HOOK_CALLS.load(AtomicOrdering::SeqCst), before + 1);
    }

    #[test]
    fn a_spawned_entity_is_a_reservation_that_leaves_other_spans_valid() {
        // The C answer to "reserved entity ids": `mid_ecs_world_spawn` hands
        // out a real id immediately, so a caller needs no queue-returned one.
        let mut w = MwWorld::new();
        let mut base = FfiSpan {
            ptr: ptr::null(),
            stride: 0,
            count: 0,
        };
        // The {A}-only archetype, which holds e[1], e[2] and e[4].
        let (with, without) = ([w.a], [w.b, w.ro]);
        let mut found = [u32::MAX; 4];
        // SAFETY: `w.ptr` is live; every list is valid for its length.
        let n = unsafe {
            mid_ecs_world_archetypes_matching_static(
                w.ptr,
                with.as_ptr(),
                1,
                without.as_ptr(),
                2,
                ptr::null(),
                0,
                found.as_mut_ptr(),
                4,
            )
        };
        assert_eq!(n, 1);
        let only_a = found[0];
        // SAFETY: `w.ptr` is live; `base` is valid for one write.
        assert_eq!(
            unsafe { mid_ecs_world_static_component_raw_span(w.ptr, only_a, w.a, &mut base) },
            OK
        );
        let count_before = unsafe { mid_ecs_world_entity_count(w.ptr) };

        // SAFETY: `w.ptr` is live.
        let reserved = unsafe { mid_ecs_world_spawn(w.ptr) };
        assert_ne!(reserved, 0);
        // SAFETY: `w.ptr` is live; `again` is valid for one write.
        let mut again = FfiSpan {
            ptr: ptr::null(),
            stride: 0,
            count: 0,
        };
        unsafe {
            assert!(mid_ecs_world_is_alive(w.ptr, reserved));
            assert_eq!(mid_ecs_world_entity_count(w.ptr), count_before + 1);
            assert_eq!(
                mid_ecs_world_static_component_raw_span(w.ptr, only_a, w.a, &mut again),
                OK
            );
        }
        assert_eq!(
            (again.ptr, again.stride, again.count),
            (base.ptr, base.stride, base.count),
            "spawning an empty entity does not move another archetype's storage"
        );

        // The reserved id is usable in queued commands straight away, and
        // can be stored in other data before the queue is applied.
        // SAFETY: `w.ptr` is live; `q` is a fresh queue freed below.
        unsafe {
            let q = mid_ecs_commands_new();
            let bytes = 99u32.to_ne_bytes();
            assert_eq!(
                mid_ecs_commands_static_component_insert(q, w.ptr, reserved, w.a, bytes.as_ptr(), 4),
                OK
            );
            assert_eq!(mid_ecs_commands_apply(q, w.ptr, ptr::null_mut(), 0), 0);
            mid_ecs_commands_free(q);
        }
        assert_eq!(
            w.rust().get_static::<MwA>(Entity::from_ffi(reserved)).unwrap().v,
            99
        );

        // Not a queued spawn: clearing a queue does not take it back, so a
        // reservation that is never used must be despawned by the caller.
        // SAFETY: `w.ptr` is live; `q` is a fresh queue freed below.
        unsafe {
            let unused = mid_ecs_world_spawn(w.ptr);
            let q = mid_ecs_commands_new();
            mid_ecs_commands_clear(q);
            mid_ecs_commands_free(q);
            assert!(mid_ecs_world_is_alive(w.ptr, unused));
            assert_eq!(mid_ecs_world_despawn(w.ptr, unused), OK);
            assert!(!mid_ecs_world_is_alive(w.ptr, unused));
        }
    }

    #[test]
    fn world_row_mut_reports_the_documented_error_variants() {
        // Through the C mapping `UnknownId` and `Absent` are both NOT_FOUND;
        // the Rust variants are distinct and ordered.
        let mut w = MwWorld::new();
        let e = w.e.clone();
        let a = ComponentId::from_u32(w.a);
        let b = ComponentId::from_u32(w.b);
        let ro = ComponentId::from_u32(w.ro);
        let world = w.rust();
        world.despawn(e[4]);
        assert_eq!(
            world.static_component_row_mut(e[4], a),
            Err(ComponentFfiError::NotAlive)
        );
        assert_eq!(
            world.static_component_row_mut(e[1], ComponentId::from_u32(9999)),
            Err(ComponentFfiError::UnknownId)
        );
        assert_eq!(
            world.static_component_row_mut(e[1], ro),
            Err(ComponentFfiError::NotWritable)
        );
        assert_eq!(
            world.static_component_row_mut(e[1], b),
            Err(ComponentFfiError::Absent)
        );
        let span = world.static_component_row_mut(e[2], a).expect("e[2] has A");
        assert_eq!((span.count, span.stride), (1, 4));
    }

    // ── resource change detection (C API) ────────────────────────────

    #[test]
    fn resource_added_and_changed_since_follow_writes_from_c() {
        let w = mid_ecs_test_resource_fixture_world_new();
        // SAFETY: `w` is a live handle for this whole block, freed at its end.
        unsafe {
            let time = mid_ecs_world_lookup_ffi_resource_id(w, b"FfiTime\0".as_ptr().cast());
            let gravity =
                mid_ecs_world_lookup_ffi_resource_id(w, b"FfiGravity\0".as_ptr().cast());
            let t0 = mid_ecs_world_change_tick(w);
            // Time is inserted by the fixture; Gravity is registered only.
            assert_eq!(mid_ecs_world_resource_added_since(w, time, 0), 1);
            assert_eq!(mid_ecs_world_resource_added_since(w, gravity, 0), 0);
            assert_eq!(mid_ecs_world_resource_changed_since(w, gravity, 0), 0);
            assert_eq!(mid_ecs_world_resource_added_since(w, time, t0), 0, "same tick");

            mid_ecs_world_increment_change_tick(w);
            let g = 9.8f32.to_ne_bytes();
            assert_eq!(mid_ecs_world_resource_write(w, gravity, g.as_ptr(), 4), OK);
            assert_eq!(mid_ecs_world_resource_added_since(w, gravity, t0), 1);
            assert_eq!(mid_ecs_world_resource_changed_since(w, gravity, t0), 1);
            assert_eq!(mid_ecs_world_resource_changed_since(w, time, t0), 0);

            let t1 = mid_ecs_world_change_tick(w);
            mid_ecs_world_increment_change_tick(w);
            let g2 = 1.6f32.to_ne_bytes();
            assert_eq!(mid_ecs_world_resource_write(w, gravity, g2.as_ptr(), 4), OK);
            assert_eq!(mid_ecs_world_resource_added_since(w, gravity, t1), 0, "replaced, not added");
            assert_eq!(mid_ecs_world_resource_changed_since(w, gravity, t1), 1);

            // Removed and written again: a new addition.
            let t2 = mid_ecs_world_change_tick(w);
            mid_ecs_world_increment_change_tick(w);
            assert_eq!(mid_ecs_world_resource_remove(w, gravity), OK);
            assert_eq!(mid_ecs_world_resource_changed_since(w, gravity, t2), 0, "gone");
            assert_eq!(mid_ecs_world_resource_write(w, gravity, g.as_ptr(), 4), OK);
            assert_eq!(mid_ecs_world_resource_added_since(w, gravity, t2), 1);

            // Errors.
            assert_eq!(mid_ecs_world_resource_added_since(w, 999, 0), NOT_FOUND);
            assert_eq!(mid_ecs_world_resource_changed_since(w, 999, 0), NOT_FOUND);
            assert_eq!(mid_ecs_world_resource_added_since(ptr::null(), time, 0), NULL_POINTER);
            assert_eq!(mid_ecs_world_resource_changed_since(ptr::null(), time, 0), NULL_POINTER);
            // A refused write stamps nothing.
            let t3 = mid_ecs_world_change_tick(w);
            mid_ecs_world_increment_change_tick(w);
            let short = [1u8, 2];
            assert!(mid_ecs_world_resource_write(w, gravity, short.as_ptr(), 2) < 0);
            assert_eq!(mid_ecs_world_resource_changed_since(w, gravity, t3), 0);
            mid_ecs_world_free(w);
        }
    }

    // ── hierarchy ───────────────────────────────────────────────────────

    unsafe fn children_of(world: *const MidEcsWorld, parent: u64) -> Vec<u64> {
        // SAFETY: the callers pass a live world.
        unsafe {
            let n = mid_ecs_world_children(world, parent, std::ptr::null_mut(), 0);
            assert!(n >= 0, "children count failed: {n}");
            let mut buf = vec![0u64; n as usize];
            let got = mid_ecs_world_children(world, parent, buf.as_mut_ptr(), buf.len());
            assert_eq!(got, n);
            buf
        }
    }

    #[test]
    fn the_hierarchy_status_code_has_its_documented_value() {
        assert_eq!(MidEcsStatus::Cycle as i32, -12);
    }

    #[test]
    fn hierarchy_functions_reject_null_pointers() {
        let null = std::ptr::null_mut::<MidEcsWorld>();
        let mut out = 0u64;
        // SAFETY: every call passes a null world, which each must reject.
        unsafe {
            let np = MidEcsStatus::NullPointer as i32;
            assert_eq!(mid_ecs_world_enable_hierarchy(null), np);
            assert_eq!(mid_ecs_world_set_parent(null, 1, 2), np);
            assert_eq!(mid_ecs_world_remove_parent(null, 1), np);
            assert_eq!(mid_ecs_world_parent(null, 1, &mut out), np);
            assert_eq!(mid_ecs_world_children(null, 1, std::ptr::null_mut(), 0), np);
            assert_eq!(mid_ecs_world_clear_children(null, 1), np);
            assert_eq!(mid_ecs_world_despawn_children(null, 1), np);
            let world = mid_ecs_world_new();
            let e = mid_ecs_world_spawn(world);
            assert_eq!(mid_ecs_world_parent(world, e, std::ptr::null_mut()), np, "null out pointer");
            mid_ecs_world_free(world);
        }
    }

    #[test]
    fn set_parent_and_children_round_trip_in_order() {
        let world = mid_ecs_world_new();
        // SAFETY: `world` non-null and not freed until the end of the block.
        unsafe {
            let p = mid_ecs_world_spawn(world);
            let kids: Vec<u64> = (0..3).map(|_| mid_ecs_world_spawn(world)).collect();
            for &k in &kids {
                assert_eq!(mid_ecs_world_set_parent(world, k, p), MidEcsStatus::Ok as i32);
            }
            assert_eq!(children_of(world, p), kids);
            let mut out = 0u64;
            assert_eq!(mid_ecs_world_parent(world, kids[1], &mut out), MidEcsStatus::Ok as i32);
            assert_eq!(out, p);
            mid_ecs_world_free(world);
        }
    }

    #[test]
    fn children_follows_the_null_buffer_and_too_small_conventions() {
        let world = mid_ecs_world_new();
        // SAFETY: `world` non-null and not freed until the end of the block.
        unsafe {
            let p = mid_ecs_world_spawn(world);
            for _ in 0..4 {
                let k = mid_ecs_world_spawn(world);
                mid_ecs_world_set_parent(world, k, p);
            }
            assert_eq!(mid_ecs_world_children(world, p, std::ptr::null_mut(), 0), 4);
            let mut small = [7u64; 3];
            assert_eq!(
                mid_ecs_world_children(world, p, small.as_mut_ptr(), small.len()),
                MidEcsStatus::BufferTooSmall as i32
            );
            assert_eq!(small, [7, 7, 7], "nothing is written when the buffer is too small");
            let mut exact = [0u64; 4];
            assert_eq!(mid_ecs_world_children(world, p, exact.as_mut_ptr(), 4), 4);
            let mut roomy = [9u64; 6];
            assert_eq!(mid_ecs_world_children(world, p, roomy.as_mut_ptr(), 6), 4);
            assert_eq!(&roomy[..4], &exact);
            assert_eq!(&roomy[4..], &[9, 9], "elements past the count are untouched");
            mid_ecs_world_free(world);
        }
    }

    #[test]
    fn a_childless_or_dead_parent_reports_correctly() {
        let world = mid_ecs_world_new();
        // SAFETY: `world` non-null and not freed until the end of the block.
        unsafe {
            let e = mid_ecs_world_spawn(world);
            assert_eq!(mid_ecs_world_children(world, e, std::ptr::null_mut(), 0), 0);
            let dead = mid_ecs_world_spawn(world);
            mid_ecs_world_despawn(world, dead);
            assert_eq!(
                mid_ecs_world_children(world, dead, std::ptr::null_mut(), 0),
                MidEcsStatus::NotAlive as i32
            );
            mid_ecs_world_free(world);
        }
    }

    #[test]
    fn set_parent_errors_map_to_distinct_codes_and_change_nothing() {
        let world = mid_ecs_world_new();
        // SAFETY: `world` non-null and not freed until the end of the block.
        unsafe {
            let a = mid_ecs_world_spawn(world);
            let b = mid_ecs_world_spawn(world);
            mid_ecs_world_set_parent(world, b, a);
            let dead = mid_ecs_world_spawn(world);
            mid_ecs_world_despawn(world, dead);

            assert_eq!(mid_ecs_world_set_parent(world, a, a), MidEcsStatus::InvalidArgument as i32);
            assert_eq!(mid_ecs_world_set_parent(world, a, b), MidEcsStatus::Cycle as i32);
            assert_eq!(mid_ecs_world_set_parent(world, a, dead), MidEcsStatus::NotAlive as i32);
            assert_eq!(mid_ecs_world_set_parent(world, dead, a), MidEcsStatus::NotAlive as i32);
            assert_eq!(children_of(world, a), vec![b]);
            let mut out = 0u64;
            assert_eq!(mid_ecs_world_parent(world, a, &mut out), MidEcsStatus::NotFound as i32);
            mid_ecs_world_free(world);
        }
    }

    #[test]
    fn parent_and_remove_parent_report_not_found_and_not_alive() {
        let world = mid_ecs_world_new();
        // SAFETY: `world` non-null and not freed until the end of the block.
        unsafe {
            let p = mid_ecs_world_spawn(world);
            let c = mid_ecs_world_spawn(world);
            let mut out = 0xDEAD_u64;
            assert_eq!(mid_ecs_world_parent(world, c, &mut out), MidEcsStatus::NotFound as i32);
            assert_eq!(out, 0xDEAD, "an unset parent leaves the output alone");
            assert_eq!(mid_ecs_world_remove_parent(world, c), MidEcsStatus::NotFound as i32);

            mid_ecs_world_set_parent(world, c, p);
            assert_eq!(mid_ecs_world_remove_parent(world, c), MidEcsStatus::Ok as i32);
            assert_eq!(mid_ecs_world_remove_parent(world, c), MidEcsStatus::NotFound as i32);
            assert!(children_of(world, p).is_empty());

            mid_ecs_world_despawn(world, c);
            assert_eq!(mid_ecs_world_remove_parent(world, c), MidEcsStatus::NotAlive as i32);
            assert_eq!(mid_ecs_world_parent(world, c, &mut out), MidEcsStatus::NotAlive as i32);
            mid_ecs_world_free(world);
        }
    }

    #[test]
    fn despawning_a_parent_despawns_the_subtree_through_c() {
        let world = mid_ecs_world_new();
        // SAFETY: `world` non-null and not freed until the end of the block.
        unsafe {
            let root = mid_ecs_world_spawn(world);
            let a = mid_ecs_world_spawn(world);
            let a1 = mid_ecs_world_spawn(world);
            let other = mid_ecs_world_spawn(world);
            mid_ecs_world_set_parent(world, a, root);
            mid_ecs_world_set_parent(world, a1, a);
            assert_eq!(mid_ecs_world_despawn(world, root), MidEcsStatus::Ok as i32);
            for dead in [root, a, a1] {
                assert_eq!(mid_ecs_world_despawn(world, dead), MidEcsStatus::NotAlive as i32);
            }
            assert_eq!(mid_ecs_world_despawn(world, other), MidEcsStatus::Ok as i32);
            mid_ecs_world_free(world);
        }
    }

    #[test]
    fn clear_and_despawn_children_return_counts() {
        let world = mid_ecs_world_new();
        // SAFETY: `world` non-null and not freed until the end of the block.
        unsafe {
            let p = mid_ecs_world_spawn(world);
            let kids: Vec<u64> = (0..3).map(|_| mid_ecs_world_spawn(world)).collect();
            for &k in &kids {
                mid_ecs_world_set_parent(world, k, p);
            }
            assert_eq!(mid_ecs_world_clear_children(world, p), 3);
            assert_eq!(mid_ecs_world_clear_children(world, p), 0);
            assert_eq!(mid_ecs_world_despawn(world, kids[0]), MidEcsStatus::Ok as i32, "still alive");

            let grand = mid_ecs_world_spawn(world);
            mid_ecs_world_set_parent(world, kids[1], p);
            mid_ecs_world_set_parent(world, grand, kids[1]);
            assert_eq!(mid_ecs_world_despawn_children(world, p), 2);
            assert_eq!(mid_ecs_world_despawn_children(world, p), 0);
            assert_eq!(mid_ecs_world_despawn(world, p), MidEcsStatus::Ok as i32, "the parent survived");
            let dead = mid_ecs_world_spawn(world);
            mid_ecs_world_despawn(world, dead);
            assert_eq!(mid_ecs_world_clear_children(world, dead), MidEcsStatus::NotAlive as i32);
            assert_eq!(mid_ecs_world_despawn_children(world, dead), MidEcsStatus::NotAlive as i32);
            mid_ecs_world_free(world);
        }
    }

    #[test]
    fn enable_hierarchy_is_idempotent_and_set_parent_works_after_it() {
        let world = mid_ecs_world_new();
        // SAFETY: `world` non-null and not freed until the end of the block.
        unsafe {
            for _ in 0..3 {
                assert_eq!(mid_ecs_world_enable_hierarchy(world), MidEcsStatus::Ok as i32);
            }
            let p = mid_ecs_world_spawn(world);
            let c = mid_ecs_world_spawn(world);
            assert_eq!(mid_ecs_world_set_parent(world, c, p), MidEcsStatus::Ok as i32);
            assert_eq!(children_of(world, p), vec![c]);
            mid_ecs_world_free(world);
        }
    }
}
