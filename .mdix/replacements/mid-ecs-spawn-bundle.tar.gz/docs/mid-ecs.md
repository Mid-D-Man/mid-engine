# mid-ecs

Data-oriented ECS using Structure of Arrays (SoA) layout.

## Status

**Entity allocation and the Sparse Shell are both real now.** `World`
(`crates/mid-ecs/src/world.rs`) — `spawn`/`despawn`/`is_alive`,
generation-checked handles via `Entity`/
`mid_collections::GenerationalIndexAllocator`. `World::insert`/`get`/
`get_mut`/`remove`/`has` (`crates/mid-ecs/src/component.rs`'s
`SparseShell`) — any `T: 'static` attachable to any entity, no upfront
declaration, type-erased via a dense `ComponentId` (registered once per
type, `TypeId` only used at that registration step) rather than a
`TypeId`-keyed `HashMap` on the hot path — design grounded directly in
Bevy ECS's real `Components`/`ComponentId`/`Table` source, not invented
independently. 66/66 real tests passing across `mid-collections` +
`mid-ecs` (verified by temporarily stripping `rayon` and `criterion`
locally, same technique used every time these MSRV walls come up,
restored unchanged afterward).

`despawn` correctly removes every attached component *before* freeing
the entity's generational slot — load-bearing ordering, not incidental,
since `SparseSet` looks up purely by raw index and can't itself tell a
stale handle from a live one sharing a reused index. Every `World`
component method checks liveness first for the same reason. Both
properties have dedicated tests proving them directly
(`reused_slot_does_not_inherit_the_old_entitys_components`,
`stale_handle_cannot_read_the_live_entity_now_sharing_its_index`), not
just described in a comment.

One real self-caught inconsistency worth noting: `insert` initially had
a `debug_assert!` for the dead-entity case, on the reasoning that it's
"almost always a caller logic bug." The test written to prove the safe
fallback immediately panicked instead, in a debug/test build — which
was the actual bug: that `debug_assert!` directly contradicted this
codebase's own established convention everywhere else
(`SparseSet::remove`, `GenerationalIndexAllocator::deallocate`) of never
panicking on this class of misuse. Removed, not worked around.

`Archetype`, `Query`, `sync`, `ffi` are still stubs. The Archetype Core
(dense/table storage for stable, always-present components — the other
half of the Hybrid ECS Architecture below) doesn't exist yet; nothing in
`component.rs` is trying to be both.

**Query — real for one and two component types.**
`World::query<T>()` iterates every `(Entity, &T)` currently alive with a
`T` attached; `World::query2<A, B>()` intersects two — every
`(Entity, &A, &B)` for entities alive with *both*. 7 new tests (39/39 in
`mid-ecs` total, 73/73 across `mid-collections` + `mid-ecs`), all passing
on the actual first run — including the two that matter most:
`query_excludes_despawned_entities` and
`query2_excludes_a_despawned_entity_even_if_it_had_both`, proving
`despawn`'s component cleanup and `query`'s iteration agree with each
other, not just each independently claiming to be correct.

Deliberate v1 scope, not an oversight: `query2` always drives iteration
off its first type parameter and checks the second per-entity, rather
than picking whichever side is actually smaller — a real optimization
for a mismatched pair, but nothing in this workspace has a real query
shape yet that would justify the extra complexity over shipping the
correct, simpler version first. No `query3`+, and no generic tuple-based
`Query<T>` trait system (the shape real ECS crates converge on for
arbitrary arity) — both are natural follow-ons once real usage patterns
exist to design against, not before.

Organizational fix caught, not by review: `query`/`query2` were first
written directly on `World` in `world.rs`. Moved to `query.rs` shortly
after — the file that already existed specifically for this — where
they belonged from the start. Implementations unchanged, `World`'s
fields made `pub(crate)` so `query.rs` can reach them.

**Archetype Core — real, with full dynamic migration, not a simplified
static-at-spawn version.** `crates/mid-ecs/src/archetype.rs`:
`Archetypes` — dense SoA [`Table`]s (one contiguous `Vec<T>` per
component type, in lockstep by row), keyed by exact component-type-set
signature, with real migration when `World::insert_static`/
`remove_static` change an entity's set. `World::get_static`/
`get_static_mut`/`has_static` round out the API — named distinctly from
the Sparse Shell's `insert`/`get`/etc. since a component type has to
live in exactly one of the two systems, and there's no enforcement yet
beyond caller discipline (a `Component` trait fixing each type's
storage strategy once, matching where Bevy eventually landed, is a real
future refinement).

Grounded in Bevy ECS's real source, cloned and read directly (not
memory, not search-result excerpts) — `archetype.rs` (1002 lines),
`storage/table/{mod,column}.rs` (1428 lines). Confirmed, not assumed:
`Table` really is `{ columns: SparseSet<ComponentId, Column>, entities:
Vec<Entity> }`, the same shape `component.rs`'s `SparseShell` converged
on independently, now confirmed twice as the right structure for this
class of problem. `Edges`-style memoized add/remove transition caching
is real here too (`Archetype::add_edges`/`remove_edges`), same idea as
Bevy's, simpler storage (`HashMap` over a dedicated sparse-array type
this project doesn't have and didn't need to build for this alone).

Deliberate, stated divergence from Bevy, not an oversimplification:
Bevy's real row-migration is `unsafe`, raw-pointer, merge-join code with
change-detection ticks this project doesn't have yet. This module gets
the *same real capability* — genuine dynamic migration, any entity, any
component, at any time, no "components fixed at spawn" restriction —
through safe Rust instead: each migrated value is briefly boxed
(`Column::swap_remove_and_forget`/`push_any`) rather than raw-copied.
One heap allocation per moved component per structural change — not per
frame, not per query, only on the path this whole Sparse-Shell-vs-
Archetype-Core split exists specifically to keep rare. Zero `unsafe`,
matching `SparseSet`/`GenerationalIndexAllocator`'s own precedent
throughout this project.

Single-component structural changes only (not Bevy's general `Bundle`
trait for atomic multi-component changes) — deliberate, not a
limitation nobody noticed: a single-component add is always a strict
superset transition, a single-component remove always a strict subset,
which is exactly what lets every *other* column move unconditionally
with no merge-join needed to work out what's actually shared.

24 new tests (15 in `archetype.rs` + 9 `World`-level integration tests),
99/99 total across `mid-collections` + `mid-ecs`, all passing on the
actual first real run after two real, caught-by-clippy `Box::new(_)`
lint fixes and two doc-link fixes. The test that matters most:
`swap_remove_during_migration_fixes_up_the_swapped_entitys_row` —
proves that when a *middle* entity migrates out of a shared archetype,
the entity swapped into its old row stays correct not just for reading
afterward, but for *its own future migrations* too. Still wasm32-clean:
re-checked via `cargo tree --target wasm32-unknown-unknown` after —
`mid-ecs` still resolves to depending on only `mid-collections` for
that target, this module added no new dependencies.

## Target

100 000+ entities at 60 Hz physics on a single core.
Parallelised queries via rayon — on native. See Platform below.

## Platform

`mid-ecs` targets native *and* wasm32 (browser), same as the rest of the
workspace (`docs/architecture.md`'s core commitments). `rayon` — real
OS threads under the hood — doesn't work on `wasm32-unknown-unknown` the
way it needs to, so it's gated to non-wasm32 targets only in
`crates/mid-ecs/Cargo.toml`, under
`[target.'cfg(not(target_arch = "wasm32"))'.dependencies]` — the same
target-gating pattern already established in
`crates/mid-net/transport-wasm/Cargo.toml`.

Confirmed directly, not assumed: `cargo tree --target
wasm32-unknown-unknown -p mid-ecs` showed rayon's entire transitive tree
(`rayon-core`, `crossbeam-deque`/`epoch`/`utils`, `either`) resolving
into the wasm32 dependency graph *before* the gate existed, and cleanly
absent after — `mid-ecs` resolves to depending on only
`mid-collections` for that target. `.github/workflows/mid-ecs-test.yml`
now has a real "Check wasm32 build" step
(`cargo check --target wasm32-unknown-unknown`) proving the crate
actually compiles clean for that target on real CI, not just that its
dependency graph looks right — the sandbox this was developed in has no
wasm32 target installed at all, so dependency-graph resolution was as
far as local verification could go.

`query.rs`'s eventual rayon-based parallel iteration will need the
matching `#[cfg(not(target_arch = "wasm32"))]` split at the *code* level
too, once it's actually built — not needed yet, it's still a stub. FFI
work for `mid-ecs` is no longer saved for the end — see the FFI section
below for the real, incremental strategy and what's already built.

## FFI — built incrementally as we go, not saved for the end

The original plan deferred all FFI work until the ECS was otherwise
"done." Revisited: `mid-ecs`'s whole reason for existing separately from
being embedded directly in a monolithic engine is that its crates are
meant to be genuinely usable from *any* game engine or language, at
real performance — which means FFI correctness isn't a final coat of
paint, it's a core requirement that needs proving as each real piece
lands, the same way every other piece in this project has been proven
as it was built rather than asserted afterward.

**`World` lifecycle — real, tested, verified against actual compiled C.**
`crates/mid-ecs/src/ffi.rs`: `mid_ecs_world_new`/`free`/`spawn`/
`despawn`/`is_alive`/`entity_count`. Conventions copied directly from
`mid-net`'s real, already-proven `ffi.rs` — `MidEcsStatus` codes,
`ffi_guard`/`catch_unwind` on every function body, null-pointer checks
before every dereference, `unsafe extern "C" fn` + `# Safety` docs,
opaque heap handle for `World` (not `repr(C)` — nothing about it is
C-representable).

The one genuinely new piece: `Entity` can't cross the boundary as a
Rust value (its fields are deliberately private — only `World::spawn`
should ever produce one) and a two-field `repr(C)` struct would make
every caller's language agree on a layout for no real benefit. Instead,
`Entity::as_ffi`/`from_ffi` (thin wrappers over `mid_collections::
GenerationalIndex::as_ffi`/`from_ffi`, which do the real packing) hand
out one plain `u64` — directly grounded in `slotmap::KeyData::as_ffi`/
`from_ffi`'s real, shipped design (checked directly, not assumed),
including the property that matters most: reconstructing from a `u64`
that never actually came from a real `as_ffi()` call is still *safe* —
every `World` method re-validates the handle's generation against the
slot's current one regardless of where the value came from, so a bogus
handle just reads back as not alive. It can never alias a real, live
entity it wasn't issued for. Proven directly, not just documented:
`generational_index.rs`'s `from_ffi_on_a_bogus_value_is_safe_and_reads_as_not_alive`
and `ffi.rs`'s `bogus_packed_entity_is_safe_and_reads_as_not_alive`
both construct a genuinely bogus value and confirm exactly this.

**Verified the same way `mid-net`'s FFI was — real gcc, real C, real
memory, not just Rust-side `unsafe {}` blocks calling into themselves.**
`crates/mid-ecs/ffi-smoke-test/{mid_ecs.h, test.c}`: hand-written header
(matching `mid-net`'s own "hand-written, not cbindgen-generated, updated
by hand alongside `ffi.rs`" convention), 19 real checks. Compiled with
real gcc, linked against the real built `libmid_ecs.so` *and*
`libmid_ecs.a` separately, both run, both 19/19 — including the stale-
handle-after-slot-reuse case and the bogus-packed-`u64` case, proven
through actual C memory, not simulated. `.github/workflows/
mid-ecs-test.yml` now runs this on every CI trigger too, mirroring
`mid-net-test.yml`'s own FFI smoke test step exactly.

**Deliberately not covered yet in the `World`-lifecycle pass above, and
why it was genuinely harder, not just more of the same:** reading
component data (a `Position` column, say) from C. Every function in
that pass either passed a value by-value or went through an opaque
handle with no live pointer into mutable interior storage — nothing had
to reason about a pointer a *later* call could invalidate. Component
data lives in `Vec<T>`-backed columns (`SparseShell`'s `SparseSet`s,
`Archetypes`' `Table`s) that `insert`/`remove`/migration can reallocate
or move out from under a previously handed-out pointer. This is what
the "FFI span" idea (`docs/mid-collections.md`'s FFI wrapper section)
was actually for.

**Sparse Shell span access — real, tested, done for v1.**
`SparseShell::register_ffi<T>`/`raw_span`/`lookup_ffi_id`
(`crates/mid-ecs/src/component.rs`), thin-wrapped at `World::
register_ffi_component`/`component_raw_span`/`lookup_ffi_component_id`.
The real problem this had to solve, worked out rather than assumed:
producing a byte-erased `(ptr, stride, count)` view through a
`ComponentId` (an opaque `u32` at the FFI boundary) *without* the
caller knowing the concrete Rust type `T` — while `Box<dyn
ComponentColumn>`'s existing type-erasure mechanism only supports
downcasting when the caller already supplies `T` generically, which an
`extern "C"` function structurally can't do. Resolved with a type-erased
accessor function (`fn(&dyn Any) -> FfiSpan`), monomorphized once per
`T` at `register_ffi::<T>()` time (where `T` *is* known, generically)
and stored in a side table keyed by `ComponentId`, called later purely
non-generically — deliberately *not* baked into the base
`ComponentColumn` trait itself as a required method, since that would
force `IntoBytes + Immutable + KnownLayout` (from `zerocopy`) onto
every component type in the Sparse Shell, including plain Rust-only
types with no FFI intent (this crate's own `Position`/`Velocity` test
types, not `#[repr(C)]`, would have stopped compiling). Opting a type
in is explicit and per-type instead — real test coverage confirms both
halves: `register_ffi_before_any_insert_still_gives_a_valid_empty_span`
etc. exercise the opted-in path, while `Position`/`Velocity`'s own
existing tests keep passing completely untouched, proving the
restriction really is scoped to only what opts in.

A real bug caught by actually running the tests, not by review: the
first `raw_span` returned `None` for a type that was `register_ffi`'d
but had nothing inserted for it yet, since `columns` entries are only
created lazily on first `insert` — inconsistent with this same file's
own already-established convention (`SparseShell::iter<T>` already
treats "nothing inserted yet" as an *empty* result, not a *not-found*
one). Fixed to match the existing convention, not patched around it.

C-side `ComponentId` registration, scoped concretely: `register_ffi`
also records a plain string name, resolved later via `lookup_ffi_id`/
`lookup_ffi_component_id` — this is *not* C defining an entirely new,
Rust-unknown component layout (that would need a parallel byte-blob
storage mode this pass doesn't touch, a real, much larger undertaking
flagged rather than attempted); it's C obtaining the `ComponentId` for
a type Rust already opted in, by the name Rust gave it. `register_ffi`
itself is necessarily still a Rust-side, generic call — an `extern "C"`
function can't be generic over `T` — real, unavoidable one-time setup
glue, not an oversight.

**Archetype Core span access — real, tested, done for v1, and
genuinely harder than the Sparse Shell side above.** `Archetypes::
register_ffi<T>`/`raw_span`/`archetypes_with`/`lookup_ffi_id`
(`crates/mid-ecs/src/archetype.rs`), thin-wrapped at `World::
register_ffi_static_component`/`static_component_raw_span`/
`archetypes_with_static_component`/`lookup_ffi_static_component_id`.
Same type-erased-accessor mechanism as the Sparse Shell side (a
`fn(&dyn Any) -> FfiSpan`, monomorphized per `T` at registration time),
same reasoning for not baking it into the base `Column` trait — but one
real, unavoidable additional wrinkle: a component type here isn't one
stable thing to read. An entity's row lives in whichever archetype
currently matches its exact component set, so one type's data is
fragmented across every archetype containing it. `raw_span` is
necessarily per-`(ArchetypeId, ComponentId)`, not just per-`ComponentId`
the way the Sparse Shell's is; `archetypes_with` enumerates the
fragments.

A real, non-obvious distinction worked through and confirmed by
dedicated tests, not glossed over: unlike the Sparse Shell's own
"registered but nothing inserted yet" case (fixed to return an empty
span, not `None`, per the bug above), an archetype's signature simply
not including a given component is a *different*, *permanent* fact
about that specific archetype — `raw_span` correctly returns `None`
there (matching `Archetypes::has`'s own established `false`-not-panic
convention), while a real *empty-but-present* column (the component is
in the signature, every entity that had it has since migrated away)
correctly returns `Some` with `count == 0` — proven directly:
`raw_span_on_an_archetype_that_does_not_have_this_component_is_none`
and `raw_span_is_some_and_empty_after_every_entity_migrates_away` are
two separate tests because they're two genuinely separate cases, not
one case described two ways. Grounded in a real check of `ensure_column`
before trusting the "empty-but-present" case could even happen: columns
are only ever added to a table, never removed, once an archetype has
been created with a given signature — confirmed by reading that
function, not assumed.

A completely separate `ComponentId` name space from the Sparse Shell's
own `register_ffi`/`lookup_ffi_id`, matching `Archetypes`' own
already-established separate `ComponentId` numbering space from
`SparseShell`'s (see this doc's Sparse Shell section above) — the same
name string can resolve to a different `ComponentId` in each system,
proven directly by
`sparse_and_static_ffi_registrations_use_independent_name_spaces`.

**Not yet done, real next increment — flagged, not silently dropped:**

- **Entity correlation**, for *both* storage systems now. Neither
  `raw_span` can tell a caller *which* entity each element belongs to
  — `Entity` itself isn't `#[repr(C)]`/zerocopy-compatible today (its
  fields are deliberately private, see `Entity::as_ffi`/`from_ffi`
  above), so a zero-copy span over either system's dense entity array
  isn't possible without a real decision about how `Entity` should
  cross this specific boundary. This is now the single real blocker
  standing between "callable" and "actually usable" for the whole FFI-
  span mechanism.
- Actual `extern "C"` functions in `ffi.rs` exposing any of this, plus
  a real C smoke test and CI wiring, matching the rigor the `World`-
  lifecycle pass above already has. Nothing above has been proven
  against real compiled C yet — only real Rust-side tests so far, 147
  of them across `mid-collections` (49, `--features ffi`) + `mid-ecs`
  (98) combined as of this pass, none of them C.

## The Hybrid ECS Architecture: Static Core, Dynamic Shell

Mid Engine completely avoids the traditional Object-Oriented memory traps by splitting entity data into two highly optimized zones:

### 1. The Archetype Core (Heavy Logic)
* Components that remain static throughout an entity's lifecycle—like `Transform`, `Velocity`, or `PhysicsBody`—are packed into rigid Archetype tables.
* This guarantees perfect CPU cache locality.
* It allows our `mid-math` wide SIMD vectors to blast through positional updates without jumping around in memory, forming our high-performance "Inner Loops".

### 2. The Sparse Shell (Volatile Logic)
* Status effects or states that flicker on and off constantly—like `IsPoisoned`, `Disabled`, or `Hidden`—are managed using Sparse Sets or highly efficient Bitsets.
* The Sparse Shell is real now — `World::insert`/`get`/`get_mut`/`remove`/`has` (`crates/mid-ecs/src/component.rs`), any `T: 'static` attachable to any entity, backed by `mid_collections::SparseSet` per component type, keyed by a dense `ComponentId` rather than a `TypeId` hash (design grounded in Bevy ECS's own real `ComponentId` source — see `component.rs`'s doc comment). `despawn` correctly cleans up every attached component before freeing the entity's slot, closing the exact stale-handle gap `SparseSet` can't close on its own.
* **The "Stutter" Fix:** If you poison 1,000 goblins, the engine just flips a bitmask or adds a tiny entry in a sparse set. 
* Result: Zero memory is physically moved between archetype tables. The engine stays fast, and we avoid the memory-copying lag spikes that plague pure archetype architectures during massive state changes.
* For lightning-fast entity querying, the engine utilizes a `BitVec` layout (1 boolean into 1 bit), allowing us to filter hundreds of thousands of entities in microseconds using simple bitwise AND operations.

## Large World Coordinates: GlobalTransform

**Status: implemented.** `GlobalTransform` and `GlobalTransformLWC`
are real, tested types in `crates/mid-ecs/src/transform.rs` — both
usable with `World::insert_static`/`query_static` today. Not yet
built: `LocalTransform`/hierarchy composition, and `mid-camera`'s own
per-frame `to_view_relative` driver loop (see "Not yet decided" below
— unchanged, still real, still not started).

**The decision: two component types, `f32` default, `f64` opt-in —
not one type, and not `f64` everywhere.**

- `GlobalTransform` — `f32`, backed by `mid-math`'s existing `Affine3`.
  The default. Lives in the Archetype Core, same as any other static,
  every-frame-touched component (see "The Archetype Core" above).
- `GlobalTransformLWC` — `f64`, backed by `mid-math`'s `DAffine3`. Opt-in,
  for entities that actually travel far enough from world origin to
  need it (open-world terrain, distant structures, anything a camera
  might travel tens of kilometers to reach). A distinct archetype
  family from `GlobalTransform`, not the same component with a
  runtime-branching representation — a tagged union inside one
  Archetype Core column would break the homogeneous-`Vec<T>`-column
  assumption `component.rs`'s FFI-span mechanism (and every other
  system that reads a column) already depends on, and would cost
  exactly the cache/branch overhead this split exists to avoid.

**Why `f32` default, not `f64` default:** `DAffine3` is 96 bytes;
`Affine3` is 64 (16-byte aligned, SSE2-backed on x86/x86_64 — corrected
here from an earlier "48" figure in this doc that didn't match
`Affine3`'s own doc comment; checked directly against
`crates/mid-math/src/f32/affine3.rs` while implementing
`GlobalTransform`, not left as a quiet inconsistency). `f64` is still
1.5x the size, not 2x — the conclusion below is unchanged.
`GlobalTransform` is about the hottest, most-iterated
component this engine will ever have — read every frame for every
visible entity, exactly the access pattern the Archetype Core exists
to make cache-friendly. Most entities in most scenes (UI-anchored
objects, particle effects, interior/local gameplay) never travel far
enough from origin to need `f64` at all. Doubling the stride of the
hottest column engine-wide, to solve a problem only some entities
have, is in direct tension with this project's own performance
mandate — so the cost is opt-in, paid only by the entities that
actually need it.

**The pipeline this feeds into**, once built: `GlobalTransformLWC`
holds true world-space state in `f64`. Once per frame, for the
active camera, every visible `GlobalTransformLWC` gets passed through
`DAffine3::to_view_relative(camera_position)` (see `docs/mid-math.md`)
— composing the camera-relative shift and the `f64`→`f32` truncation
in one step, safe regardless of how far the entity is from world
origin, because only the shifted (small) translation gets truncated,
never the raw world-magnitude one. The result is a plain `f32`
`Affine3`, indistinguishable downstream from a `GlobalTransform`
entity's own data — rendering, culling, and anything else consuming
"the" transform for a draw call never needs to know or care which
storage precision an entity actually used. That narrow point (right
before GPU upload) is the only place the two component types'
consumers actually have to know both exist.

**Not yet decided:** how `LocalTransform`/hierarchy (parent-relative,
always small-magnitude, always `f32` regardless of world size)
composes into either `GlobalTransform` variant — that's the actual
"Integrating f64 global transform components into archetype storage
tables" implementation work, not yet started. `mid-camera` (planned,
not started — this engine's Cinemachine equivalent, sitting on top of
both this system and `mid-math`'s existing `camera/` module) is what
will eventually own "which entity is the active camera" and drive the
per-frame `to_view_relative` call above.

## The Ubel Stratum Bridge (The OOP Illusion)

**Design vision, not confirmed integration.** `docs/mid-collections.md`
is explicit about this: Ubel is *"a separate project... deliberately
not folded in here."* `mid-log.md`/`mid-net.md` both hedge the same
way (*"prepared for"*, *"a plausible future consumer"*). This section
previously read as settled architecture with no such hedge — a real
contradiction with those three docs, not just a tone mismatch, since
it described the bridge mechanism as if it already existed. Fixed to
match the same framing used everywhere else in this workspace: the
idea below is real and worth recording, but Ubel's actual integration
with `mid-ecs` specifically is not decided, designed in detail, or
started.

The vision, as discussed: gameplay code never touches Archetypes or
Bitsets directly.
* **HIGH Tier:** a gameplay programmer would interact with what reads
  like standard OOP classes (an `Actor`/`Entity` object).
* **LOW Tier:** if built, an Ubel compiler would lower that high-level
  code (`player.health -= 10`) into raw, memory-safe array accesses
  against `mid-ecs`'s own storage — Sparse Shell or Archetype Core,
  whichever the accessed component actually lives in.

Real open question this doc doesn't answer, and shouldn't pretend to:
whether that lowering targets this crate's own Rust API directly, or
goes through the FFI-span mechanism `component.rs`/`archetype.rs`
already expose — the latter would make Ubel just another FFI
consumer, no different in kind from any other non-Rust caller this
crate already supports, rather than a special-cased integration.

## Network Sync (Multiplayer-First)

The `sync` module marks components for `mid-net` replication.
This is the Multiplayer-First mandate in practice: networking is baked into the ECS from day one, not bolted on later.
* Components can be explicitly flagged for synchronization (e.g., `@net Transform`). 
* The engine automatically handles serialization via DixScript (`.mdix`) to sync state across the wire.
* Because data is stored contiguously in the Archetype Core, the network system can simply request a memory block and run a single SIMD pass over that memory to detect deltas, compress with MBFA-lite, encrypt, and ship the UDP packet.

## Modules

### `diag_query2_unchecked.rs`

Temporary diagnostic module, delete once the investigation it exists
for concludes (see its own NOTICE header). Real CI (rustc 1.98.0)
shows `query2_static_two_components` running 2.96x-4.57x slower than
`bevy_ecs` on an equivalent workload, in every run since the
Iter1/Iter2 rewrite. This sandbox's own rustc 1.91.1 has never
reproduced it — the same code measures within noise of `bevy_ecs`
here every time. An `#[inline(always)]`/`#[inline(never)]` three-way
diagnostic (`diag_inline.rs`) already ruled out inlining as the cause,
run for real on rustc 1.98.0.

Real source comparison against `Mid-D-Man/bevy` (`crates/bevy_ecs/src/
query/iter.rs` and `fetch.rs`, read directly) found a real structural
difference. Bevy's `QueryIterationCursor` is one generic struct,
parameterized over `D: QueryData`. A two-component query has no
hand-written "two-component" implementation at all — `D = (A, B)`,
`D::Fetch<'w> = (A::Fetch<'w>, B::Fetch<'w>)`, and `D::fetch` is
generated by a macro (`impl_tuple_query_data`, expanded once per arity
via `all_tuples!`) as `Some((A::fetch(...)?, B::fetch(...)?))` — the
same single-component fetch code, reused twice, composed through the
tuple impl. `&T`'s own `fetch` (`ReadFetch<T>`) reads through
`table.get_unchecked(table_row.index())`, `#[inline(always)]`, no
bounds check. mid-ecs's `Iter1` and `Iter2` (`archetype.rs`) are
instead two separately hand-written structs — meant to be the same
shape, but not literally the same code the compiler sees, and this
kind of divergence between two independently-authored near-duplicates
is exactly the sort of thing whose optimization treatment can differ
across a compiler version bump.

Four new variants, each isolating one candidate cause, matching what
was actually different between mid-ecs's approach and bevy's:

* `Iter1Unchecked`/`Iter2Unchecked` — the current `Iter1`/`Iter2`
  logic unchanged, except entity/column indexing goes through
  `get_unchecked` instead of safe indexing, directly matching bevy's
  own technique. Sound: `len` is already set to the min of every
  slice's length on each archetype advance, so `row < len` already
  proves every access in bounds — this was already true of the safe
  version's own reasoning (see `Iter2`'s doc comment in
  `archetype.rs`), `get_unchecked` just stops asking the compiler to
  re-derive it. This is the first `unsafe` in `mid-ecs`'s own query
  iteration path — agreed as a deliberate, scoped exception for this
  crate specifically, not a change to the workspace's general
  zero-unsafe default.
* `Iter2TwoTupleItem` — reads both `a_col` and `b_col` per item like
  the real `Iter2`, but combines them into one derived value before
  returning, so `Item` is a 2-tuple instead of a 3-tuple. Isolates the
  tuple/`Item`-shape question from the two-slice-fields question.
* `Iter2UnusedBCol` — same struct shape as the real `Iter2` (both
  `a_col` and `b_col` fields present, both kept current on every
  archetype advance), but the hot loop only ever reads `entities`/
  `a_col` — `b_col` is tracked for `len` only, never indexed per item.
  Isolates whether merely carrying the extra field matters,
  independent of whether it's read.

Each variant has a correctness test in `query.rs` cross-checking its
output against the real, safe `query_static`/`query2_static` — an
`unsafe` variant that's merely fast and wrong isn't useful data. All
pass, 176/176 total `mid-ecs` tests, sandbox rustc 1.91.1.

Not yet run on real CI. That's the actual next step — none of this
sandbox's numbers can confirm or rule out anything here, the same
asymmetry that opened this investigation in the first place. Exposed
via `World::query_static_diag_unchecked`/`query2_static_diag_unchecked`/
`query2_static_diag_two_tuple_item`/`query2_static_diag_unused_b_col`,
`#[doc(hidden)] pub` for the same reason as `diag_inline.rs`'s own
methods — `benches/archetype_core.rs` needs real public API to reach
them from outside the crate. Benching them is the next real
deliverable, not built yet.

Bench group `query2_static_diag_unchecked` added to
`archetype_core.rs`, covering all four variants. Real, same-sandbox-
session numbers, N=10,000, next to a same-session run of the real safe
`Iter1`/`Iter2` for direct comparison:

* Safe (current, real): `query_static` 7.291µs, `query2_static`
  10.265µs — ratio 1.41x (matches this sandbox's usual ~1.28-1.35x
  baseline within normal run-to-run variance).
* `Iter1Unchecked`: 7.222µs — indistinguishable from safe `Iter1`,
  consistent with `Iter1` already being at parity with `bevy_ecs`
  everywhere this has been measured.
* `Iter2Unchecked`: 29.044µs — **~2.83x slower than safe `Iter2`**,
  on this sandbox. `Iter2TwoTupleItem` (28.700µs) and `Iter2UnusedBCol`
  (28.706µs) land in the same place, all three roughly 4x the unchecked
  1-column number, at every N from 100 to 100,000 (ratio actually
  creeps up slightly with N: 3.51x at N=100 to 4.10x at N=100,000 — a
  per-item cost difference, not a one-time per-archetype-advance cost).

This is a real, surprising sandbox result, not a reason to abandon
these variants — `get_unchecked` should never make correct code
slower than the safe equivalent it replaces, on any toolchain that's
reasoning about it correctly, so this is itself informative. Worth
noting directly: 29.044µs is almost exactly the same number
`Iter2::next`'s own doc comment records for the earlier, reverted
`#[inline(always)]` attempt (~29µs) — on this same sandbox, two
completely different changes (forcing inlining, and switching to
`get_unchecked`) both land at close to the same, worse number. This
sandbox (rustc 1.91.1) has now shown *two* real cases where a change
that's well-motivated by bevy's own real source makes `Iter2`
specifically worse here — while the actual regression this whole
investigation exists to explain only shows up on rustc 1.98.0, never
here. That asymmetry cuts both ways: a sandbox result saying "worse"
carries exactly as little weight as one saying "better" would have.
Real CI is the only real answer here, same as every other toolchain-
sensitive question in this investigation so far.

Correctness is independent of this and already solid: all four
variants pass their dedicated tests in `query.rs`, cross-checked
against the real, safe `query_static`/`query2_static` output, 176/176
`mid-ecs` tests total.

### Real CI results (Archetype Core build #7, rustc 1.98.1)

These four variants ran on real CI for the first time. The result
overturns the sandbox reading above, which is exactly why the sandbox
numbers were never trusted on their own.

At N=10,000: safe `query2_static` 37.446µs against safe `query_static`
9.4228µs, ratio 3.97x, matching every prior real CI run of this
comparison. `Iter2Unchecked` (`query2_static_unchecked_2col`) measured
37.758µs and `Iter2UnusedBCol` (`unused_b_col`) measured 37.734µs,
both indistinguishable from the safe baseline. `get_unchecked` alone
does nothing on real CI either, same conclusion the sandbox reached,
for once matching it.

`Iter2TwoTupleItem` (`two_tuple_item`) measured 9.4864µs, matching
`query_static`'s single-column number almost exactly, at every N from
100 to 100,000. This is the opposite of what the sandbox showed
(28.700µs there, indistinguishable from the other two variants). One
variant returning a single owned value instead of two references
closes nearly the entire gap on the toolchain where the gap is real,
despite doing more work per item: its `combine` function reads all six
fields across both components (`Position`'s three plus `Velocity`'s
three) and constructs a new `Position` by value, against the baseline
loop's two field reads (`pos.x`, `vel.dx`). More arithmetic, less time.

This rules a specific thing in, not just several things out. Returning
`(Entity, &A, &B)` is not inherently slow. `Mid-D-Man/bevy`'s own
`D::Item` for a two-component query is exactly this shape (`(A::Item,
B::Item)` off the tuple macro, `(&Position, &Velocity)` for a plain
read query), and bevy pays no penalty for it (`ecs-vs-bevy-ecs` build
#10, same day: `query_static_single_component` 1.0x, `raw_slice_ceiling`
1.0x). Also checked and ruled out this pass: `mid-ecs`'s real `Iter2`
(`archetype.rs`) downcasts its `Box<dyn Any>` columns to `&[A]`/`&[B]`
once per archetype advance, same as every diagnostic variant, never
per item, so the downcast itself isn't a per-item cost candidate.

What's actually different, still untested until this pass: bevy's
tuple `QueryData::fetch` composes as `Some((A::fetch(...)?,
B::fetch(...)?))`, two independent single-component fetch calls glued
by `?`. `Iter2`, `Iter2Unchecked`, `Iter2TwoTupleItem`, and
`Iter2UnusedBCol` all instead read both columns inline in one
hand-written tuple literal. Whether returning two references together
is the cost, or whether it only becomes the cost when they're
constructed by one block instead of composed from two calls, hasn't
been separated yet.

### `Iter2Composed` (built this pass, not yet run on real CI)

Isolates exactly that. Same struct fields, same archetype-advance and
per-archetype downcast logic as `Iter2Unchecked`, same `Item =
(Entity, &A, &B)`. The only real change: two small functions,
`fetch_one::<A>`/`fetch_one::<B>`, each doing one
`get_unchecked`-and-wrap-in-`Some`, called from `next()` as `Some((...,
fetch_one(a_col, row)?, fetch_one(b_col, row)?))` instead of building
the tuple directly from `&self.a_col[row]`/`&self.b_col[row]` inline.
Mirrors bevy's own composition shape as closely as a hand-written
non-generic version reasonably can.

Two dedicated tests in `query.rs`
(`diag_query2_static_composed_matches_the_real_query2_static`,
`diag_query2_static_composed_empty_when_one_side_was_never_registered`),
cross-checked against real `query2_static` the same way every other
variant's tests are. 178/178 `mid-ecs` tests total now. Exposed via
`World::query2_static_diag_composed`, same `#[doc(hidden)] pub`
pattern as the other four. Bench arm `composed` added to the
`query2_static_diag_unchecked` group in `archetype_core.rs`.

Not run on real CI yet. Given `Iter2TwoTupleItem`'s result, the most
useful outcome to watch for is whether `Iter2Composed` also closes
most of the gap despite still returning two references, which would
point at the inline-tuple-literal construction itself as the real
cost rather than the reference-pair return value; or whether it stays
near the current 4x, which would point back at something specific to
carrying two live references out of `next()` together, and make
`Iter2TwoTupleItem`'s result closer to a lucky side effect of also
narrowing the return type rather than a real fix for a query API that
actually needs to hand back both components separately.

### Real CI result for `Iter2Composed` (Archetype Core build #8, rustc 1.98.1)

Second answer, not the first. `Iter2Composed`'s own bench arm measured
42.350µs at N=10,000, indistinguishable from the safe baseline
(42.505µs), `Iter2Unchecked` (42.271µs), and `Iter2UnusedBCol`
(42.335µs). Composing the fetch as two separate calls glued by `?`,
matching bevy's own macro shape exactly, changed nothing. That rules
out "how the fetch is composed" as the cost.

What actually separates the fast variant from the three slow ones,
looking at all four together:

| Variant | Struct holds both a_col and b_col? | Item | Real CI (N=10,000) |
|---|---|---|---|
| `Iter1Unchecked` | No, one column only | `&T` | 10.6µs, fast |
| `Iter2UnusedBCol` | Yes, b_col never read | `&A` | 42.3µs, slow |
| `Iter2TwoTupleItem` | Yes, b_col read via `combine` | `A` (owned) | 10.7µs, fast |
| `Iter2` / `Unchecked` / `Composed` | Yes | `(&A, &B)` | 42.3-42.5µs, slow |

`Iter2UnusedBCol` is the tell. Its `Item` is `(Entity, &A)`, the exact
same shape as the fast `Iter1Unchecked`, and it never reads `b_col` in
the hot loop. The only thing it does differently from `Iter1Unchecked`
is carry a second, unread, differently-typed slice field
(`b_col: &'a [B]`) that gets updated on every archetype advance. That
alone reproduces the full regression. Meanwhile `Iter2TwoTupleItem`
reads both columns every item and stays fast, because what crosses
back out of `next()` is owned, not a reference.

So it isn't "returning two references" (bevy does that and pays
nothing) and it isn't "how many columns get read" (`TwoTupleItem`
reads more than `UnusedBCol` and is faster). It's specifically: once
the iterator's own state holds two independently-typed live slice
references, returning any reference from `next()` pays a real cost
that returning an owned value does not, regardless of how much work
built that owned value or how the fetch that produced it was
structured.

### `Iter2RawPtr` (built this pass, not yet run on real CI)

Direct test of this. Same struct and archetype-advance logic as
`Iter2Unchecked`, but `a_col`/`b_col` are `*const A`/`*const B`
instead of `&'a [A]`/`&'a [B]`, with a `PhantomData<(&'a [A], &'a
[B])>` marker carrying the same lifetime obligation the slice fields
used to enforce directly. `next()` builds the returned item with
`&*self.a_col.add(row)`/`&*self.b_col.add(row)` instead of indexing a
stored slice. This is a hand-rolled version of the same idea as
`ThinSlicePtr`, not a dependency on it; `Mid-D-Man/bevy` is source-read
and porting reference only, never a direct dependency, so nothing here
imports `bevy_ptr`.

Two dedicated tests
(`diag_query2_static_raw_ptr_matches_the_real_query2_static`,
`diag_query2_static_raw_ptr_empty_when_one_side_was_never_registered`),
same cross-check pattern as every other variant. 180/180 `mid-ecs`
tests total now. Exposed via `World::query2_static_diag_raw_ptr`.
Bench arm `raw_ptr` added to the same group.

If this closes the gap on real CI, the natural next step is exactly
what was asked for: a small, focused, no-std-style crate mirroring
`ThinSlicePtr`'s actual shape (`NonNull<T>` plus debug-only length plus
a `PhantomData<&'a [T]>` marker, `get_unchecked` returning `&'a T`),
built as mid-engine's own, not a dependency on `bevy_ptr` itself, the
same relationship `Mid-D-Man/bevy` already has to everything else in
this project. Worth building once real CI says raw-pointer storage is
actually the fix and not one more thing that looks right for reasons
that don't hold up outside this sandbox, the same caution every other
diagnostic in this file has been given.

### Real CI result for `Iter2RawPtr` (Archetype Core build #9, rustc 1.98.1)

It didn't. 37.452µs at N=10,000, indistinguishable from every other
reference-returning variant (safe baseline 37.672µs, `Unchecked`
37.458µs, `UnusedBCol` 37.402µs, `Composed` 37.445µs). Storage
representation, slice vs raw pointer, changes nothing.

This makes sense in hindsight rather than being a dead end. `RawPtr`
and `Unchecked` both still return `Option<(Entity, &'a A, &'a B)>` from
`next()` — identical signatures. Converting a raw pointer back to
`&'a T` inside the function produces the exact same type crossing the
exact same boundary; whatever LLVM does with that signature doesn't
know or care whether the reference was built by indexing a slice or
adding to a pointer. The lever that was actually being pulled every
time (`Unchecked`'s safety, `Composed`'s call structure, `RawPtr`'s
storage) was never the one that mattered. The one variable that has
correlated with the result every single time is simpler: does `Item`
contain a reference, or not.

### `Iter2OwnedDirect` (built this pass, not yet run on real CI): isolating the one remaining confound

Before settling on "owned return is what matters," one thing needed
separating out. `Iter2TwoTupleItem`, the only fast variant found so
far, gets its owned value through `(self.combine)(a, b)` — a stored
`fn(&A, &B) -> A` pointer field, called indirectly. An indirect call
through a function pointer is its own kind of optimization barrier;
LLVM generally can't inline through one. Every slow variant
(`Unchecked`, `UnusedBCol`, `Composed`, `RawPtr`) calls nothing
indirectly. So "returns an owned value" and "goes through an opaque,
uninlinable call" have been riding together in the one data point that
worked, and it hadn't been checked which of the two actually explains
the speed.

`Iter2OwnedDirect` separates them: same owned-return shape as
`TwoTupleItem` (`Item = (Entity, A)`), same struct fields as
`Unchecked` (`a_col`/`b_col` as real `&'a [_]` slices, no pointer
games), but the combine step goes through `DiagCombine`, a small
trait with one method, called as `A::diag_combine(a, b)` rather than
through a stored function pointer. A trait method call like this is
fully known at compile time and monomorphized per concrete type, so
the compiler is free to inline it — there's no runtime indirection at
all, unlike a `fn` pointer field whose target isn't fixed until the
value is constructed.

`DiagCombine` is `pub`, not `pub(crate)` (re-exported hidden from
`lib.rs` as `mid_ecs::DiagCombine`, module itself stays private): the
bench is a separate crate linking against `mid-ecs` and needs to
implement it for its own `Position`/`Velocity` to call
`World::query2_static_diag_owned_direct` at all. Two dedicated tests
(`diag_query2_static_owned_direct_matches_manual_combine`,
`diag_query2_static_owned_direct_empty_when_one_side_was_never_registered`),
same cross-check discipline as every other variant. 182/182 `mid-ecs`
tests total now. Bench arm `owned_direct` added to the same group.

Two possible outcomes once this runs on real CI. Lands near 9.4µs,
matching `TwoTupleItem` and the 1-column baseline: confirms owned
return is genuinely what matters, independent of the function-pointer
question, and `TwoTupleItem`'s result wasn't a fluke of that
confound. Stays near 37µs, matching every reference-returning variant:
means the opaque call boundary itself was doing the real work in
`TwoTupleItem`, a stranger and more specific finding about this
toolchain's handling of that particular loop shape, not about owned
values at all — and would mean the `ThinSlice`/raw-pointer design
sketch proposed above is very unlikely to be the fix, whatever else it
might still be worth for other reasons.

### Real CI result for `Iter2OwnedDirect` (Archetype Core builds #10 and #11, rustc 1.98.1)

Second outcome. Build #10's absolute numbers were a false alarm (a
uniform ~31% drop across every group in that run, including
benchmarks nothing in this investigation touches — CI noise, caught
and re-run by the user rather than trusted). Build #11, same commit,
is back in the normal range and settles it: `owned_direct` measured
42.267µs at N=10,000, indistinguishable from every reference-returning
variant (safe baseline 42.793µs, `Unchecked` 42.276µs, `UnusedBCol`
42.250µs, `Composed` 42.260µs, `RawPtr` 42.279µs). `TwoTupleItem`
stayed fast at 10.712µs, matching the 1-column baseline (10.593µs).
Build #10's noisy absolute values still preserved this same relative
split (owned_direct 26.046µs next to a 26.0-26.1µs cluster, two_tuple_item
alone at 11.614µs), so it's two real CI runs agreeing on the ordering,
not one.

This rules out "owned return" outright. `Iter2OwnedDirect` returns
owned, same as `TwoTupleItem`, and it's exactly as slow as every
reference-returning variant. The one thing left standing, out of seven
variants tested, is that `TwoTupleItem` is the only one whose combine
step goes through a genuine indirect call (a stored `fn` pointer) that
the compiler can't inline through. Every other variant, whatever else
differs between them, fully inlines.

### Bevy's own benchmark convention (found this pass, checked directly against Mid-D-Man/bevy)

Went back to `Mid-D-Man/bevy` with a narrower question than before:
not what the fetch code does, but how bevy structures the benchmark
loop itself. Checked `benches/benches/bevy_ecs/iteration/` directly —
`iter_simple.rs`, `iter_frag.rs`, `iter_simple_foreach.rs`,
`iter_simple_contiguous.rs`, no exceptions found across the ones
checked. Every one wraps its loop in a `#[inline(never)] fn
run(&mut self)` on a small `Benchmark` struct, and `mod.rs` calls it as
`b.iter(move || bench.run())` — the criterion closure is a single call
to an opaque, never-inlined function that does the real work inside
itself. None of this project's benches do that anywhere; every loop,
in every variant above and in `benches/ecs-vs-bevy-ecs/benches/vs_bevy_ecs.rs`,
sits directly inside `b.iter(...)`, fully visible to the optimizer
alongside criterion's own harness code.

Checked whether this alone explains bevy's own speed before assuming
it explains mid-ecs's slowness: `vs_bevy_ecs.rs`'s `dense_query_iteration`
benches both engines the same way, loop inline in `b.iter()`, no
wrapper, for both sides. `bevy_ecs` still lands at parity there (its
own iteration doesn't need the wrapper to be fast). So this can't be
the whole explanation. But that doesn't rule out `mid-ecs`'s specific
`Iter2` needing it, independent of whatever bevy's implementation is
doing.

### Real, unmodified `query2_static`/`query_static`, wrapped to match bevy's convention (built this pass, not yet run on real CI)

Two new bench arms in the same group, `real_query1_inline_never_wrapper`
and `real_query2_inline_never_wrapper`. Neither touches archetype.rs
or adds a new Iter2 variant — both call the real, current, completely
unmodified `World::query_static`/`World::query2_static`, from inside a
`#[inline(never)] fn run(&mut self)` on a small wrapper struct, called
as `b.iter(|| black_box(bench.run()))`, matching bevy's own structure
exactly. Compiles clean, smoke-tested locally (`cargo bench -- --test`,
all arms report `Success` — sandbox numbers themselves stay
non-authoritative as always, this only confirms nothing panics).

This is the most direct test yet of what's actually been driving every
result in this file so far, and it uses zero diagnostic code: if
wrapping the real `query2_static` in a never-inlined function alone
closes most of the gap, a meaningful part of this entire investigation
has been chasing a benchmark-harness artifact rather than a real
runtime difference in `Iter2` itself — the fix would be to the bench,
not the iterator. If it stays near 37-43µs even wrapped, that rules
out harness structure too, and leaves indirect-call-specifically (not
owned return, not harness shape) as the one remaining explanation with
any real evidence behind it, which would need a real disassembly
comparison on rustc 1.98.1 to actually resolve.

### Real CI result for the `inline_never` wrapper test (Archetype Core builds #12 and #13, rustc 1.98.1)

Not a clean answer either way. The user ran this twice specifically to
check it wasn't a fluke, and both runs agree with each other, but not
in a way that confirms the wrapper hypothesis. What actually moved:

`query2_static_two_components` (real `Iter2`, no wrapper): 37.7µs
historical -> ~27.5-28.5µs both builds. `real_query2_inline_never_wrapper`
(same real `Iter2`, wrapped): ~27.5-28.9µs, indistinguishable from the
unwrapped version right next to it. So the wrapper itself changed
nothing — wrapped and unwrapped moved together.

But `query_static_single_component` (real `Iter1`, its own separate
top-level group, unrelated to this pass's diagnostic work) went the
other direction: ~9.4-11.6µs historical -> ~24.5-26.2µs both builds,
over *twice* as slow. And `raw_slice_ceiling` — zero mid-ecs code at
all, two plain `Vec`s — dropped from ~9.3-10.5µs to ~6.0-6.5µs, faster
in the opposite direction from `query_static_single_component`. Three
benchmarks that share no code moved three different amounts in two
different directions in the same run, twice.

That's not "the regression closed." The `query2_static_two_components`
vs `query_static_single_component` ratio only looks good (1.1-1.25x
this run, versus the usual ~4x) because the denominator got worse by
coincidence, not because the numerator got better for a real reason.
The number that actually matters was checked the same day and didn't
move: `ecs-vs-bevy-ecs` build #14, `dense_query_iteration`, still
3.99x (37.440µs vs bevy's fresh, independently-compiled 9.3733µs).
That comparison doesn't share this file's internal noise sources at
all, and it's unchanged. Treating builds #12/#13 as resolution would
mean trusting the one measurement that's easiest to fool and ignoring
the one that isn't.

Real, useful signal from this regardless: `archetype_core.rs`'s
internal "regression guard" ratio can swing this wide from
measurement conditions alone, with zero code change on either side of
the ratio. That's a concrete argument for the granular rework below —
a comparison with more independent, narrowly-scoped operations makes
a coincidence like this easier to catch (three unrelated numbers
moving inconsistently is a clearer tell than two numbers producing a
falsely-reassuring ratio).

### `benches/ecs-vs-bevy-ecs/benches/vs_bevy_ecs.rs`: single-op and multi-op rework

The four original groups (`spawn_n_entities_two_components`,
`query_static_single_component`, `dense_query_iteration`,
`raw_slice_ceiling`, `structural_churn_insert_remove` — five, not
four; that miscount predates this pass, fixed in the file's own doc
comment while here) were broad workload buckets. Six more added this
pass break specific operations out individually, matching
`crates/mid-math/benches/vs_glam.rs`'s own granularity: one
`bench_function` pair per concrete operation, not per broad workload.

`spawn_single_component`, `insert_single_component`,
`remove_single_component`: single-component versions of operations
the existing groups only measure bundled with a second component
(`spawn_n_entities_two_components`) or not at all (bare insert/remove
with no spawn or churn mixed in). `get_component_random_access`: a
genuinely different code path from every iteration group above, N
separate entity-by-id lookups rather than one contiguous archetype
scan. `insert_bundle_on_existing_entity`, `remove_bundle_two_components`:
multi-component structural moves on an entity that already carries
data, distinct from `spawn_n_entities_two_components`'s spawn-then-
immediately-bundle case and `structural_churn_insert_remove`'s
single-component churn.

Every new loop is wrapped in a `#[inline(never)]` free function,
matching bevy_ecs's own benchmark convention (confirmed by direct
source read this pass, see the `diag_query2_unchecked.rs` module
section above) — adopted unconditionally, not because builds #12/#13
confirmed it matters for mid-ecs specifically (they didn't confirm
anything either way), but because using bevy's own practice can only
make the comparison fairer, never less fair.

Verification: `ecs-vs-bevy-ecs` itself still can't be checked in this
sandbox at all (`bevy_ecs`'s `rust-version = "1.95.0"` blocks even
reaching this crate's own code on the sandbox's rustc 1.91, same wall
as always). The mid-ecs half of all six new functions was verified for
real instead: extracted into a standalone throwaway binary crate
depending on real `mid-ecs` directly (no `bevy_ecs` involved, so it
actually compiles here), with assertions checking each operation's
actual effect (entity count after spawn, `has_static` after
insert/remove, the summed value after random-access get, bundle
membership after insert/remove onto a non-empty entity) — all passed,
then deleted. The bevy_ecs half is grounded the same way the original
four groups already were: read directly against real source
(`World::spawn_empty`, `World::get`, `World::get_mut`,
`EntityWorldMut::insert`/`remove`, all confirmed in
`Mid-D-Man/bevy`'s `world/mod.rs` and `world/entity_access/world_mut.rs`),
not locally compiled. Confirm it actually builds on the next real CI
run before trusting bevy_ecs's numbers specifically, same standing
caveat the file's own header has always carried.

`.github/workflows/bench-vs-bevy-ecs.yml`'s own summary text hardcoded
"Three groups" — already wrong before this pass (there were five), now
updated to describe all eleven. `scripts/bench_vs_bevy_ecs.py` needed
no changes at all: it discovers groups by name from criterion's own
output and builds one table per group automatically, so the six new
groups just show up.

Checked `Mid-D-Man/bevy`'s actual `crates/bevy_ptr/src/lib.rs` directly
on the lead the user gave: bevy_ecs doesn't just happen to avoid this,
it has a dedicated crate (`bevy_ptr`, `#![no_std]`, one dependency,
`bevy_utils`) built specifically so its storage layer never holds
plain `&[T]` slice references across a fetch boundary. The relevant
type is `ThinSlicePtr<'a, T>`: a `NonNull<T>` plus a debug-only `len`
plus `PhantomData<&'a [T]>` for the borrow checker, with
`get_unchecked(&self, index) -> &'a T` doing the same
pointer-add-and-deref `Iter2RawPtr` does below. Confirmed this is not
a coincidence: `query/fetch.rs` imports it directly
(`use bevy_ptr::{ThinSlicePtr, UnsafeCellDeref};`), and `ReadFetch<'w,
T>`, the real `WorldQuery::Fetch` type for a plain `&T` query (its own
doc comment says so), stores its table column as exactly
`Option<ThinSlicePtr<'w, UnsafeCell<T>>>`, never a `&'w [T]`. A
2-component query composes two of these side by side, same shape
`Iter2UnusedBCol`/`Iter2Composed` tested, except bevy's two fields are
`ThinSlicePtr` and mid-ecs's are `&'a [_]`.


### Builds #11 and #13 (Archetype Core, rustc 1.98.1): the regression-guard ratio's own instability

Two real CI runs pasted back this pass, not adjacent — build #11 (03:36)
showed the regression-guard ratio at a "bad" 3.14-4.08x (flagged red by
the job summary itself); build #13 (12:51, same day) showed it at a
"good" 1.09-1.24x (flagged green, "consistent with the ~1.28-1.35x
currently-observed baseline"). Read at face value, that looks like the
gap closed on its own between the two runs. It didn't — the ratio's own
denominator moved, not its numerator.

**What actually moved, `build #13 / build #11`, at N=100,000:**

| Group | Build #11 | Build #13 | Ratio (13/11) |
|---|---|---|---|
| `query_static_single_component` (Iter1, safe, real) | 106.09µs | 262.06µs | **1.90x SLOWER** |
| `query_static_unchecked_1col` (Iter1Unchecked) | 106.01µs | 65.413µs | 0.617x (38% faster) |
| `two_tuple_item` (Iter2TwoTupleItem) | 106.39µs | 89.366µs | 0.840x (16% faster) |
| `query2_static_two_components` (Iter2, safe, real) | 433.32µs | 299.11µs | 0.690x (31% faster) |
| `query2_static_unchecked_2col` (Iter2Unchecked) | 423.22µs | 265.28µs | 0.627x (37% faster) |
| `raw_slice_ceiling — one_field_sum` (zero ECS code) | 105.76µs | 65.626µs | 0.620x (38% faster) |
| `spawn_insert_bundle` | 19.906ms | 12.234ms | 0.615x (39% faster) |
| `structural_churn_insert_remove` | 21.624ms | 14.708ms | 0.680x (32% faster) |

Every group in the binary got faster in build #13 — between 16% and
39% — except one: `query_static_single_component`, which got 90%
*slower*, enough on its own to land it almost exactly inside build
#13's "slow" cluster (262.06µs, next to `query2_static_unchecked_2col`'s
265.28µs) despite querying one column, not two. Its own nearest
sibling, `query_static_unchecked_1col` — same state machine, same
archetype-advance logic, the *only* line that differs is
`get_unchecked` instead of safe indexing — moved with the crowd (38%
faster). This is not "everything is noisy in the same direction," the
usual, dismissable pattern (see `structural_churn`/`spawn_insert_bundle`
above, which did move together with the crowd, consistent with a
faster run in general). One specific, safe, real, production function
moved alone, against 15+ others in the same binary, by a wide margin.

**The clean signal, unaffected by any of this:** `query_static_unchecked_1col`
vs `query2_static_unchecked_2col` — both diagnostics, both `get_unchecked`,
neither touched by whatever hit `query_static_single_component` — sits
at 3.99x (build #11) and 4.06x (build #13) at N=100,000, 3.33x/3.18x at
N=100. Stable, in lockstep, across a run where literally everything
else's absolute numbers moved by up to 39%. **This is the trustworthy
number, and it says unchanged: still ~4x, matching `ecs-vs-bevy-ecs`'s
own `dense_query_iteration` (3.99x as of build #14, a separate binary
sharing none of `archetype_core.rs`'s internal noise sources).** Build
#13's 1.24x reading is real data, correctly transcribed, and still
wrong to trust as "fixed" — its denominator broke, not its numerator.

**Cross-referencing this against `diag_inline.rs`'s own Never/Always/
Default group, already present in both these builds but not yet read
this way:** at N=100,000, `Default` (`query2_static_two_components`
itself) sits 1.1% from `Never` and 2.4% from `Always` in build #11; 0.2%
from `Never` and 10.7% from `Always` in build #13. Default tracks
Never, not Always, in both runs — the compiler is not silently
auto-inlining `Iter2::next` by default on rustc 1.98.1. That specific
theory (a hidden default-heuristic inline causing the gap) is ruled
out. What's *not* ruled out: build #13 shows `Always` measurably faster
than `Default`/`Never` (267.06µs vs ~298-299µs, ~11% at N=100,000,
~14-17% at smaller N) — the opposite of what the sandbox found when
`#[inline(always)]` was tried and reverted on `Iter2::next` itself (see
that method's own doc comment in `archetype.rs`, and this module's
header). Build #11 shows no such gap (all three within ~3.5% of each
other). One run showing an effect and one showing nothing is a lead,
not a finding — needs a third run to know if build #13's edge for
`Always` is real or noise.

**Built this pass, not yet run on real CI:** `Iter1Never`/`Iter1Always`
in `diag_inline.rs`, exposed as `World::query_static_diag_never`/
`_always`, benched as the new `query_static_single_component_diag_inlining`
group in `archetype_core.rs` — the exact same Never/Always/Default
treatment `Iter2` already has, applied to `Iter1` for the first time.
Motivation is the table above: `query_static_single_component` just
produced the single most specific, isolable anomaly this investigation
has seen (one real function, alone, moving hard against everything else
in its own binary), and until now nothing has ever tested whether
`Iter1`'s inline attribute matters the way `Iter2`'s might. If `Iter1`
shows the same Default≈Never pattern with `Always` pulling ahead, that's
a second, independent signal pointing at the same lever as `Iter2`'s —
and worth actually shipping `#[inline(always)]` on both real functions
if a third run confirms it, reversing the earlier sandbox-only-informed
revert (which never had real-CI `Iter2` data to check against — it does
now, partially, and this adds the `Iter1` half). If `Iter1` does *not*
show the pattern, `query_static_single_component`'s build #13 anomaly
has some other cause, and that's worth knowing too before spending more
time on the inlining line of investigation specifically.

Not a fix yet. Land this, run Archetype Core at least twice more (one
run already looked like a fluke this project — build #10 — and was
caught only by rerunning), and read `Iter1`'s new group the same way
the table above reads `query_static_single_component`'s.

### Builds #15 and #16: the `Iter1` attribute test came back negative, and something more useful came back positive instead

Landed the `Iter1Never`/`Iter1Always` diagnostic from the previous
section, then ran Archetype Core twice (builds #15, #16) specifically
to check the result wasn't a fluke, same discipline as everywhere else
in this investigation. It wasn't a fluke — the two runs agree with
each other to within 1-2% on nearly every group, a level of internal
consistency this suite hasn't shown since build #7. But the answer
itself is a clean negative on the question asked, and a clean positive
on a different, better question asked by accident.

**The negative result:** `query_static_single_component_diag_inlining`
— `inline_never`, `inline_always`, and `Default` (`query_static_single_component`
itself) — all landed within 1% of each other in both builds (e.g.
build #15 @ N=100,000: 377.18µs / 375.18µs / 375.25µs). No split at all,
in either direction. Pinning `Iter1::next`'s own inline attribute does
nothing, for either extreme — the same clean negative `Iter2Never`/
`Iter2Always` already gave for the 2-column case. **An attribute on
`next` itself, in isolation, is not the lever, for either arity.** That
line of investigation is closed.

**The accidental finding:** every benchmark that used to separate into
a "fast" 1-column cluster and a "slow" 2-column cluster has collapsed
into one cluster in both builds — including `query_static_single_component`
itself (375-377µs, up from its historical ~65-106µs) *and*
`query_static_unchecked_1col` (Iter1Unchecked — 375µs, also up from its
own historical ~65-106µs, and previously the single most reliable
"stays fast no matter what" reference point in this whole matrix).
Three things are still fast, unmoved, matching their own historical
numbers exactly: `raw_slice_ceiling` (~94µs, zero ECS code — nothing
for a binary-layout shift to grab onto), `two_tuple_item` (~94µs,
unchanged), and — this is the one worth sitting with —
`real_query1_inline_never_wrapper` (~94µs, unchanged), while its
structural twin `real_query2_inline_never_wrapper` sits at ~395-400µs,
matching `query2_static_two_components` exactly.

`RealQuery1::run`/`RealQuery2::run` (in `archetype_core.rs`'s
`bench_query2_static_diag_unchecked`) are byte-for-byte identical in
shape — same `#[inline(never)] fn run(&mut self) -> f32`, same for-loop
calling the real, unmodified `query_static`/`query2_static`, differing
only in `sum += pos.x` vs `sum += pos.x + vel.dx`. Wrapping the *whole
consuming loop* in an outer `#[inline(never)]` boundary reliably fixes
the 1-column case and reliably does not touch the 2-column case — this
is now the same result across at least three separate builds (#12/#13
per the previous session, #15/#16 this one). **"Just wrap the call
site" is ruled out as a sufficient fix for `query2_static` specifically
— whatever's different has to be something `Iter2::next` carries on its
own, not something fixable purely from outside it.**

**The likely explanation for the collapse itself, stated plainly since
it changes how to read the last several sections:** nothing in
`archetype.rs` changed between build #13 and build #15 — `Iter1::next`
is the exact same source it's been all session. What changed is that
`diag_inline.rs` and `query.rs` grew new code in the same compilation
unit `Iter1::next` lives in. The most likely read is that this shifted
enough about the compiled binary's layout to tip `Iter1::next` — which
build #13 already showed *can* tip, just not reliably before now — into
whatever regime `Iter2::next` sits in permanently. Shipping the next
diagnostic pushed the very thing it was trying to observe into a new,
now-stable state. Worth stating plainly rather than treating as a
side note: the regression-guard table's own baseline
(`query_static_single_component`) is not currently a safe thing to read
at face value, and won't be until this is actually understood, not just
patched around.

**Patched around in the meantime, because leaving it silent is worse
than a workaround:** `scripts/bench_mid_ecs_archetype_core.py` now
cross-checks `query_static_single_component` against `raw_slice_ceiling`'s
own floor at N≥1,000 (N=100 excluded — checked directly against build
#11's own healthy numbers, which still show a 2.6× baseline/floor ratio
at N=100 alone from ordinary fixed-per-call overhead, a false positive
this exclusion avoids) and refuses to print a clean ✅ — downgrading
every row to at least ⚠️ regardless of how good the raw ratio looks —
if that baseline is running >2.0× the floor. Verified against both
regimes directly: build #11's real numbers (healthy baseline, genuine
4.08× worst ratio) still correctly print the original 🔴 for the
original reason; build #15's real numbers (collapsed baseline, a
misleadingly clean 1.07-1.13×) now correctly print a drift warning and
downgrade every ✅ to ⚠️ instead of reporting a false pass. This doesn't
fix the underlying issue — it stops the summary from actively lying
about it while it's unresolved.

**Built and shipped this pass, not yet run on real CI:**
`Iter2ColdSplit` in `diag_query2_unchecked.rs` — `Iter2`'s exact logic
with the archetype-advance ("cold") branch physically moved into its
own `#[inline(never)] fn advance`, leaving `next`'s own body as just
the per-entity fast path and a call out to `advance` on the rare
branch. Different question than the already-closed one above: not "does
an attribute on `next` matter" (closed, no) and not "does wrapping the
*caller* matter" (closed for 2 columns, no) but "does the *cold path's
own size*, sitting physically inside `next`, affect how well the *hot*
path inlines at 2 columns' worth of state" — untested until now, and
the one remaining structural difference between `Iter2` and
`Iter1`/`Iter2TwoTupleItem` this investigation hasn't tried adjusting.
Three new tests (`diag_query2_static_cold_split_matches_the_real_query2_static`,
`_empty_when_one_side_was_never_registered`, and a new three-archetype
`_walks_multiple_matching_archetypes_and_skips_a_non_matching_one_between_them`
case — `two_archetype_world`'s own two archetypes weren't enough to be
confident the split between `next`/`advance` hands off state correctly
across more than one real archetype boundary) — 185/185 mid-ecs tests
pass, bench compiles clean. Benched as a new `cold_split` entry in the
existing `query2_static_diag_unchecked` group — no new bench group
needed, it slots in next to `composed`/`raw_ptr`/`owned_direct`.

Land it, run Archetype Core at least twice (same standing discipline),
and read `cold_split` against `two_tuple_item`/`raw_slice_ceiling` (the
still-reliable fast references) rather than against
`query_static_single_component` — which, per the section above, isn't
a safe comparison point right now regardless of what the automated
table says about it.

### Builds #17 and #18: `cold_split` is a clean negative, and the profile itself became a suspect

Ran Archetype Core twice more (builds #17, #18 — same commit,
triggered together, ~12-13% apart in absolute terms across every group
uniformly — the ordinary "different runner" pattern this project has
always treated as dismissable noise, not the isolated single-function
pattern builds #13/#15/#16 showed). `cold_split` landed in the slow
cluster in both — 376.37µs / 423.40µs at N=100,000, indistinguishable
from `composed`/`raw_ptr`/`owned_direct`/`unused_b_col`. **Clean
negative: the cold path's own size, factored out into its own
`#[inline(never)]` function, is not what's holding the hot path back.**
That closes this specific structural line of inquiry — outlining
doesn't help, at least not the way it was tried here. `query_static_single_component`
and `query_static_unchecked_1col` are still sitting in the collapsed
state builds #15/#16 first showed, in both #17 and #18 — four
consecutive builds now, so whatever tipped it during the `Iter1Never`/
`Iter1Always` addition looks like a settled new state, not a fluke.

At this point every source-level variant of `Iter2`'s own logic this
investigation has tried — safe, unchecked, raw-pointer, owned,
composed-fetch, attribute-pinned, cold-path-split — reproduces the same
number, with the sole exception of the one that adds a genuine indirect
call. That's a strong pattern in one direction (something about a fully
analyzable, fully inlinable 2-column loop specifically) but seven-plus
negative results without a working fix for the real API starts to look
like the wrong axis is being varied. Two things checked this pass that
aren't another `Iter2` source variant:

**Checked directly, not assumed: this workspace's own build profile.**
Root `Cargo.toml`'s `[profile.bench]` sets `codegen-units = 1` and
`lto = true` workspace-wide — added 2026-08-23, for a real, different,
already-fixed problem (`wide::i32x4::add` benching ~14x slower than
mid-math's own equivalent, a cross-crate inlining gap; see
docs/platform-optimization.md §9). Two things about it worth stating
plainly: (1) `benches/ecs-vs-bevy-ecs` is a workspace member, not a
separate workspace (checked directly, per its own Cargo.toml's
comment), so real `bevy_ecs` compiles under this exact same
codegen-units=1+LTO regime whenever that comparison runs — it isn't
somehow exempt. (2) Mid-D-Man/bevy's own root `Cargo.toml` (real
source, re-checked this pass) has neither a bare `[profile.release]`
nor any `[profile.bench]` at all — bevy's own benchmarks, the same
`benches/benches/bevy_ecs/iteration/*.rs` already read for the
`#[inline(never)]`-wrapper convention, run under cargo's plain,
unconfigured default: `codegen-units = 16`, no LTO. Bevy leans on
explicit `#[inline(always)]` (confirmed on `QueryIterationCursor::next`
itself) to guarantee its own hot path's codegen, not on whole-program
LTO to let the compiler figure it out. This project's workspace applies
LTO+single-codegen-unit to `Iter1`/`Iter2` as a side effect of fixing an
unrelated crate's problem, not as a deliberate choice for these two
functions specifically.

Searched before treating this as more than a coincidence: LTO making
one *specific* loop's own codegen measurably worse, independent of any
codegen-unit-reshuffling question, is real and already confirmed
upstream — rust-lang/rust#106609 ("LTO produces worse codegen for a
loop," with real before/after disassembly showing the LTO'd version
adds an extra live pointer the non-LTO'd version optimizes away) and
rust-lang/rust#146497 (a 2025 nalgebra/criterion reproduction showing
over 4000% degradation from `lto = "fat"` alone). Separately,
vortex-data/vortex#9259 (real PR, months old) hit the *other*
mechanism — `codegen-units = 16` reshuffling which functions share a
unit when unrelated code is added, moving benchmarks with no source
change on the branch that added them — and fixed it by moving *to*
codegen-units=1+lto=true, the setting this workspace already has. Two
distinct, independently-real mechanisms; this project's current
profile is already the known fix for one of them, and has never been
tested against the other for `Iter2`'s specific loop shape.

**Built and shipped, not yet run on real CI:** a `profile.bench-nolto`
entry in the root `Cargo.toml` (`inherits = "release"`, then every
field set explicitly: `opt-level = 3, lto = false, codegen-units = 16,
strip = false, debug = true` — matching bevy's own actual, unconfigured
numbers rather than guessing at them), plus a `profile` dispatch input
on this workflow (`bench`, the current default, or `bench-nolto`),
wired into the actual `cargo bench --profile` invocation and into the
cache key so the two don't share a `target/` cache entry. Verified
directly on this sandbox: `cargo build -p mid-ecs --profile bench-nolto`
and `cargo bench -p mid-ecs --bench archetype_core --profile bench-nolto`
both compile and run cleanly (rustc 1.91.1) — this only confirms the
plumbing works, not anything about the performance question itself,
which this sandbox has never been able to speak to for this
investigation either way.

Run Archetype Core once with `profile: bench-nolto` and once more with
the default `bench` on the same commit, and read the two side by side —
particularly `query2_static_two_components`, `query2_static_unchecked_2col`,
and (now that it's a clean negative under the current profile)
`cold_split` again under the other one. If any of them move
meaningfully between the two profiles while `raw_slice_ceiling` and
`two_tuple_item` don't, that's the profile, not the source, and the
seven-plus negative source-level results above stop being seven-plus
negative results and start being seven-plus results that were never
going to show anything because the actual lever was never in the
source to begin with.

### Builds #19 and #20: the A/B test landed, and it reframes the question rather than closing it

Ran Archetype Core once on each profile, same commit (`ae43fc5`).
Build #19 (`bench`, current default): the usual current numbers.
Build #20 (`bench-nolto`, matches bevy's own real settings): and here
is the actual result, stated plainly because it's not the clean "the
profile explains everything" story the previous section was hoping
for — it's more specific and, once seen, more useful than that.

**`two_tuple_item` and `real_query1_inline_never_wrapper` — the two
things that have been reliably fast (~94-106µs) in every single build
this entire investigation has run — both collapsed under `bench-nolto`.**
`two_tuple_item`: 106.37µs → 514.81µs (worse than the "slow" cluster).
`real_query1_inline_never_wrapper`: 106.15µs → 376.91µs (now
indistinguishable from unwrapped `query_static_single_component`,
377.11µs, in the same run). Everything else moved by the ordinary
~10-13% a different run/profile produces on its own — `raw_slice_ceiling`
stayed the true floor in both (105.75µs → 93.943µs, actually a bit
faster without LTO, consistent with the general trend, not a collapse).

Read together, this says something more specific than "LTO matters":
**both of this investigation's clean "fast" reference points depend on
LTO's whole-program view being able to prove something about them that
isn't true without it.** `two_tuple_item`'s combine step is a stored
`fn(&A,&B)->A` pointer — genuinely indirect in the source, but if it's
only ever constructed with one concrete function in the whole program,
LTO can see that across crate/module boundaries and devirtualize it
into a plain, inlinable call; without LTO, that proof isn't available
and it's a real, un-inlinable indirect call, with real, unhidden
overhead. `real_query1_inline_never_wrapper`'s own `#[inline(never)]`
wrapper doesn't touch whether `Iter1::next` inlines into `run`'s own
loop — whatever made that combination fast was something LTO's
cross-module view was doing, not the wrapper attribute itself doing
anything without it.

**The more important thing this run showed:** without LTO's help,
there is no meaningful gap between 1 column and 2 columns at all.
`query_static_single_component` (377.11µs) and `query2_static_two_components`
(397.29µs) sit within 5% of each other — both roughly 4x
`raw_slice_ceiling`'s floor. This is worth stating as plainly as the
reversal above: **the "query2_static costs ~4x query_static" framing
that has organized this entire investigation has, in every build this
session, only ever shown up when the comparison's 1-column side was
something LTO specifically blesses** (build #11's original
`query_static_single_component`, before whatever this session's own
`Iter1Never`/`Iter1Always` addition did to it; `two_tuple_item`;
`real_query1_inline_never_wrapper`). Take those out of the picture —
compare `query_static_single_component` to `query2_static_two_components`
directly, either profile — and both cost roughly the same, both roughly
4x the floor. The seven-plus `Iter2`-only diagnostic variants this
investigation has built were all answering "what's different about 2
columns," a question this run casts real doubt on as the right one to
be asking. The steadier, more basic question underneath it, that this
investigation hasn't actually asked yet: **why does going through
`Iter1`/`Iter2` at all — for either arity — cost ~4x a raw slice sum**,
when build #11 shows that cost used to be ~1x for the 1-column case,
specifically.

**Built and shipped, not yet run on real CI:** `benches/iter1-isolated`,
a new, minimal workspace member containing exactly two groups —
`query_static_single_component` and `raw_slice_ceiling`'s
`one_field_sum`, mirrored byte-for-byte from `archetype_core.rs` — and
nothing else. No `Iter2`, no diagnostics, none of what
`archetype_core.rs` has accumulated across this entire investigation.
Same workspace, same `[profile.bench]` (or `[profile.bench-nolto]` —
new workflow takes the same profile choice) held constant, so the one
variable this isolates is exactly the one the "builds #15-#20" section
above flags but never tests directly: does `query_static` come back
close to the floor once it's the only thing in the crate, the way it
was in build #11, before this investigation's own accumulated code
apparently pushed it into the same regime `query2_static` has been in
all along? New workflow: `bench-iter1-isolated.yml`, modeled on
`bench-mid-collections-sparse-set.yml`'s simpler bash-grep summary
(two groups doesn't need `archetype_core.py`'s regression-guard
machinery). Verified end-to-end on this sandbox (compiles, runs,
produces correctly-shaped output) — meaningless for the actual
question, as always, since this sandbox has never reproduced this
investigation's regression in either direction.

**Also caught and fixed while building the above:** the `profile`
dispatch input added to this workflow two sessions ago broke its own
step-summary size-limit fix for any profile name other than the literal
word `bench` — the guard's `grep`/`awk` pattern was `` Finished `bench`
profile `` (an exact match), and `cargo bench --profile bench-nolto`
prints `` Finished `bench-nolto` profile `` instead, which doesn't
contain that exact substring. Build #20's run fell through to the
"compilation never finished" fallback despite compiling and running
cleanly — wrong, and pointless, since that fallback exists specifically
to show build *errors*, not a clean run's own already-stripped-of-value
warning preamble. Caught by testing the pattern against both real
strings directly (not assumed safe from one string alone) and fixed by
matching the `` `bench `` prefix only, which fires for any profile name
starting with it. Applied to the new `bench-iter1-isolated.yml` from
the start, so it isn't carrying the same bug into its first run.

### Builds #1 and #2 (Iter1 Isolated, rustc 1.98.1): closing the investigation

Real CI, `benches/iter1-isolated`, commit `f8412070`. Build #1 (`bench`,
LTO on): `query_static_single_component` 106.09µs vs
`raw_slice_ceiling`'s 105.71µs at N=100,000 — **~1.0x, matching
Archetype Core build #11 almost to the microsecond.** Build #2
(`bench-nolto`): 329.59µs vs 81.97µs — **~4.02x**, matching what
`archetype_core.rs` itself has shown under either profile since build
#13, and matching builds #19/#20's own no-LTO numbers for the same
query.

That's the answer builds #19/#20 reframed but didn't close: isolating
`Iter1` from everything `archetype_core.rs` has accumulated (seven-plus
`Iter2` diagnostic variants, their own `Iter1`-side additions,
`Iter2ColdSplit`) restores it to the floor — **but only with LTO on**.
Without LTO it costs the same ~4x as everything else in this
investigation always has, isolated or not. Read together with #19/#20's
own reversals (`two_tuple_item` and the outer wrapper both collapsing
under `bench-nolto`), the whole thread comes down to one mechanism:
**LTO's whole-program devirtualization is what made `Iter1` fast in
build #11, and it stops fully resolving `Iter1::next`'s call sites once
the compilation unit gets large enough** — which is exactly what
`archetype_core.rs` became across this investigation's own diagnostic
additions. Not a structural difference between 1 and 2 columns (#19/#20
already ruled that out), not `Iter1`'s own codegen — just LTO losing
headroom as the surrounding file grew. Upstream-confirmed pattern, not
a stretch: rust-lang/rust#106609, #146497.

**Closing here**, per the call made at the start of this pass rather
than running a ninth diagnostic: the mechanism is confirmed and real;
further digging is diminishing returns. `archetype_core.rs` and
`benches/iter1-isolated` both stay as-is — kept for reference, not
deleted — since "is the gap real" is answerable by pointing at these
two builds now, not by re-running anything. Real, separate wins that
came out of this thread regardless of the open question closing
inconclusively-by-choice rather than definitively: the step-summary
overflow fix, the regression-guard's N=100 false-positive fix, and
`get_two_mut`/`get_disjoint_mut`'s real 1.83x/2.49x improvements.

### `scratch.rs`: a swappable arena abstraction, not wired in yet

Built to make good on the standing plan: bumpalo backs `mid-ecs`'s
scratch storage today, a future `mid-arena`-backed type replaces it
once that's been benched for this exact access pattern — without a
second rewrite of whatever calls it. `archetype.rs`'s own doc comment
already names the cost this targets: each migrated component value is
boxed as `Box<dyn Any>` (`Column::swap_remove_and_forget`/`push_any`),
one heap allocation per moved component per structural change.
`spawn_insert_bundle` and `structural_churn` are flagged in
`archetype_core.rs` as real, measured gaps against `bevy_ecs`
(~2.9-5x) — but **no root-cause pass has been done on either yet**.
This module doesn't claim boxing is that gap; it makes the one named,
understood cost swappable so a future profiling pass has something to
swap, rather than starting from a raw-pointer rewrite of `Column`
itself.

**Design:** `ScratchArena<'a>` (`alloc<T: 'static>(&'a self, value: T)
-> Self::Erased`, `reset(&mut self)`) plus an `ErasedValue` trait
(`downcast<T>(self) -> Result<T, Self>`) mirroring `Box<dyn
Any>::downcast`'s own contract exactly — wrong type back unchanged in
`Err`, never dropped or lost. Two real implementations:

- `HeapScratch` — today's actual behavior, given a name. One real heap
  allocation per `alloc`, zero new dependencies, default.
- `BumpaloScratch` (behind the new `scratch-arena` feature,
  `bumpalo = "3.20.3"`, `features = ["boxed"]`, optional) —
  `bumpalo::Bump` plus its own `boxed::Box<'a, dyn Any>`.

**Why bumpalo directly and not `mid-arena`'s own `BumpArena<T>`:**
checked directly, `mid-arena`'s `BumpArena<T>` is single-typed —
built for many values of *one* `T`, not a match for what a structural
change needs (several *different* component types, one arena, for the
width of one entity's migration, then thrown away). `bumpalo::Bump`
already solves that shape — it's what `bevy_ecs`'s own `BundleScratch`
uses, real source read directly — so it's the right backing today;
`mid-arena` stays the eventual target once it grows a matching type,
not before.

**Why this doesn't need `Box<'a, T>`'s unstable `allocator_api`:**
a naive trait returning `Box<dyn Any>` (the real, `alloc::boxed` type)
would be impossible for a bump-backed implementation to satisfy on
stable Rust — `Box` isn't allocator-parameterized outside nightly.
`bumpalo`'s own `boxed` feature (stable, zero extra dependencies —
checked directly, `bumpalo` 3.20.3's `Cargo.toml`: `boxed = []`) solves
this with its own `Box<'a, T>`, which is the actual return type behind
`ErasedValue` for the bumpalo-backed side. Its `Drop` impl was read
directly (`src/boxed.rs`): calls `drop_in_place` and nothing else — the
arena owns reclaiming memory, not the `Box` — exactly the property this
module needs. Erasing a concrete `Box<'a, T>` into `Box<'a, dyn Any>`
needs one small `unsafe` block (`Box::into_raw` -> unsize cast -> 
`Box::from_raw`) — bumpalo's own documented pattern for building a
type-erased `Box` (`boxed.rs`'s "Manually create a `Box`" example), not
an invented technique, and narrow enough to audit in one function.

**Verified, not assumed:** 4 tests with default features (`HeapScratch`
only), 9 with `--features scratch-arena` (both implementations against
the same shared test bodies, generic over `ScratchArena`) — roundtrip,
wrong-type downcast returns the value unharmed, and critically,
dropping an un-downcast value still runs its destructor exactly once
(a `DropCounter` type with a real `Drop` impl, checked against a shared
counter) for both `HeapScratch` and `BumpaloScratch`. Full existing
suite re-run both ways: 189/189 (default), 194/194 (`scratch-arena`) —
185 pre-existing plus this module's own, nothing broken either way.

**Not done yet, on purpose:** `Column::swap_remove_and_forget`/
`push_any` still use `Box<dyn Any>` directly — this module is
standalone infrastructure, not wired into the migration path. Next
step, not this one: wire `BumpaloScratch` into that one call site once
there's been an actual root-cause pass confirming boxing is worth
fixing before `spawn_insert_bundle`/`structural_churn` get touched
further.

### `diag_alloc_count.rs` and the `remove_bundle`/`insert_bundle` allocation pass

Root-caused rather than guessed at, using a real, sandbox-valid signal
the Iter1/Iter2 investigation didn't have available: allocation
*counts* through a `#[global_allocator]` wrapper are deterministic
regardless of optimization level, unlike timing — same code, same
allocations, every run. `examples/diag_alloc_count.rs` mirrors three of
`vs_bevy_ecs.rs`'s real workloads exactly (N=10,000, same component
shapes and call sequence) and reports real allocs/op, release profile.

**A real correction found along the way, stated plainly:** `insert`/
`get`/`has` are the *Sparse Shell*; `insert_static`/`get_static`/
`has_static` are the *Archetype Core* — the reverse of what "static"
sounds like it should mean, confirmed directly from this crate's own
tests (`using_a_sparse_type_with_insert_static_panics`), not assumed.
`Marker` in the real bench is inserted via `insert_static`, so it's a
real, archetype-tracked, *surviving* column on every
`remove_bundle_two_components`/`insert_bundle_on_existing_entity` call
— not a sparse one sitting outside the archetype entirely, which is
what an earlier pass through this same file mistakenly assumed. The
initial "fast path, only when every column is being removed" design
built on that wrong assumption was real and tested, but never actually
fired on the real benchmark because of it — superseded below by a
version of the same idea that's unconditionally true instead.

**Three real, verified fixes, each checked against the diagnostic
before being trusted:**

1. **`Bundle::component_ids`/`existing_component_ids` returned
   `Vec<ComponentId>`** — one heap allocation on *every*
   `insert_bundle`/`remove_bundle` call, every arity, regardless of
   whether that call ends up boxing anything. Replaced with
   `ComponentIdList`, a fixed 8-slot inline buffer (`impl_bundle_for_
   tuple!` never generates past arity 8) plus a real length — `Deref`/
   `DerefMut` to `[ComponentId]` so every existing call site kept
   working unchanged except one `for &id in &ids` → `for &id in
   ids.iter()` (`for` loops need `IntoIterator` directly; `Deref`
   coercion doesn't reach that far). Measured: `remove_bundle_two_
   components` 4.00 → 3.00 allocs/op, `insert_bundle_on_existing_
   entity` and `spawn_n_entities_two_components` both 1.00 → ~0.

2. **`B`'s own removed elements never need `Box<dyn Any>` at all** —
   true unconditionally, not just when nothing else survives. Added
   `Bundle::take_direct`, which pulls `Self` straight out of the
   source columns via typed `swap_remove`, and changed
   `remove_bundle`'s migration loop to `continue` past any column
   that's one of `ids` (handled by `take_direct` instead) rather than
   boxing it into a `removed: HashMap<ComponentId, Box<dyn Any>>` the
   way it used to. That `HashMap` — and the `Bundle::take_from` method
   that only ever existed to drain it — are both gone entirely, not
   just avoided in a special case. Only the genuinely-unknown-at-
   compile-time *other* columns still go through `Column::
   swap_remove_and_forget`/`push_any`'s type-erased path, since that
   one's unavoidable (which components those are is a runtime fact).

3. **Net result, measured, not estimated:** `remove_bundle_two_
   components` 4.00 → 3.00 → **0.002** allocs/op. `insert_bundle_on_
   existing_entity` 1.00 → **0.005**. `spawn_n_entities_two_components`
   1.00 → **0.011**. All three are now allocation-free in practice —
   the small residual counts are one-time archetype/edge-cache setup
   cost on the first few calls, not per-op cost (they don't scale with
   N). `Marker` itself was never contributing to any of the box-related
   counts regardless of this fix — it's a zero-sized type, and boxing a
   ZST is a well-known no-op for Rust's allocator (never reaches
   `GlobalAlloc::alloc` at all), which is *why* the original wrong
   "Marker is sparse" assumption didn't get caught by the numbers
   sooner: the allocation counts were real and correct throughout, only
   the narrative explaining *why* needed correcting.

**190/190 tests pass**, including a new one this pass added
specifically because none of the existing `remove_bundle` tests
actually reached the surviving-column path (every one of them removed
an entity's entire archetype-tracked signature) —
`remove_bundle_migrates_a_surviving_component_to_the_new_archetype`
uses a third component (`Health`) that must migrate intact, exercising
exactly the branch the rest of the suite never touched.

**What this means for `scratch.rs`, stated plainly:** its original
motivation — `remove_bundle_two_components`'s boxing cost — is gone,
not reduced. `B`'s own elements never box at all now, on any bundle
shape. The only `Box<dyn Any>` still in play is for *surviving*,
non-`B` columns during a structural change, which is real but
narrower than what `scratch.rs` was built against, and hasn't itself
been measured as a real cost anywhere yet (every survivor in the
actual benchmarks measured this pass happens to be a free-to-box ZST).
`scratch.rs` stays as real, tested, standalone infrastructure — not
wired in, still correct, still the right tool if a future profiling
pass finds a real non-ZST survivor path worth it — but wiring it into
`Column` itself turned out to run into a real architectural tension
this pass surfaced for the first time: `Column` is `Box<dyn Column>`
(a trait object, long-lived, shared across many unrelated operations),
while any arena is inherently transient (one per structural change) —
threading a transient arena's lifetime through a long-lived trait
object's own signature doesn't have a clean answer on stable Rust, and
isn't one this pass forced through on a guess.

### `Iter1UncheckedAlways`/`Iter2UncheckedAlways`: the one combination never tested

Prompted by a direct, real comparative source read of `Mid-D-Man/bevy`
(`crates/bevy_ecs/src/query/iter.rs` and `fetch.rs`) after the Iter1
Isolated investigation closed — worth doing since this crate's own
documented policy already authorizes it: "the first `unsafe` in
`mid-ecs`'s own query iteration path — agreed as a deliberate, scoped
exception for this crate specifically" (this doc, `Iter1Unchecked`'s
own entry above), and bevy's real numbers have been consistently ahead
across every build this investigation has produced.

**What the source comparison actually found, checked line by line, not
assumed:** bevy's single-component fetch is three layers, every one
`#[inline(always)]`, every one using `get_unchecked` — `QueryIter::next`
(`iter.rs:1050`) calls `QueryIterationCursor::next` (`iter.rs:3143`,
`get_unchecked` on the entity index) which calls `<&T as
QueryData>::fetch` (`fetch.rs:1898`, `get_unchecked` on the table row).
None of it depends on LTO deciding anything — the compiler is told,
at every hop, regardless of codegen-units or whether LTO is even on.
That's the real reason bevy's own numbers stay consistent under
`codegen-units=16, no LTO` (its actual, already-confirmed real
`Cargo.toml`) — it was never leaning on LTO's cooperation.

**Neither existing mid-ecs diagnostic tested that full combination.**
`diag_inline.rs`'s attribute-only three-way test (real CI, rustc
1.98.0) found pinning `next()`'s own inline attribute does nothing —
but that's the *safe*, bounds-checked version, attribute alone.
`Iter1Unchecked`/`Iter2Unchecked` (this doc, above) are unsafe
(`get_unchecked`) but carry no inline attribute at all, and collapsed
under the same LTO/compilation-unit-size pressure as everything else
once `archetype_core.rs` grew past whatever point trips it (builds
#15 onward, this doc's "the collapse" section). Both real, both
already spent — neither is what bevy actually does. `get_unchecked`
*and* `#[inline(always)]`, stacked on the same function, is the one
cell in this matrix that's never actually been filled in.

**`Iter1UncheckedAlways`/`Iter2UncheckedAlways`** (`diag_query2_
unchecked.rs`): `Iter1Unchecked`/`Iter2Unchecked`'s exact bodies,
`#[inline(always)]` added to `next()` — nothing else changed, so a
positive result isolates this specific combination rather than mixing
in some other variable. Same soundness argument as the existing
unchecked variants (`len` already proven ≤ every slice's length on
each archetype advance, `get_unchecked` just stops re-deriving what the
safe version's own bounds check already guaranteed). Correctness
tested the same way every other diagnostic in this file has been —
cross-checked against the real, safe `query_static`/`query2_static`,
not trusted because it compiles: 4 new tests, 194/194 `mid-ecs` tests
total, sandbox rustc 1.91.1. Wired into `archetype_core.rs`'s existing
`query2_static_diag_unchecked` bench group as `query_static_unchecked_
always_1col`/`query2_static_unchecked_always_2col`, exposed via
`World::query_static_diag_unchecked_always`/`query2_static_diag_
unchecked_always`, same `#[doc(hidden)] pub` convention as every other
entry in this group.

**Not yet run on real CI — that's the actual next step, same asymmetry
as always.** If this closes the gap where the attribute-alone and
unsafe-alone variants didn't, it's real, actionable evidence that
`Iter1`/`Iter2`'s production `next()` should move to this same
combination for real, not a diagnostic-only conclusion — the crate's
own unsafe policy already clears that path if the numbers say so. If
it *doesn't* close the gap, that's real evidence too: it would mean
bevy's consistency isn't fully explained by this specific mechanism
either, and the honest next move is the same one this investigation
already reached once before — name what's confirmed, stop guessing at
what isn't, and decide deliberately whether continuing is worth it
rather than drifting into a ninth variant by default.

### `Iter2RefUncheckedAlways`: unsafe + forced inlining, in true isolation this time

Follows directly from `benches/query2-ref-isolated`'s own real result
(Query2-Ref Isolated builds #1/#2): `query2_static_ref` — the
apples-to-apples, entity-free, 16-byte-item shape against `bevy_ecs`'s
own `Query<(&A, &B)>` — still sits at ~4x the raw-slice floor in *true
isolation*, both `bench` and `bench-nolto`. That's a stronger result
than anything `archetype_core.rs` itself could produce: it rules out
the ABI-register-threshold theory (16 bytes was supposed to be the
side that inlines cleanly; it isn't) and the compilation-unit-size
theory at the same time (isolation is exactly what fixed `Iter1`, and
it didn't fix this).

One combination was still untested: `get_unchecked` +
`#[inline(always)]` together, the same pairing `Iter2UncheckedAlways`
already tried and found negative — but only ever inside
`archetype_core.rs`, never in true isolation. `Iter2RefUncheckedAlways`
(`archetype/iter.rs`) is `Iter2Ref`'s exact body with both added,
wired into `benches/query2-ref-isolated` as a second bench function
(`query2_static_ref_two_components — unchecked_always`) alongside the
real one, same bench binary, same isolation. 5 new correctness tests
added for `query_static_ref`/`query2_static_ref`/this variant — none
of the three had any coverage before this pass, cross-checked against
the real, safe `query2_static_ref` output the same way every unsafe
diagnostic in this crate's history has been. 185/185 tests
(`scratch-arena`), nothing broken.

**Real CI result (Query2-Ref Isolated builds #3 and #4, rustc 1.98.1,
commit `33003bc`): clean negative.** `unchecked_always` is
indistinguishable from the real `query2_static_ref` in both profiles.
`bench` (LTO), N=100,000: 423.40µs (real) vs 423.27µs
(`unchecked_always`) vs 105.99µs raw-slice floor, 3.99x. `bench-nolto`,
N=100,000: 328.67µs vs 328.04µs vs 82.09µs, 4.00x. The ratio is flat at
~4.0x from N=10,000 up (~4.2x at N=1,000, ~7x at N=100 where fixed
per-call cost is still a visible share). Absolute numbers drifted ~13%
between the two builds' baselines on mid-ecs *and* the floor together,
which is runner variance, not a code effect; only within-run ratios are
usable.

That closes the attribute / unsafe / isolation family: each variant
(attribute alone, unsafe alone, both together) has now been tested both
inside `archetype_core.rs` and in true isolation, none reaches the
floor. **Decision: accept the two-column gap as documented and
currently unsolved, and move on to other engine work** (next entry,
`hash.rs`). Two axes were never touched and stay available if this
reopens: the emitted assembly of the isolated inner loop taken on CI's
toolchain (sandbox rustc 1.91 has never reproduced this regression, so
assembly from it is not evidence), and the structure of bevy's
tuple-composed fetch (only its inline/unsafe attributes have been
read, not its composition).

### `hash.rs`: fast hashers for the Archetype Core's hot-path maps

Built after the `Iter2` investigation was parked (see the result above),
aimed at the compute-shaped `ecs-vs-bevy-ecs` gaps that the allocation
pass could not explain: `get_component_random_access`,
`insert_bundle_on_existing_entity`, `spawn_n_entities_two_components`,
and the `remove_bundle_two_components` residual. Allocation counts for
the last three were already ~0 (see `diag_alloc_count.rs` above), so
what was left had to be instructions, not allocations.

**Finding, measured with callgrind (deterministic instruction counts,
see `diag_ir_ops.rs` below).** One `World::get_static` cost ~242
instructions. ~132 of those were `Archetypes::existing_component_id`:
a `std::collections::HashMap<TypeId, ComponentId>` lookup, ~100 of
them SipHash and ~32 the hashbrown probe. Structural changes pay the
same tax on every call: `component_ids` plus the per-archetype
`add_edges`/`remove_edges` maps (`HashMap<ComponentId, ArchetypeId>`),
~228 instructions of SipHash per `insert_bundle`/`remove_bundle`/spawn.

**What bevy does instead** (bevy_ecs 0.19.1 and bevy_utils 0.19.1
source, the versions `ecs-vs-bevy-ecs` actually depends on):
`Components::indices` is a `TypeIdMap<ComponentId>`, which is
`IndexMap<TypeId, V, NoOpHash>` — no hashing work at all, since
`TypeId` is already a fingerprint. Not the whole gap by itself; it is
the largest single piece of the per-lookup difference that could be
checked without a bevy build.

**Change.** New `crates/mid-ecs/src/hash.rs`, `pub(crate)`, zero
dependencies:

- `TypeIdHasher`: passes the value `TypeId`'s own `Hash` impl writes
  straight through (`write_u64`; `write_u128` xor-folds). Correctness
  never depends on which `write_*` method a toolchain's `TypeId` calls
  (equal keys always produce the same write sequence); the byte
  fallback only keeps quality acceptable if that impl changes shape.
- `DenseIdHasher`: Fibonacci multiplicative hash for small dense ids.
  Multiplying by an odd constant is a bijection on the low bits, so
  consecutive `ComponentId`s never share a bucket index (a test proves
  it for 1,024 ids), while the high bits hashbrown uses for control
  bytes come out well mixed.

`archetype.rs`: `Archetypes::component_ids` becomes `TypeIdMap`, and
`Archetype::add_edges`/`remove_edges` become `DenseIdMap`. Nothing else
changed. HashDoS resistance is irrelevant here: every key is
`TypeId::of::<T>()` or a locally-issued counter, never external input.

**Sandbox result (rustc 1.91.1, callgrind Ir per operation, N=10,000,
op-run minus setup-only run, profile: opt-level 3, lto off, 16 CGUs):**

| operation | before | after | change |
|---|---|---|---|
| `get_static` (random access) | 235.0 | 118.0 | -50% |
| `insert_bundle`, entity already has `Marker` | 1236.8 | 826.8 | -33% |
| `remove_bundle`, 2 components | 1336.7 | 939.7 | -30% |
| spawn + `insert_bundle` | 1338.4 | 928.4 | -31% |

Instruction counts, not timing, and not from CI's toolchain: fewer
instructions is necessary evidence, not sufficient. Real CI timing is
the authority.

**Not changed, deliberately.** The Sparse Shell's own
`SparseShell::component_ids` (`component.rs`) has the same
`HashMap<TypeId, ComponentId>` shape and would take the same fix, but
it is not on any path `ecs-vs-bevy-ecs` measures and has not been
measured itself. `signature_to_id` (`HashMap<Vec<ComponentId>, _>`) is
only hit on an edge-cache miss; the FFI maps are cold.

**Remaining cost centres after this change, and the two candidates
they suggest** (Ir per op, same method):

- Structural ops: `insert_bundle` 228 self, `edge_for_insert` 132,
  `push_into` 104, `Bundle::component_ids` 87. Bevy caches transitions
  per *bundle* (`Edges::insert_bundle: SparseArray<BundleId, _>`, and
  `Bundles::bundle_ids` is a `TypeIdMap`), one lookup per whole bundle.
  mid-ecs chains one `edge_for_insert` per component and creates
  intermediate archetypes on the way (see the doc comment on
  `Archetypes::iter` in `archetype.rs`, which hit exactly this). A whole-bundle edge cache is the
  obvious next candidate.
- `Archetypes::get`: 71 of `get_static`'s remaining 118. It looks the
  entity up twice (`World::is_alive`, then `locations.get`; the second
  is index-only, which is why the first is required) and makes two
  virtual calls per lookup (`Column::as_any`, then the `downcast_ref`'s
  `type_id`). Removing the downcast would need an `unsafe` cast whose
  invariant (the `ComponentId` was derived from the same `T`) holds by
  construction; that is a policy decision, not made here.

**Real CI result (`ecs-vs-bevy-ecs` build #25 and Archetype Core build
#32, rustc 1.98.1, commit `ce6ce32`).** Ratios are mid-ecs over
bevy_ecs in the same run. "Before" is the last figure on record (build
#20 for `remove_bundle`, the previous handover for the rest), not
re-measured in this run.

| group | before | build #25 |
|---|---|---|
| `insert_bundle_on_existing_entity` | ~1.6x | 0.99x (696.44µs vs 702.50µs) |
| `remove_bundle_two_components` | 1.48x | 0.97x (714.21µs vs 739.36µs) |
| `spawn_n_entities_two_components` | ~2x | 1.72x (892.10µs vs 519.27µs) |
| `get_component_random_access` | ~2.7x | **4.79x** (362.16µs vs 75.638µs) |
| `spawn_single_component` | n/a | 1.87x |
| `insert_single_component` | n/a | 1.45x |
| `structural_churn_insert_remove` | n/a | 1.49x |
| `remove_single_component` | n/a | 0.87x |

Controls did not move, as they should not: `query_static_single_component`
1.00x, `raw_slice_ceiling` 1.00x, `dense_query_iteration` 3.93x, and in
Archetype Core #32 `query_static` 94.3µs against the raw one-field floor
at 93.8µs (N=100,000) with the two-column ratio at 3.99x. No
compilation-unit shift showed up in them.

Two structural groups reached parity, and `spawn_n_entities_two_components`
moved from ~2x to 1.72x: the prediction held there, and the drop in
`remove_bundle`'s own time (1.0674ms in build #20, 714µs here) is close
to the sandbox's ~30% instruction reduction, with the usual caveat that
absolute time across builds carries runner drift.

**The miss: `get_component_random_access`.** Per lookup, mid-ecs took
36.2ns against bevy_ecs's 7.6ns in the same run. The sandbox predicted
the opposite direction: instructions per lookup 218 -> 113, and isolated
wall-clock `get_static` 17.3ns -> 7.1ns (rustc 1.91.1, `bench`-style fat
LTO with 1 CGU, 2.1GHz Xeon, 10,000 sequential lookups, best of several
runs). So CI's mid-ecs number is roughly 5x the sandbox's after-number
for the same source, while bevy_ecs measures 7.6ns on that same runner,
and, if the ~2.7x on record was right, it is slower than before the
change rather than faster. Not explained. Ruled out from source: the
`TypeIdHasher` byte fallback (rustc 1.98's `TypeId::hash` calls
`write_u64` on one half of the id, read directly from
`library/core/src/any.rs` at CI's compiler commit). The structural
groups go through the same `TypeId` map (`existing_component_ids`) and
improved, so the hasher itself is not the problem.

Diagnostic built for it (see `diag_ir_ops.rs` below):
`scripts/diag_ir_ops_ab.py`, driven by
`.github/workflows/diag-ir-ops.yml`. It builds the example twice on one
CI machine and toolchain, once from the current tree and once with
`archetype.rs`/`lib.rs` reverted to the last pre-fix commit, then
reports callgrind instructions per operation (deterministic, on
rustc 1.98.1) and isolated wall-clock ns per lookup for both. The
outcomes it separates: instructions high on 1.98.1 means codegen
differs from the sandbox and the callgrind function list shows where;
instructions ~113 with isolated time near the sandbox's means the
36ns comes from the full bench binary (compilation-unit effect, the
same shape as the `Iter1` story); instructions ~113 with isolated
time also slow means the machine, not the instruction count, is the
cost.

**A/B outcome (`diag Ir/op A/B` builds #1 and #2, rustc 1.98.1, commit
`d395f26`): the second one.** On CI's own toolchain the fix does what
the sandbox said. Build #1 is the `bench` profile (Intel Xeon Platinum
8370C @ 2.80GHz), build #2 is `bench-nolto` (AMD EPYC 7763):

| op | #1 prefix Ir | #1 current Ir | #1 ratio | #2 prefix Ir | #2 current Ir | #2 ratio |
|---|---|---|---|---|---|---|
| get | 213.0 | 109.0 | 0.51x | 218.0 | 116.0 | 0.53x |
| insert | 1129.7 | 665.7 | 0.59x | 1213.3 | 803.3 | 0.66x |
| remove | 1052.1 | 591.6 | 0.56x | 1313.7 | 903.7 | 0.69x |
| spawn | 1197.1 | 734.1 | 0.61x | 1316.3 | 906.3 | 0.69x |

Isolated `get_static` wall-clock, prefix -> current: 16.28ns -> 7.54ns
per lookup (162.8µs -> 75.4µs per 10,000) in `bench`, 16.41ns ->
8.79ns (164.1µs -> 87.8µs) in `bench-nolto`. The isolated "current"
figure, 75.4µs, is what bevy_ecs measured in the full bench (75.6µs,
build #25). So the code path is not the problem: the full
`vs_bevy_ecs` binary, or the way it was run, makes mid-ecs's identical
lookup take ~4.8x longer. Also of note, the isolated *prefix* time
(~163µs) is close to the ~204µs the full bench showed before the fix
(~2.7x on record), so the full-bench penalty was ~1.25x before and is
~4.8x after; whatever it is, it grew with this change or with
something else that changed alongside it (nothing else touched
`get_static`'s path, per the diff between `68500e6` and `ce6ce32`).

Heap-layout sensitivity was checked in the sandbox and is not it there:
`get_static` stayed at 7.0-7.3ns across allocation padding from 0 to
512KB and with heavy allocator churn before the world was built
(CI's CPUs were not checked).

Remaining candidates, none yet tested: criterion and the bench-file
structure; the other groups having run first in the same process;
bevy_ecs linked into the same fat-LTO unit; both worlds alive at once.
`get_bisect.rs` (below) adds them back one at a time.

**Outcome of the bisect, and the re-run.** `ecs-vs-bevy-ecs` re-dispatched
unchanged at `270cf72` (build #26) measured `get_component_random_access`
at 85.0µs against bevy_ecs's 73.0µs, 1.16x, where build #25 had 362.2µs
and 4.79x. So #25 was the runner, not the code. The bisect (`diag get_component_random_access bisect`
builds #1 and #2, same commit) says what varied:

| | #1 `bench`, AMD EPYC 9V74 | #2 `bench-nolto`, AMD EPYC 7763 |
|---|---|---|
| mid-ecs, bevy world not built yet | 255.9µs | 87.4µs |
| mid-ecs, both worlds alive | 264.7µs | 87.5µs |
| bevy_ecs, same binary | 50.5µs | 66.5µs |
| real bench filtered to this group, mid-ecs | 255.5µs | 85.8µs |
| real bench filtered to this group, bevy_ecs | 58.9µs | 73.4µs |
| callgrind Ir per lookup, mid-ecs / bevy_ecs | 109 / 88 | 116 / 94 |

Per 10,000 lookups. The bevy world's presence, criterion, and other
groups having run first all make no difference on either machine
(alone ~ alive ~ filtered bench). The CPU does: the same 109
instructions take ~255µs on the EPYC 9V74 and ~85µs on the EPYC 7763
(and ~75µs on the Xeon 8370C in `diag Ir/op A/B` build #1, ~84µs on the
7763 in build #3), while bevy_ecs runs *faster* on the 9V74 than on the
7763. So mid-ecs's `get_static` has a CPU-specific penalty of about 3x at
equal instruction count on that machine, and bevy_ecs's lookup does not.
Build #25's CPU was not recorded (the bench summary header carried no
CPU field), so that it ran on such a machine is consistent with the data
but unproven. The mechanism is unknown. One untested candidate: the two
virtual calls per lookup (`Column::as_any`, then the `downcast_ref`'s
`type_id`), which bevy_ecs does not make, interact badly with that
core's indirect-branch handling; removing them is already a candidate on
instruction count alone. Testing it needs the variant built and a
runner on the affected CPU, which CI does not let us choose (run
identical jobs in a matrix and read the CPU column).

Consequence for reading any bench in this repo: compare ratios within a
run, and note the CPU. `bench-vs-bevy-ecs.yml`'s summary header now
prints it. Other runners seen so far: Intel Xeon Platinum 8370C @
2.80GHz, AMD EPYC 7763, AMD EPYC 9V74.

**State after build #26** (ratios vs bevy_ecs; before = last figure on
record): `insert_bundle_on_existing_entity` ~1.6x -> 0.92x,
`remove_bundle_two_components` 1.48x -> 0.84x, `get_component_random_access`
~2.7x -> 1.16x, `spawn_n_entities_two_components` ~2x -> 1.24x,
`remove_single_component` 0.84x, `structural_churn_insert_remove` 1.29x,
`insert_single_component` 1.37x, `spawn_single_component` 1.71x,
`dense_query_iteration` 3.98x (parked, see the `Iter2` entries above).

### `diag_ir_ops.rs`

`examples/diag_ir_ops.rs`, kept for reference like `diag_alloc_count.rs`.
Counts *instructions* per operation under callgrind, for gaps that
allocation counts cannot see. Modes `get`, `insert`, `remove`, `spawn`
mirror `vs_bevy_ecs.rs`'s workloads (same N, shapes, call sequence);
second argument `0` runs setup only, `1` runs setup plus the measured
op, and the op's cost is the difference between the two runs' totals.
Usage is in the file's own header. Deterministic for a given binary,
so it can rank changes without a CI round trip; it does not replace
CI timing. Extra mode `time-get` prints isolated wall-clock ns per
`get_static` lookup (best of 7 repetitions of 300 passes over 10,000
entities), with nothing but `mid-ecs` in the binary.

`scripts/diag_ir_ops_ab.py` builds the example for the current tree
and for a tree with `archetype.rs`/`lib.rs` reverted to `--prefix-sha`
(restoring the working tree afterwards), then runs callgrind on the four
modes and `time-get` on both, on one machine, and prints a markdown
report with per-function self cost for `get` and `insert`.
`strip = false` is forced through
`CARGO_PROFILE_<NAME>_STRIP`, because the workspace's `bench` profile
inherits `release`'s `strip = true` and callgrind would otherwise
report raw addresses. `.github/workflows/diag-ir-ops.yml`
(`workflow_dispatch` only, like every workflow here) runs it on CI with
valgrind installed and uploads the callgrind outputs. Its numbers depend on the build profile: the table above
was taken with lto off and 16 CGUs, the workspace `[profile.release]`
(fat LTO, 1 CGU) gives different absolute counts, so only compare
runs taken with the same profile.

### `get_bisect.rs`

`benches/ecs-vs-bevy-ecs/examples/get_bisect.rs`, driven by
`scripts/diag_get_bisect.py` and
`.github/workflows/diag-get-bisect.yml`. Built because the A/B above
showed the fix works in isolation while the full bench still reports
mid-ecs's `get_component_random_access` at 36.2ns per lookup. The
isolated binary has nothing but mid-ecs in it; the real bench has
criterion, every other group, and bevy_ecs in one fat-LTO unit. This
binary contains mid-ecs AND bevy_ecs (both worlds built, same order and
shapes as `bench_get_component_random_access`) and no criterion.

The driver, on one machine and toolchain: (1) `get_bisect time`: mid
lookup ns with the bevy world not yet built, then with it alive, and
bevy's own lookup; (2) callgrind instructions per lookup for both
engines in that binary, with per-function self cost for mid-ecs (the
isolated binary gives 109); (3) the real `vs_bevy_ecs` bench filtered to
that one group, so no other group runs first in the process.

How to read it: example fast and filtered bench fast means earlier
groups' history (or build #25 was a transient run); example fast and
filtered bench slow means criterion or the bench file's structure;
example slow with the "alone" figure fast means the bevy world's
presence; example slow with "alone" slow and instructions above 109
means bevy in the LTO unit changed mid-ecs's codegen (the function list
says where); example slow with instructions near 109 means the machine,
not the instruction count. Locally the driver was tested end to end
against a stub package with a minimal stand-in for `bevy_ecs` (bevy 0.19
needs rustc 1.95+, the sandbox has 1.91): the mid-ecs half, callgrind
flow, timing and criterion parsing ran for real; the few lines of real
`bevy_ecs` API in the example (the import, `#[derive(Component)]`,
`World::new`, `spawn(..).id()`, `get`) mirror `vs_bevy_ecs.rs` and have
not been compiled outside CI.

### Single-component structural paths: `StorageClaims` hasher and boxing-free migration

After the bundle groups reached parity (`ecs-vs-bevy-ecs` build #26),
the single-component groups were the largest structural gaps
(`spawn_single_component` 1.71x, `insert_single_component` 1.37x,
`structural_churn_insert_remove` 1.29x, `remove_single_component` at
parity). Allocation counts (`diag_alloc_count.rs`, scenarios 4-7 added
for this) split them into two kinds: `spawn_single` and `insert_single`
were already ~0 allocs/op, so their gap was compute; `remove_single`
made 1.001 allocs/op and churn 2.001, so those were boxing.

**Cause 1, compute: `StorageClaims::claim`.** Every `insert_static`
(and the Sparse Shell `insert`) calls it. It was a
`std::collections::HashMap<TypeId, StorageKind>` (SipHash) doing a `get`
and then an unconditional `insert` (a second hash and a write) even
when the claim was already recorded: ~265 of `insert_static`'s ~692
instructions. `insert_bundle`/`remove_bundle` do not go through claims
(the limitation `StorageClaims`'s own doc comment already names), which
is why the bundle groups reached parity while the single-component ones
did not. Fix: `TypeIdMap<StorageKind>` (the `hash.rs` hasher) and only
insert when absent. Semantics are unchanged: the first system a type is
used with is recorded, same-system repeats are no-ops, the other system
panics.

**Cause 2, allocation: boxed migration.** Every component value moved
between archetypes went through `Column::swap_remove_and_forget`
(returning `Box<dyn Any>`) and `Column::push_any`: one heap allocation
per moved component per structural change. `remove_static` also boxed
the removed value just to downcast it straight back. Fix:
`Column::move_row_to(row, dest: &mut dyn Column)` swap-removes the value
and pushes it onto `dest` with both ends typed inside the one generic
impl (`dest.as_any_mut().downcast_mut::<Vec<T>>()`), still with no
`unsafe`. `Archetypes::remove` takes the removed value out with a typed
`swap_remove`. `swap_remove_and_forget` and `push_any` are deleted. All
four migration sites (`insert`, `remove`, `insert_bundle`,
`remove_bundle`'s survivors) use `move_row_to`. `scratch.rs` stays as
standalone infrastructure, but the cost it was built for is gone; its
doc comment now says so.

**Sandbox result (rustc 1.91.1, callgrind Ir per operation, `bench`
profile, N=10,000, before = `270cf72`):**

| operation | before | claim fix only | both | change |
|---|---|---|---|---|
| `spawn_single` (spawn + `insert_static`) | 853.3 | 589.4 | 586.4 | -31% |
| `insert_single` (`insert_static`) | 692.4 | 428.4 | 425.9 | -38% |
| `remove_single` (`remove_static`) | 499.0 | 499.0 | 344.5 | -31% |
| `churn_single` (insert + remove `Marker`) | 1499.6 | 1246.6 | 916.6 | -39% |
| `get_static` | 113.0 | 113.0 | 113.0 | 0 (control) |
| `insert_bundle` | 711.2 | n/a | 692.7 | -3% |
| `remove_bundle` | 732.1 | n/a | 729.1 | 0% |
| spawn + `insert_bundle` | 789.2 | n/a | 784.2 | -1% |

Allocations per op (`diag_alloc_count.rs`): `remove_single_component`
1.001 -> 0.001, `structural_churn_insert_remove` 2.001 -> 0.001; the
others were already ~0 and stay there. The bundle groups barely move
because they never used claims and their survivor in the benchmark is a
zero-sized `Marker`; they and `get_static` are the controls.

Tests: 192 default, 197 with `scratch-arena` (six new). The new tests
use archetype-tracked (`insert_static`) survivors, which the older
`remove_bundle` migration test does not: it inserts its survivor
through the Sparse Shell's `insert`, so it never reached the archetype
migration loop. They cover value preservation across swap-removes,
`remove_static` returning the right value while survivors migrate, each
value dropped exactly once (moved, never dropped, by migration; dropped
once on despawn; handed back undropped by `remove_static`), and the
bundle insert/remove survivor paths. They were also run against the
pre-change code and pass there, so they check behaviour, not the new
implementation.

**What is left in `insert_single` (425.9 Ir):** `World::insert_static`
self ~232 (inlines `is_alive`, the claim lookup, `component_id`, and the
body of `Archetypes::insert`), `edge_for_insert` 65, the location
`SparseSet::insert` 43, `get_two_mut` 40. Two structural candidates, not
started: entity lookups happen twice (`World::is_alive`, then
`locations.get`), and `spawn` followed by `insert_static` writes the
entity's location twice and hops through the empty archetype, where
bevy's `spawn(bundle)` writes it once. A direct spawn-with-components
API would remove that hop for `spawn_single` and
`spawn_n_entities_two_components`; the bench file's own note that
`spawn` is not perfectly apples-to-apples is about exactly this.

**Not yet run on real CI.** To read against: `spawn_single_component`,
`insert_single_component`, `structural_churn_insert_remove` and
`remove_single_component` should fall; the bundle groups, `get` and the
query groups should not move (controls). Note the runner CPU in the
summary header (added in `bench-vs-bevy-ecs.yml`) before comparing to
build #26 (1.71x, 1.37x, 1.29x, 0.84x); ratios within one run are the
comparison.

`diag_ir_ops.rs` gained modes `spawn1`, `insert1`, `remove1`, `churn1`
for these four groups, and `scripts/diag_ir_ops_ab.py` measures them
and now reverts `world.rs` as well as `archetype.rs`/`lib.rs` for its
"prefix" build (needed because this change touches `world.rs`).

### Direct bundle spawn: `World::spawn_bundle`

Real CI (`ecs-vs-bevy-ecs` build #28, commit `55caf87`) confirmed the
`StorageClaims`/`move_row_to` fix: `spawn_single_component` reached
parity (1.71x -> 1.00x), `insert_single_component` and
`remove_single_component` now measure *faster* than bevy_ecs (0.79x,
0.57x), `structural_churn_insert_remove` too (0.82x). Controls held:
`get_component_random_access` 1.17x, matching build #26's 1.16x, not
the CPU-dependent ~4.8x outlier; bundle groups and queries flat. Full
numbers in the "State after build #26" entry above, now superseded by
build #28's.

One real gap was left: `spawn_n_entities_two_components` at 1.30x,
unmoved by that fix, because `insert_bundle` never goes through
`StorageClaims` (`StorageClaims`'s own doc comment already names this
as a known, deliberate limitation). The benchmark's own top doc
comment already named the actual cause: bevy's `World::spawn(bundle)`
places an entity directly into its final archetype in one call;
mid-ecs's closest equivalent was `World::spawn()` (into the empty
archetype) then `World::insert_bundle(e, bundle)` (one migration back
out) — every call pays for a stop nothing ever reads. Concretely: the
entity's row and location are written twice, `get_two_mut` fetches two
archetypes when only one is ever touched, and the (trivially empty,
but not free) column-migration loop runs once for no reason, since a
fresh entity's "from" archetype never has columns.

**Fix:** `Archetypes::spawn_bundle` walks the same `edge_for_insert`
chain `insert_bundle` does, but starting cold from `EMPTY_ARCHETYPE`
with no location or table row written until the real destination
archetype is known — one row push, one `push_into`, one location
insert. `World::spawn_bundle<B: Bundle>(&mut self, bundle: B) -> Entity`
is the public entry point, the direct counterpart to bevy's
`spawn(bundle)`. Infallible, unlike `insert_bundle`: a brand-new entity
can never already hold one of `B`'s components, so there's no failure
case. Bypasses `StorageClaims` — same as `insert_bundle`, an existing,
already-documented decision, not something this pass changed.

**Sandbox result** (rustc 1.91.1, callgrind Ir per op, `bench` profile,
N=10,000, two-component bundle): the two-call path (`World::spawn` +
`insert_bundle`) costs 833.2 Ir/op; `spawn_bundle` costs 614.6, a 26%
drop. Self cost that disappears entirely: `World::insert_bundle`'s own
162 Ir, `get_two_mut` 40, and roughly half of the location `SparseSet`
insert (113 -> 69, one insert instead of two). `diag_ir_ops.rs` gained
mode `spawnbundle` for this measurement, compared against the existing
`spawn` mode (same two-component bundle, old two-call path).

**New bench group, not a replacement for the old one.**
`spawn_n_entities_two_components` (`World::spawn()` + `insert_bundle`)
is left exactly as-is — the benchmark's own doc comment already treats
that gap as real and worth measuring honestly, not something to hide
by quietly swapping in the faster call. `spawn_bundle_direct`
(`benches/ecs-vs-bevy-ecs/benches/vs_bevy_ecs.rs`) is the new, now-fair
comparison: mid-ecs's `World::spawn_bundle` against bevy's
`World::spawn(bundle)`, same shape as every other single-call
`bench_*` group added earlier. Registered in the same
`criterion_group!` list. The bench file's own top doc comment on
`spawn` is updated to point at this new group as the apples-to-apples
one instead of asserting there is no equivalent.

**Tests:** 198 default (six new — value/count/archetype-sharing checks,
a drop-once check via a `Drop`-tracking type, and one test that
`spawn_bundle` and `spawn()`+`insert_bundle()` for the same bundle type
land in one shared archetype, not two accidentally-distinct ones —
`edge_for_insert` is shared code between both paths, but this is the
only test that actually exercises them landing on the same archetype
together, via a real `query2_static` scan across both). 203 with
`scratch-arena`.

**Not yet run on real CI.** Expected: `spawn_bundle_direct` should be
close to or at parity with bevy_ecs (the earlier bundle-path fixes
already closed `insert_bundle_on_existing_entity` and
`remove_bundle_two_components` under the same `StorageClaims`-free,
`move_row_to`-based machinery, and this removes the one remaining
structural difference `spawn_bundle_direct` specifically measures).
`spawn_n_entities_two_components` is not expected to move — it still
exercises the two-call path on purpose. Note the runner CPU (once the
still-unapplied `bench-vs-bevy-ecs.yml` CPU-header edit lands) before
reading `get_component_random_access` on this run.

**What's left in `spawn_bundle` (Ir breakdown):** `edge_for_insert` 130,
`Bundle::push_into` 112, `__memcpy` (copying `Position`/`Velocity`
into their columns) ~100, `Bundle::component_ids` 93 (still a `TypeId`
lookup per component, per call — a per-`Bundle`-type cache, keyed once
rather than once per component, is the next structural candidate here,
mirroring bevy's own `bundle_ids: TypeIdMap<BundleId>` read from its
0.19.1 source earlier in this doc), location `SparseSet::insert` 69.
