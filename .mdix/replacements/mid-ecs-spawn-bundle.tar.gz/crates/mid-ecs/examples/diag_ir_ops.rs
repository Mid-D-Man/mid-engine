// ============================================================================
// NOTICE: Full documentation, design decisions, and fix history for this file
// live in docs/mid-ecs.md, section "diag_ir_ops.rs"
// ============================================================================
//! Diagnostic, kept for reference like `diag_alloc_count.rs`: a
//! sandbox-valid way to count *instructions* per operation, for the
//! compute-shaped `ecs-vs-bevy-ecs` gaps that allocation counts can't
//! see (`get_component_random_access`, `insert_bundle_on_existing_entity`,
//! `spawn_n_entities_two_components`, `remove_bundle_two_components`).
//!
//! Instruction counts under callgrind are deterministic for a given
//! binary, unlike timing, so they can rank "which change removed work"
//! without a CI round trip. They are NOT a substitute for real CI
//! timing: fewer instructions is necessary evidence, not sufficient.
//!
//! Usage (the op's cost is the difference between the two runs):
//!
//! ```text
//! cargo build --release --example diag_ir_ops
//! valgrind --tool=callgrind --callgrind-out-file=a.out \
//!     target/release/examples/diag_ir_ops insert 0
//! valgrind --tool=callgrind --callgrind-out-file=b.out \
//!     target/release/examples/diag_ir_ops insert 1
//! # Ir/op = (total(b) - total(a)) / ops, ops = 10_000 (get: 200_000)
//! ```
//!
//! Modes: `get`, `insert`, `remove`, `spawn` (two-component bundles), and
//! `spawn1`, `insert1`, `remove1`, `churn1` (the single-component
//! `insert_static`/`remove_static` groups: `spawn_single_component`,
//! `insert_single_component`, `remove_single_component`,
//! `structural_churn_insert_remove`). Second argument `0` runs
//! setup only, `1` runs setup plus the measured operation. Workloads
//! mirror `vs_bevy_ecs.rs` (same N, component shapes and call
//! sequence).
//!
//! Extra mode `time-get` (no second argument): wall-clock
//! `get_static` cost, best of 7 repetitions of 300 passes over the
//! same 10,000 entities, printed as ns per lookup. Isolated: nothing
//! but `mid-ecs` in the binary, unlike `vs_bevy_ecs.rs`. Added to
//! separate "instructions changed" from "CI timing changed" for
//! `get_component_random_access` (see `docs/mid-ecs.md`, `hash.rs`
//! section); driven by `scripts/diag_ir_ops_ab.py` /
//! `.github/workflows/diag-ir-ops.yml`.

use std::hint::black_box;
use std::time::Instant;

use mid_ecs::world::{Entity, World};

#[allow(dead_code)] // only `x` is read; the rest mirror the bench shape
#[derive(Clone, Copy)]
struct Position {
    x: f32,
    y: f32,
    z: f32,
}

#[allow(dead_code)]
#[derive(Clone, Copy)]
struct Velocity {
    dx: f32,
    dy: f32,
    dz: f32,
}

struct Marker;

const N: usize = 10_000;
const GET_ROUNDS: usize = 20;

fn bundle() -> (Position, Velocity) {
    (
        Position { x: 1.0, y: 2.0, z: 3.0 },
        Velocity { dx: 0.1, dy: 0.2, dz: 0.3 },
    )
}

#[inline(never)]
fn op_get(world: &World, entities: &[Entity]) -> f32 {
    let mut sum = 0.0;
    for &e in entities {
        if let Some(p) = world.get_static::<Position>(e) {
            sum += p.x;
        }
    }
    sum
}

#[inline(never)]
fn op_insert(world: &mut World, entities: &[Entity]) {
    for &e in entities {
        world.insert_bundle(e, bundle());
    }
}

#[inline(never)]
fn op_remove(world: &mut World, entities: &[Entity]) {
    for &e in entities {
        world.remove_bundle::<(Position, Velocity)>(e);
    }
}

#[inline(never)]
fn op_spawn1(world: &mut World) {
    for _ in 0..N {
        let e = world.spawn();
        world.insert_static(e, Position { x: 1.0, y: 2.0, z: 3.0 });
    }
}

#[inline(never)]
fn op_insert1(world: &mut World, entities: &[Entity]) {
    for &e in entities {
        world.insert_static(e, Position { x: 1.0, y: 2.0, z: 3.0 });
    }
}

#[inline(never)]
fn op_remove1(world: &mut World, entities: &[Entity]) {
    for &e in entities {
        world.remove_static::<Position>(e);
    }
}

#[inline(never)]
fn op_churn1(world: &mut World, entities: &[Entity]) {
    for &e in entities {
        world.insert_static(e, Marker);
        world.remove_static::<Marker>(e);
    }
}

#[inline(never)]
fn op_spawn(world: &mut World) {
    for _ in 0..N {
        let e = world.spawn();
        world.insert_bundle(e, bundle());
    }
}

#[inline(never)]
fn op_spawn_bundle_direct(world: &mut World) {
    for _ in 0..N {
        world.spawn_bundle(bundle());
    }
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    let Some(mode) = args.get(1) else {
        eprintln!("usage: diag_ir_ops <get|insert|remove|spawn|spawn1|insert1|remove1|churn1|spawnbundle> <0|1> | time-get");
        std::process::exit(2);
    };
    let run_op = args.get(2).is_some_and(|r| r == "1");
    let mut world = World::new();
    match mode.as_str() {
        "get" => {
            let entities: Vec<_> = (0..N)
                .map(|_| {
                    let e = world.spawn();
                    world.insert_bundle(e, bundle());
                    e
                })
                .collect();
            if run_op {
                for _ in 0..GET_ROUNDS {
                    black_box(op_get(&world, &entities));
                }
            }
        }
        "insert" => {
            let entities: Vec<_> = (0..N)
                .map(|_| {
                    let e = world.spawn();
                    world.insert_static(e, Marker);
                    e
                })
                .collect();
            if run_op {
                op_insert(&mut world, &entities);
            }
        }
        "remove" => {
            let entities: Vec<_> = (0..N)
                .map(|_| {
                    let e = world.spawn();
                    world.insert_static(e, Marker);
                    world.insert_bundle(e, bundle());
                    e
                })
                .collect();
            if run_op {
                op_remove(&mut world, &entities);
            }
        }
        "spawn" => {
            if run_op {
                op_spawn(&mut world);
            }
        }
        "spawnbundle" => {
            if run_op {
                op_spawn_bundle_direct(&mut world);
            }
        }
        "spawn1" => {
            if run_op {
                op_spawn1(&mut world);
            }
        }
        "insert1" => {
            let entities: Vec<_> = (0..N).map(|_| world.spawn()).collect();
            if run_op {
                op_insert1(&mut world, &entities);
            }
        }
        "remove1" | "churn1" => {
            let entities: Vec<_> = (0..N)
                .map(|_| {
                    let e = world.spawn();
                    world.insert_static(e, Position { x: 1.0, y: 2.0, z: 3.0 });
                    e
                })
                .collect();
            if run_op {
                if mode == "remove1" {
                    op_remove1(&mut world, &entities);
                } else {
                    op_churn1(&mut world, &entities);
                }
            }
        }
        "time-get" => {
            let entities: Vec<_> = (0..N)
                .map(|_| {
                    let e = world.spawn();
                    world.insert_bundle(e, bundle());
                    e
                })
                .collect();
            let mut best = f64::MAX;
            for _ in 0..7 {
                let start = Instant::now();
                for _ in 0..300 {
                    black_box(op_get(black_box(&world), black_box(&entities)));
                }
                let ns = start.elapsed().as_nanos() as f64 / (300.0 * N as f64);
                best = best.min(ns);
            }
            println!("time-get best_ns_per_lookup={best:.3}");
        }
        other => {
            eprintln!("unknown mode `{other}`");
            std::process::exit(2);
        }
    }
    black_box(&world);
}
