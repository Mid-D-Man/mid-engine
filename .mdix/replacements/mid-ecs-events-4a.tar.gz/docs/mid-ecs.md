# mid-ecs

Data-oriented ECS using Structure of Arrays (SoA) layout.

## Status

**Entity allocation and the Sparse Shell are both real now.** `World`
(`crates/mid-ecs/src/world.rs`) — `spawn`/`despawn`/`is_alive`,
generation-checked handles via `Entity`/
`mid_collections::GenerationalIndexAllocator`. `World::insert`/`get`/
`get_mut`/`remove`/`has` (`crates/mid-ecs/src/component.rs`'s
`SparseShell`) — any `T: 'static` attachable to any entity, no upfront
declaration, type-erased via a dense `ComponentId` (registered once per
type, `TypeId` only used at that registration step) rather than a
`TypeId`-keyed `HashMap` on the hot path — design grounded directly in
Bevy ECS's real `Components`/`ComponentId`/`Table` source, not invented
independently. 66/66 real tests passing across `mid-collections` +
`mid-ecs` (verified by temporarily stripping `rayon` and `criterion`
locally, same technique used every time these MSRV walls come up,
restored unchanged afterward).

`despawn` correctly removes every attached component *before* freeing
the entity's generational slot — load-bearing ordering, not incidental,
since `SparseSet` looks up purely by raw index and can't itself tell a
stale handle from a live one sharing a reused index. Every `World`
component method checks liveness first for the same reason. Both
properties have dedicated tests proving them directly
(`reused_slot_does_not_inherit_the_old_entitys_components`,
`stale_handle_cannot_read_the_live_entity_now_sharing_its_index`), not
just described in a comment.

One real self-caught inconsistency worth noting: `insert` initially had
a `debug_assert!` for the dead-entity case, on the reasoning that it's
"almost always a caller logic bug." The test written to prove the safe
fallback immediately panicked instead, in a debug/test build — which
was the actual bug: that `debug_assert!` directly contradicted this
codebase's own established convention everywhere else
(`SparseSet::remove`, `GenerationalIndexAllocator::deallocate`) of never
panicking on this class of misuse. Removed, not worked around.

`Archetype`, `Query`, `sync`, `ffi` are still stubs. The Archetype Core
(dense/table storage for stable, always-present components — the other
half of the Hybrid ECS Architecture below) doesn't exist yet; nothing in
`component.rs` is trying to be both.

**Query — real for one and two component types.**
`World::query<T>()` iterates every `(Entity, &T)` currently alive with a
`T` attached; `World::query2<A, B>()` intersects two — every
`(Entity, &A, &B)` for entities alive with *both*. 7 new tests (39/39 in
`mid-ecs` total, 73/73 across `mid-collections` + `mid-ecs`), all passing
on the actual first run — including the two that matter most:
`query_excludes_despawned_entities` and
`query2_excludes_a_despawned_entity_even_if_it_had_both`, proving
`despawn`'s component cleanup and `query`'s iteration agree with each
other, not just each independently claiming to be correct.

Deliberate v1 scope, not an oversight: `query2` always drives iteration
off its first type parameter and checks the second per-entity, rather
than picking whichever side is actually smaller — a real optimization
for a mismatched pair, but nothing in this workspace has a real query
shape yet that would justify the extra complexity over shipping the
correct, simpler version first. No `query3`+, and no generic tuple-based
`Query<T>` trait system (the shape real ECS crates converge on for
arbitrary arity) — both are natural follow-ons once real usage patterns
exist to design against, not before.

Organizational fix caught, not by review: `query`/`query2` were first
written directly on `World` in `world.rs`. Moved to `query.rs` shortly
after — the file that already existed specifically for this — where
they belonged from the start. Implementations unchanged, `World`'s
fields made `pub(crate)` so `query.rs` can reach them.

**Archetype Core — real, with full dynamic migration, not a simplified
static-at-spawn version.** `crates/mid-ecs/src/archetype.rs`:
`Archetypes` — dense SoA [`Table`]s (one contiguous `Vec<T>` per
component type, in lockstep by row), keyed by exact component-type-set
signature, with real migration when `World::insert_static`/
`remove_static` change an entity's set. `World::get_static`/
`get_static_mut`/`has_static` round out the API — named distinctly from
the Sparse Shell's `insert`/`get`/etc. since a component type has to
live in exactly one of the two systems, and there's no enforcement yet
beyond caller discipline (a `Component` trait fixing each type's
storage strategy once, matching where Bevy eventually landed, is a real
future refinement).

Grounded in Bevy ECS's real source, cloned and read directly (not
memory, not search-result excerpts) — `archetype.rs` (1002 lines),
`storage/table/{mod,column}.rs` (1428 lines). Confirmed, not assumed:
`Table` really is `{ columns: SparseSet<ComponentId, Column>, entities:
Vec<Entity> }`, the same shape `component.rs`'s `SparseShell` converged
on independently, now confirmed twice as the right structure for this
class of problem. `Edges`-style memoized add/remove transition caching
is real here too (`Archetype::add_edges`/`remove_edges`), same idea as
Bevy's, simpler storage (`HashMap` over a dedicated sparse-array type
this project doesn't have and didn't need to build for this alone).

Deliberate, stated divergence from Bevy, not an oversimplification:
Bevy's real row-migration is `unsafe`, raw-pointer, merge-join code with
change-detection ticks this project doesn't have yet. This module gets
the *same real capability* — genuine dynamic migration, any entity, any
component, at any time, no "components fixed at spawn" restriction —
through safe Rust instead: each migrated value is briefly boxed
(`Column::swap_remove_and_forget`/`push_any`) rather than raw-copied.
One heap allocation per moved component per structural change — not per
frame, not per query, only on the path this whole Sparse-Shell-vs-
Archetype-Core split exists specifically to keep rare. Zero `unsafe`,
matching `SparseSet`/`GenerationalIndexAllocator`'s own precedent
throughout this project.

Single-component structural changes only (not Bevy's general `Bundle`
trait for atomic multi-component changes) — deliberate, not a
limitation nobody noticed: a single-component add is always a strict
superset transition, a single-component remove always a strict subset,
which is exactly what lets every *other* column move unconditionally
with no merge-join needed to work out what's actually shared.

24 new tests (15 in `archetype.rs` + 9 `World`-level integration tests),
99/99 total across `mid-collections` + `mid-ecs`, all passing on the
actual first real run after two real, caught-by-clippy `Box::new(_)`
lint fixes and two doc-link fixes. The test that matters most:
`swap_remove_during_migration_fixes_up_the_swapped_entitys_row` —
proves that when a *middle* entity migrates out of a shared archetype,
the entity swapped into its old row stays correct not just for reading
afterward, but for *its own future migrations* too. Still wasm32-clean:
re-checked via `cargo tree --target wasm32-unknown-unknown` after —
`mid-ecs` still resolves to depending on only `mid-collections` for
that target, this module added no new dependencies.

## Target

100 000+ entities at 60 Hz physics on a single core.
Parallelised queries via rayon — on native. See Platform below.

## Platform

`mid-ecs` targets native *and* wasm32 (browser), same as the rest of the
workspace (`docs/architecture.md`'s core commitments). `rayon` — real
OS threads under the hood — doesn't work on `wasm32-unknown-unknown` the
way it needs to, so it's gated to non-wasm32 targets only in
`crates/mid-ecs/Cargo.toml`, under
`[target.'cfg(not(target_arch = "wasm32"))'.dependencies]` — the same
target-gating pattern already established in
`crates/mid-net/transport-wasm/Cargo.toml`.

Confirmed directly, not assumed: `cargo tree --target
wasm32-unknown-unknown -p mid-ecs` showed rayon's entire transitive tree
(`rayon-core`, `crossbeam-deque`/`epoch`/`utils`, `either`) resolving
into the wasm32 dependency graph *before* the gate existed, and cleanly
absent after — `mid-ecs` resolves to depending on only
`mid-collections` for that target. `.github/workflows/mid-ecs-test.yml`
now has a real "Check wasm32 build" step
(`cargo check --target wasm32-unknown-unknown`) proving the crate
actually compiles clean for that target on real CI, not just that its
dependency graph looks right — the sandbox this was developed in has no
wasm32 target installed at all, so dependency-graph resolution was as
far as local verification could go.

The matching `#[cfg(not(target_arch = "wasm32"))]` split at the *code*
level exists now, in `system_param.rs` (`pool_threads`, `run_batches`: rayon
off wasm32, the batches run one after another on the calling thread on
wasm32); see "Parallel iteration" below. FFI
work for `mid-ecs` is no longer saved for the end — see the FFI section
below for the real, incremental strategy and what's already built.

## FFI — built incrementally as we go, not saved for the end

The original plan deferred all FFI work until the ECS was otherwise
"done." Revisited: `mid-ecs`'s whole reason for existing separately from
being embedded directly in a monolithic engine is that its crates are
meant to be genuinely usable from *any* game engine or language, at
real performance — which means FFI correctness isn't a final coat of
paint, it's a core requirement that needs proving as each real piece
lands, the same way every other piece in this project has been proven
as it was built rather than asserted afterward.

**`World` lifecycle — real, tested, verified against actual compiled C.**
`crates/mid-ecs/src/ffi.rs`: `mid_ecs_world_new`/`free`/`spawn`/
`despawn`/`is_alive`/`entity_count`. Conventions copied directly from
`mid-net`'s real, already-proven `ffi.rs` — `MidEcsStatus` codes,
`ffi_guard`/`catch_unwind` on every function body, null-pointer checks
before every dereference, `unsafe extern "C" fn` + `# Safety` docs,
opaque heap handle for `World` (not `repr(C)` — nothing about it is
C-representable).

The one genuinely new piece: `Entity` can't cross the boundary as a
Rust value (its fields are deliberately private — only `World::spawn`
should ever produce one) and a two-field `repr(C)` struct would make
every caller's language agree on a layout for no real benefit. Instead,
`Entity::as_ffi`/`from_ffi` (thin wrappers over `mid_collections::
GenerationalIndex::as_ffi`/`from_ffi`, which do the real packing) hand
out one plain `u64` — directly grounded in `slotmap::KeyData::as_ffi`/
`from_ffi`'s real, shipped design (checked directly, not assumed),
including the property that matters most: reconstructing from a `u64`
that never actually came from a real `as_ffi()` call is still *safe* —
every `World` method re-validates the handle's generation against the
slot's current one regardless of where the value came from, so a bogus
handle just reads back as not alive. It can never alias a real, live
entity it wasn't issued for. Proven directly, not just documented:
`generational_index.rs`'s `from_ffi_on_a_bogus_value_is_safe_and_reads_as_not_alive`
and `ffi.rs`'s `bogus_packed_entity_is_safe_and_reads_as_not_alive`
both construct a genuinely bogus value and confirm exactly this.

**Verified the same way `mid-net`'s FFI was — real gcc, real C, real
memory, not just Rust-side `unsafe {}` blocks calling into themselves.**
`crates/mid-ecs/ffi-smoke-test/{mid_ecs.h, test.c}`: hand-written header
(matching `mid-net`'s own "hand-written, not cbindgen-generated, updated
by hand alongside `ffi.rs`" convention), 19 real checks. Compiled with
real gcc, linked against the real built `libmid_ecs.so` *and*
`libmid_ecs.a` separately, both run, both 19/19 — including the stale-
handle-after-slot-reuse case and the bogus-packed-`u64` case, proven
through actual C memory, not simulated. `.github/workflows/
mid-ecs-test.yml` now runs this on every CI trigger too, mirroring
`mid-net-test.yml`'s own FFI smoke test step exactly.

**Deliberately not covered yet in the `World`-lifecycle pass above, and
why it was genuinely harder, not just more of the same:** reading
component data (a `Position` column, say) from C. Every function in
that pass either passed a value by-value or went through an opaque
handle with no live pointer into mutable interior storage — nothing had
to reason about a pointer a *later* call could invalidate. Component
data lives in `Vec<T>`-backed columns (`SparseShell`'s `SparseSet`s,
`Archetypes`' `Table`s) that `insert`/`remove`/migration can reallocate
or move out from under a previously handed-out pointer. This is what
the "FFI span" idea (`docs/mid-collections.md`'s FFI wrapper section)
was actually for.

**Sparse Shell span access — real, tested, done for v1.**
`SparseShell::register_ffi<T>`/`raw_span`/`lookup_ffi_id`
(`crates/mid-ecs/src/component.rs`), thin-wrapped at `World::
register_ffi_component`/`component_raw_span`/`lookup_ffi_component_id`.
The real problem this had to solve, worked out rather than assumed:
producing a byte-erased `(ptr, stride, count)` view through a
`ComponentId` (an opaque `u32` at the FFI boundary) *without* the
caller knowing the concrete Rust type `T` — while `Box<dyn
ComponentColumn>`'s existing type-erasure mechanism only supports
downcasting when the caller already supplies `T` generically, which an
`extern "C"` function structurally can't do. Resolved with a type-erased
accessor function (`fn(&dyn Any) -> FfiSpan`), monomorphized once per
`T` at `register_ffi::<T>()` time (where `T` *is* known, generically)
and stored in a side table keyed by `ComponentId`, called later purely
non-generically — deliberately *not* baked into the base
`ComponentColumn` trait itself as a required method, since that would
force `IntoBytes + Immutable + KnownLayout` (from `zerocopy`) onto
every component type in the Sparse Shell, including plain Rust-only
types with no FFI intent (this crate's own `Position`/`Velocity` test
types, not `#[repr(C)]`, would have stopped compiling). Opting a type
in is explicit and per-type instead — real test coverage confirms both
halves: `register_ffi_before_any_insert_still_gives_a_valid_empty_span`
etc. exercise the opted-in path, while `Position`/`Velocity`'s own
existing tests keep passing completely untouched, proving the
restriction really is scoped to only what opts in.

A real bug caught by actually running the tests, not by review: the
first `raw_span` returned `None` for a type that was `register_ffi`'d
but had nothing inserted for it yet, since `columns` entries are only
created lazily on first `insert` — inconsistent with this same file's
own already-established convention (`SparseShell::iter<T>` already
treats "nothing inserted yet" as an *empty* result, not a *not-found*
one). Fixed to match the existing convention, not patched around it.

C-side `ComponentId` registration, scoped concretely: `register_ffi`
also records a plain string name, resolved later via `lookup_ffi_id`/
`lookup_ffi_component_id` — this is *not* C defining an entirely new,
Rust-unknown component layout (that would need a parallel byte-blob
storage mode this pass doesn't touch, a real, much larger undertaking
flagged rather than attempted); it's C obtaining the `ComponentId` for
a type Rust already opted in, by the name Rust gave it. `register_ffi`
itself is necessarily still a Rust-side, generic call — an `extern "C"`
function can't be generic over `T` — real, unavoidable one-time setup
glue, not an oversight.

**Archetype Core span access — real, tested, done for v1, and
genuinely harder than the Sparse Shell side above.** `Archetypes::
register_ffi<T>`/`raw_span`/`archetypes_with`/`lookup_ffi_id`
(`crates/mid-ecs/src/archetype.rs`), thin-wrapped at `World::
register_ffi_static_component`/`static_component_raw_span`/
`archetypes_with_static_component`/`lookup_ffi_static_component_id`.
Same type-erased-accessor mechanism as the Sparse Shell side (a
`fn(&dyn Any) -> FfiSpan`, monomorphized per `T` at registration time),
same reasoning for not baking it into the base `Column` trait — but one
real, unavoidable additional wrinkle: a component type here isn't one
stable thing to read. An entity's row lives in whichever archetype
currently matches its exact component set, so one type's data is
fragmented across every archetype containing it. `raw_span` is
necessarily per-`(ArchetypeId, ComponentId)`, not just per-`ComponentId`
the way the Sparse Shell's is; `archetypes_with` enumerates the
fragments.

A real, non-obvious distinction worked through and confirmed by
dedicated tests, not glossed over: unlike the Sparse Shell's own
"registered but nothing inserted yet" case (fixed to return an empty
span, not `None`, per the bug above), an archetype's signature simply
not including a given component is a *different*, *permanent* fact
about that specific archetype — `raw_span` correctly returns `None`
there (matching `Archetypes::has`'s own established `false`-not-panic
convention), while a real *empty-but-present* column (the component is
in the signature, every entity that had it has since migrated away)
correctly returns `Some` with `count == 0` — proven directly:
`raw_span_on_an_archetype_that_does_not_have_this_component_is_none`
and `raw_span_is_some_and_empty_after_every_entity_migrates_away` are
two separate tests because they're two genuinely separate cases, not
one case described two ways. Grounded in a real check of `ensure_column`
before trusting the "empty-but-present" case could even happen: columns
are only ever added to a table, never removed, once an archetype has
been created with a given signature — confirmed by reading that
function, not assumed.

A completely separate `ComponentId` name space from the Sparse Shell's
own `register_ffi`/`lookup_ffi_id`, matching `Archetypes`' own
already-established separate `ComponentId` numbering space from
`SparseShell`'s (see this doc's Sparse Shell section above) — the same
name string can resolve to a different `ComponentId` in each system,
proven directly by
`sparse_and_static_ffi_registrations_use_independent_name_spaces`.

**Not yet done, real next increment — flagged, not silently dropped:**

- **Entity correlation**, for *both* storage systems now. Neither
  `raw_span` can tell a caller *which* entity each element belongs to
  — `Entity` itself isn't `#[repr(C)]`/zerocopy-compatible today (its
  fields are deliberately private, see `Entity::as_ffi`/`from_ffi`
  above), so a zero-copy span over either system's dense entity array
  isn't possible without a real decision about how `Entity` should
  cross this specific boundary. This is now the single real blocker
  standing between "callable" and "actually usable" for the whole FFI-
  span mechanism.
- Actual `extern "C"` functions in `ffi.rs` exposing any of this, plus
  a real C smoke test and CI wiring, matching the rigor the `World`-
  lifecycle pass above already has. Nothing above has been proven
  against real compiled C yet — only real Rust-side tests so far, 147
  of them across `mid-collections` (49, `--features ffi`) + `mid-ecs`
  (98) combined as of this pass, none of them C.

## The Hybrid ECS Architecture: Static Core, Dynamic Shell

Mid Engine completely avoids the traditional Object-Oriented memory traps by splitting entity data into two highly optimized zones:

### 1. The Archetype Core (Heavy Logic)
* Components that remain static throughout an entity's lifecycle—like `Transform`, `Velocity`, or `PhysicsBody`—are packed into rigid Archetype tables.
* This guarantees perfect CPU cache locality.
* It allows our `mid-math` wide SIMD vectors to blast through positional updates without jumping around in memory, forming our high-performance "Inner Loops".

### 2. The Sparse Shell (Volatile Logic)
* Status effects or states that flicker on and off constantly—like `IsPoisoned`, `Disabled`, or `Hidden`—are managed using Sparse Sets or highly efficient Bitsets.
* The Sparse Shell is real now — `World::insert`/`get`/`get_mut`/`remove`/`has` (`crates/mid-ecs/src/component.rs`), any `T: 'static` attachable to any entity, backed by `mid_collections::SparseSet` per component type, keyed by a dense `ComponentId` rather than a `TypeId` hash (design grounded in Bevy ECS's own real `ComponentId` source — see `component.rs`'s doc comment). `despawn` correctly cleans up every attached component before freeing the entity's slot, closing the exact stale-handle gap `SparseSet` can't close on its own.
* **The "Stutter" Fix:** If you poison 1,000 goblins, the engine just flips a bitmask or adds a tiny entry in a sparse set. 
* Result: Zero memory is physically moved between archetype tables. The engine stays fast, and we avoid the memory-copying lag spikes that plague pure archetype architectures during massive state changes.
* For lightning-fast entity querying, the engine utilizes a `BitVec` layout (1 boolean into 1 bit), allowing us to filter hundreds of thousands of entities in microseconds using simple bitwise AND operations.

## Large World Coordinates: GlobalTransform

**Status: implemented.** `GlobalTransform` and `GlobalTransformLWC`
are real, tested types in `crates/mid-ecs/src/transform.rs` — both
usable with `World::insert_static`/`query_static` today. Not yet
built: `LocalTransform`/hierarchy composition, and `mid-camera`'s own
per-frame `to_view_relative` driver loop (see "Not yet decided" below
— unchanged, still real, still not started).

**The decision: two component types, `f32` default, `f64` opt-in —
not one type, and not `f64` everywhere.**

- `GlobalTransform` — `f32`, backed by `mid-math`'s existing `Affine3`.
  The default. Lives in the Archetype Core, same as any other static,
  every-frame-touched component (see "The Archetype Core" above).
- `GlobalTransformLWC` — `f64`, backed by `mid-math`'s `DAffine3`. Opt-in,
  for entities that actually travel far enough from world origin to
  need it (open-world terrain, distant structures, anything a camera
  might travel tens of kilometers to reach). A distinct archetype
  family from `GlobalTransform`, not the same component with a
  runtime-branching representation — a tagged union inside one
  Archetype Core column would break the homogeneous-`Vec<T>`-column
  assumption `component.rs`'s FFI-span mechanism (and every other
  system that reads a column) already depends on, and would cost
  exactly the cache/branch overhead this split exists to avoid.

**Why `f32` default, not `f64` default:** `DAffine3` is 96 bytes;
`Affine3` is 64 (16-byte aligned, SSE2-backed on x86/x86_64 — corrected
here from an earlier "48" figure in this doc that didn't match
`Affine3`'s own doc comment; checked directly against
`crates/mid-math/src/f32/affine3.rs` while implementing
`GlobalTransform`, not left as a quiet inconsistency). `f64` is still
1.5x the size, not 2x — the conclusion below is unchanged.
`GlobalTransform` is about the hottest, most-iterated
component this engine will ever have — read every frame for every
visible entity, exactly the access pattern the Archetype Core exists
to make cache-friendly. Most entities in most scenes (UI-anchored
objects, particle effects, interior/local gameplay) never travel far
enough from origin to need `f64` at all. Doubling the stride of the
hottest column engine-wide, to solve a problem only some entities
have, is in direct tension with this project's own performance
mandate — so the cost is opt-in, paid only by the entities that
actually need it.

**The pipeline this feeds into**, once built: `GlobalTransformLWC`
holds true world-space state in `f64`. Once per frame, for the
active camera, every visible `GlobalTransformLWC` gets passed through
`DAffine3::to_view_relative(camera_position)` (see `docs/mid-math.md`)
— composing the camera-relative shift and the `f64`→`f32` truncation
in one step, safe regardless of how far the entity is from world
origin, because only the shifted (small) translation gets truncated,
never the raw world-magnitude one. The result is a plain `f32`
`Affine3`, indistinguishable downstream from a `GlobalTransform`
entity's own data — rendering, culling, and anything else consuming
"the" transform for a draw call never needs to know or care which
storage precision an entity actually used. That narrow point (right
before GPU upload) is the only place the two component types'
consumers actually have to know both exist.

**Not yet decided:** how `LocalTransform`/hierarchy (parent-relative,
always small-magnitude, always `f32` regardless of world size)
composes into either `GlobalTransform` variant — that's the actual
"Integrating f64 global transform components into archetype storage
tables" implementation work, not yet started. `mid-camera` (planned,
not started — this engine's Cinemachine equivalent, sitting on top of
both this system and `mid-math`'s existing `camera/` module) is what
will eventually own "which entity is the active camera" and drive the
per-frame `to_view_relative` call above.

## The Ubel Stratum Bridge (The OOP Illusion)

**Design vision, not confirmed integration.** `docs/mid-collections.md`
is explicit about this: Ubel is *"a separate project... deliberately
not folded in here."* `mid-log.md`/`mid-net.md` both hedge the same
way (*"prepared for"*, *"a plausible future consumer"*). This section
previously read as settled architecture with no such hedge — a real
contradiction with those three docs, not just a tone mismatch, since
it described the bridge mechanism as if it already existed. Fixed to
match the same framing used everywhere else in this workspace: the
idea below is real and worth recording, but Ubel's actual integration
with `mid-ecs` specifically is not decided, designed in detail, or
started.

The vision, as discussed: gameplay code never touches Archetypes or
Bitsets directly.
* **HIGH Tier:** a gameplay programmer would interact with what reads
  like standard OOP classes (an `Actor`/`Entity` object).
* **LOW Tier:** if built, an Ubel compiler would lower that high-level
  code (`player.health -= 10`) into raw, memory-safe array accesses
  against `mid-ecs`'s own storage — Sparse Shell or Archetype Core,
  whichever the accessed component actually lives in.

Real open question this doc doesn't answer, and shouldn't pretend to:
whether that lowering targets this crate's own Rust API directly, or
goes through the FFI-span mechanism `component.rs`/`archetype.rs`
already expose — the latter would make Ubel just another FFI
consumer, no different in kind from any other non-Rust caller this
crate already supports, rather than a special-cased integration.

## Network Sync (Multiplayer-First)

The `sync` module marks components for `mid-net` replication.
This is the Multiplayer-First mandate in practice: networking is baked into the ECS from day one, not bolted on later.
* Components can be explicitly flagged for synchronization (e.g., `@net Transform`). 
* The engine automatically handles serialization via DixScript (`.mdix`) to sync state across the wire.
* Because data is stored contiguously in the Archetype Core, the network system can simply request a memory block and run a single SIMD pass over that memory to detect deltas, compress with MBFA-lite, encrypt, and ship the UDP packet.

## Modules

### `diag_query2_unchecked.rs`

Temporary diagnostic module, delete once the investigation it exists
for concludes (see its own NOTICE header). Real CI (rustc 1.98.0)
shows `query2_static_two_components` running 2.96x-4.57x slower than
`bevy_ecs` on an equivalent workload, in every run since the
Iter1/Iter2 rewrite. This sandbox's own rustc 1.91.1 has never
reproduced it — the same code measures within noise of `bevy_ecs`
here every time. An `#[inline(always)]`/`#[inline(never)]` three-way
diagnostic (`diag_inline.rs`) already ruled out inlining as the cause,
run for real on rustc 1.98.0.

Real source comparison against `Mid-D-Man/bevy` (`crates/bevy_ecs/src/
query/iter.rs` and `fetch.rs`, read directly) found a real structural
difference. Bevy's `QueryIterationCursor` is one generic struct,
parameterized over `D: QueryData`. A two-component query has no
hand-written "two-component" implementation at all — `D = (A, B)`,
`D::Fetch<'w> = (A::Fetch<'w>, B::Fetch<'w>)`, and `D::fetch` is
generated by a macro (`impl_tuple_query_data`, expanded once per arity
via `all_tuples!`) as `Some((A::fetch(...)?, B::fetch(...)?))` — the
same single-component fetch code, reused twice, composed through the
tuple impl. `&T`'s own `fetch` (`ReadFetch<T>`) reads through
`table.get_unchecked(table_row.index())`, `#[inline(always)]`, no
bounds check. mid-ecs's `Iter1` and `Iter2` (`archetype.rs`) are
instead two separately hand-written structs — meant to be the same
shape, but not literally the same code the compiler sees, and this
kind of divergence between two independently-authored near-duplicates
is exactly the sort of thing whose optimization treatment can differ
across a compiler version bump.

Four new variants, each isolating one candidate cause, matching what
was actually different between mid-ecs's approach and bevy's:

* `Iter1Unchecked`/`Iter2Unchecked` — the current `Iter1`/`Iter2`
  logic unchanged, except entity/column indexing goes through
  `get_unchecked` instead of safe indexing, directly matching bevy's
  own technique. Sound: `len` is already set to the min of every
  slice's length on each archetype advance, so `row < len` already
  proves every access in bounds — this was already true of the safe
  version's own reasoning (see `Iter2`'s doc comment in
  `archetype.rs`), `get_unchecked` just stops asking the compiler to
  re-derive it. This is the first `unsafe` in `mid-ecs`'s own query
  iteration path — agreed as a deliberate, scoped exception for this
  crate specifically, not a change to the workspace's general
  zero-unsafe default.
* `Iter2TwoTupleItem` — reads both `a_col` and `b_col` per item like
  the real `Iter2`, but combines them into one derived value before
  returning, so `Item` is a 2-tuple instead of a 3-tuple. Isolates the
  tuple/`Item`-shape question from the two-slice-fields question.
* `Iter2UnusedBCol` — same struct shape as the real `Iter2` (both
  `a_col` and `b_col` fields present, both kept current on every
  archetype advance), but the hot loop only ever reads `entities`/
  `a_col` — `b_col` is tracked for `len` only, never indexed per item.
  Isolates whether merely carrying the extra field matters,
  independent of whether it's read.

Each variant has a correctness test in `query.rs` cross-checking its
output against the real, safe `query_static`/`query2_static` — an
`unsafe` variant that's merely fast and wrong isn't useful data. All
pass, 176/176 total `mid-ecs` tests, sandbox rustc 1.91.1.

Not yet run on real CI. That's the actual next step — none of this
sandbox's numbers can confirm or rule out anything here, the same
asymmetry that opened this investigation in the first place. Exposed
via `World::query_static_diag_unchecked`/`query2_static_diag_unchecked`/
`query2_static_diag_two_tuple_item`/`query2_static_diag_unused_b_col`,
`#[doc(hidden)] pub` for the same reason as `diag_inline.rs`'s own
methods — `benches/archetype_core.rs` needs real public API to reach
them from outside the crate. Benching them is the next real
deliverable, not built yet.

Bench group `query2_static_diag_unchecked` added to
`archetype_core.rs`, covering all four variants. Real, same-sandbox-
session numbers, N=10,000, next to a same-session run of the real safe
`Iter1`/`Iter2` for direct comparison:

* Safe (current, real): `query_static` 7.291µs, `query2_static`
  10.265µs — ratio 1.41x (matches this sandbox's usual ~1.28-1.35x
  baseline within normal run-to-run variance).
* `Iter1Unchecked`: 7.222µs — indistinguishable from safe `Iter1`,
  consistent with `Iter1` already being at parity with `bevy_ecs`
  everywhere this has been measured.
* `Iter2Unchecked`: 29.044µs — **~2.83x slower than safe `Iter2`**,
  on this sandbox. `Iter2TwoTupleItem` (28.700µs) and `Iter2UnusedBCol`
  (28.706µs) land in the same place, all three roughly 4x the unchecked
  1-column number, at every N from 100 to 100,000 (ratio actually
  creeps up slightly with N: 3.51x at N=100 to 4.10x at N=100,000 — a
  per-item cost difference, not a one-time per-archetype-advance cost).

This is a real, surprising sandbox result, not a reason to abandon
these variants — `get_unchecked` should never make correct code
slower than the safe equivalent it replaces, on any toolchain that's
reasoning about it correctly, so this is itself informative. Worth
noting directly: 29.044µs is almost exactly the same number
`Iter2::next`'s own doc comment records for the earlier, reverted
`#[inline(always)]` attempt (~29µs) — on this same sandbox, two
completely different changes (forcing inlining, and switching to
`get_unchecked`) both land at close to the same, worse number. This
sandbox (rustc 1.91.1) has now shown *two* real cases where a change
that's well-motivated by bevy's own real source makes `Iter2`
specifically worse here — while the actual regression this whole
investigation exists to explain only shows up on rustc 1.98.0, never
here. That asymmetry cuts both ways: a sandbox result saying "worse"
carries exactly as little weight as one saying "better" would have.
Real CI is the only real answer here, same as every other toolchain-
sensitive question in this investigation so far.

Correctness is independent of this and already solid: all four
variants pass their dedicated tests in `query.rs`, cross-checked
against the real, safe `query_static`/`query2_static` output, 176/176
`mid-ecs` tests total.

### Real CI results (Archetype Core build #7, rustc 1.98.1)

These four variants ran on real CI for the first time. The result
overturns the sandbox reading above, which is exactly why the sandbox
numbers were never trusted on their own.

At N=10,000: safe `query2_static` 37.446µs against safe `query_static`
9.4228µs, ratio 3.97x, matching every prior real CI run of this
comparison. `Iter2Unchecked` (`query2_static_unchecked_2col`) measured
37.758µs and `Iter2UnusedBCol` (`unused_b_col`) measured 37.734µs,
both indistinguishable from the safe baseline. `get_unchecked` alone
does nothing on real CI either, same conclusion the sandbox reached,
for once matching it.

`Iter2TwoTupleItem` (`two_tuple_item`) measured 9.4864µs, matching
`query_static`'s single-column number almost exactly, at every N from
100 to 100,000. This is the opposite of what the sandbox showed
(28.700µs there, indistinguishable from the other two variants). One
variant returning a single owned value instead of two references
closes nearly the entire gap on the toolchain where the gap is real,
despite doing more work per item: its `combine` function reads all six
fields across both components (`Position`'s three plus `Velocity`'s
three) and constructs a new `Position` by value, against the baseline
loop's two field reads (`pos.x`, `vel.dx`). More arithmetic, less time.

This rules a specific thing in, not just several things out. Returning
`(Entity, &A, &B)` is not inherently slow. `Mid-D-Man/bevy`'s own
`D::Item` for a two-component query is exactly this shape (`(A::Item,
B::Item)` off the tuple macro, `(&Position, &Velocity)` for a plain
read query), and bevy pays no penalty for it (`ecs-vs-bevy-ecs` build
#10, same day: `query_static_single_component` 1.0x, `raw_slice_ceiling`
1.0x). Also checked and ruled out this pass: `mid-ecs`'s real `Iter2`
(`archetype.rs`) downcasts its `Box<dyn Any>` columns to `&[A]`/`&[B]`
once per archetype advance, same as every diagnostic variant, never
per item, so the downcast itself isn't a per-item cost candidate.

What's actually different, still untested until this pass: bevy's
tuple `QueryData::fetch` composes as `Some((A::fetch(...)?,
B::fetch(...)?))`, two independent single-component fetch calls glued
by `?`. `Iter2`, `Iter2Unchecked`, `Iter2TwoTupleItem`, and
`Iter2UnusedBCol` all instead read both columns inline in one
hand-written tuple literal. Whether returning two references together
is the cost, or whether it only becomes the cost when they're
constructed by one block instead of composed from two calls, hasn't
been separated yet.

### `Iter2Composed` (built this pass, not yet run on real CI)

Isolates exactly that. Same struct fields, same archetype-advance and
per-archetype downcast logic as `Iter2Unchecked`, same `Item =
(Entity, &A, &B)`. The only real change: two small functions,
`fetch_one::<A>`/`fetch_one::<B>`, each doing one
`get_unchecked`-and-wrap-in-`Some`, called from `next()` as `Some((...,
fetch_one(a_col, row)?, fetch_one(b_col, row)?))` instead of building
the tuple directly from `&self.a_col[row]`/`&self.b_col[row]` inline.
Mirrors bevy's own composition shape as closely as a hand-written
non-generic version reasonably can.

Two dedicated tests in `query.rs`
(`diag_query2_static_composed_matches_the_real_query2_static`,
`diag_query2_static_composed_empty_when_one_side_was_never_registered`),
cross-checked against real `query2_static` the same way every other
variant's tests are. 178/178 `mid-ecs` tests total now. Exposed via
`World::query2_static_diag_composed`, same `#[doc(hidden)] pub`
pattern as the other four. Bench arm `composed` added to the
`query2_static_diag_unchecked` group in `archetype_core.rs`.

Not run on real CI yet. Given `Iter2TwoTupleItem`'s result, the most
useful outcome to watch for is whether `Iter2Composed` also closes
most of the gap despite still returning two references, which would
point at the inline-tuple-literal construction itself as the real
cost rather than the reference-pair return value; or whether it stays
near the current 4x, which would point back at something specific to
carrying two live references out of `next()` together, and make
`Iter2TwoTupleItem`'s result closer to a lucky side effect of also
narrowing the return type rather than a real fix for a query API that
actually needs to hand back both components separately.

### Real CI result for `Iter2Composed` (Archetype Core build #8, rustc 1.98.1)

Second answer, not the first. `Iter2Composed`'s own bench arm measured
42.350µs at N=10,000, indistinguishable from the safe baseline
(42.505µs), `Iter2Unchecked` (42.271µs), and `Iter2UnusedBCol`
(42.335µs). Composing the fetch as two separate calls glued by `?`,
matching bevy's own macro shape exactly, changed nothing. That rules
out "how the fetch is composed" as the cost.

What actually separates the fast variant from the three slow ones,
looking at all four together:

| Variant | Struct holds both a_col and b_col? | Item | Real CI (N=10,000) |
|---|---|---|---|
| `Iter1Unchecked` | No, one column only | `&T` | 10.6µs, fast |
| `Iter2UnusedBCol` | Yes, b_col never read | `&A` | 42.3µs, slow |
| `Iter2TwoTupleItem` | Yes, b_col read via `combine` | `A` (owned) | 10.7µs, fast |
| `Iter2` / `Unchecked` / `Composed` | Yes | `(&A, &B)` | 42.3-42.5µs, slow |

`Iter2UnusedBCol` is the tell. Its `Item` is `(Entity, &A)`, the exact
same shape as the fast `Iter1Unchecked`, and it never reads `b_col` in
the hot loop. The only thing it does differently from `Iter1Unchecked`
is carry a second, unread, differently-typed slice field
(`b_col: &'a [B]`) that gets updated on every archetype advance. That
alone reproduces the full regression. Meanwhile `Iter2TwoTupleItem`
reads both columns every item and stays fast, because what crosses
back out of `next()` is owned, not a reference.

So it isn't "returning two references" (bevy does that and pays
nothing) and it isn't "how many columns get read" (`TwoTupleItem`
reads more than `UnusedBCol` and is faster). It's specifically: once
the iterator's own state holds two independently-typed live slice
references, returning any reference from `next()` pays a real cost
that returning an owned value does not, regardless of how much work
built that owned value or how the fetch that produced it was
structured.

### `Iter2RawPtr` (built this pass, not yet run on real CI)

Direct test of this. Same struct and archetype-advance logic as
`Iter2Unchecked`, but `a_col`/`b_col` are `*const A`/`*const B`
instead of `&'a [A]`/`&'a [B]`, with a `PhantomData<(&'a [A], &'a
[B])>` marker carrying the same lifetime obligation the slice fields
used to enforce directly. `next()` builds the returned item with
`&*self.a_col.add(row)`/`&*self.b_col.add(row)` instead of indexing a
stored slice. This is a hand-rolled version of the same idea as
`ThinSlicePtr`, not a dependency on it; `Mid-D-Man/bevy` is source-read
and porting reference only, never a direct dependency, so nothing here
imports `bevy_ptr`.

Two dedicated tests
(`diag_query2_static_raw_ptr_matches_the_real_query2_static`,
`diag_query2_static_raw_ptr_empty_when_one_side_was_never_registered`),
same cross-check pattern as every other variant. 180/180 `mid-ecs`
tests total now. Exposed via `World::query2_static_diag_raw_ptr`.
Bench arm `raw_ptr` added to the same group.

If this closes the gap on real CI, the natural next step is exactly
what was asked for: a small, focused, no-std-style crate mirroring
`ThinSlicePtr`'s actual shape (`NonNull<T>` plus debug-only length plus
a `PhantomData<&'a [T]>` marker, `get_unchecked` returning `&'a T`),
built as mid-engine's own, not a dependency on `bevy_ptr` itself, the
same relationship `Mid-D-Man/bevy` already has to everything else in
this project. Worth building once real CI says raw-pointer storage is
actually the fix and not one more thing that looks right for reasons
that don't hold up outside this sandbox, the same caution every other
diagnostic in this file has been given.

### Real CI result for `Iter2RawPtr` (Archetype Core build #9, rustc 1.98.1)

It didn't. 37.452µs at N=10,000, indistinguishable from every other
reference-returning variant (safe baseline 37.672µs, `Unchecked`
37.458µs, `UnusedBCol` 37.402µs, `Composed` 37.445µs). Storage
representation, slice vs raw pointer, changes nothing.

This makes sense in hindsight rather than being a dead end. `RawPtr`
and `Unchecked` both still return `Option<(Entity, &'a A, &'a B)>` from
`next()` — identical signatures. Converting a raw pointer back to
`&'a T` inside the function produces the exact same type crossing the
exact same boundary; whatever LLVM does with that signature doesn't
know or care whether the reference was built by indexing a slice or
adding to a pointer. The lever that was actually being pulled every
time (`Unchecked`'s safety, `Composed`'s call structure, `RawPtr`'s
storage) was never the one that mattered. The one variable that has
correlated with the result every single time is simpler: does `Item`
contain a reference, or not.

### `Iter2OwnedDirect` (built this pass, not yet run on real CI): isolating the one remaining confound

Before settling on "owned return is what matters," one thing needed
separating out. `Iter2TwoTupleItem`, the only fast variant found so
far, gets its owned value through `(self.combine)(a, b)` — a stored
`fn(&A, &B) -> A` pointer field, called indirectly. An indirect call
through a function pointer is its own kind of optimization barrier;
LLVM generally can't inline through one. Every slow variant
(`Unchecked`, `UnusedBCol`, `Composed`, `RawPtr`) calls nothing
indirectly. So "returns an owned value" and "goes through an opaque,
uninlinable call" have been riding together in the one data point that
worked, and it hadn't been checked which of the two actually explains
the speed.

`Iter2OwnedDirect` separates them: same owned-return shape as
`TwoTupleItem` (`Item = (Entity, A)`), same struct fields as
`Unchecked` (`a_col`/`b_col` as real `&'a [_]` slices, no pointer
games), but the combine step goes through `DiagCombine`, a small
trait with one method, called as `A::diag_combine(a, b)` rather than
through a stored function pointer. A trait method call like this is
fully known at compile time and monomorphized per concrete type, so
the compiler is free to inline it — there's no runtime indirection at
all, unlike a `fn` pointer field whose target isn't fixed until the
value is constructed.

`DiagCombine` is `pub`, not `pub(crate)` (re-exported hidden from
`lib.rs` as `mid_ecs::DiagCombine`, module itself stays private): the
bench is a separate crate linking against `mid-ecs` and needs to
implement it for its own `Position`/`Velocity` to call
`World::query2_static_diag_owned_direct` at all. Two dedicated tests
(`diag_query2_static_owned_direct_matches_manual_combine`,
`diag_query2_static_owned_direct_empty_when_one_side_was_never_registered`),
same cross-check discipline as every other variant. 182/182 `mid-ecs`
tests total now. Bench arm `owned_direct` added to the same group.

Two possible outcomes once this runs on real CI. Lands near 9.4µs,
matching `TwoTupleItem` and the 1-column baseline: confirms owned
return is genuinely what matters, independent of the function-pointer
question, and `TwoTupleItem`'s result wasn't a fluke of that
confound. Stays near 37µs, matching every reference-returning variant:
means the opaque call boundary itself was doing the real work in
`TwoTupleItem`, a stranger and more specific finding about this
toolchain's handling of that particular loop shape, not about owned
values at all — and would mean the `ThinSlice`/raw-pointer design
sketch proposed above is very unlikely to be the fix, whatever else it
might still be worth for other reasons.

### Real CI result for `Iter2OwnedDirect` (Archetype Core builds #10 and #11, rustc 1.98.1)

Second outcome. Build #10's absolute numbers were a false alarm (a
uniform ~31% drop across every group in that run, including
benchmarks nothing in this investigation touches — CI noise, caught
and re-run by the user rather than trusted). Build #11, same commit,
is back in the normal range and settles it: `owned_direct` measured
42.267µs at N=10,000, indistinguishable from every reference-returning
variant (safe baseline 42.793µs, `Unchecked` 42.276µs, `UnusedBCol`
42.250µs, `Composed` 42.260µs, `RawPtr` 42.279µs). `TwoTupleItem`
stayed fast at 10.712µs, matching the 1-column baseline (10.593µs).
Build #10's noisy absolute values still preserved this same relative
split (owned_direct 26.046µs next to a 26.0-26.1µs cluster, two_tuple_item
alone at 11.614µs), so it's two real CI runs agreeing on the ordering,
not one.

This rules out "owned return" outright. `Iter2OwnedDirect` returns
owned, same as `TwoTupleItem`, and it's exactly as slow as every
reference-returning variant. The one thing left standing, out of seven
variants tested, is that `TwoTupleItem` is the only one whose combine
step goes through a genuine indirect call (a stored `fn` pointer) that
the compiler can't inline through. Every other variant, whatever else
differs between them, fully inlines.

### Bevy's own benchmark convention (found this pass, checked directly against Mid-D-Man/bevy)

Went back to `Mid-D-Man/bevy` with a narrower question than before:
not what the fetch code does, but how bevy structures the benchmark
loop itself. Checked `benches/benches/bevy_ecs/iteration/` directly —
`iter_simple.rs`, `iter_frag.rs`, `iter_simple_foreach.rs`,
`iter_simple_contiguous.rs`, no exceptions found across the ones
checked. Every one wraps its loop in a `#[inline(never)] fn
run(&mut self)` on a small `Benchmark` struct, and `mod.rs` calls it as
`b.iter(move || bench.run())` — the criterion closure is a single call
to an opaque, never-inlined function that does the real work inside
itself. None of this project's benches do that anywhere; every loop,
in every variant above and in `benches/ecs-vs-bevy-ecs/benches/vs_bevy_ecs.rs`,
sits directly inside `b.iter(...)`, fully visible to the optimizer
alongside criterion's own harness code.

Checked whether this alone explains bevy's own speed before assuming
it explains mid-ecs's slowness: `vs_bevy_ecs.rs`'s `dense_query_iteration`
benches both engines the same way, loop inline in `b.iter()`, no
wrapper, for both sides. `bevy_ecs` still lands at parity there (its
own iteration doesn't need the wrapper to be fast). So this can't be
the whole explanation. But that doesn't rule out `mid-ecs`'s specific
`Iter2` needing it, independent of whatever bevy's implementation is
doing.

### Real, unmodified `query2_static`/`query_static`, wrapped to match bevy's convention (built this pass, not yet run on real CI)

Two new bench arms in the same group, `real_query1_inline_never_wrapper`
and `real_query2_inline_never_wrapper`. Neither touches archetype.rs
or adds a new Iter2 variant — both call the real, current, completely
unmodified `World::query_static`/`World::query2_static`, from inside a
`#[inline(never)] fn run(&mut self)` on a small wrapper struct, called
as `b.iter(|| black_box(bench.run()))`, matching bevy's own structure
exactly. Compiles clean, smoke-tested locally (`cargo bench -- --test`,
all arms report `Success` — sandbox numbers themselves stay
non-authoritative as always, this only confirms nothing panics).

This is the most direct test yet of what's actually been driving every
result in this file so far, and it uses zero diagnostic code: if
wrapping the real `query2_static` in a never-inlined function alone
closes most of the gap, a meaningful part of this entire investigation
has been chasing a benchmark-harness artifact rather than a real
runtime difference in `Iter2` itself — the fix would be to the bench,
not the iterator. If it stays near 37-43µs even wrapped, that rules
out harness structure too, and leaves indirect-call-specifically (not
owned return, not harness shape) as the one remaining explanation with
any real evidence behind it, which would need a real disassembly
comparison on rustc 1.98.1 to actually resolve.

### Real CI result for the `inline_never` wrapper test (Archetype Core builds #12 and #13, rustc 1.98.1)

Not a clean answer either way. The user ran this twice specifically to
check it wasn't a fluke, and both runs agree with each other, but not
in a way that confirms the wrapper hypothesis. What actually moved:

`query2_static_two_components` (real `Iter2`, no wrapper): 37.7µs
historical -> ~27.5-28.5µs both builds. `real_query2_inline_never_wrapper`
(same real `Iter2`, wrapped): ~27.5-28.9µs, indistinguishable from the
unwrapped version right next to it. So the wrapper itself changed
nothing — wrapped and unwrapped moved together.

But `query_static_single_component` (real `Iter1`, its own separate
top-level group, unrelated to this pass's diagnostic work) went the
other direction: ~9.4-11.6µs historical -> ~24.5-26.2µs both builds,
over *twice* as slow. And `raw_slice_ceiling` — zero mid-ecs code at
all, two plain `Vec`s — dropped from ~9.3-10.5µs to ~6.0-6.5µs, faster
in the opposite direction from `query_static_single_component`. Three
benchmarks that share no code moved three different amounts in two
different directions in the same run, twice.

That's not "the regression closed." The `query2_static_two_components`
vs `query_static_single_component` ratio only looks good (1.1-1.25x
this run, versus the usual ~4x) because the denominator got worse by
coincidence, not because the numerator got better for a real reason.
The number that actually matters was checked the same day and didn't
move: `ecs-vs-bevy-ecs` build #14, `dense_query_iteration`, still
3.99x (37.440µs vs bevy's fresh, independently-compiled 9.3733µs).
That comparison doesn't share this file's internal noise sources at
all, and it's unchanged. Treating builds #12/#13 as resolution would
mean trusting the one measurement that's easiest to fool and ignoring
the one that isn't.

Real, useful signal from this regardless: `archetype_core.rs`'s
internal "regression guard" ratio can swing this wide from
measurement conditions alone, with zero code change on either side of
the ratio. That's a concrete argument for the granular rework below —
a comparison with more independent, narrowly-scoped operations makes
a coincidence like this easier to catch (three unrelated numbers
moving inconsistently is a clearer tell than two numbers producing a
falsely-reassuring ratio).

### `benches/ecs-vs-bevy-ecs/benches/vs_bevy_ecs.rs`: single-op and multi-op rework

The four original groups (`spawn_n_entities_two_components`,
`query_static_single_component`, `dense_query_iteration`,
`raw_slice_ceiling`, `structural_churn_insert_remove` — five, not
four; that miscount predates this pass, fixed in the file's own doc
comment while here) were broad workload buckets. Six more added this
pass break specific operations out individually, matching
`crates/mid-math/benches/vs_glam.rs`'s own granularity: one
`bench_function` pair per concrete operation, not per broad workload.

`spawn_single_component`, `insert_single_component`,
`remove_single_component`: single-component versions of operations
the existing groups only measure bundled with a second component
(`spawn_n_entities_two_components`) or not at all (bare insert/remove
with no spawn or churn mixed in). `get_component_random_access`: a
genuinely different code path from every iteration group above, N
separate entity-by-id lookups rather than one contiguous archetype
scan. `insert_bundle_on_existing_entity`, `remove_bundle_two_components`:
multi-component structural moves on an entity that already carries
data, distinct from `spawn_n_entities_two_components`'s spawn-then-
immediately-bundle case and `structural_churn_insert_remove`'s
single-component churn.

Every new loop is wrapped in a `#[inline(never)]` free function,
matching bevy_ecs's own benchmark convention (confirmed by direct
source read this pass, see the `diag_query2_unchecked.rs` module
section above) — adopted unconditionally, not because builds #12/#13
confirmed it matters for mid-ecs specifically (they didn't confirm
anything either way), but because using bevy's own practice can only
make the comparison fairer, never less fair.

Verification: `ecs-vs-bevy-ecs` itself still can't be checked in this
sandbox at all (`bevy_ecs`'s `rust-version = "1.95.0"` blocks even
reaching this crate's own code on the sandbox's rustc 1.91, same wall
as always). The mid-ecs half of all six new functions was verified for
real instead: extracted into a standalone throwaway binary crate
depending on real `mid-ecs` directly (no `bevy_ecs` involved, so it
actually compiles here), with assertions checking each operation's
actual effect (entity count after spawn, `has_static` after
insert/remove, the summed value after random-access get, bundle
membership after insert/remove onto a non-empty entity) — all passed,
then deleted. The bevy_ecs half is grounded the same way the original
four groups already were: read directly against real source
(`World::spawn_empty`, `World::get`, `World::get_mut`,
`EntityWorldMut::insert`/`remove`, all confirmed in
`Mid-D-Man/bevy`'s `world/mod.rs` and `world/entity_access/world_mut.rs`),
not locally compiled. Confirm it actually builds on the next real CI
run before trusting bevy_ecs's numbers specifically, same standing
caveat the file's own header has always carried.

`.github/workflows/bench-vs-bevy-ecs.yml`'s own summary text hardcoded
"Three groups" — already wrong before this pass (there were five), now
updated to describe all eleven. `scripts/bench_vs_bevy_ecs.py` needed
no changes at all: it discovers groups by name from criterion's own
output and builds one table per group automatically, so the six new
groups just show up.

Checked `Mid-D-Man/bevy`'s actual `crates/bevy_ptr/src/lib.rs` directly
on the lead the user gave: bevy_ecs doesn't just happen to avoid this,
it has a dedicated crate (`bevy_ptr`, `#![no_std]`, one dependency,
`bevy_utils`) built specifically so its storage layer never holds
plain `&[T]` slice references across a fetch boundary. The relevant
type is `ThinSlicePtr<'a, T>`: a `NonNull<T>` plus a debug-only `len`
plus `PhantomData<&'a [T]>` for the borrow checker, with
`get_unchecked(&self, index) -> &'a T` doing the same
pointer-add-and-deref `Iter2RawPtr` does below. Confirmed this is not
a coincidence: `query/fetch.rs` imports it directly
(`use bevy_ptr::{ThinSlicePtr, UnsafeCellDeref};`), and `ReadFetch<'w,
T>`, the real `WorldQuery::Fetch` type for a plain `&T` query (its own
doc comment says so), stores its table column as exactly
`Option<ThinSlicePtr<'w, UnsafeCell<T>>>`, never a `&'w [T]`. A
2-component query composes two of these side by side, same shape
`Iter2UnusedBCol`/`Iter2Composed` tested, except bevy's two fields are
`ThinSlicePtr` and mid-ecs's are `&'a [_]`.


### Builds #11 and #13 (Archetype Core, rustc 1.98.1): the regression-guard ratio's own instability

Two real CI runs pasted back this pass, not adjacent — build #11 (03:36)
showed the regression-guard ratio at a "bad" 3.14-4.08x (flagged red by
the job summary itself); build #13 (12:51, same day) showed it at a
"good" 1.09-1.24x (flagged green, "consistent with the ~1.28-1.35x
currently-observed baseline"). Read at face value, that looks like the
gap closed on its own between the two runs. It didn't — the ratio's own
denominator moved, not its numerator.

**What actually moved, `build #13 / build #11`, at N=100,000:**

| Group | Build #11 | Build #13 | Ratio (13/11) |
|---|---|---|---|
| `query_static_single_component` (Iter1, safe, real) | 106.09µs | 262.06µs | **1.90x SLOWER** |
| `query_static_unchecked_1col` (Iter1Unchecked) | 106.01µs | 65.413µs | 0.617x (38% faster) |
| `two_tuple_item` (Iter2TwoTupleItem) | 106.39µs | 89.366µs | 0.840x (16% faster) |
| `query2_static_two_components` (Iter2, safe, real) | 433.32µs | 299.11µs | 0.690x (31% faster) |
| `query2_static_unchecked_2col` (Iter2Unchecked) | 423.22µs | 265.28µs | 0.627x (37% faster) |
| `raw_slice_ceiling — one_field_sum` (zero ECS code) | 105.76µs | 65.626µs | 0.620x (38% faster) |
| `spawn_insert_bundle` | 19.906ms | 12.234ms | 0.615x (39% faster) |
| `structural_churn_insert_remove` | 21.624ms | 14.708ms | 0.680x (32% faster) |

Every group in the binary got faster in build #13 — between 16% and
39% — except one: `query_static_single_component`, which got 90%
*slower*, enough on its own to land it almost exactly inside build
#13's "slow" cluster (262.06µs, next to `query2_static_unchecked_2col`'s
265.28µs) despite querying one column, not two. Its own nearest
sibling, `query_static_unchecked_1col` — same state machine, same
archetype-advance logic, the *only* line that differs is
`get_unchecked` instead of safe indexing — moved with the crowd (38%
faster). This is not "everything is noisy in the same direction," the
usual, dismissable pattern (see `structural_churn`/`spawn_insert_bundle`
above, which did move together with the crowd, consistent with a
faster run in general). One specific, safe, real, production function
moved alone, against 15+ others in the same binary, by a wide margin.

**The clean signal, unaffected by any of this:** `query_static_unchecked_1col`
vs `query2_static_unchecked_2col` — both diagnostics, both `get_unchecked`,
neither touched by whatever hit `query_static_single_component` — sits
at 3.99x (build #11) and 4.06x (build #13) at N=100,000, 3.33x/3.18x at
N=100. Stable, in lockstep, across a run where literally everything
else's absolute numbers moved by up to 39%. **This is the trustworthy
number, and it says unchanged: still ~4x, matching `ecs-vs-bevy-ecs`'s
own `dense_query_iteration` (3.99x as of build #14, a separate binary
sharing none of `archetype_core.rs`'s internal noise sources).** Build
#13's 1.24x reading is real data, correctly transcribed, and still
wrong to trust as "fixed" — its denominator broke, not its numerator.

**Cross-referencing this against `diag_inline.rs`'s own Never/Always/
Default group, already present in both these builds but not yet read
this way:** at N=100,000, `Default` (`query2_static_two_components`
itself) sits 1.1% from `Never` and 2.4% from `Always` in build #11; 0.2%
from `Never` and 10.7% from `Always` in build #13. Default tracks
Never, not Always, in both runs — the compiler is not silently
auto-inlining `Iter2::next` by default on rustc 1.98.1. That specific
theory (a hidden default-heuristic inline causing the gap) is ruled
out. What's *not* ruled out: build #13 shows `Always` measurably faster
than `Default`/`Never` (267.06µs vs ~298-299µs, ~11% at N=100,000,
~14-17% at smaller N) — the opposite of what the sandbox found when
`#[inline(always)]` was tried and reverted on `Iter2::next` itself (see
that method's own doc comment in `archetype.rs`, and this module's
header). Build #11 shows no such gap (all three within ~3.5% of each
other). One run showing an effect and one showing nothing is a lead,
not a finding — needs a third run to know if build #13's edge for
`Always` is real or noise.

**Built this pass, not yet run on real CI:** `Iter1Never`/`Iter1Always`
in `diag_inline.rs`, exposed as `World::query_static_diag_never`/
`_always`, benched as the new `query_static_single_component_diag_inlining`
group in `archetype_core.rs` — the exact same Never/Always/Default
treatment `Iter2` already has, applied to `Iter1` for the first time.
Motivation is the table above: `query_static_single_component` just
produced the single most specific, isolable anomaly this investigation
has seen (one real function, alone, moving hard against everything else
in its own binary), and until now nothing has ever tested whether
`Iter1`'s inline attribute matters the way `Iter2`'s might. If `Iter1`
shows the same Default≈Never pattern with `Always` pulling ahead, that's
a second, independent signal pointing at the same lever as `Iter2`'s —
and worth actually shipping `#[inline(always)]` on both real functions
if a third run confirms it, reversing the earlier sandbox-only-informed
revert (which never had real-CI `Iter2` data to check against — it does
now, partially, and this adds the `Iter1` half). If `Iter1` does *not*
show the pattern, `query_static_single_component`'s build #13 anomaly
has some other cause, and that's worth knowing too before spending more
time on the inlining line of investigation specifically.

Not a fix yet. Land this, run Archetype Core at least twice more (one
run already looked like a fluke this project — build #10 — and was
caught only by rerunning), and read `Iter1`'s new group the same way
the table above reads `query_static_single_component`'s.

### Builds #15 and #16: the `Iter1` attribute test came back negative, and something more useful came back positive instead

Landed the `Iter1Never`/`Iter1Always` diagnostic from the previous
section, then ran Archetype Core twice (builds #15, #16) specifically
to check the result wasn't a fluke, same discipline as everywhere else
in this investigation. It wasn't a fluke — the two runs agree with
each other to within 1-2% on nearly every group, a level of internal
consistency this suite hasn't shown since build #7. But the answer
itself is a clean negative on the question asked, and a clean positive
on a different, better question asked by accident.

**The negative result:** `query_static_single_component_diag_inlining`
— `inline_never`, `inline_always`, and `Default` (`query_static_single_component`
itself) — all landed within 1% of each other in both builds (e.g.
build #15 @ N=100,000: 377.18µs / 375.18µs / 375.25µs). No split at all,
in either direction. Pinning `Iter1::next`'s own inline attribute does
nothing, for either extreme — the same clean negative `Iter2Never`/
`Iter2Always` already gave for the 2-column case. **An attribute on
`next` itself, in isolation, is not the lever, for either arity.** That
line of investigation is closed.

**The accidental finding:** every benchmark that used to separate into
a "fast" 1-column cluster and a "slow" 2-column cluster has collapsed
into one cluster in both builds — including `query_static_single_component`
itself (375-377µs, up from its historical ~65-106µs) *and*
`query_static_unchecked_1col` (Iter1Unchecked — 375µs, also up from its
own historical ~65-106µs, and previously the single most reliable
"stays fast no matter what" reference point in this whole matrix).
Three things are still fast, unmoved, matching their own historical
numbers exactly: `raw_slice_ceiling` (~94µs, zero ECS code — nothing
for a binary-layout shift to grab onto), `two_tuple_item` (~94µs,
unchanged), and — this is the one worth sitting with —
`real_query1_inline_never_wrapper` (~94µs, unchanged), while its
structural twin `real_query2_inline_never_wrapper` sits at ~395-400µs,
matching `query2_static_two_components` exactly.

`RealQuery1::run`/`RealQuery2::run` (in `archetype_core.rs`'s
`bench_query2_static_diag_unchecked`) are byte-for-byte identical in
shape — same `#[inline(never)] fn run(&mut self) -> f32`, same for-loop
calling the real, unmodified `query_static`/`query2_static`, differing
only in `sum += pos.x` vs `sum += pos.x + vel.dx`. Wrapping the *whole
consuming loop* in an outer `#[inline(never)]` boundary reliably fixes
the 1-column case and reliably does not touch the 2-column case — this
is now the same result across at least three separate builds (#12/#13
per the previous session, #15/#16 this one). **"Just wrap the call
site" is ruled out as a sufficient fix for `query2_static` specifically
— whatever's different has to be something `Iter2::next` carries on its
own, not something fixable purely from outside it.**

**The likely explanation for the collapse itself, stated plainly since
it changes how to read the last several sections:** nothing in
`archetype.rs` changed between build #13 and build #15 — `Iter1::next`
is the exact same source it's been all session. What changed is that
`diag_inline.rs` and `query.rs` grew new code in the same compilation
unit `Iter1::next` lives in. The most likely read is that this shifted
enough about the compiled binary's layout to tip `Iter1::next` — which
build #13 already showed *can* tip, just not reliably before now — into
whatever regime `Iter2::next` sits in permanently. Shipping the next
diagnostic pushed the very thing it was trying to observe into a new,
now-stable state. Worth stating plainly rather than treating as a
side note: the regression-guard table's own baseline
(`query_static_single_component`) is not currently a safe thing to read
at face value, and won't be until this is actually understood, not just
patched around.

**Patched around in the meantime, because leaving it silent is worse
than a workaround:** `scripts/bench_mid_ecs_archetype_core.py` now
cross-checks `query_static_single_component` against `raw_slice_ceiling`'s
own floor at N≥1,000 (N=100 excluded — checked directly against build
#11's own healthy numbers, which still show a 2.6× baseline/floor ratio
at N=100 alone from ordinary fixed-per-call overhead, a false positive
this exclusion avoids) and refuses to print a clean ✅ — downgrading
every row to at least ⚠️ regardless of how good the raw ratio looks —
if that baseline is running >2.0× the floor. Verified against both
regimes directly: build #11's real numbers (healthy baseline, genuine
4.08× worst ratio) still correctly print the original 🔴 for the
original reason; build #15's real numbers (collapsed baseline, a
misleadingly clean 1.07-1.13×) now correctly print a drift warning and
downgrade every ✅ to ⚠️ instead of reporting a false pass. This doesn't
fix the underlying issue — it stops the summary from actively lying
about it while it's unresolved.

**Built and shipped this pass, not yet run on real CI:**
`Iter2ColdSplit` in `diag_query2_unchecked.rs` — `Iter2`'s exact logic
with the archetype-advance ("cold") branch physically moved into its
own `#[inline(never)] fn advance`, leaving `next`'s own body as just
the per-entity fast path and a call out to `advance` on the rare
branch. Different question than the already-closed one above: not "does
an attribute on `next` matter" (closed, no) and not "does wrapping the
*caller* matter" (closed for 2 columns, no) but "does the *cold path's
own size*, sitting physically inside `next`, affect how well the *hot*
path inlines at 2 columns' worth of state" — untested until now, and
the one remaining structural difference between `Iter2` and
`Iter1`/`Iter2TwoTupleItem` this investigation hasn't tried adjusting.
Three new tests (`diag_query2_static_cold_split_matches_the_real_query2_static`,
`_empty_when_one_side_was_never_registered`, and a new three-archetype
`_walks_multiple_matching_archetypes_and_skips_a_non_matching_one_between_them`
case — `two_archetype_world`'s own two archetypes weren't enough to be
confident the split between `next`/`advance` hands off state correctly
across more than one real archetype boundary) — 185/185 mid-ecs tests
pass, bench compiles clean. Benched as a new `cold_split` entry in the
existing `query2_static_diag_unchecked` group — no new bench group
needed, it slots in next to `composed`/`raw_ptr`/`owned_direct`.

Land it, run Archetype Core at least twice (same standing discipline),
and read `cold_split` against `two_tuple_item`/`raw_slice_ceiling` (the
still-reliable fast references) rather than against
`query_static_single_component` — which, per the section above, isn't
a safe comparison point right now regardless of what the automated
table says about it.

### Builds #17 and #18: `cold_split` is a clean negative, and the profile itself became a suspect

Ran Archetype Core twice more (builds #17, #18 — same commit,
triggered together, ~12-13% apart in absolute terms across every group
uniformly — the ordinary "different runner" pattern this project has
always treated as dismissable noise, not the isolated single-function
pattern builds #13/#15/#16 showed). `cold_split` landed in the slow
cluster in both — 376.37µs / 423.40µs at N=100,000, indistinguishable
from `composed`/`raw_ptr`/`owned_direct`/`unused_b_col`. **Clean
negative: the cold path's own size, factored out into its own
`#[inline(never)]` function, is not what's holding the hot path back.**
That closes this specific structural line of inquiry — outlining
doesn't help, at least not the way it was tried here. `query_static_single_component`
and `query_static_unchecked_1col` are still sitting in the collapsed
state builds #15/#16 first showed, in both #17 and #18 — four
consecutive builds now, so whatever tipped it during the `Iter1Never`/
`Iter1Always` addition looks like a settled new state, not a fluke.

At this point every source-level variant of `Iter2`'s own logic this
investigation has tried — safe, unchecked, raw-pointer, owned,
composed-fetch, attribute-pinned, cold-path-split — reproduces the same
number, with the sole exception of the one that adds a genuine indirect
call. That's a strong pattern in one direction (something about a fully
analyzable, fully inlinable 2-column loop specifically) but seven-plus
negative results without a working fix for the real API starts to look
like the wrong axis is being varied. Two things checked this pass that
aren't another `Iter2` source variant:

**Checked directly, not assumed: this workspace's own build profile.**
Root `Cargo.toml`'s `[profile.bench]` sets `codegen-units = 1` and
`lto = true` workspace-wide — added 2026-08-23, for a real, different,
already-fixed problem (`wide::i32x4::add` benching ~14x slower than
mid-math's own equivalent, a cross-crate inlining gap; see
docs/platform-optimization.md §9). Two things about it worth stating
plainly: (1) `benches/ecs-vs-bevy-ecs` is a workspace member, not a
separate workspace (checked directly, per its own Cargo.toml's
comment), so real `bevy_ecs` compiles under this exact same
codegen-units=1+LTO regime whenever that comparison runs — it isn't
somehow exempt. (2) Mid-D-Man/bevy's own root `Cargo.toml` (real
source, re-checked this pass) has neither a bare `[profile.release]`
nor any `[profile.bench]` at all — bevy's own benchmarks, the same
`benches/benches/bevy_ecs/iteration/*.rs` already read for the
`#[inline(never)]`-wrapper convention, run under cargo's plain,
unconfigured default: `codegen-units = 16`, no LTO. Bevy leans on
explicit `#[inline(always)]` (confirmed on `QueryIterationCursor::next`
itself) to guarantee its own hot path's codegen, not on whole-program
LTO to let the compiler figure it out. This project's workspace applies
LTO+single-codegen-unit to `Iter1`/`Iter2` as a side effect of fixing an
unrelated crate's problem, not as a deliberate choice for these two
functions specifically.

Searched before treating this as more than a coincidence: LTO making
one *specific* loop's own codegen measurably worse, independent of any
codegen-unit-reshuffling question, is real and already confirmed
upstream — rust-lang/rust#106609 ("LTO produces worse codegen for a
loop," with real before/after disassembly showing the LTO'd version
adds an extra live pointer the non-LTO'd version optimizes away) and
rust-lang/rust#146497 (a 2025 nalgebra/criterion reproduction showing
over 4000% degradation from `lto = "fat"` alone). Separately,
vortex-data/vortex#9259 (real PR, months old) hit the *other*
mechanism — `codegen-units = 16` reshuffling which functions share a
unit when unrelated code is added, moving benchmarks with no source
change on the branch that added them — and fixed it by moving *to*
codegen-units=1+lto=true, the setting this workspace already has. Two
distinct, independently-real mechanisms; this project's current
profile is already the known fix for one of them, and has never been
tested against the other for `Iter2`'s specific loop shape.

**Built and shipped, not yet run on real CI:** a `profile.bench-nolto`
entry in the root `Cargo.toml` (`inherits = "release"`, then every
field set explicitly: `opt-level = 3, lto = false, codegen-units = 16,
strip = false, debug = true` — matching bevy's own actual, unconfigured
numbers rather than guessing at them), plus a `profile` dispatch input
on this workflow (`bench`, the current default, or `bench-nolto`),
wired into the actual `cargo bench --profile` invocation and into the
cache key so the two don't share a `target/` cache entry. Verified
directly on this sandbox: `cargo build -p mid-ecs --profile bench-nolto`
and `cargo bench -p mid-ecs --bench archetype_core --profile bench-nolto`
both compile and run cleanly (rustc 1.91.1) — this only confirms the
plumbing works, not anything about the performance question itself,
which this sandbox has never been able to speak to for this
investigation either way.

Run Archetype Core once with `profile: bench-nolto` and once more with
the default `bench` on the same commit, and read the two side by side —
particularly `query2_static_two_components`, `query2_static_unchecked_2col`,
and (now that it's a clean negative under the current profile)
`cold_split` again under the other one. If any of them move
meaningfully between the two profiles while `raw_slice_ceiling` and
`two_tuple_item` don't, that's the profile, not the source, and the
seven-plus negative source-level results above stop being seven-plus
negative results and start being seven-plus results that were never
going to show anything because the actual lever was never in the
source to begin with.

### Builds #19 and #20: the A/B test landed, and it reframes the question rather than closing it

Ran Archetype Core once on each profile, same commit (`ae43fc5`).
Build #19 (`bench`, current default): the usual current numbers.
Build #20 (`bench-nolto`, matches bevy's own real settings): and here
is the actual result, stated plainly because it's not the clean "the
profile explains everything" story the previous section was hoping
for — it's more specific and, once seen, more useful than that.

**`two_tuple_item` and `real_query1_inline_never_wrapper` — the two
things that have been reliably fast (~94-106µs) in every single build
this entire investigation has run — both collapsed under `bench-nolto`.**
`two_tuple_item`: 106.37µs → 514.81µs (worse than the "slow" cluster).
`real_query1_inline_never_wrapper`: 106.15µs → 376.91µs (now
indistinguishable from unwrapped `query_static_single_component`,
377.11µs, in the same run). Everything else moved by the ordinary
~10-13% a different run/profile produces on its own — `raw_slice_ceiling`
stayed the true floor in both (105.75µs → 93.943µs, actually a bit
faster without LTO, consistent with the general trend, not a collapse).

Read together, this says something more specific than "LTO matters":
**both of this investigation's clean "fast" reference points depend on
LTO's whole-program view being able to prove something about them that
isn't true without it.** `two_tuple_item`'s combine step is a stored
`fn(&A,&B)->A` pointer — genuinely indirect in the source, but if it's
only ever constructed with one concrete function in the whole program,
LTO can see that across crate/module boundaries and devirtualize it
into a plain, inlinable call; without LTO, that proof isn't available
and it's a real, un-inlinable indirect call, with real, unhidden
overhead. `real_query1_inline_never_wrapper`'s own `#[inline(never)]`
wrapper doesn't touch whether `Iter1::next` inlines into `run`'s own
loop — whatever made that combination fast was something LTO's
cross-module view was doing, not the wrapper attribute itself doing
anything without it.

**The more important thing this run showed:** without LTO's help,
there is no meaningful gap between 1 column and 2 columns at all.
`query_static_single_component` (377.11µs) and `query2_static_two_components`
(397.29µs) sit within 5% of each other — both roughly 4x
`raw_slice_ceiling`'s floor. This is worth stating as plainly as the
reversal above: **the "query2_static costs ~4x query_static" framing
that has organized this entire investigation has, in every build this
session, only ever shown up when the comparison's 1-column side was
something LTO specifically blesses** (build #11's original
`query_static_single_component`, before whatever this session's own
`Iter1Never`/`Iter1Always` addition did to it; `two_tuple_item`;
`real_query1_inline_never_wrapper`). Take those out of the picture —
compare `query_static_single_component` to `query2_static_two_components`
directly, either profile — and both cost roughly the same, both roughly
4x the floor. The seven-plus `Iter2`-only diagnostic variants this
investigation has built were all answering "what's different about 2
columns," a question this run casts real doubt on as the right one to
be asking. The steadier, more basic question underneath it, that this
investigation hasn't actually asked yet: **why does going through
`Iter1`/`Iter2` at all — for either arity — cost ~4x a raw slice sum**,
when build #11 shows that cost used to be ~1x for the 1-column case,
specifically.

**Built and shipped, not yet run on real CI:** `benches/iter1-isolated`,
a new, minimal workspace member containing exactly two groups —
`query_static_single_component` and `raw_slice_ceiling`'s
`one_field_sum`, mirrored byte-for-byte from `archetype_core.rs` — and
nothing else. No `Iter2`, no diagnostics, none of what
`archetype_core.rs` has accumulated across this entire investigation.
Same workspace, same `[profile.bench]` (or `[profile.bench-nolto]` —
new workflow takes the same profile choice) held constant, so the one
variable this isolates is exactly the one the "builds #15-#20" section
above flags but never tests directly: does `query_static` come back
close to the floor once it's the only thing in the crate, the way it
was in build #11, before this investigation's own accumulated code
apparently pushed it into the same regime `query2_static` has been in
all along? New workflow: `bench-iter1-isolated.yml`, modeled on
`bench-mid-collections-sparse-set.yml`'s simpler bash-grep summary
(two groups doesn't need `archetype_core.py`'s regression-guard
machinery). Verified end-to-end on this sandbox (compiles, runs,
produces correctly-shaped output) — meaningless for the actual
question, as always, since this sandbox has never reproduced this
investigation's regression in either direction.

**Also caught and fixed while building the above:** the `profile`
dispatch input added to this workflow two sessions ago broke its own
step-summary size-limit fix for any profile name other than the literal
word `bench` — the guard's `grep`/`awk` pattern was `` Finished `bench`
profile `` (an exact match), and `cargo bench --profile bench-nolto`
prints `` Finished `bench-nolto` profile `` instead, which doesn't
contain that exact substring. Build #20's run fell through to the
"compilation never finished" fallback despite compiling and running
cleanly — wrong, and pointless, since that fallback exists specifically
to show build *errors*, not a clean run's own already-stripped-of-value
warning preamble. Caught by testing the pattern against both real
strings directly (not assumed safe from one string alone) and fixed by
matching the `` `bench `` prefix only, which fires for any profile name
starting with it. Applied to the new `bench-iter1-isolated.yml` from
the start, so it isn't carrying the same bug into its first run.

### Builds #1 and #2 (Iter1 Isolated, rustc 1.98.1): closing the investigation

Real CI, `benches/iter1-isolated`, commit `f8412070`. Build #1 (`bench`,
LTO on): `query_static_single_component` 106.09µs vs
`raw_slice_ceiling`'s 105.71µs at N=100,000 — **~1.0x, matching
Archetype Core build #11 almost to the microsecond.** Build #2
(`bench-nolto`): 329.59µs vs 81.97µs — **~4.02x**, matching what
`archetype_core.rs` itself has shown under either profile since build
#13, and matching builds #19/#20's own no-LTO numbers for the same
query.

That's the answer builds #19/#20 reframed but didn't close: isolating
`Iter1` from everything `archetype_core.rs` has accumulated (seven-plus
`Iter2` diagnostic variants, their own `Iter1`-side additions,
`Iter2ColdSplit`) restores it to the floor — **but only with LTO on**.
Without LTO it costs the same ~4x as everything else in this
investigation always has, isolated or not. Read together with #19/#20's
own reversals (`two_tuple_item` and the outer wrapper both collapsing
under `bench-nolto`), the whole thread comes down to one mechanism:
**LTO's whole-program devirtualization is what made `Iter1` fast in
build #11, and it stops fully resolving `Iter1::next`'s call sites once
the compilation unit gets large enough** — which is exactly what
`archetype_core.rs` became across this investigation's own diagnostic
additions. Not a structural difference between 1 and 2 columns (#19/#20
already ruled that out), not `Iter1`'s own codegen — just LTO losing
headroom as the surrounding file grew. Upstream-confirmed pattern, not
a stretch: rust-lang/rust#106609, #146497.

**Closing here**, per the call made at the start of this pass rather
than running a ninth diagnostic: the mechanism is confirmed and real;
further digging is diminishing returns. `archetype_core.rs` and
`benches/iter1-isolated` both stay as-is — kept for reference, not
deleted — since "is the gap real" is answerable by pointing at these
two builds now, not by re-running anything. Real, separate wins that
came out of this thread regardless of the open question closing
inconclusively-by-choice rather than definitively: the step-summary
overflow fix, the regression-guard's N=100 false-positive fix, and
`get_two_mut`/`get_disjoint_mut`'s real 1.83x/2.49x improvements.

### `scratch.rs`: a swappable arena abstraction, not wired in yet

Built to make good on the standing plan: bumpalo backs `mid-ecs`'s
scratch storage today, a future `mid-arena`-backed type replaces it
once that's been benched for this exact access pattern — without a
second rewrite of whatever calls it. `archetype.rs`'s own doc comment
already names the cost this targets: each migrated component value is
boxed as `Box<dyn Any>` (`Column::swap_remove_and_forget`/`push_any`),
one heap allocation per moved component per structural change.
`spawn_insert_bundle` and `structural_churn` are flagged in
`archetype_core.rs` as real, measured gaps against `bevy_ecs`
(~2.9-5x) — but **no root-cause pass has been done on either yet**.
This module doesn't claim boxing is that gap; it makes the one named,
understood cost swappable so a future profiling pass has something to
swap, rather than starting from a raw-pointer rewrite of `Column`
itself.

**Design:** `ScratchArena<'a>` (`alloc<T: 'static>(&'a self, value: T)
-> Self::Erased`, `reset(&mut self)`) plus an `ErasedValue` trait
(`downcast<T>(self) -> Result<T, Self>`) mirroring `Box<dyn
Any>::downcast`'s own contract exactly — wrong type back unchanged in
`Err`, never dropped or lost. Two real implementations:

- `HeapScratch` — today's actual behavior, given a name. One real heap
  allocation per `alloc`, zero new dependencies, default.
- `BumpaloScratch` (behind the new `scratch-arena` feature,
  `bumpalo = "3.20.3"`, `features = ["boxed"]`, optional) —
  `bumpalo::Bump` plus its own `boxed::Box<'a, dyn Any>`.

**Why bumpalo directly and not `mid-arena`'s own `BumpArena<T>`:**
checked directly, `mid-arena`'s `BumpArena<T>` is single-typed —
built for many values of *one* `T`, not a match for what a structural
change needs (several *different* component types, one arena, for the
width of one entity's migration, then thrown away). `bumpalo::Bump`
already solves that shape — it's what `bevy_ecs`'s own `BundleScratch`
uses, real source read directly — so it's the right backing today;
`mid-arena` stays the eventual target once it grows a matching type,
not before.

**Why this doesn't need `Box<'a, T>`'s unstable `allocator_api`:**
a naive trait returning `Box<dyn Any>` (the real, `alloc::boxed` type)
would be impossible for a bump-backed implementation to satisfy on
stable Rust — `Box` isn't allocator-parameterized outside nightly.
`bumpalo`'s own `boxed` feature (stable, zero extra dependencies —
checked directly, `bumpalo` 3.20.3's `Cargo.toml`: `boxed = []`) solves
this with its own `Box<'a, T>`, which is the actual return type behind
`ErasedValue` for the bumpalo-backed side. Its `Drop` impl was read
directly (`src/boxed.rs`): calls `drop_in_place` and nothing else — the
arena owns reclaiming memory, not the `Box` — exactly the property this
module needs. Erasing a concrete `Box<'a, T>` into `Box<'a, dyn Any>`
needs one small `unsafe` block (`Box::into_raw` -> unsize cast -> 
`Box::from_raw`) — bumpalo's own documented pattern for building a
type-erased `Box` (`boxed.rs`'s "Manually create a `Box`" example), not
an invented technique, and narrow enough to audit in one function.

**Verified, not assumed:** 4 tests with default features (`HeapScratch`
only), 9 with `--features scratch-arena` (both implementations against
the same shared test bodies, generic over `ScratchArena`) — roundtrip,
wrong-type downcast returns the value unharmed, and critically,
dropping an un-downcast value still runs its destructor exactly once
(a `DropCounter` type with a real `Drop` impl, checked against a shared
counter) for both `HeapScratch` and `BumpaloScratch`. Full existing
suite re-run both ways: 189/189 (default), 194/194 (`scratch-arena`) —
185 pre-existing plus this module's own, nothing broken either way.

**Not done yet, on purpose:** `Column::swap_remove_and_forget`/
`push_any` still use `Box<dyn Any>` directly — this module is
standalone infrastructure, not wired into the migration path. Next
step, not this one: wire `BumpaloScratch` into that one call site once
there's been an actual root-cause pass confirming boxing is worth
fixing before `spawn_insert_bundle`/`structural_churn` get touched
further.

### `diag_alloc_count.rs` and the `remove_bundle`/`insert_bundle` allocation pass

Root-caused rather than guessed at, using a real, sandbox-valid signal
the Iter1/Iter2 investigation didn't have available: allocation
*counts* through a `#[global_allocator]` wrapper are deterministic
regardless of optimization level, unlike timing — same code, same
allocations, every run. `examples/diag_alloc_count.rs` mirrors three of
`vs_bevy_ecs.rs`'s real workloads exactly (N=10,000, same component
shapes and call sequence) and reports real allocs/op, release profile.

**A real correction found along the way, stated plainly:** `insert`/
`get`/`has` are the *Sparse Shell*; `insert_static`/`get_static`/
`has_static` are the *Archetype Core* — the reverse of what "static"
sounds like it should mean, confirmed directly from this crate's own
tests (`using_a_sparse_type_with_insert_static_panics`), not assumed.
`Marker` in the real bench is inserted via `insert_static`, so it's a
real, archetype-tracked, *surviving* column on every
`remove_bundle_two_components`/`insert_bundle_on_existing_entity` call
— not a sparse one sitting outside the archetype entirely, which is
what an earlier pass through this same file mistakenly assumed. The
initial "fast path, only when every column is being removed" design
built on that wrong assumption was real and tested, but never actually
fired on the real benchmark because of it — superseded below by a
version of the same idea that's unconditionally true instead.

**Three real, verified fixes, each checked against the diagnostic
before being trusted:**

1. **`Bundle::component_ids`/`existing_component_ids` returned
   `Vec<ComponentId>`** — one heap allocation on *every*
   `insert_bundle`/`remove_bundle` call, every arity, regardless of
   whether that call ends up boxing anything. Replaced with
   `ComponentIdList`, a fixed 8-slot inline buffer (`impl_bundle_for_
   tuple!` never generates past arity 8) plus a real length — `Deref`/
   `DerefMut` to `[ComponentId]` so every existing call site kept
   working unchanged except one `for &id in &ids` → `for &id in
   ids.iter()` (`for` loops need `IntoIterator` directly; `Deref`
   coercion doesn't reach that far). Measured: `remove_bundle_two_
   components` 4.00 → 3.00 allocs/op, `insert_bundle_on_existing_
   entity` and `spawn_n_entities_two_components` both 1.00 → ~0.

2. **`B`'s own removed elements never need `Box<dyn Any>` at all** —
   true unconditionally, not just when nothing else survives. Added
   `Bundle::take_direct`, which pulls `Self` straight out of the
   source columns via typed `swap_remove`, and changed
   `remove_bundle`'s migration loop to `continue` past any column
   that's one of `ids` (handled by `take_direct` instead) rather than
   boxing it into a `removed: HashMap<ComponentId, Box<dyn Any>>` the
   way it used to. That `HashMap` — and the `Bundle::take_from` method
   that only ever existed to drain it — are both gone entirely, not
   just avoided in a special case. Only the genuinely-unknown-at-
   compile-time *other* columns still go through `Column::
   swap_remove_and_forget`/`push_any`'s type-erased path, since that
   one's unavoidable (which components those are is a runtime fact).

3. **Net result, measured, not estimated:** `remove_bundle_two_
   components` 4.00 → 3.00 → **0.002** allocs/op. `insert_bundle_on_
   existing_entity` 1.00 → **0.005**. `spawn_n_entities_two_components`
   1.00 → **0.011**. All three are now allocation-free in practice —
   the small residual counts are one-time archetype/edge-cache setup
   cost on the first few calls, not per-op cost (they don't scale with
   N). `Marker` itself was never contributing to any of the box-related
   counts regardless of this fix — it's a zero-sized type, and boxing a
   ZST is a well-known no-op for Rust's allocator (never reaches
   `GlobalAlloc::alloc` at all), which is *why* the original wrong
   "Marker is sparse" assumption didn't get caught by the numbers
   sooner: the allocation counts were real and correct throughout, only
   the narrative explaining *why* needed correcting.

**190/190 tests pass**, including a new one this pass added
specifically because none of the existing `remove_bundle` tests
actually reached the surviving-column path (every one of them removed
an entity's entire archetype-tracked signature) —
`remove_bundle_migrates_a_surviving_component_to_the_new_archetype`
uses a third component (`Health`) that must migrate intact, exercising
exactly the branch the rest of the suite never touched.

**What this means for `scratch.rs`, stated plainly:** its original
motivation — `remove_bundle_two_components`'s boxing cost — is gone,
not reduced. `B`'s own elements never box at all now, on any bundle
shape. The only `Box<dyn Any>` still in play is for *surviving*,
non-`B` columns during a structural change, which is real but
narrower than what `scratch.rs` was built against, and hasn't itself
been measured as a real cost anywhere yet (every survivor in the
actual benchmarks measured this pass happens to be a free-to-box ZST).
`scratch.rs` stays as real, tested, standalone infrastructure — not
wired in, still correct, still the right tool if a future profiling
pass finds a real non-ZST survivor path worth it — but wiring it into
`Column` itself turned out to run into a real architectural tension
this pass surfaced for the first time: `Column` is `Box<dyn Column>`
(a trait object, long-lived, shared across many unrelated operations),
while any arena is inherently transient (one per structural change) —
threading a transient arena's lifetime through a long-lived trait
object's own signature doesn't have a clean answer on stable Rust, and
isn't one this pass forced through on a guess.

### `Iter1UncheckedAlways`/`Iter2UncheckedAlways`: the one combination never tested

Prompted by a direct, real comparative source read of `Mid-D-Man/bevy`
(`crates/bevy_ecs/src/query/iter.rs` and `fetch.rs`) after the Iter1
Isolated investigation closed — worth doing since this crate's own
documented policy already authorizes it: "the first `unsafe` in
`mid-ecs`'s own query iteration path — agreed as a deliberate, scoped
exception for this crate specifically" (this doc, `Iter1Unchecked`'s
own entry above), and bevy's real numbers have been consistently ahead
across every build this investigation has produced.

**What the source comparison actually found, checked line by line, not
assumed:** bevy's single-component fetch is three layers, every one
`#[inline(always)]`, every one using `get_unchecked` — `QueryIter::next`
(`iter.rs:1050`) calls `QueryIterationCursor::next` (`iter.rs:3143`,
`get_unchecked` on the entity index) which calls `<&T as
QueryData>::fetch` (`fetch.rs:1898`, `get_unchecked` on the table row).
None of it depends on LTO deciding anything — the compiler is told,
at every hop, regardless of codegen-units or whether LTO is even on.
That's the real reason bevy's own numbers stay consistent under
`codegen-units=16, no LTO` (its actual, already-confirmed real
`Cargo.toml`) — it was never leaning on LTO's cooperation.

**Neither existing mid-ecs diagnostic tested that full combination.**
`diag_inline.rs`'s attribute-only three-way test (real CI, rustc
1.98.0) found pinning `next()`'s own inline attribute does nothing —
but that's the *safe*, bounds-checked version, attribute alone.
`Iter1Unchecked`/`Iter2Unchecked` (this doc, above) are unsafe
(`get_unchecked`) but carry no inline attribute at all, and collapsed
under the same LTO/compilation-unit-size pressure as everything else
once `archetype_core.rs` grew past whatever point trips it (builds
#15 onward, this doc's "the collapse" section). Both real, both
already spent — neither is what bevy actually does. `get_unchecked`
*and* `#[inline(always)]`, stacked on the same function, is the one
cell in this matrix that's never actually been filled in.

**`Iter1UncheckedAlways`/`Iter2UncheckedAlways`** (`diag_query2_
unchecked.rs`): `Iter1Unchecked`/`Iter2Unchecked`'s exact bodies,
`#[inline(always)]` added to `next()` — nothing else changed, so a
positive result isolates this specific combination rather than mixing
in some other variable. Same soundness argument as the existing
unchecked variants (`len` already proven ≤ every slice's length on
each archetype advance, `get_unchecked` just stops re-deriving what the
safe version's own bounds check already guaranteed). Correctness
tested the same way every other diagnostic in this file has been —
cross-checked against the real, safe `query_static`/`query2_static`,
not trusted because it compiles: 4 new tests, 194/194 `mid-ecs` tests
total, sandbox rustc 1.91.1. Wired into `archetype_core.rs`'s existing
`query2_static_diag_unchecked` bench group as `query_static_unchecked_
always_1col`/`query2_static_unchecked_always_2col`, exposed via
`World::query_static_diag_unchecked_always`/`query2_static_diag_
unchecked_always`, same `#[doc(hidden)] pub` convention as every other
entry in this group.

**Not yet run on real CI — that's the actual next step, same asymmetry
as always.** If this closes the gap where the attribute-alone and
unsafe-alone variants didn't, it's real, actionable evidence that
`Iter1`/`Iter2`'s production `next()` should move to this same
combination for real, not a diagnostic-only conclusion — the crate's
own unsafe policy already clears that path if the numbers say so. If
it *doesn't* close the gap, that's real evidence too: it would mean
bevy's consistency isn't fully explained by this specific mechanism
either, and the honest next move is the same one this investigation
already reached once before — name what's confirmed, stop guessing at
what isn't, and decide deliberately whether continuing is worth it
rather than drifting into a ninth variant by default.

### `Iter2RefUncheckedAlways`: unsafe + forced inlining, in true isolation this time

Follows directly from `benches/query2-ref-isolated`'s own real result
(Query2-Ref Isolated builds #1/#2): `query2_static_ref` — the
apples-to-apples, entity-free, 16-byte-item shape against `bevy_ecs`'s
own `Query<(&A, &B)>` — still sits at ~4x the raw-slice floor in *true
isolation*, both `bench` and `bench-nolto`. That's a stronger result
than anything `archetype_core.rs` itself could produce: it rules out
the ABI-register-threshold theory (16 bytes was supposed to be the
side that inlines cleanly; it isn't) and the compilation-unit-size
theory at the same time (isolation is exactly what fixed `Iter1`, and
it didn't fix this).

One combination was still untested: `get_unchecked` +
`#[inline(always)]` together, the same pairing `Iter2UncheckedAlways`
already tried and found negative — but only ever inside
`archetype_core.rs`, never in true isolation. `Iter2RefUncheckedAlways`
(`archetype/iter.rs`) is `Iter2Ref`'s exact body with both added,
wired into `benches/query2-ref-isolated` as a second bench function
(`query2_static_ref_two_components — unchecked_always`) alongside the
real one, same bench binary, same isolation. 5 new correctness tests
added for `query_static_ref`/`query2_static_ref`/this variant — none
of the three had any coverage before this pass, cross-checked against
the real, safe `query2_static_ref` output the same way every unsafe
diagnostic in this crate's history has been. 185/185 tests
(`scratch-arena`), nothing broken.

**Real CI result (Query2-Ref Isolated builds #3 and #4, rustc 1.98.1,
commit `33003bc`): clean negative.** `unchecked_always` is
indistinguishable from the real `query2_static_ref` in both profiles.
`bench` (LTO), N=100,000: 423.40µs (real) vs 423.27µs
(`unchecked_always`) vs 105.99µs raw-slice floor, 3.99x. `bench-nolto`,
N=100,000: 328.67µs vs 328.04µs vs 82.09µs, 4.00x. The ratio is flat at
~4.0x from N=10,000 up (~4.2x at N=1,000, ~7x at N=100 where fixed
per-call cost is still a visible share). Absolute numbers drifted ~13%
between the two builds' baselines on mid-ecs *and* the floor together,
which is runner variance, not a code effect; only within-run ratios are
usable.

That closes the attribute / unsafe / isolation family: each variant
(attribute alone, unsafe alone, both together) has now been tested both
inside `archetype_core.rs` and in true isolation, none reaches the
floor. **Decision: accept the two-column gap as documented and
currently unsolved, and move on to other engine work** (next entry,
`hash.rs`). Two axes were never touched and stay available if this
reopens: the emitted assembly of the isolated inner loop taken on CI's
toolchain (sandbox rustc 1.91 has never reproduced this regression, so
assembly from it is not evidence), and the structure of bevy's
tuple-composed fetch (only its inline/unsafe attributes have been
read, not its composition).

### `hash.rs`: fast hashers for the Archetype Core's hot-path maps

Built after the `Iter2` investigation was parked (see the result above),
aimed at the compute-shaped `ecs-vs-bevy-ecs` gaps that the allocation
pass could not explain: `get_component_random_access`,
`insert_bundle_on_existing_entity`, `spawn_n_entities_two_components`,
and the `remove_bundle_two_components` residual. Allocation counts for
the last three were already ~0 (see `diag_alloc_count.rs` above), so
what was left had to be instructions, not allocations.

**Finding, measured with callgrind (deterministic instruction counts,
see `diag_ir_ops.rs` below).** One `World::get_static` cost ~242
instructions. ~132 of those were `Archetypes::existing_component_id`:
a `std::collections::HashMap<TypeId, ComponentId>` lookup, ~100 of
them SipHash and ~32 the hashbrown probe. Structural changes pay the
same tax on every call: `component_ids` plus the per-archetype
`add_edges`/`remove_edges` maps (`HashMap<ComponentId, ArchetypeId>`),
~228 instructions of SipHash per `insert_bundle`/`remove_bundle`/spawn.

**What bevy does instead** (bevy_ecs 0.19.1 and bevy_utils 0.19.1
source, the versions `ecs-vs-bevy-ecs` actually depends on):
`Components::indices` is a `TypeIdMap<ComponentId>`, which is
`IndexMap<TypeId, V, NoOpHash>` — no hashing work at all, since
`TypeId` is already a fingerprint. Not the whole gap by itself; it is
the largest single piece of the per-lookup difference that could be
checked without a bevy build.

**Change.** New `crates/mid-ecs/src/hash.rs`, `pub(crate)`, zero
dependencies:

- `TypeIdHasher`: passes the value `TypeId`'s own `Hash` impl writes
  straight through (`write_u64`; `write_u128` xor-folds). Correctness
  never depends on which `write_*` method a toolchain's `TypeId` calls
  (equal keys always produce the same write sequence); the byte
  fallback only keeps quality acceptable if that impl changes shape.
- `DenseIdHasher`: Fibonacci multiplicative hash for small dense ids.
  Multiplying by an odd constant is a bijection on the low bits, so
  consecutive `ComponentId`s never share a bucket index (a test proves
  it for 1,024 ids), while the high bits hashbrown uses for control
  bytes come out well mixed.

`archetype.rs`: `Archetypes::component_ids` becomes `TypeIdMap`, and
`Archetype::add_edges`/`remove_edges` become `DenseIdMap`. Nothing else
changed. HashDoS resistance is irrelevant here: every key is
`TypeId::of::<T>()` or a locally-issued counter, never external input.

**Sandbox result (rustc 1.91.1, callgrind Ir per operation, N=10,000,
op-run minus setup-only run, profile: opt-level 3, lto off, 16 CGUs):**

| operation | before | after | change |
|---|---|---|---|
| `get_static` (random access) | 235.0 | 118.0 | -50% |
| `insert_bundle`, entity already has `Marker` | 1236.8 | 826.8 | -33% |
| `remove_bundle`, 2 components | 1336.7 | 939.7 | -30% |
| spawn + `insert_bundle` | 1338.4 | 928.4 | -31% |

Instruction counts, not timing, and not from CI's toolchain: fewer
instructions is necessary evidence, not sufficient. Real CI timing is
the authority.

**Not changed, deliberately.** The Sparse Shell's own
`SparseShell::component_ids` (`component.rs`) has the same
`HashMap<TypeId, ComponentId>` shape and would take the same fix, but
it is not on any path `ecs-vs-bevy-ecs` measures and has not been
measured itself. `signature_to_id` (`HashMap<Vec<ComponentId>, _>`) is
only hit on an edge-cache miss; the FFI maps are cold.

**Remaining cost centres after this change, and the two candidates
they suggest** (Ir per op, same method):

- Structural ops: `insert_bundle` 228 self, `edge_for_insert` 132,
  `push_into` 104, `Bundle::component_ids` 87. Bevy caches transitions
  per *bundle* (`Edges::insert_bundle: SparseArray<BundleId, _>`, and
  `Bundles::bundle_ids` is a `TypeIdMap`), one lookup per whole bundle.
  mid-ecs chains one `edge_for_insert` per component and creates
  intermediate archetypes on the way (see the doc comment on
  `Archetypes::iter` in `archetype.rs`, which hit exactly this). A whole-bundle edge cache is the
  obvious next candidate.
- `Archetypes::get`: 71 of `get_static`'s remaining 118. It looks the
  entity up twice (`World::is_alive`, then `locations.get`; the second
  is index-only, which is why the first is required) and makes two
  virtual calls per lookup (`Column::as_any`, then the `downcast_ref`'s
  `type_id`). Removing the downcast would need an `unsafe` cast whose
  invariant (the `ComponentId` was derived from the same `T`) holds by
  construction; that is a policy decision, not made here.

**Real CI result (`ecs-vs-bevy-ecs` build #25 and Archetype Core build
#32, rustc 1.98.1, commit `ce6ce32`).** Ratios are mid-ecs over
bevy_ecs in the same run. "Before" is the last figure on record (build
#20 for `remove_bundle`, the previous handover for the rest), not
re-measured in this run.

| group | before | build #25 |
|---|---|---|
| `insert_bundle_on_existing_entity` | ~1.6x | 0.99x (696.44µs vs 702.50µs) |
| `remove_bundle_two_components` | 1.48x | 0.97x (714.21µs vs 739.36µs) |
| `spawn_n_entities_two_components` | ~2x | 1.72x (892.10µs vs 519.27µs) |
| `get_component_random_access` | ~2.7x | **4.79x** (362.16µs vs 75.638µs) |
| `spawn_single_component` | n/a | 1.87x |
| `insert_single_component` | n/a | 1.45x |
| `structural_churn_insert_remove` | n/a | 1.49x |
| `remove_single_component` | n/a | 0.87x |

Controls did not move, as they should not: `query_static_single_component`
1.00x, `raw_slice_ceiling` 1.00x, `dense_query_iteration` 3.93x, and in
Archetype Core #32 `query_static` 94.3µs against the raw one-field floor
at 93.8µs (N=100,000) with the two-column ratio at 3.99x. No
compilation-unit shift showed up in them.

Two structural groups reached parity, and `spawn_n_entities_two_components`
moved from ~2x to 1.72x: the prediction held there, and the drop in
`remove_bundle`'s own time (1.0674ms in build #20, 714µs here) is close
to the sandbox's ~30% instruction reduction, with the usual caveat that
absolute time across builds carries runner drift.

**The miss: `get_component_random_access`.** Per lookup, mid-ecs took
36.2ns against bevy_ecs's 7.6ns in the same run. The sandbox predicted
the opposite direction: instructions per lookup 218 -> 113, and isolated
wall-clock `get_static` 17.3ns -> 7.1ns (rustc 1.91.1, `bench`-style fat
LTO with 1 CGU, 2.1GHz Xeon, 10,000 sequential lookups, best of several
runs). So CI's mid-ecs number is roughly 5x the sandbox's after-number
for the same source, while bevy_ecs measures 7.6ns on that same runner,
and, if the ~2.7x on record was right, it is slower than before the
change rather than faster. Not explained. Ruled out from source: the
`TypeIdHasher` byte fallback (rustc 1.98's `TypeId::hash` calls
`write_u64` on one half of the id, read directly from
`library/core/src/any.rs` at CI's compiler commit). The structural
groups go through the same `TypeId` map (`existing_component_ids`) and
improved, so the hasher itself is not the problem.

Diagnostic built for it (see `diag_ir_ops.rs` below):
`scripts/diag_ir_ops_ab.py`, driven by
`.github/workflows/diag-ir-ops.yml`. It builds the example twice on one
CI machine and toolchain, once from the current tree and once with
`archetype.rs`/`lib.rs` reverted to the last pre-fix commit, then
reports callgrind instructions per operation (deterministic, on
rustc 1.98.1) and isolated wall-clock ns per lookup for both. The
outcomes it separates: instructions high on 1.98.1 means codegen
differs from the sandbox and the callgrind function list shows where;
instructions ~113 with isolated time near the sandbox's means the
36ns comes from the full bench binary (compilation-unit effect, the
same shape as the `Iter1` story); instructions ~113 with isolated
time also slow means the machine, not the instruction count, is the
cost.

**A/B outcome (`diag Ir/op A/B` builds #1 and #2, rustc 1.98.1, commit
`d395f26`): the second one.** On CI's own toolchain the fix does what
the sandbox said. Build #1 is the `bench` profile (Intel Xeon Platinum
8370C @ 2.80GHz), build #2 is `bench-nolto` (AMD EPYC 7763):

| op | #1 prefix Ir | #1 current Ir | #1 ratio | #2 prefix Ir | #2 current Ir | #2 ratio |
|---|---|---|---|---|---|---|
| get | 213.0 | 109.0 | 0.51x | 218.0 | 116.0 | 0.53x |
| insert | 1129.7 | 665.7 | 0.59x | 1213.3 | 803.3 | 0.66x |
| remove | 1052.1 | 591.6 | 0.56x | 1313.7 | 903.7 | 0.69x |
| spawn | 1197.1 | 734.1 | 0.61x | 1316.3 | 906.3 | 0.69x |

Isolated `get_static` wall-clock, prefix -> current: 16.28ns -> 7.54ns
per lookup (162.8µs -> 75.4µs per 10,000) in `bench`, 16.41ns ->
8.79ns (164.1µs -> 87.8µs) in `bench-nolto`. The isolated "current"
figure, 75.4µs, is what bevy_ecs measured in the full bench (75.6µs,
build #25). So the code path is not the problem: the full
`vs_bevy_ecs` binary, or the way it was run, makes mid-ecs's identical
lookup take ~4.8x longer. Also of note, the isolated *prefix* time
(~163µs) is close to the ~204µs the full bench showed before the fix
(~2.7x on record), so the full-bench penalty was ~1.25x before and is
~4.8x after; whatever it is, it grew with this change or with
something else that changed alongside it (nothing else touched
`get_static`'s path, per the diff between `68500e6` and `ce6ce32`).

Heap-layout sensitivity was checked in the sandbox and is not it there:
`get_static` stayed at 7.0-7.3ns across allocation padding from 0 to
512KB and with heavy allocator churn before the world was built
(CI's CPUs were not checked).

Remaining candidates, none yet tested: criterion and the bench-file
structure; the other groups having run first in the same process;
bevy_ecs linked into the same fat-LTO unit; both worlds alive at once.
`get_bisect.rs` (below) adds them back one at a time.

**Outcome of the bisect, and the re-run.** `ecs-vs-bevy-ecs` re-dispatched
unchanged at `270cf72` (build #26) measured `get_component_random_access`
at 85.0µs against bevy_ecs's 73.0µs, 1.16x, where build #25 had 362.2µs
and 4.79x. So #25 was the runner, not the code. The bisect (`diag get_component_random_access bisect`
builds #1 and #2, same commit) says what varied:

| | #1 `bench`, AMD EPYC 9V74 | #2 `bench-nolto`, AMD EPYC 7763 |
|---|---|---|
| mid-ecs, bevy world not built yet | 255.9µs | 87.4µs |
| mid-ecs, both worlds alive | 264.7µs | 87.5µs |
| bevy_ecs, same binary | 50.5µs | 66.5µs |
| real bench filtered to this group, mid-ecs | 255.5µs | 85.8µs |
| real bench filtered to this group, bevy_ecs | 58.9µs | 73.4µs |
| callgrind Ir per lookup, mid-ecs / bevy_ecs | 109 / 88 | 116 / 94 |

Per 10,000 lookups. The bevy world's presence, criterion, and other
groups having run first all make no difference on either machine
(alone ~ alive ~ filtered bench). The CPU does: the same 109
instructions take ~255µs on the EPYC 9V74 and ~85µs on the EPYC 7763
(and ~75µs on the Xeon 8370C in `diag Ir/op A/B` build #1, ~84µs on the
7763 in build #3), while bevy_ecs runs *faster* on the 9V74 than on the
7763. So mid-ecs's `get_static` has a CPU-specific penalty of about 3x at
equal instruction count on that machine, and bevy_ecs's lookup does not.
Build #25's CPU was not recorded (the bench summary header carried no
CPU field), so that it ran on such a machine is consistent with the data
but unproven. The mechanism is unknown. One untested candidate: the two
virtual calls per lookup (`Column::as_any`, then the `downcast_ref`'s
`type_id`), which bevy_ecs does not make, interact badly with that
core's indirect-branch handling; removing them is already a candidate on
instruction count alone. Testing it needs the variant built and a
runner on the affected CPU, which CI does not let us choose (run
identical jobs in a matrix and read the CPU column).

Consequence for reading any bench in this repo: compare ratios within a
run, and note the CPU. `bench-vs-bevy-ecs.yml`'s summary header now
prints it. Other runners seen so far: Intel Xeon Platinum 8370C @
2.80GHz, AMD EPYC 7763, AMD EPYC 9V74.

**State after build #26** (ratios vs bevy_ecs; before = last figure on
record): `insert_bundle_on_existing_entity` ~1.6x -> 0.92x,
`remove_bundle_two_components` 1.48x -> 0.84x, `get_component_random_access`
~2.7x -> 1.16x, `spawn_n_entities_two_components` ~2x -> 1.24x,
`remove_single_component` 0.84x, `structural_churn_insert_remove` 1.29x,
`insert_single_component` 1.37x, `spawn_single_component` 1.71x,
`dense_query_iteration` 3.98x (parked, see the `Iter2` entries above).

### `diag_ir_ops.rs`

`examples/diag_ir_ops.rs`, kept for reference like `diag_alloc_count.rs`.
Counts *instructions* per operation under callgrind, for gaps that
allocation counts cannot see. Modes `get`, `insert`, `remove`, `spawn`
mirror `vs_bevy_ecs.rs`'s workloads (same N, shapes, call sequence);
second argument `0` runs setup only, `1` runs setup plus the measured
op, and the op's cost is the difference between the two runs' totals.
Usage is in the file's own header. Deterministic for a given binary,
so it can rank changes without a CI round trip; it does not replace
CI timing. Extra mode `time-get` prints isolated wall-clock ns per
`get_static` lookup (best of 7 repetitions of 300 passes over 10,000
entities), with nothing but `mid-ecs` in the binary.

`scripts/diag_ir_ops_ab.py` builds the example for the current tree
and for a tree with `archetype.rs`/`lib.rs` reverted to `--prefix-sha`
(restoring the working tree afterwards), then runs callgrind on the four
modes and `time-get` on both, on one machine, and prints a markdown
report with per-function self cost for `get` and `insert`.
`strip = false` is forced through
`CARGO_PROFILE_<NAME>_STRIP`, because the workspace's `bench` profile
inherits `release`'s `strip = true` and callgrind would otherwise
report raw addresses. `.github/workflows/diag-ir-ops.yml`
(`workflow_dispatch` only, like every workflow here) runs it on CI with
valgrind installed and uploads the callgrind outputs. Its numbers depend on the build profile: the table above
was taken with lto off and 16 CGUs, the workspace `[profile.release]`
(fat LTO, 1 CGU) gives different absolute counts, so only compare
runs taken with the same profile.

### `get_bisect.rs`

`benches/ecs-vs-bevy-ecs/examples/get_bisect.rs`, driven by
`scripts/diag_get_bisect.py` and
`.github/workflows/diag-get-bisect.yml`. Built because the A/B above
showed the fix works in isolation while the full bench still reports
mid-ecs's `get_component_random_access` at 36.2ns per lookup. The
isolated binary has nothing but mid-ecs in it; the real bench has
criterion, every other group, and bevy_ecs in one fat-LTO unit. This
binary contains mid-ecs AND bevy_ecs (both worlds built, same order and
shapes as `bench_get_component_random_access`) and no criterion.

The driver, on one machine and toolchain: (1) `get_bisect time`: mid
lookup ns with the bevy world not yet built, then with it alive, and
bevy's own lookup; (2) callgrind instructions per lookup for both
engines in that binary, with per-function self cost for mid-ecs (the
isolated binary gives 109); (3) the real `vs_bevy_ecs` bench filtered to
that one group, so no other group runs first in the process.

How to read it: example fast and filtered bench fast means earlier
groups' history (or build #25 was a transient run); example fast and
filtered bench slow means criterion or the bench file's structure;
example slow with the "alone" figure fast means the bevy world's
presence; example slow with "alone" slow and instructions above 109
means bevy in the LTO unit changed mid-ecs's codegen (the function list
says where); example slow with instructions near 109 means the machine,
not the instruction count. Locally the driver was tested end to end
against a stub package with a minimal stand-in for `bevy_ecs` (bevy 0.19
needs rustc 1.95+, the sandbox has 1.91): the mid-ecs half, callgrind
flow, timing and criterion parsing ran for real; the few lines of real
`bevy_ecs` API in the example (the import, `#[derive(Component)]`,
`World::new`, `spawn(..).id()`, `get`) mirror `vs_bevy_ecs.rs` and have
not been compiled outside CI.

### Single-component structural paths: `StorageClaims` hasher and boxing-free migration

After the bundle groups reached parity (`ecs-vs-bevy-ecs` build #26),
the single-component groups were the largest structural gaps
(`spawn_single_component` 1.71x, `insert_single_component` 1.37x,
`structural_churn_insert_remove` 1.29x, `remove_single_component` at
parity). Allocation counts (`diag_alloc_count.rs`, scenarios 4-7 added
for this) split them into two kinds: `spawn_single` and `insert_single`
were already ~0 allocs/op, so their gap was compute; `remove_single`
made 1.001 allocs/op and churn 2.001, so those were boxing.

**Cause 1, compute: `StorageClaims::claim`.** Every `insert_static`
(and the Sparse Shell `insert`) calls it. It was a
`std::collections::HashMap<TypeId, StorageKind>` (SipHash) doing a `get`
and then an unconditional `insert` (a second hash and a write) even
when the claim was already recorded: ~265 of `insert_static`'s ~692
instructions. `insert_bundle`/`remove_bundle` do not go through claims
(the limitation `StorageClaims`'s own doc comment already names), which
is why the bundle groups reached parity while the single-component ones
did not. Fix: `TypeIdMap<StorageKind>` (the `hash.rs` hasher) and only
insert when absent. Semantics are unchanged: the first system a type is
used with is recorded, same-system repeats are no-ops, the other system
panics.

**Cause 2, allocation: boxed migration.** Every component value moved
between archetypes went through `Column::swap_remove_and_forget`
(returning `Box<dyn Any>`) and `Column::push_any`: one heap allocation
per moved component per structural change. `remove_static` also boxed
the removed value just to downcast it straight back. Fix:
`Column::move_row_to(row, dest: &mut dyn Column)` swap-removes the value
and pushes it onto `dest` with both ends typed inside the one generic
impl (`dest.as_any_mut().downcast_mut::<Vec<T>>()`), still with no
`unsafe`. `Archetypes::remove` takes the removed value out with a typed
`swap_remove`. `swap_remove_and_forget` and `push_any` are deleted. All
four migration sites (`insert`, `remove`, `insert_bundle`,
`remove_bundle`'s survivors) use `move_row_to`. `scratch.rs` stays as
standalone infrastructure, but the cost it was built for is gone; its
doc comment now says so.

**Sandbox result (rustc 1.91.1, callgrind Ir per operation, `bench`
profile, N=10,000, before = `270cf72`):**

| operation | before | claim fix only | both | change |
|---|---|---|---|---|
| `spawn_single` (spawn + `insert_static`) | 853.3 | 589.4 | 586.4 | -31% |
| `insert_single` (`insert_static`) | 692.4 | 428.4 | 425.9 | -38% |
| `remove_single` (`remove_static`) | 499.0 | 499.0 | 344.5 | -31% |
| `churn_single` (insert + remove `Marker`) | 1499.6 | 1246.6 | 916.6 | -39% |
| `get_static` | 113.0 | 113.0 | 113.0 | 0 (control) |
| `insert_bundle` | 711.2 | n/a | 692.7 | -3% |
| `remove_bundle` | 732.1 | n/a | 729.1 | 0% |
| spawn + `insert_bundle` | 789.2 | n/a | 784.2 | -1% |

Allocations per op (`diag_alloc_count.rs`): `remove_single_component`
1.001 -> 0.001, `structural_churn_insert_remove` 2.001 -> 0.001; the
others were already ~0 and stay there. The bundle groups barely move
because they never used claims and their survivor in the benchmark is a
zero-sized `Marker`; they and `get_static` are the controls.

Tests: 192 default, 197 with `scratch-arena` (six new). The new tests
use archetype-tracked (`insert_static`) survivors, which the older
`remove_bundle` migration test does not: it inserts its survivor
through the Sparse Shell's `insert`, so it never reached the archetype
migration loop. They cover value preservation across swap-removes,
`remove_static` returning the right value while survivors migrate, each
value dropped exactly once (moved, never dropped, by migration; dropped
once on despawn; handed back undropped by `remove_static`), and the
bundle insert/remove survivor paths. They were also run against the
pre-change code and pass there, so they check behaviour, not the new
implementation.

**What is left in `insert_single` (425.9 Ir):** `World::insert_static`
self ~232 (inlines `is_alive`, the claim lookup, `component_id`, and the
body of `Archetypes::insert`), `edge_for_insert` 65, the location
`SparseSet::insert` 43, `get_two_mut` 40. Two structural candidates, not
started: entity lookups happen twice (`World::is_alive`, then
`locations.get`), and `spawn` followed by `insert_static` writes the
entity's location twice and hops through the empty archetype, where
bevy's `spawn(bundle)` writes it once. A direct spawn-with-components
API would remove that hop for `spawn_single` and
`spawn_n_entities_two_components`; the bench file's own note that
`spawn` is not perfectly apples-to-apples is about exactly this.

**Not yet run on real CI.** To read against: `spawn_single_component`,
`insert_single_component`, `structural_churn_insert_remove` and
`remove_single_component` should fall; the bundle groups, `get` and the
query groups should not move (controls). Note the runner CPU in the
summary header (added in `bench-vs-bevy-ecs.yml`) before comparing to
build #26 (1.71x, 1.37x, 1.29x, 0.84x); ratios within one run are the
comparison.

`diag_ir_ops.rs` gained modes `spawn1`, `insert1`, `remove1`, `churn1`
for these four groups, and `scripts/diag_ir_ops_ab.py` measures them
and now reverts `world.rs` as well as `archetype.rs`/`lib.rs` for its
"prefix" build (needed because this change touches `world.rs`).

### Direct bundle spawn: `World::spawn_bundle`

Real CI (`ecs-vs-bevy-ecs` build #28, commit `55caf87`) confirmed the
`StorageClaims`/`move_row_to` fix: `spawn_single_component` reached
parity (1.71x -> 1.00x), `insert_single_component` and
`remove_single_component` now measure *faster* than bevy_ecs (0.79x,
0.57x), `structural_churn_insert_remove` too (0.82x). Controls held:
`get_component_random_access` 1.17x, matching build #26's 1.16x, not
the CPU-dependent ~4.8x outlier; bundle groups and queries flat. Full
numbers in the "State after build #26" entry above, now superseded by
build #28's.

One real gap was left: `spawn_n_entities_two_components` at 1.30x,
unmoved by that fix, because `insert_bundle` never goes through
`StorageClaims` (`StorageClaims`'s own doc comment already names this
as a known, deliberate limitation). The benchmark's own top doc
comment already named the actual cause: bevy's `World::spawn(bundle)`
places an entity directly into its final archetype in one call;
mid-ecs's closest equivalent was `World::spawn()` (into the empty
archetype) then `World::insert_bundle(e, bundle)` (one migration back
out) — every call pays for a stop nothing ever reads. Concretely: the
entity's row and location are written twice, `get_two_mut` fetches two
archetypes when only one is ever touched, and the (trivially empty,
but not free) column-migration loop runs once for no reason, since a
fresh entity's "from" archetype never has columns.

**Fix:** `Archetypes::spawn_bundle` walks the same `edge_for_insert`
chain `insert_bundle` does, but starting cold from `EMPTY_ARCHETYPE`
with no location or table row written until the real destination
archetype is known — one row push, one `push_into`, one location
insert. `World::spawn_bundle<B: Bundle>(&mut self, bundle: B) -> Entity`
is the public entry point, the direct counterpart to bevy's
`spawn(bundle)`. Infallible, unlike `insert_bundle`: a brand-new entity
can never already hold one of `B`'s components, so there's no failure
case. Bypasses `StorageClaims` — same as `insert_bundle`, an existing,
already-documented decision, not something this pass changed.

**Sandbox result** (rustc 1.91.1, callgrind Ir per op, `bench` profile,
N=10,000, two-component bundle): the two-call path (`World::spawn` +
`insert_bundle`) costs 833.2 Ir/op; `spawn_bundle` costs 614.6, a 26%
drop. Self cost that disappears entirely: `World::insert_bundle`'s own
162 Ir, `get_two_mut` 40, and roughly half of the location `SparseSet`
insert (113 -> 69, one insert instead of two). `diag_ir_ops.rs` gained
mode `spawnbundle` for this measurement, compared against the existing
`spawn` mode (same two-component bundle, old two-call path).

**New bench group, not a replacement for the old one.**
`spawn_n_entities_two_components` (`World::spawn()` + `insert_bundle`)
is left exactly as-is — the benchmark's own doc comment already treats
that gap as real and worth measuring honestly, not something to hide
by quietly swapping in the faster call. `spawn_bundle_direct`
(`benches/ecs-vs-bevy-ecs/benches/vs_bevy_ecs.rs`) is the new, now-fair
comparison: mid-ecs's `World::spawn_bundle` against bevy's
`World::spawn(bundle)`, same shape as every other single-call
`bench_*` group added earlier. Registered in the same
`criterion_group!` list. The bench file's own top doc comment on
`spawn` is updated to point at this new group as the apples-to-apples
one instead of asserting there is no equivalent.

**Tests:** 198 default (six new — value/count/archetype-sharing checks,
a drop-once check via a `Drop`-tracking type, and one test that
`spawn_bundle` and `spawn()`+`insert_bundle()` for the same bundle type
land in one shared archetype, not two accidentally-distinct ones —
`edge_for_insert` is shared code between both paths, but this is the
only test that actually exercises them landing on the same archetype
together, via a real `query2_static` scan across both). 203 with
`scratch-arena`.

**Not yet run on real CI.** Expected: `spawn_bundle_direct` should be
close to or at parity with bevy_ecs (the earlier bundle-path fixes
already closed `insert_bundle_on_existing_entity` and
`remove_bundle_two_components` under the same `StorageClaims`-free,
`move_row_to`-based machinery, and this removes the one remaining
structural difference `spawn_bundle_direct` specifically measures).
`spawn_n_entities_two_components` is not expected to move — it still
exercises the two-call path on purpose. Note the runner CPU (once the
still-unapplied `bench-vs-bevy-ecs.yml` CPU-header edit lands) before
reading `get_component_random_access` on this run.

**What's left in `spawn_bundle` (Ir breakdown):** `edge_for_insert` 130,
`Bundle::push_into` 112, `__memcpy` (copying `Position`/`Velocity`
into their columns) ~100, `Bundle::component_ids` 93 (still a `TypeId`
lookup per component, per call — a per-`Bundle`-type cache, keyed once
rather than once per component, is the next structural candidate here,
mirroring bevy's own `bundle_ids: TypeIdMap<BundleId>` read from its
0.19.1 source earlier in this doc), location `SparseSet::insert` 69.

### `filter.rs`: `With` / `Without` / `Or` query filters

**What it does:** Narrows which archetypes a query on the Archetype Core
visits, without adding anything to the query's item. `With<T>` keeps an
archetype only if `T` is in its signature, `Without<T>` only if it is not,
a tuple `(F1, F2, ...)` (up to eight members) only if *every* member does,
and `Or<(F1, F2, ...)>` (also up to eight members) only if *any* member
does. `()` means no filter.

```rust
// Every (Entity, &Position) whose archetype holds `Player` and not `Frozen`.
world.query_static_filtered::<Position, (With<Player>, Without<Frozen>)>()
```

Four new `World` methods, one per unfiltered Archetype Core query, with the
filter as the last type parameter: `query_static_filtered`,
`query2_static_filtered`, `query_static_ref_filtered`,
`query2_static_ref_filtered`. They are separate methods and not a defaulted
type parameter on the existing ones because Rust does not infer a
function's type parameter from a default, so adding `F` to `query2_static`
would break every existing `query2_static::<A, B>()` call site.
`With`, `Without` and `QueryFilter` are re-exported from the crate root.
The runtime, id-based form for callers without Rust types is
`World::archetypes_matching_static`, exposed over C; see the next section.

**Where it plugs in.** Every query iterator (`Iter1`, `Iter2`, `Iter1Ref`,
`Iter2Ref`) takes one input from outside: the `matched: Vec<ArchetypeId>`
list built when the query is created. A filter only changes how that list
is built (`Archetypes::matched_filtered` in `archetype/iter.rs`, one pass
over every archetype's signature). The iterators themselves are untouched
and are the same types the unfiltered queries return. That matters
because the `next()` bodies in `iter.rs` are held byte-for-byte fixed (see
that file's header and the LTO inline-budget findings above), and it is why
a filtered query pays nothing per row.

**Ported from bevy, read directly, not from memory.** `With`, `Without`
and the tuple impl's `matches_component_set` in `query/filter.rs` and
`query/world_query.rs` of `Mid-D-Man/bevy` (currently `0.20.0-dev`; the
bench crate pins the published `0.19.1`, so this is a source-reading
reference only). Same shape: filter state resolved once per query, a
`matches_component_set` check per candidate archetype, tuples combine with
AND.

**Where it differs from bevy, and why:**

- *No registration on a read path.* Bevy's `init_state` registers the
  filter's component if it is new. `Archetypes` does not spend a
  `ComponentId` on a type just because something asked about it (see
  `existing_component_id`), so a leaf filter's state is
  `Option<ComponentId>`. `None` has a defined meaning: `With<T>` on a type
  nothing archetype-tracked has ever held matches nothing, and
  `Without<T>` on it matches everything. No archetype can contain a type
  that has no id, so both are correct by construction. A test checks that
  asking does not register the type: a later real insert of it is still
  found.
- *Sealed, no `unsafe`.* Bevy's `QueryFilter` is an `unsafe trait` because
  implementors make access-soundness claims. Nothing here touches
  component data, so there is no `unsafe`. The trait is sealed instead,
  which leaves room to change its shape later without breaking anyone.
- *Archetype half only.* Bevy's trait splits filters into archetypal ones
  (`IS_ARCHETYPAL`, resolved per archetype) and per-row ones (`Changed`,
  `Added`, which call `filter_fetch` per entity and need change-detection
  ticks on columns). This trait has only the archetypal half. `Changed`
  and `Added` are *not* implemented as `QueryFilter`s — they exist, but as
  their own dedicated `World` methods, entirely outside this trait; see
  `tick.rs` below for why, and what "outside this trait" actually means
  for how they compose with `With`/`Without`/`Or` today (it doesn't, yet).

**`Or`: OR-semantics tuples.** `Or<(F1, F2, ...)>` wraps a tuple the same
way the plain tuple impl does, but evaluates it with OR instead of AND.
That needed a second trait, `OrFilterGroup` (sealed, implemented only for
tuples of `QueryFilter` up to eight members by
`impl_or_filter_group_for_tuple!`), because the plain tuple `QueryFilter`
impl's own `matches_component_set` is hard-coded to AND — `Or` can't just
call it. `OrFilterGroup::any_matches` is the OR version of that same
check; `Or<T: OrFilterGroup>`'s own `QueryFilter` impl is a two-line
wrapper delegating to it. `Or` is itself a `QueryFilter`, so it composes
with everything else: `(Or<(With<A>, With<B>)>, Without<C>)` is `(A or B)
and not C`, and `Or` can nest inside `Or`. Read directly from bevy's own
`Or<T>` (`query/filter.rs`) for the shape (a tuple's states ORed together
via a second per-member check, not the tuple's own AND check) — this
crate's version differs the same two ways the plain tuple version does
(sealed instead of `unsafe`, no registration on a read path), for the same
reasons. `Or<()>` has no impl and does not compile — there's no sensible
"any of nothing" reading to pick, and nothing needs it.

`archetypes_matching`/`archetypes_matching_static`/
`mid_ecs_world_archetypes_matching_static` (below) all gained a third
`any_of` list for `Or`'s id-based counterpart, in the same pass — this
crate's stated policy for the FFI surface (each new ECS feature ships its
C counterpart alongside it, not as an afterthought).

**Scope limits, on purpose:**

- *Archetype Core only.* The Sparse Shell has no archetype signature to
  test. A `With`/`Without` there would be a per-entity lookup, a different
  cost model, and `query2` already works that way (drive off one storage,
  check the other per entity).
- *Archetype-tracked components only.* A type that only ever lived in the
  Sparse Shell has no `ComponentId` in the Archetype Core's numbering, so
  `With` of it matches nothing. The two storage systems stay independent.
  This is tested (`filter_on_a_sparse_shell_only_type_matches_nothing`)
  and is a silent footgun if forgotten, so it is stated in the module doc
  comment too.

**Measured (sandbox, rustc 1.91.1, callgrind Ir, `bench` profile).**
`query2_static_ref` and its filtered forms over 10,000 entities (5,000
with a `Marker`, 5,000 without, two archetypes with rows plus zero-row
intermediates from `spawn_bundle`), 200 passes per run, setup subtracted:

| Query | Ir per row |
|---|---|
| `query2_static_ref` (unfiltered) | 43.07 |
| `query2_static_ref_filtered::<_, _, ()>` | 43.07 |
| `..._filtered::<_, _, With<Marker>>` (5,000 rows/pass) | 43.11 |
| `..._filtered::<_, _, Without<Marker>>` (5,000 rows/pass) | 43.11 |

Creating a query (2,000 creations, `.take(0)`): 402 Ir unfiltered, 410 Ir
with `With<Marker>`. Both are timing-independent instruction counts, not a
CI timing result, and the sandbox has never reproduced the x86_64 iteration
gap seen on CI (`dense_query_iteration`, ~4x), so this shows the filter adds
no per-row work, not what the absolute per-row cost is on CI hardware. One
caveat on the bench: `bevy_query` is built once outside the timed loop,
while mid-ecs builds its matched list inside it on every iteration
(~400 Ir per query, about 0.2% of a 5,000-row pass). Bevy caches matched
archetypes in `QueryState`; mid-ecs does not, and would only need to if
query creation ever shows up in a profile.

**Tests:** 225 default (27 new) at first delivery, 230 with
`scratch-arena`, plus one compiled doctest on `query_static_filtered`. 11
tests in `filter.rs` cover the leaf and tuple logic without a `World`
(unregistered types, empty signatures, contradictory tuples, nested
tuples, the eight-member arity). 16 tests in `query.rs` cover all four
`World` methods across four distinct archetypes, `()` matching the
unfiltered query exactly including order, `With` and `Without`
partitioning the unfiltered result, results following
`remove_static`/`insert_static`/`despawn`, and zero-row intermediate
archetypes left behind by `insert_bundle` (a `Without` filter matches
those and must contribute nothing and not panic). `Or` added 8 more tests
in `filter.rs` (any-member matching, one-member and nested `Or`, `Or`
composing inside a tuple, the eight-member arity, an unregistered member
inside `Or` not poisoning the whole filter the way it would inside a plain
`With` tuple) and one `query.rs` test proving `Or` needed no new `World`
method — it's a `QueryFilter` like any other, so it works through
`query_static_filtered` unmodified.

**Bench:** new group `filtered_query_iteration` in
`benches/ecs-vs-bevy-ecs/benches/vs_bevy_ecs.rs`, mid-ecs's
`query2_static_ref_filtered::<Position, Velocity, (With<Marker>,
Without<Frozen>)>` against bevy's `Query<(&A, &B), (With<M>, Without<F>)>`.
Three populations (5,000 `Marker`, 2,500 plain, 2,500 `Marker` + `Frozen`)
so both leaves exclude something; the query visits the first 5,000. Setup
asserts both engines return exactly 5,000 rows before timing. Uses the
entity-free `(&A, &B)` shape, the one bevy's own query yields, so it is not
comparable to `dense_query_iteration`'s numbers (10,000 rows, entity
carrying).

**CI result (build #31, commit `06bef2c`, the first run with the CPU line in
the header).** The bevy half compiled on the first try. Ratio and per-row
cost of `filtered_query_iteration` (mid-ecs, `Iter2Ref`, 5,000 rows) next to
`dense_query_iteration` (mid-ecs, `Iter2`, 10,000 rows):

| Platform (CPU) | filtered ratio | dense ratio | mid-ecs ns/row, filtered | mid-ecs ns/row, dense |
|---|---|---|---|---|
| x86_64 (AMD EPYC 9V45) | 6.1x | 6.0x | 2.75 | 2.70 |
| macOS (Apple M1, virtual) | 3.06x | 0.94x | 3.15 | 1.15 |
| aarch64 (Neoverse-N2) | 4.12x | 1.25x | 2.93 | 0.89 |

The prediction above (same ratio as `dense_query_iteration` on each platform)
held on x86_64 and did not hold on macOS or aarch64. The filter is not the
cause. Evidence, all sandbox instruction counts (callgrind, `bench` profile,
rustc 1.91.1):

- In one binary, `query2_static_ref`, the `()` filter, `With<Marker>` and
  `Without<Marker>` cost 43.07, 43.07, 43.11 and 43.11 Ir per row. The
  filter adds nothing per row.
- The identical `With`/`Without` loop as the only query in its binary costs
  15.13 Ir per row. Adding one unrelated `assert_eq!(query.count(), 5000)`
  to `main` moves the same loop to 43.15 Ir per row. Built with symbols
  (`CARGO_PROFILE_BENCH_STRIP=none`), the slow binary shows
  `Iter2Ref::next` as an out-of-line function taking 32 Ir per row, plus 10
  Ir per row in the loop; the fast one inlines it.
- Keeping `matched_filtered` out of line (`#[inline(never)]`) changed
  nothing, so it is not the filter's own code being inlined or not.

That is the mechanism this file's own history already records (the whole
program inliner declines to resolve `next()` once the surrounding
compilation unit is large or crowded enough, see the `iter.rs` header), now
reproduced on demand in the sandbox with instruction counts, which the
earlier x86 investigation could not do. Two consequences worth keeping:
per-row cost of the same iterator varies about 3x with unrelated code in
the same binary, so a criterion group's ratio here says as much about the
bench binary's layout as about the iterator; and on the same Neoverse-N2
hardware class `dense_query_iteration` mid-ecs went from 7.49 us (build #30)
to 8.91 us (build #31) while bevy stayed at 7.11 us, after only code was
added (this group, the filter API). No iterator was changed. The x86_64 gap
also depends on the CPU tier: on the EPYC 9V45 the raw-slice floor and bevy
run about 2.1x faster than on the earlier EPYC 7763 (9.4 us to 4.5 us for
dense), while mid-ecs runs about 1.4x faster (37.4 us to 27.0 us), which
turns the ~4x gap into 6x.

### FFI: filtered archetype enumeration, and a `raw_span` fix

**Scope rule for FFI on new ECS features.** Each new ECS feature ships
with its C counterpart in the same pass, scoped the way the existing
surface already is:

- Component types are registered from Rust (`register_ffi_*`, generic, so
  it cannot be `extern "C"`) and C refers to them by name, then by the
  `uint32_t` id the lookup returns.
- Read-only. C walks archetypes and reads spans, and there are no
  iterator handles and no write access from C. Nothing here changes the
  existing safety story: a span is valid only until the next structural
  change to the world.
- Same structural semantics as the Rust side, with a test that runs both
  and compares them.

**What was added.** `Archetypes::archetypes_matching(with, without, any_of)`
and `World::archetypes_matching_static(with, without, any_of)` list every
archetype whose signature contains all of `with`, none of `without`, and —
if `any_of` is non-empty — at least one of `any_of`. Over C:

```c
int32_t mid_ecs_world_archetypes_matching_static(
    const MidEcsWorld *world,
    const uint32_t *with_ids, size_t with_len,
    const uint32_t *without_ids, size_t without_len,
    const uint32_t *any_of_ids, size_t any_of_len,
    uint32_t *out_buf, size_t out_buf_capacity);
```

It follows the conventions of `mid_ecs_world_archetypes_with_static_component`:
a NULL `out_buf` returns the count, a too-small buffer returns
`MID_ECS_BUFFER_TOO_SMALL` with nothing written, and it never returns
`MID_ECS_NOT_FOUND`. Each id list may be NULL only when its own length is
0. The semantics are structural: archetypes with zero rows are included,
an id that names no registered component matches nothing in
`with_ids`/`any_of_ids` and is ignored in `without_ids`, an id in both
`with_ids` and `without_ids` matches nothing, and `with_ids`/`without_ids`
both empty with `any_of_ids` also empty matches every archetype (the empty
archetype included). An empty `any_of_ids` is "no `Or` constraint", not
"match nothing" — the same reading `Or`'s own Rust side has no typed
spelling for (see the `filter.rs` section above). Include the component to
be read in `with_ids`, since an archetype that lacks it answers `raw_span`
and `entity_ids` with `MID_ECS_NOT_FOUND`.

**`any_of_ids`/`any_of_len` were added to this function's signature when
`Or` landed on the Rust side**, inserted before `out_buf` — a breaking
signature change to a function that had already shipped, not a second
function. This project's own convention: the C surface is redelivered in
full with every change, never frozen against a stable ABI mid-development,
so extending an existing signature and updating every call site in the
same pass (the 7 in `ffi.rs`'s own tests, plus `test.c`) costs the same as
adding a parallel function, without leaving two ways to do the same thing.
Every existing call site (this crate's own tests included) needed the two
new arguments added — `NULL, 0` where unused.

This is the same set of archetypes the typed `*_static_filtered` queries
visit. A test builds one world, runs eight filter combinations through both
the typed queries and the C entry point, and requires identical entity
sets.

`mid_ecs_test_filter_fixture_world_new` (with `MidEcsTestFlagA` and
`MidEcsTestFlagB`) is a second test-only fixture, like the existing one,
because a pure C program cannot register types or insert components. Three
entities in three archetypes, one of them built with a bundle in an order
that leaves zero-row intermediate archetypes behind.

**Bug found while building this, and fixed: `raw_span` on a column-less
archetype.** `Archetypes::raw_span` returned `None` (`MID_ECS_NOT_FOUND`
over C) for an archetype whose signature contains the component but has no
column for it yet. Such archetypes exist: `insert_bundle` and
`spawn_bundle` walk `edge_for_insert` once per bundle element, so a bundle
`(A, B)` creates `{A}` on the way to `{A, B}`, and no entity is ever moved
into `{A}`, so it never gets a column. `archetypes_with` (and so
`mid_ecs_world_archetypes_with_static_component`) lists `{A}` because the
signature matches. A C caller walking that list therefore got
`MID_ECS_NOT_FOUND` from `raw_span` for an id the library had just handed
out, while `entity_ids` on the same archetype returned an empty list, so
the two per-archetype calls disagreed. This contradicts the contract
`raw_span`'s own doc comment already stated (a signature that includes the
component is `Some` with `count == 0` when empty). The typed query
iterators already tolerated the column-less case (`Iter1::next` treats a
missing column as an empty slice), so only the FFI path was affected.

The fix is in `raw_span`: when the column is missing but the signature
contains the component, return the empty span. A signature that does not
contain the component still returns `None`, unchanged. Reproduced first
with a probe (two archetypes listed for `A`, `raw_span` `None` on the
first), then covered by three tests that fail without the fix (checked by
reverting it): one at the `Archetypes` level, and two through the C
surface, one of which walks every enumerated archetype and requires `OK`
from `raw_span`.

**Tests (first delivery, `With`/`Without` only):** 237 default (12 new: 6
at the `Archetypes` level covering `archetypes_matching` and the
`raw_span` cases, 6 through the C surface covering the expected archetype
counts, `raw_span` on every enumerated archetype, typed-versus-FFI parity,
the buffer idiom, the NULL cases, and bogus and contradictory ids). The C
smoke test gained 13 checks and compiles clean under `-Wall -Wextra`; it
ran against a debug `libmid_ecs.so` in the sandbox and all checks passed.

**Tests added for `any_of` (`Or`).** 2 more at the `Archetypes` level
(`any_of` requiring at least one match, combined with `with`/`without`; an
empty `any_of` behaving exactly like the pre-`any_of` function), 1 more
through the C surface (`matching_static_any_of_matches_the_typed_or_filter`:
`any_of` matching the typed `Or<(With<A>, With<B>)>` filter exactly via
`entities_via_ffi` extended with an `any_of` parameter, an empty `any_of`
matching the plain call, and `any_of` naming only a never-registered id
matching nothing), plus the NULL case for `any_of_ids` with a non-zero
length added to the existing NULL-pointer test. `test.c`'s own `WALK`
macro gained an `any_of` pair of arguments, plus three new checks: `with
{Health} any_of {FlagA, FlagB}` — 3 archetypes, not 2, because the
zero-row `{FlagB, Health}` intermediate has `FlagB` in its own signature
too and so still counts, a fact this project's own earlier
`archetypes_with` tests had already established but this delivery's first
draft of the new check forgot, caught by actually compiling and running
it (real gcc, real link, real failure) rather than predicting the
number — an empty, non-NULL `any_of` matching the no-`any_of` count
exactly, and `any_of` naming only a never-registered id matching nothing.
At the time of this pass the C smoke step was `continue-on-error`, so a
green job proved nothing about it. It has since moved to its own workflow
with its own pass/fail; see "FFI test and bench" below.

**Not covered, on purpose.** The Sparse Shell (no archetypes to
enumerate) and change detection. `Changed`/`Added`'s own FFI surface is a
separate, deliberately deferred scoping decision — see `tick.rs` below.

### `resource.rs`: resources and their C write path

**What it does.** A resource is at most one value of a Rust type, owned by the
`World` and attached to no entity (a clock, a configuration, an input
snapshot). Typed Rust API on `World`:

```rust
world.insert_resource(Clock { secs: 0.0 });          // -> Option<Clock>, the previous value
world.get_resource::<Clock>();                        // -> Option<&Clock>
world.get_resource_mut::<Clock>();                    // -> Option<&mut Clock>
world.remove_resource::<Clock>();                     // -> Option<Clock>
world.contains_resource::<Clock>();                   // -> bool
```

Names follow bevy (`insert_resource`, `get_resource`, `get_resource_mut`,
`remove_resource`, `contains_resource`); the getters return `Option` and never
panic, which is this crate's convention (`get`, `has`). Storage is a
`TypeIdMap<Box<dyn Any>>` using the hasher from `hash.rs`, with no `unsafe`.
A type can be both a resource and a component at once; the two are separate
namespaces and the storage-claim guard does not involve resources.

**Left out on purpose:** the `Send`/non-`Send` split (`World` is already not
`Send`, its columns are `Box<dyn Column>`), change detection (needs the same
tick storage as `Changed`/`Added`), and bevy's resources-as-components
representation. A resource here is a plain map entry, not an entity.

**FFI scope, including writes.** Writing from C is required, so resources have a
write path, not just spans. The shape:

- Rust registers each C-visible resource type once, by name
  (`World::register_ffi_resource::<T>(name)`, generic, so not callable from C),
  and C looks the name up: `mid_ecs_world_lookup_ffi_resource_id`. Resource
  ids are their own dense namespace from 0, separate from component ids.
  Idempotent for the same type; registering one name for two types panics, like
  the component registrations.
- `T` must be `FromBytes + IntoBytes + Immutable + KnownLayout`. `FromBytes`
  is the new requirement (component registration needs only the read side): C
  writes raw bytes, so every bit pattern has to be a valid value.
- Read: `mid_ecs_world_resource_raw_span` gives a one-element span, or
  `count == 0` if the resource is registered but not inserted.
- Write: `mid_ecs_world_resource_write(world, id, bytes, len)` copies `len`
  bytes in. `len` must equal the type's size exactly, else the new status
  `MID_ECS_SIZE_MISMATCH` (-6) and nothing changes. If the resource is absent
  the write inserts it. Bytes are copied and need no alignment.
- Remove: `mid_ecs_world_resource_remove`. `MID_ECS_NOT_FOUND` covers both an id
  that was never issued and a resource that is not currently inserted.

**Why a copy-in write and not a mutable span.** No mutable pointer into Rust
memory ever crosses the boundary. A write validates the length, builds a value
with `FromBytes::read_from_bytes`, and stores it, so C cannot scribble past the
value or hold a writable alias while Rust also holds a reference. The cost is
one copy of a value that is normally a few words.

**Span validity.** A write to an existing resource replaces the value inside
its existing `Box`, so the address does not change and a span taken earlier
stays valid and sees the new bytes. A span is invalidated by
`mid_ecs_world_resource_remove`, by a Rust-side `insert_resource` or
`remove_resource` of the same type (which replace or free the box), and by
freeing the world. Both directions are tested: the pointer is compared before
and after a write, and the old pointer is read.

**Writes to components from C are not covered here.** The existing component
spans stay read-only; a component write path is a separate decision (rows
move on structural change, so it needs its own safety story).

**Tests:** 260 default (23 new): 12 in `resource.rs` (typed API, replace and
remove return values, distinct types, exactly-once drops including through
replace and remove, idempotent registration, name reuse panic, span contents,
write inserts when absent, in-place write keeping the address, wrong size and
unknown id changing nothing, remove reporting unknown and absent distinctly), 4
in `world.rs` (through the `World` API, resource and component of one type,
entity lifecycle not touching resources, a full register/write/read/remove
round trip), and 7 through the C surface (lookup, span contents and the empty
registered case, in-place write, write-inserts, size mismatch for several
lengths, remove then span then second remove, NULL and unknown-id cases). The C
smoke test gained 20 checks, compiles clean under `-Wall -Wextra`, and passed
against a debug `libmid_ecs.so` in the sandbox. (That CI step has since moved
to its own workflow; see "FFI test and bench" below.)

**Measured only against itself.** A lookup here is a hash probe plus a
`downcast_ref`; bevy's is an id-indexed lookup. `resource_access` in
`benches/ffi_overhead.rs` now measures the Rust-side read/write against the
`extern "C"` read/write on the same world (see "FFI test and bench" below), but
nothing measures it against `world.resource::<T>()` in bevy yet. Given the
inlining behaviour recorded in the filters section, read any ratio with the
bench binary's layout in mind.

### `tick.rs`: change ticks, `ChangeTracker`, `Added`/`Changed` queries

**What it does.** `World` owns one monotonically increasing counter
(`Tick`, a `u32` wrapper), advanced by `World::increment_change_tick()`.
Every archetype-tracked component value gets a paired `ComponentTicks {
added, changed }`: `added`/`changed` are both set to the current tick on
insertion (`insert_static`, `insert_bundle`, `spawn_bundle`), and
`changed` is updated again on every `World::get_static_mut` call, and (added
in a later pass, see "Mutable queries") on every mutable dereference of
the `Mut<T>` the bulk mutable queries yield. When this pass was written
`get_static_mut` was the only place a value could be mutated through, since
there was no bulk `&mut` query yet. `ChangeTracker` is a small, caller-held "since when"
marker: `ChangeTracker::new()` starts at `Tick::ZERO` (so a fresh one
sees everything currently present as added/changed), and
`ChangeTracker::update(&world)` advances it to the world's current tick.
`World::query_added::<T>(&tracker)` and `World::query_changed::<T>(&tracker)`
are the two new `World` methods that read it.

```rust
let mut tracker = ChangeTracker::new();
// ... spawn / mutate entities ...
for (entity, health) in world.query_changed::<Health>(&tracker) { /* ... */ }
tracker.update(&world); // now last_run == this step's tick
world.increment_change_tick(); // caller's own game loop, once per step
```

**No `Schedule`, so this is manual.** Bevy's own change detection is
automatic because a `System` has its own `last_run` tick that its
`Schedule` advances for it. This crate has neither, so the caller owns
both steps explicitly: advancing the world's tick once per step of their
own game loop, and advancing each `ChangeTracker` they keep after using
it. This is not a smaller version of bevy's design so much as the same
mechanism with the automation stripped out, because there is nothing yet
to do the automating.

**Deliberately simplified relative to bevy's own tick comparison.** The
comparison itself (`Tick::is_newer_than`, wrapping-counter arithmetic) is
read directly from `Mid-D-Man/bevy`'s `change_detection/tick.rs` — same
`ticks_since_insert`/`ticks_since_last_run` shape. What was **not**
ported: bevy periodically scans every stored tick (`check_tick`) and
clamps its age to `MAX_CHANGE_AGE`, because a long-running `Schedule`
would otherwise let `this_run - tick` overflow `u32::MAX` and silently
invert every comparison. Nothing here runs that scan, so the comparison
is only correct as long as no single tick's age exceeds roughly
`u32::MAX / 2` — at one `increment_change_tick` per rendered frame,
somewhere past a billion frames between an insertion and a query
checking it. Stated in `tick.rs`'s own doc comment as a real, load-bearing
limit, not a rounding error glossed over: a `check_tick`-equivalent is
real future work if this crate ever needs to run that long without a
restart.

**Why `Added`/`Changed` are their own `World` methods, not `QueryFilter`
types.** This was the plan going into this pass (see `filter.rs`'s own
earlier note: "`Changed`/`Added` ... will change this trait"), and it
turned out to conflict with something this project has already paid for
twice: `archetype/iter.rs`'s `next()` bodies are held byte-for-byte fixed
because the whole-program inliner's willingness to resolve them at all is
inline-budget-sensitive, and the `filter.rs` section above just measured
that sensitivity directly (a 3x per-row swing from one unrelated line of
code in the same binary). `Added`/`Changed` are inherently a per-row
check — unlike `With`/`Without`/`Or`, which resolve once per archetype
before `next()` is ever called — so making them `QueryFilter`s the same
way would mean a branch inside `Iter1`/`Iter2`/`Iter1Ref`/`Iter2Ref`'s
`next()` itself, which is exactly the kind of change that file's own
header already warns off. So `query_added`/`query_changed` are a separate
path (`World::change_rows` in `query.rs`): walk
`Archetypes::archetypes_with`, then a new `Archetypes::rows_with_ticks`
gives one archetype's entities/values/ticks as three row-aligned slices,
zipped and filtered with a plain iterator chain. Neither touches
`Iter1`/`Iter2`/`Iter1Ref`/`Iter2Ref` or their `matched`-list-building
helpers at all.

**Scope this pass stopped at, stated plainly:**

- **Single-component only.** `query_added<T>`/`query_changed<T>` take one
  type, both the filter and the fetch. No `query2_added`, and no way yet
  to combine an archetype-level `With`/`Without`/`Or` filter with a
  row-level `Added`/`Changed` check in one call — the natural next step,
  not built here.
- **No bulk mutable query** *(closed since: see "Mutable queries")*.
  `World::get_static_mut` was the *only* place `changed` got touched,
  because it was the only place that existed. Whenever a
  `query_static_mut`-style bulk mutable iterator got built, it needed to
  mark `changed` per row it yields, or `Changed` would silently miss
  everything written through it. It does, through `Mut<T>`.
- **No FFI counterpart in this pass, unlike every other feature** (`Or`
  included), for a real reason: a C caller needs per-row change data, a
  different shape from every enumeration function that existed then. Its
  design was done in the FFI test/bench pass; see "FFI test and bench"
  below for what shipped and what was chosen over the alternatives.

**Row-alignment risk, and how it was actually checked, not just argued.**
Threading `Table::ticks` (a new `SparseSet<ComponentId, Vec<ComponentTicks>>`,
row-aligned with `Table::columns`' own per-component `Vec<T>`, mirrored via
a new `ensure_ticks` alongside every `ensure_column`) through
`Table::swap_remove_row`, `Archetypes::insert<T>`/`remove<T>`,
`spawn_bundle`/`insert_bundle`/`remove_bundle`'s survivor-migration loops,
and the `Bundle` trait's `push_into`/`take_direct` touches nearly every
structural code path in `archetype.rs`. The existing 260-test suite passing
unchanged is one signal, but the real, adversarial check was two mutation
tests added specifically for this: spawn 6 entities sharing one archetype,
mutate two of them, then force a swap-remove that lands a *mutated* entity
into the *slot being freed* (despawning entity 0, whose freed row-0 slot
gets filled by entity 5's row — the table's last row — because
`Vec::swap_remove(0)` moves the last element into the freed one). A ticks
vector that wasn't kept in lockstep would make entity 5 read back with
entity 0's stale, never-changed ticks instead of its own — and a plain
"despawn from the middle, check the untouched ones" test does not expose
this, because coincidentally correct-looking output can hide the bug (this
project's own first draft of this test made exactly that mistake and had
to be rewritten once the coincidence was noticed). Both mutation checks
were actually run: reverting `swap_remove_row`'s ticks handling, and
separately reverting `insert<T>`'s survivor-tick migration, each broke the
adversarial test (the second one also broke several pre-existing tests via
a `ticks`/`columns` key-set mismatch panic elsewhere, extra confirmation
the migration code is load-bearing) — confirmed by actually reverting and
re-running, not assumed from reading the diff.

**Tests:** 294 with `scratch-arena` (289 default), up from 260 at the
start of this pass. 7 in `tick.rs` itself (ordering, the tick-zero
boundary, and a `u32` wraparound case for `is_newer_than`; `added`/
`changed` diverging independently on one `ComponentTicks`). 10 in
`world.rs`: the tick counter starting at 1 and advancing, a fresh tracker
seeing everything present, `update` narrowing what a tracker sees,
`get_static_mut` marking `changed` but not `added`, a read-only
`get_static` never marking `changed`, survivor ticks preserved across both
an unrelated insert and an unrelated remove (proving a structural move
doesn't look like a re-add or a spurious change), `query_added`/
`query_changed` empty for a never-registered type, and the two adversarial
swap-remove tests above (one through `Table::swap_remove_row` via
`despawn`, one through `Archetypes::insert<T>`'s survivor-migration path).

**Not measured.** No bench group yet for `query_added`/`query_changed` or
for the per-insertion/per-mutation tick-write cost. The tick write itself
is two `u32` stores per insertion and one per `get_static_mut` call, so it
should be small next to everything else those paths already do, but that's
an expectation, not a measurement — put it through the same real-CI
process as everything else here before trusting it.

### FFI test and bench

Three pieces, done together: the FFI shape of `Added`/`Changed`, the FFI
smoke test split into its own workflow, and a first bench of the `extern "C"`
surface.

#### Changed/Added over the C ABI

**What shipped.** Four functions and one accessor pair on the Rust side:

- `mid_ecs_world_change_tick(world) -> u32` and
  `mid_ecs_world_increment_change_tick(world) -> u32` (`0` on a NULL world; a
  real world's tick starts at `1`, so `0` is never a real reading).
- `mid_ecs_world_static_component_added_rows(world, archetype_id,
  component_id, last_run, out_rows, out_capacity)` and
  `..._changed_rows(...)`: for one `(archetype, component)` pair, the
  ascending row indices whose value was inserted (added) or inserted or
  mutated (changed) after `last_run`. `last_run` is a plain `uint32_t` the
  caller holds; a fresh tracker is `0`, and after using the rows the caller
  sets it to `change_tick`. That is `ChangeTracker` with the tracker on the C
  side.
- On the Rust side, `World::static_component_added_rows` /
  `static_component_changed_rows` (untyped, id-based, taking a `Tick`) over a
  new `Archetypes::ticks_span`, which mirrors `raw_span`'s rules.

**Why a row list, not a parallel tick buffer.** The two shapes the tick.rs
section left open were "a parallel tick buffer next to `raw_span`" and "a
`last_run`/`this_run` pair passed in and a filtered index list back". The row
list won on three grounds. It keeps `ComponentTicks` (`pub(crate)`, two `u32`s
today) out of the C ABI, so its layout can still change. The wrapping-counter
comparison (`Tick::is_newer_than`) stays in one place, Rust, instead of being
re-implemented by every C caller, which is exactly the code that goes subtly
wrong at a wrap. And it composes with what already exists: row `i` is element
`i` of `raw_span` and `entity_ids` for the same pair, so a caller picks the
changed elements out of the span it already reads. The cost is that the check
is per `(archetype, component)`; a C caller enumerates archetypes with
`archetypes_matching_static` and calls per archetype.

**Semantics carried over, not re-decided.** Measured against the world's
current tick, so call `increment_change_tick` between a step's mutations and
the check that should see them (a value touched in the same tick `last_run`
was set to is not reported; this is `is_newer_than`'s existing behaviour).
`NotFound` under exactly the conditions `static_component_raw_span` returns it
(including the FFI-registration gate); an archetype with no rows is `0`, not
an error; the NULL-buffer-queries-count and `BufferTooSmall` (nothing written)
idioms are the same as every other enumeration.

**Not covered.** Archetype Core only, because the Sparse Shell has no ticks.
When this shipped C could not mutate an archetype-tracked component (the spans
were read-only), so `changed_rows` reported only changes made by the Rust side
of a mixed-language program; the C tests got a Rust-side "frame of game code"
through a test-only fixture pair, `mid_ecs_test_change_fixture_world_new` and
`mid_ecs_test_change_fixture_mutate`. C can write now, and those writes show in
`changed_rows` too: see "Writing component data from C" below. Still single-component, and still not
composable with `With`/`Without`/`Or` in one call (a caller composes them
itself: enumerate with `archetypes_matching_static`, then call the row
function per archetype).

**Verification.** 8 new Rust tests in `ffi.rs` (297 default / 302 with
`scratch-arena`, up from 289/294), and 22 new C checks (100 in `test.c` now,
`-Wall -Wextra -Werror` clean, run against both `libmid_ecs.so` and
`libmid_ecs.a`). One test compares the C row lists step by step against the
typed `query_added`/`query_changed` through a mutation-then-add sequence.
Mutation-checked, not just written: making `swap_remove_row` use
`Vec::remove` for ticks fails `change_rows_stay_aligned_with_entity_ids_after_a_swap_remove`;
making `added_rows` compute the changed set fails three tests and one C check;
disabling the capacity guard fails `change_rows_buffer_idiom`. Each mutant was
reverted and the suite re-run green.

#### The FFI smoke test is its own workflow

`.github/workflows/mid-ecs-ffi-test.yml` (results script
`scripts/mid_ecs_ffi_results.py`; published as the "mid-ecs FFI" card on the
site's tests page, see "Publishing" below). It runs the Rust `ffi::` unit tests, then
`test.c` compiled with `gcc -Wall -Wextra` against `libmid_ecs.so`, then
against `libmid_ecs.a`, then the `.so` build under valgrind (`--error-exitcode=99`,
definite leaks counted as errors). The step was removed from
`mid-ecs-test.yml`; its raw log used to be an artifact only, so a failure there
was invisible to that dashboard and job summary.

**The one deliberate difference from `mid-ecs-test.yml`.** Every step here is
allowed to fail on its own so that later steps run and the results are always
reported, but the last step fails the run if any check in the results JSON
failed or none were collected. The rest of this repo's test workflows never
gate; this one does, because its only purpose is to say whether the C ABI still
works. If that is the wrong call, delete the final step; nothing else depends
on it.

**A missing log is a failure.** `scripts/mid_ecs_ffi_results.py` turns a C log
with no closing `=== N check(s) failed ===` line (compile error, link error,
crash) into one failed check. Without that, a crash prints no `FAIL:` lines and
would read as zero failures.

**Publishing.** This workflow deploys nothing. The site is on Cloudflare Pages
(`deploy-site.yml`, see `docs/mid-engine-site.md`), and `deploy-site.yml`
re-runs these same steps behind its `run_tests_first` input, writes
`mid-ecs-ffi-test-results.json` into `dist/tests/mid-ecs-ffi/`, and
`web/tests/index.html` has a "mid-ecs FFI" card reading it. The steps in
`deploy-site.yml` are a mirror: change one, change the other. This workflow was
first written with an HTML dashboard pushed to `gh-pages`, copied from
`mid-ecs-test.yml`, before the migration notes in
`docs/RUST_AND_CRATE_GUIDELINES.md` section 7 were read; that half (template,
deploy job, landing-page card) was removed, not built on.

**First real CI run, and what it changed.** Dispatched on rustc 1.98.1, both
this workflow (#1) and `mid-ecs-test.yml` (#17) died with `cargo: command not
found` (exit 127) at their first cargo call, although `rustc --version` had
worked right after the toolchain install; `mid-ecs-test.yml` #16, on 1.98.0,
had passed. The only step between the two shared by both workflows was the
cache restore. Cause: suspected, by the same mechanism section 7 of the
guidelines records for `mid-ptr-test.yml` (a bare `cargo-registry-` restore
prefix matching another workflow's archive, and an archive holding
`~/.cargo/bin/` overwriting the installed rustup proxies). The symptom here was
127, not that incident's "Exec format error", so it is the same family, not a
proven match. Two changes, both from that documented fix: `~/.cargo/bin/` left
the cached paths, and the key is now `cargo-registry-mid-ecs-${{ runner.os }}-<hash>`
with a matching restore prefix instead of a bare one. A "Toolchain check" step
after the restore prints `PATH` and runs `cargo --version`, so a recurrence names
its own cause. Ten other workflows cache `~/.cargo/bin/`; five of them still
use the bare `cargo-registry-` restore prefix (`headless-server-smoke-test`,
`mid-log-test`, `mid-math-test`, `mid-net-test`, `mid-net-transport-wasm-test`)
and were not touched.

The same run exposed a hole in `scripts/mid_ecs_ffi_results.py`: with cargo
dead, the Rust `ffi::` suite simply was not in the results, and only the C
suites' failures turned the run red. A Rust-only breakage next to healthy C
logs would have gated green (reproduced, then fixed): a Rust log that yields no
tests is now one failed check, "collected at least one test".

**Checked before shipping.** The script was run on real logs from the same
commands the workflow runs (247 checks: 41 Rust, 101 per C link mode, 4
valgrind) and on deliberately broken logs. For the Deploy Site wiring, the real
`run:` blocks of the new `deploy-site.yml` steps and of its "Assemble dist/"
step were executed in the sandbox in order, and the tests page was rendered
against the assembled `dist/` (the FFI card read "247 passed", the cards with no
JSON "No results yet"). Linting every workflow caught a real error before it
shipped: an unquoted step name containing `ffi:: ` reads as a YAML mapping and
would have broken all of Deploy Site. Valgrind was
confirmed able to fail: with one `mid_ecs_world_free` removed from `test.c` it
exits 99 and reports 832 bytes definitely lost. The static-link flags
(`-lpthread -ldl -lm`) were confirmed on the sandbox's Linux only.

#### `benches/ffi_overhead.rs`: FFI call overhead

Workflow `.github/workflows/bench-mid-ecs-ffi.yml`, parser
`scripts/bench_mid_ecs_ffi.py`, criterion, in-crate (no bevy dependency, so no
toolchain wall). Groups: `lifecycle_spawn_despawn`, `span_read` (with
`*_call_only` variants that stop after obtaining the span), `archetypes_matching`
(swept over the number of archetypes, not entities), `change_rows` (1 row in 10
changed), `resource_access`. Every group asserts at setup that its `rust` and
`ffi` variants compute the same answer.

**What it does not measure.** The `ffi` side is the `extern "C"` function called
from Rust, so it includes null checks, `catch_unwind`, status plumbing and the
count-then-fill double call, but not the ABI crossing from a separately compiled
C program. Under the default `bench` profile (LTO, one codegen unit) the
optimizer can also inline through the boundary inside the one bench binary,
which no real C caller allows. Read every ratio as a lower bound, and dispatch
`profile: bench-nolto` as well before trusting a small one. A C-timed harness
(`clock_gettime` in `test.c`-style code against the real `.so`) is the remaining
half of "both" and is not built.

**First real CI run** (`bench-mid-ecs-ffi` #1, rustc 1.98.1, `bench` profile
only, `bench-nolto` not yet dispatched). Mean times, `rust` vs `ffi`:

| Group | Rust | FFI | FFI ÷ Rust |
|---|---|---|---|
| `lifecycle_spawn_despawn`, N=100 to 100,000 | 4.12 µs to 6.63 ms | 4.40 µs to 6.94 ms | 1.04–1.12× |
| `span_read`, span call only | 18.5–19.0 ns | 22.9–23.2 ns | 1.20–1.24× (+4.4 ns, constant in N) |
| `span_read`, span plus sum | 34.8 ns to 10.8 µs | 46.8 ns to 10.8 µs | 1.34× at N=100, 1.00× at N=100,000 |
| `archetypes_matching`, K=1 / 4 / 16 | 27.7 / 71.0 / 208.9 ns | 88.8 / 174.9 / 418.0 ns | 3.21× / 2.47× / 2.00× |
| `archetypes_matching`, `ffi_count_only` | | 40.2 / 83.2 / 215.0 ns | |
| `change_rows`, N=100 to 100,000 | 85 ns to 44.2 µs | 318 ns to 110.6 µs | 3.74× to 2.50× |
| `resource_access` read | 4.12 ns | 14.10 ns | 3.42× |
| `resource_access` write | 3.86 ns | 9.04 ns | 2.34× |

Read: per-call cost is small and constant (a span is about 4 ns, a resource
read about 10 ns, a write about 5 ns), and a plain span read stops showing it
by N=100,000 (1.00×). The large ratios are two idioms, not the calls.
`archetypes_matching`: one `ffi_count_only` call (writes nothing) already costs
about as much as the whole Rust collect at K=16 (215 vs 209 ns) and more than
it at K=1 (40 vs 28 ns), and count-then-fill is about 2x count-only at every K,
which fits the match being computed twice. `change_rows` scans the tick column
twice (count, then fill) and allocates a `Vec` each call; its ratio shrinks as
N grows, but the absolute gap is 66 µs at N=100,000 for 10,000 changed rows.
Both are expectations from reading the code, not attributions: none of it has
been profiled. The obvious candidate, if one of these ever matters, is an
enumeration that fills the caller's buffer in one pass and reports the count
separately; it is not done because it would change the count-then-fill idiom
every other enumeration shares. An earlier sandbox-only sample (rustc 1.91.1)
agreed in shape but ran higher on `change_rows` (3.55–5.27×) and resource reads
(4.54×); this table replaces it.

**Also not done.** `query_added`/`query_changed` still have no bench against
bevy (the "Not measured" note in the tick.rs section stands); the tick-write
cost on insertion and mutation is still an expectation, not a measurement.

### Mutable queries

`Mut<T>`, `World::query_static_mut`, `query2_static_mut`,
`query2_static_mut_ref` and their `_filtered` forms: the bulk counterpart of
`get_static_mut`, and the closing of the hole the tick.rs section recorded
("No bulk mutable query"). Before this, a bulk write could not be seen by
`Changed`, from Rust or over the C ABI.

**What it does.**

- `query_static_mut::<T>()` yields `(Entity, Mut<T>)`; `query2_static_mut::<A, B>()`
  yields `(Entity, Mut<A>, Mut<B>)`; `query2_static_mut_ref::<A, B>()` yields
  `(Entity, Mut<A>, &B)`, the `(&mut Position, &Velocity)` shape most per-frame
  updates are. Each has a `_filtered::<.., F: QueryFilter>` form taking the same
  `With`/`Without`/`Or` filters as the shared queries. Archetype Core only,
  `&mut self`, same archetype and row order as the shared queries.
- `Mut<T>` derefs to `&T` for free and stamps the row changed, at the world's tick
  as of query creation, on every *mutable* dereference. A row a query merely
  visits is not marked, which is the difference from `get_static_mut`, where the
  call itself marks. `set_changed()` marks without a write;
  `bypass_change_detection()` writes without marking; `is_added`/`is_changed`
  take the `ChangeTracker` the caller already holds (bevy's take no argument
  because a system carries its own last-run tick; there is no system here).
- Same-type queries (`query2_static_mut::<Position, Position>()`) panic when the
  query is created, not part-way through it: one value cannot be borrowed
  mutably twice.
- The usual rule from the tick.rs section applies: advance
  `increment_change_tick()` between a step's writes and the check that should see
  them.

**Zero `unsafe`.** `SparseSet::iter_mut` hands out one `&mut Archetype` at a
time, and inside one archetype a `Table`'s `columns`, `ticks` and `entities` are
disjoint fields, so destructuring `&mut Table` gives independent borrows of the
value column, its tick column and the entity list. Two columns of one archetype
come from `SparseSet::get_disjoint_mut`, which is `split_at_mut` underneath.
Archetype selection reuses `matched_filtered` (the one change to `iter.rs`: its
visibility, `pub(super)`; no function body) and keeps the matching archetypes in
the dense order `iter_mut` walks them in, which is the order `iter()` enumerates.
That is what makes the result visit the same entities in the same order as the
shared queries, and a test asserts it, because the merge depends on it.

**Separate from `Iter1`/`Iter2` on purpose.** The code lives in
`archetype/iter_mut.rs`; `Iter1`/`Iter2` and their `Ref` forms are untouched.

**The iterator went through four designs, and the first was 5.6x too slow for a
`for` loop.** Instruction counts under callgrind (deterministic, unlike timing),
release profile, rustc 1.91.1, one archetype of 5,000 rows, 200 passes. Ir per
row:

| Design | one column, `for` | one column, `for_each` | mixed `(&mut A, &B)`, `for` |
|---|---|---|---|
| `flat_map` over per-archetype `zip` | 63–65 | 6.1 | 17.1 |
| hand-written, one cursor per column, one fat `next()` | 44.1 | 5.6 | 22.1 |
| same, with `next()` split from a cold `advance()` | 19.1 | 5.6 | 41.1 |
| **shipped:** one nested `Zip` per archetype, cold `advance()` | **16.1** | **6.1** | **25.1** |

For reference, the shared `query_static` summing one column is 11.1 and
`query2_static` summing two is 13.1. Reading through a `Mut` (`Deref`, no write)
is 12.1; the write and its tick store add about 4. The mixed row does two writes,
so two tick stores, where its shared counterpart does two reads.

What each step taught:

- A `for` loop calls `next()`, never `fold`, so an iterator's `fold` override
  does nothing for it, and `FlatMap::next` is the slow path. `for_each` through the same iterator was
  already 6, so the first design looked fine until it was measured the way
  people write loops.
- Splitting a cold, out-of-line `advance()` off `next()` made the single-column
  case 2.3x cheaper but left the 4-column case at 41: the hot path was inlined
  (forcing `#[inline(always)]` changed nothing) but `advance(&mut self)` being a
  real call keeps the iterator in memory, so every per-column cursor is loaded
  and stored each row, and cost scaled with column count (3 cursors 19, 4
  cursors 41).
- One nested `Zip` of slice iterators specializes to a single shared row index,
  so the state a `for` loop carries is one counter however many columns the query
  has. A column shorter than the entity list truncates the zip instead of
  misaligning rows. `fold` is overridden (by-value `zip`, which keeps that
  specialization) so `for_each`, `sum` and friends stay on the fast path;
  `next()` is `#[inline]` with the archetype advance out of line and `#[cold]`.

This is a sandbox measurement. The `Iter1::next` notes in `iter.rs` record a
`next()`/`advance()` split that regressed on real CI (builds #29/#30) while
looking fine here, and every figure above depends on the whole-program inliner,
so read the table as "no obvious per-row disaster", not as the number CI will
show.

**Verification.** 20 new tests (297 default / 302 `scratch-arena` became 317 /
322): `Mut` semantics (read does not mark, write marks `changed` and never
`added`, `set_changed`, `bypass_change_detection`, `Debug`); that a visit is not
a write; that exactly the written rows are marked, in the right rows; that
writes stay attached to their entity through a `despawn` swap-remove (the entity
that lands in the freed slot is the one written, per the tick.rs lesson that a
mid-list despawn passes even with broken ticks); filter parity with the shared
queries over `()`, `With`, `Without`, `(With, Without)`, `Or` and an
unregistered type, same entities in the same order; mixed mutability marking only
the mutable side; two mutable components marked independently; the same-type
panics; zero-row intermediate archetypes (`insert_bundle`); `for` loop and
`for_each` agreeing across several archetypes; iteration continuing past an
archetype with no rows; and one end-to-end test that a bulk write is visible
through the C `..._changed_rows`. Seven mutants were each caught by the right
tests and reverted: `DerefMut` not marking (8 tests); `next()` marking every
visited row (6); `advance()` dropping the first row of each archetype (7);
selection ignoring the filter (2); the two-mutable ticks swapped (1); `fold`
never marking (1); `fold` stopping at the first archetype (1). The last two are
only reachable through `for_each`, which is why the `for`-loop tests alone were
not enough once `fold` existed.

**Not covered, stated plainly.**

- **No `Ref<T>`.** *(Done later: see "`Ref<T>`, `Added`/`Changed` terms and
  filters" below.)* The read-only counterpart (`is_changed()` on a shared
  fetch) is what combining a row-level `Changed` with other query terms in one
  call needs; `query_changed`/`query_added` stay single-component and
  separate paths.
- **No three-component or entity-free forms, no `Option<&T>`/`Has<T>`.**
- **No C counterpart, deliberately, the one exception to shipping FFI with each
  feature.** The spans were read-only, so there was no bulk mutable query to
  mirror; a C-side write path was a byte-copy design like `resource_write` that
  deserved its own pass, and got one: "Writing component data from C" below.
  What C got from *this* pass is `..._changed_rows` reporting bulk writes made
  by the Rust side.
- **Benched since, not yet on real CI.** See "Mutable-query benches" below.
- **Sparse Shell has no ticks**, so there is no `Mut` for it.

### Mutable-query benches

Added after the iterator went in, because the only evidence for the shipped
design was a sandbox instruction-count probe. Two places, deliberately split the
way the read-side benches are:

- **`crates/mid-ecs/benches/archetype_core.rs`**, in-crate, any toolchain:
  `query_static_mut_single_component` and
  `query2_static_mut_ref_two_components`, each at N = 100 / 1,000 / 10,000 /
  100,000 with three variants. `for_loop` is what people write (it goes through
  `next()`), `for_each` goes through the `fold` override, `read_only` is a
  mutable query that only dereferences immutably, so no row is stamped (the
  wrapper's own cost). `raw_slice_ceiling` gained `one_field_write` and
  `two_field_update`, the zero-abstraction floor for the same writes.
  `scripts/bench_mid_ecs_archetype_core.py` prints the existing group tables
  automatically (it discovers groups; it has no expected-groups list) plus a
  closing table of each mutable variant over the shared query at the same N.
  That table has no pass/fail flags: there is no real-CI baseline yet, and a
  threshold invented without one would be a guess.
- **`benches/ecs-vs-bevy-ecs/benches/vs_bevy_ecs.rs`**, the comparison that
  does not share the in-crate file's layout noise:
  `mutable_query_single_component` (`Query<(Entity, &mut A)>`) and
  `mutable_query_iteration` (`Query<(Entity, &mut A, &B)>`), N = 10,000, plain
  `for` loop on both sides, the write going through each engine's change-tracked
  `Mut`. `Entity` is in bevy's tuple on purpose: mid-ecs's mutable queries have no
  entity-free form, so both sides load the same item shape (this differs from
  `filtered_query_iteration`, which pairs mid-ecs's entity-free shared query with
  bevy's entity-free one). Setup runs one write pass per engine and asserts the
  resulting sum outside the timed closure.

**The bevy half is not compiled.** `bevy_macro_utils` 0.19.1 needs a std feature
(`rwlock_downgrade`) that rustc 1.91.1 does not have, so even a type check stops
there, the same wall the crate's own header records. What was done instead:
the bevy_ecs 0.19.1 source was read for every call the new groups make
(`QueryState::iter_mut(&mut self, &mut World)`, `&mut T` yielding `Mut<T>`,
`Entity` as query data, tuples implementing `IterQueryData`, `spawn_batch`), and
all of them match. The mid-ecs half compiles and runs. Confirm the bevy half
builds on the first real run before trusting its numbers.

**Sandbox result (rustc 1.91.1, short sampling, not authoritative).** The
in-crate groups run and the parser handles them. The numbers themselves taught
one thing worth recording, which the instruction-count probe could not:

- At N = 10,000, one column, summing through a `Mut` in a `for` loop
  (`read_only`) took 28.2 µs. The shared `query_static` summing the same
  column took 7.1 µs, and a `map(..).sum()` through the same mutable iterator
  (the `fold` path) took 7.06 µs. Instruction counts had said 12.1 versus 11.1
  Ir/row, so counts predicted parity and time did not.
- Probing further, with throwaway variants that are not in the tree: summing
  `to_bits()` into a `u32` instead of an `f32` took 7.0 µs through the mutable
  query and **17.3 µs through the shared one**, the reverse of the `f32` pair.
  Same iterator code on both sides; changing only the accumulator type moved
  which query was slow, by about 4x, in opposite directions. A loop through
  the mutable query that did no float work (it only counted rows) took 13.8 µs.
- Reading: this looks like the layout/inlining sensitivity already recorded for
  builds #12/#13 (three unrelated benchmarks moving by different amounts in the
  same run) rather than a cost of `Mut`. The mechanism was not identified (no disassembly
  was done), so "consistent with" is as far as it goes. The practical
  consequences: a lone slow variant in `archetype_core.rs` is a layout shift until
  it repeats, an instruction-count parity does not establish a time parity, and
  the same-run bevy groups are the number to read, as with every other group.
  **Partly superseded by the CI results below**: on CI the effect is
  deterministic (4.0x at every N, in both shapes), not random, and it follows
  the call site, not the accumulator type. The "not a cost of `Mut`" half of
  this reading still holds, the "lottery" half does not.
- The write variants, for scale and as sandbox figures only: one column at
  N = 10,000 `for_loop` 16.5-18.3 µs, `for_each` 10.4-11.9 µs, against a raw
  `one_field_write` floor of 2.8 µs (the raw loop vectorizes; neither iterator
  here can). Whether bevy's `iter_mut` pays the same is exactly what
  `mutable_query_single_component` answers.

**What real CI should answer.** (1) Does the bevy half build. (2) The
`mutable_query_*` mid-ecs/bevy ratios per platform, read the way
`dense_query_iteration` is: x86_64 may differ from macOS and aarch64. (3) Whether
`for_each` beats `for_loop` on the same machine by the margin the sandbox shows.
(4) Whether the in-crate `read_only` ratio is an outlier on CI or consistent.

**Real CI results (rustc 1.99.0, AMD EPYC 7763, commit 110e0fa).**
`bench-mid-ecs-archetype-core` #33 and `bench-vs-bevy-ecs` #35.

In-crate, N = 10,000 (the ratios hold at every N from 100 to 100,000):

| | one column | two columns |
|---|---|---|
| shared query, sum in a `for` loop | 9.39 µs | 37.4 µs |
| mutable, write in a `for` loop | 16.3 µs | 20.2 µs |
| mutable, write through `for_each` | 6.77 µs | 7.06 µs |
| mutable, read-only sum in a `for` loop | 37.4 µs | 37.4 µs |
| raw slice, sum / write / update | 9.28 / 3.11 µs | 9.32 µs sum, 4.07 µs update |

Against bevy_ecs, N = 10,000: `mutable_query_single_component` mid-ecs 14.9 µs
vs bevy 15.7 µs (parity); `mutable_query_iteration` mid-ecs 20.3 µs vs bevy
11.0 µs (1.85x). The bevy half built and ran first time. Bevy's own two-column
write (11.0 µs) is faster than its one-column write (15.7 µs), which more work
cannot explain, so layout noise reaches both sides of that comparison and a
single run of either ratio should not be over-read.

What follows from it, and what does not:

- **The read-only sum through the mutable iterator is exactly the shared
  two-column cost** (37.4 µs, ~3.7 ns a row, whatever the column count) and 4x
  the shared one-column query, which sits at the raw floor. An earlier reading
  of #35 compared the mutable *write* (14.9 µs) with the shared *read-only sum*
  (37.4 µs) and suggested the mutable iterator design avoids the chain the shared
  iterators pay. That was a workload difference, not a design difference: the
  like-for-like `read_only` loop pays the same chain. **There is no evidence here
  for porting the `iter_mut` design into `Iter1`/`Iter2`.** If anything the
  shared one-column iterator is the one to learn from.
- **The 4x follows the call site, not the iterator.** The same
  `query_static::<Position>()` loop is 9.39 µs in `archetype_core.rs` and 37.4
  µs in `vs_bevy_ecs.rs` (#35, `query_static_single_component`), on the same
  runner in the same week. Whether `next()` is inlined into a given benchmark
  closure is the leading suspect (a loop-carried `f32` sum has to be kept
  somewhere across a call), and it is only a suspect: no disassembly of the CI
  binary exists. The sandbox reproduces a 4x read-only case on x86_64 (a
  disassemblable one), which is the cheapest place to look.
- **`for_each` is the fast path**: the write through `for_each` is 6.77 µs and
  7.06 µs, against 16.3 µs and 20.2 µs through a `for` loop (2.4x and 2.9x), and
  against 37.4 µs for the read-only sum in a `for` loop (5.5x and 5.3x). `fold`
  runs a whole archetype in one call with no per-row `next()`, which is the
  presumed reason; it was not confirmed in the disassembly.
- The mutable `for_loop` against the raw write floor: 16.3 µs vs 3.11 µs (one
  column), 20.2 µs vs 4.07 µs (two). The raw loops vectorise and neither
  iterator can, which is most of that gap, so it is not a number to chase on
  its own; the bevy comparison above is the yardstick, and it says parity on
  one column.

**Call-site investigation: what the slow `for` loop does (x86_64 assembly,
sandbox, rustc 1.91.1).** Done to find out why the same loop is 4x apart between
two call sites. A throwaway probe (not in the tree) put each loop shape in its
own `#[inline(never)]` function, timed it on 10,000 rows, and emitted the
assembly. The criterion closures themselves cannot be read: they are inlined
into one `benches` function of tens of thousands of lines.

| loop, 10,000 rows | µs |
|---|---|
| shared one column, `for`, sum | 28.7 |
| mutable one column, `for`, read-only sum | 28.9 |
| mutable one column, `for_each`, sum | 7.2 |
| mutable one column, `for`, write | 16.0 |
| mutable one column, `for_each`, write | 11.1 |
| shared two columns, `for`, sum | 13.2 |
| mutable two columns, `for`, read-only sum | 32.1 |

That reproduces the CI pattern on x86_64: the `for` sum is about 4x the
`for_each` sum (0.72 ns a row, the chain-bound floor), and the shared
one-column loop that is 9.4 µs inside `archetype_core.rs` is 28.7 µs on its own,
so what it costs depends on the function around it. (The shared two-column loop
read 13.2 µs here and 10.1 µs on a rerun, so single figures are good to roughly
30%.)

*What the slow loop is.* In the mutable one-column read-sum loop the hot path
is fully inlined, but the accumulator and the iterator's cursor and end both
live **on the stack**: every row does `movss` from memory, `addss`, `movss`
back, and a load, increment and store of the cursor. Those are loop-carried
dependencies through store-forwarding, about 4x the register-resident chain.
The only call in the loop is the out-of-line, deliberately `#[cold]
#[inline(never)]` `advance`. On x86_64 System V every `xmm` register is
caller-saved, so an `f32` accumulator cannot be kept in a register across a
call, and `advance(&mut self)` takes the iterator's address, so its state has to
be in memory too. LLVM did not just spill around the cold call; it kept both in
memory for the whole loop. `fold`/`for_each` has no per-row call path, so its sum
sits in a register (13 unrolled `addss` in the assembly), which is the fast case.

*Whether this explains "x86_64 only".* The parked 4x gap reads 1.11x on macOS
and 1.05x on ARM. On AArch64 the low halves of `d8`-`d15` are callee-saved, which
would let an `f32` accumulator survive a call. That is reasoning from the
calling convention, **not tested**: there was no ARM machine here.

*Experiment, not applied.* Changing the three `IterMut*::advance` functions from
`#[cold] #[inline(never)]` to `#[inline(always)]`, one scratch build:

| loop, 10,000 rows | before | after |
|---|---|---|
| mutable one column, `for`, read-only sum | 28.9 | 11.7 |
| mutable one column, `for`, write | 16.0 | 10.9 |
| mutable two columns `(Mut<A>, &B)`, `for`, sum | 32.1 | 29.3 |

The one-column loop gets close to its floor. The two-column loop does not move:
its inlined body still contains indirect calls and panic paths, and its sum is
still on the stack (`movss 4(%rsp)`). So inlining `advance` is a partial fix,
and a full one for the two-column shapes needs `advance` rebuilt so that no call
is left inside the loop at all, which is a design change, not an attribute.

*Why none of it is in the tree.* It was measured in the sandbox only, and this
file already records an `advance()` change to `Iter1`/`Iter2` that looked fine
in the sandbox and regressed on CI (#29/#30); `iter.rs` also records
`#[inline(always)]` tried on `Iter1::next`. Performance work is paused until the
ECS is feature-complete, so this stays a documented candidate. **When it resumes:
the lead is "no call inside the `for` loop", checked in assembly on x86_64
first, then on CI, then the ARM runner.**

**Not done.** No C-timed bench (there is no C counterpart to time). No
`bench-nolto` dispatch of these groups. No bench for `query2_static_mut` (both
sides mutable) or the `_filtered` forms; the `(&mut A, &B)` shape is the one most
per-frame updates are. No `Ref<T>` bench (`Ref<T>` was added later, unmeasured).

### Commands: `commands.rs` (`CommandQueue`, `Commands`, `EntityCommands`)

Built because a query holds `&World` for the life of its iterator, so no
spawn, despawn, insert or remove can run inside the loop that finds the
entities to change. This records those changes and runs them after.
Gap-list item 2 against bevy_ecs. The C counterpart covers queued spawns
and despawns only, see "The C counterpart" below.

**What it is.** `CommandQueue` owns an ordered `Vec` of commands.
`CommandQueue::commands()` gives a `Commands` to record onto,
`Commands::spawn`/`spawn_bundle`/`entity` give an `EntityCommands` whose
methods chain, and `CommandQueue::apply(&mut World)` runs everything
first-queued-first, leaves the queue empty and reusable, and returns the
entities its spawns produced, in spawn order. Covered: spawn, spawn with
a bundle, despawn, `insert_static`/`remove_static`,
`insert_bundle`/`remove_bundle`, `insert_resource`/`remove_resource`,
and `queue(closure)` on both `Commands` and `EntityCommands` for anything
else (Sparse Shell inserts included).

**Each command is exactly the `World` method it names.** Not a new set of
semantics. A command aimed at a dead entity does nothing, and
`insert_static` of a component the entity already has is a no-op (the
first value stays, as in `World::insert_static`). The second one was
found by a failing test: the first draft asserted a later insert
overwrites an earlier one, and it does not.

**Decision: deferred spawn targets a slot, not a reserved entity.**
`spawn()` cannot return a real `Entity`, because nothing is allocated
until `apply`. It returns an `EntityCommands` aimed at "the nth entity
this queue spawns", and `apply` hands back the real entities. The
alternative is bevy's: reserve the entity id immediately through `&self`
so `spawn()` can return it. Here that means making
`GenerationalIndexAllocator::allocate` work without `&mut` (an atomic
cursor over the free list, plus a flush step that creates the archetype
row), a change to `mid-collections`, a foundational crate, for a benefit
that only appears once systems hold `&World` and a command buffer at the
same time, and there is no scheduler yet. Slots need no allocator
change, and the move is additive later (an `EntityCommands::id()` is a
new method, nothing existing breaks). The bevy side of this comparison
is from knowledge of bevy_ecs, not from reading `Mid-D-Man/bevy` this
pass.

**Decision: safe, boxed closures, not a byte buffer.** bevy's queue
stores commands inline in one byte buffer with function-pointer
metadata, which needs `unsafe`. The workspace denies `unsafe_code`, and
`iter_mut.rs` held to zero `unsafe`, so this keeps to safe Rust.
Removals and despawns carry no payload (removals are a monomorphised
function pointer), so they do not allocate. An insert or a bundle boxes
one closure, which is where the component value lives, so each insert
allocates once. No benchmark exists for this yet; the allocation is the
first thing to measure against bevy's `Commands` before deciding the
byte buffer is worth its `unsafe`.

**Decision: `Commands` is separate from `CommandQueue`.** With no
`SystemParam` yet, one type would do. Splitting now means the later
`SystemParam` wraps `Commands` and nothing is renamed.

**Not required of the closures: `Send`.** `World` does not require
`Send` of its components, so the queue does not either. Moving a queue
across threads is a decision for when parallel iteration exists.

**Panic behaviour.** If a command panics during `apply`, the commands
after it are dropped unrun, the queue is left empty and reusable with
slot numbering reset, and the panic propagates. Covered by a test.

**Tests (29 in `commands.rs`, 356 default lib tests with the FFI ones below; 1 new doctest, 3 total).** Ordering
(insert-then-remove vs remove-then-insert), chaining, interleaved spawns
each getting their own inserts, spawn-with-bundle and further commands on
its target, bundle insert/remove, dead-entity and
despawned-earlier-in-the-queue no-ops (including that a recycled slot
does not pick up the dead entity's insert), the two iteration patterns
this exists for (despawn while iterating, spawn while iterating), queue
reuse, slot numbering restarting after `apply` and after `clear`,
`clear`, dropping a queue unapplied, resources, `queue` closures seeing
earlier effects, a Sparse Shell insert through `EntityCommands::queue`,
the panic case, and that an inserted component counts as `Added` to a
`ChangeTracker` that predates the `apply`.

**Mutation testing (8 mutants, all caught).** Reversed apply order (15
tests fail); slot index off by one (3); `apply` not resetting the spawn
counter (3); `clear` not resetting it (caught only after a test fix, see
below); a spawn not incrementing the counter (3); despawn skipped (4);
removal made a no-op (3); a bundle spawn not recorded as a slot (2). The
`clear` mutant survived the first draft of its test: the test called
`apply` straight after `clear`, and `apply` resets the counter itself, so
the reset in `clear` could not be seen. The test now queues a spawn
straight after `clear`, with no `apply` between.

**Verified on a fresh clone of main (rustc 1.91.1, sandbox only).** fmt
clean on the new files; 356 lib tests pass (361 with `scratch-arena`);
doctests pass; the C smoke test passes against both the `.so` and the `.a`
and is clean under valgrind. Not run on real CI.

**The C counterpart.** `MidEcsCommands`, an opaque handle like
`MidEcsWorld`: `mid_ecs_commands_new/free/len/spawn_count/clear`,
`mid_ecs_commands_spawn`, `mid_ecs_commands_despawn(commands, entity)` and
`mid_ecs_commands_apply(commands, world, out_entities, out_capacity)`.
`CommandQueue::spawn_count` was added to the Rust side for it, and is public.

- **`apply` checks the buffer before it runs anything.** It returns the number
  of entities written, or `BufferTooSmall` when `out_capacity` is below
  `spawn_count` (or `out_entities` is NULL while spawns wait). In that case
  nothing is applied: queue, world and buffer are exactly as they were, so the
  caller sizes a buffer and calls again. This is the shape of
  `mid_ecs_world_component_entity_ids`, except that apply is destructive and a
  partial fill could not be retried, so the size is checked first. A NULL
  buffer is never written through, whatever capacity the caller claims for it.
  With no spawns waiting the buffer may be NULL.
- **Despawn is always accepted at queue time.** Liveness is checked when the
  command runs, where a dead, stale or bogus value is a no-op; a stale handle
  never touches the entity that reused its slot (a test and a C check cover
  it).
- **Slots were not exposed in this pass.** The entities come back in spawn
  order from `apply`. Nothing in C could address a slot yet, because there was
  no queued insert to aim at one. There is now: see "Inserting a component from
  C" below (`Commands::queued_spawn`, `..._insert_spawned`).
- **Tests.** 10 Rust-level (`commands_*` in `ffi.rs`) and 28 new C checks
  (101 to 129), run against both libraries, valgrind clean. Seven mutants, all
  caught: the capacity check removed (1 test), the NULL-buffer check removed
  (caught as a crash when the null pointer is dereferenced), `spawn_count`
  returning `len` (1), `clear` a no-op (2), output written in reverse (1),
  despawn aimed at the wrong entity (3), and the written prefix off by one (1).
  Three of them first survived because the tests were too weak: nothing passed
  a NULL buffer with a non-zero capacity, no Rust test mixed spawns with other
  commands to tell `spawn_count` from `len`, and no single-spawn test checked
  the entity written out. All three tests were added.

**Not done.**
- **Queuing a component insert from C.** Built later, see "Inserting a
  component from C" below. (When this shipped it was an open design question:
  a byte-copy write into a registered type, like `write_resource_bytes`.)
- Reserved entity ids (above), `spawn_batch`, an `Entity`-returning
  `spawn()`.
- A benchmark of `Commands` against bevy's, and of the per-insert box.
- Dedicated Sparse Shell methods (`queue(closure)` covers them).
- `RemovedComponents`, hooks and events: despawn and remove through a
  command behave exactly as through the `World` method, with no extra
  notification.

### Multi-term queries: `query_data.rs` (`QueryData`, `Has`, `World::query_data`)

Gap-list item 1 against bevy_ecs: queries over three or more components,
plus `Option<&T>`, `Has<T>` and `Entity` terms. Before this, the widest
Archetype Core query was `query2_static` (two components, no optional
terms). Archetype Core only, read-only. Mutable terms, `Ref<T>` and
`Added`/`Changed` terms are not part of this pass, see "Not done" below (all
three were added in later passes).

**What it is.** `World::query_data::<Q>()` and
`World::query_data_filtered::<Q, F>()`, where `Q` is one term or a tuple of
up to twelve, and `F` is any `QueryFilter` (`With`, `Without`, `Or`, tuples
of them). The item shape is a type instead of a method name:
`(Entity, &A, &B, &C)` is a three-component query,
`(&A, Option<&B>, Has<C>)` visits every archetype with an `A` and reports,
per row, `B` if the archetype has it and whether it has a `C`. Tuples nest.

| term | item | archetype must contain `T`? |
|---|---|---|
| `Entity` | `Entity` | no |
| `&T` | `&T` | yes |
| `Option<&T>` | `Option<&T>` | no, `None` where it is absent |
| `Has<T>` | `bool` | no, `false` where it is absent |

**Where it lives.** `query_data.rs` holds the sealed `QueryData` trait,
`Has<T>`, the impls for the four terms and the tuple macro.
`archetype/iter_data.rs` holds `TableView` (a read-only view of one
archetype handed to the terms), the generic `IterData` iterator and
`Archetypes::iter_data_filtered`. The two `World` methods are in
`query.rs`. `lib.rs` re-exports `QueryData` and `Has`.

**A correction to the plan.** The handover that proposed this item called it
"extending the tuple macros in `filter.rs`". That was wrong: the tuple macros
in `filter.rs` implement `QueryFilter`, which only decides whether an archetype
matches. Query item shapes were hand-written iterators (`Iter1`, `Iter2` and
their `Ref` and mutable forms). Adding `Iter3`..`Iter8` by hand cannot give
`Option<&T>` or `Has<T>`, because every mix of terms would need its own
iterator, so this is a new trait and one generic iterator, not a macro
extension.

**Decisions, with reasons.**
- **A separate iterator, not a change to `Iter1`/`Iter2`.** Their `next()`
  bodies are held byte-for-byte fixed for the LTO inline budget (header of
  `iter.rs`), and optimization is paused. `iter_mut.rs` made the same choice.
  The existing `query_static`/`query2_static` paths are untouched.
- **Resolve once per archetype, index per row.** On entering an archetype each
  term turns into the thing it reads rows from (`&[T]`, `Option<&[T]>`, a
  `bool`, `&[Entity]`); a row is then slice indexing. The row count served is
  the table's entity count clamped to every column slice held, so indexing can
  not go out of bounds. Zero `unsafe`: the slices come from a safe
  `downcast_ref`.
- **Only `&T` terms narrow which archetypes are visited.** `Option<&T>` and
  `Has<T>` are decided per archetype and never remove one. The required ids go
  through the same `matched_filtered` the other queries use, so archetypes and
  rows come out in the same order as `query2_static` for the same components
  (asserted by a test).
- **Presence is the archetype's signature, not whether a column object
  exists.** A signature can list a component whose column the table has not
  created yet (columns appear on the first row). `Option<&T>` and `Has<T>`
  read the signature; `&T` falls back to an empty slice for a missing column,
  and such a table has no rows anyway.
- **Unseen types never register anything.** If the Archetype Core has never
  seen `T`: `&T` makes the whole query empty (no archetype is visited),
  `Option<&T>` is always `None`, `Has<T>` is always `false`. Asking spends no
  `ComponentId`, the contract `filter.rs` already documents. A test checks
  `existing_component_id` is still `None` afterwards.
- **A query with no `&T` term visits every archetype, the empty one included.**
  `World::spawn` places every entity in the empty archetype, so
  `query_data::<Entity>()` enumerates every live entity, componentless ones
  too, like bevy's `Query<Entity>`.
- **Twelve terms, not eight.** Bundles and filters stop at eight. A query
  spends terms on `Entity`, `Option` and `Has` as well as components, so the
  limit is higher, and tuples nest for anything beyond it. It is one line in
  the macro invocations to change.
- **Duplicate `&T` terms are allowed.** `(&A, &A)` yields the same reference
  twice; both are shared reads.
- **`Q: 'a` on the two methods.** `IterData<'w, Q>` stores `Q::Fetch<'w>`, so
  naming it needs `Q` to outlive the borrow. It costs callers nothing: the
  elided lifetime in `query_data::<(&A, &B)>()` is inferred and always
  satisfiable. The first draft without it was a compile error (E0311).
- **Name.** `query_data` follows bevy's `QueryData`. Rename freely: it is two
  method names and a re-export.

**The C counterpart: nothing new, on purpose.** A tuple of item types cannot
cross a C ABI, and the existing calls already carry everything it needs. A
three-component query is `mid_ecs_world_archetypes_matching_static` with
`with_ids` holding all three, then `mid_ecs_world_static_component_raw_span`
(and `_entity_ids`) per archetype per component. `Option<&T>` and `Has<T>` are
the status of that same `raw_span` call on an archetype from the list: `OK`
means present, `NOT_FOUND` means absent. Two new C checks pin both patterns on
the filter fixture (`Health`, `FlagA`, `FlagB`): the three-component query
returns exactly e3's row with hp 3 / FlagA 30 / FlagB 300 in step, and the
optional pass over `{Health}` finds 2 rows with a `FlagA` (20 + 30), 1
without, and 1 with a `FlagB`.

**Tests, from the sandbox (rustc 1.91.1; real CI not yet run).**
- 18 tests in `query_data.rs` and 2 in `archetype/iter_data.rs`, 1 doctest,
  2 C checks. Default lib tests 356 to 376 (361 to 381 with `scratch-arena`),
  doctests 3 to 4, C checks 129 to 131, the C program clean under `-Wall
  -Wextra` against both `libmid_ecs.so` and `libmid_ecs.a` and under valgrind.
- **Mutation testing: 17 of 18 mutants caught.** Caught: `Option` never
  `Some`, `Option` `Some` even when absent, `Has` inverted, `Has` always
  true, `Option` and `Has` made to narrow, an `Entity` row off by one, `&T`
  / `Option` / tuple fetch ignoring the row, `contains` always true, the
  filter ignored, the row counter not reset on a new archetype, the last row
  skipped, and the first archetype's rows skipped. Two survived the first
  test set, `&T` not pushing its id into the required list and
  `is_satisfiable` always true, because both only change *which archetypes
  are visited*, and an archetype without the column yields no rows, so items
  can't show it. The two tests in `iter_data.rs` look at the matched-archetype
  list itself and kill both. The one survivor is an equivalent mutant: the
  `&T` row-count clamp against a column shorter than its table, which the
  table invariant makes unobservable. It stays as a defensive bound.

**Not done.**
- **Mutable terms (`&mut T`, `Mut<T>`) in a tuple.** Done in the next pass: see
  "Mutable terms in `query_data`" below. (Not by generalising
  `SparseSet::get_disjoint_mut`, which only pairs two keys.)
- `Ref<T>`, and `Added`/`Changed` combined with `With`/`Without`/`Or` in one
  call (gap-list item 3). Done in a later pass: see "`Ref<T>`, `Added`/`Changed`
  terms and filters" below.
- **No benchmark, and no performance claim.** `next()` pays a per-row check on
  the current archetype's slices on top of the indexing, and the earlier call-
  site investigation (see "Mutable-query benches") showed that what a loop
  costs depends on the function around it, so nothing is assumed about it
  until it is measured. Optimization is paused.
- No `size_hint`, no cached matched-archetype list (`QueryState`-style):
  every call walks the archetypes once.

### Mutable terms in `query_data` (`Mut<T>`, `Option<Mut<T>>`, `World::query_data_mut`)

The follow-up the previous section left open: write access in the same
tuples. `Mut<T>` and `Option<Mut<T>>` are new `QueryData` terms, and
`World::query_data_mut::<Q>()` / `query_data_mut_filtered::<Q, F>()` take
`&mut self` and accept any terms, mutable or not:

```rust
for (mut pos, vel, frozen) in world.query_data_mut::<(Mut<Pos>, &Vel, Option<&Frozen>)>() {
    if frozen.is_none() { pos.0 += vel.0; }
}
```

| term | item | archetype must contain `T`? | access |
|---|---|---|---|
| `Mut<T>` | `Mut<T>` | yes | write |
| `Option<Mut<T>>` | `Option<Mut<T>>` | no, `None` where it is absent | write |

`Mut<T>` is the crate's existing change-tracked wrapper: a write through it
stamps the row changed, a read does not, so `query_changed` and
`Mut::is_changed` see what a `query_data_mut` call wrote, exactly as they see
`query_static_mut`.

**What changed in the code.** `query_data.rs` gained the two terms, the
`ReadOnlyQueryData` marker, the hidden `AccessEntry` and `MutFetch`, and the
trait grew `collect_access` and changed two signatures (`init_fetch` takes a
`&mut TableAccess`, `fetch` takes `&mut Fetch`). In `archetype/iter_data.rs`
`TableView` became `TableAccess` (two modes, below) and `IterDataMut` is the
exclusive iterator beside `IterData`. `iter_mut.rs` changed one word: `select`
is now `pub(super)`. `query.rs` has the two new methods, and `query_data`'s
bound went from `QueryData` to `ReadOnlyQueryData`. That is source-compatible
for every read-only caller, and a `compile_fail,E0277` doctest pins that a
`Mut` term is rejected on a shared `&World`.

**Decisions, with reasons.**
- **One trait with a read-only marker, not a second trait.** `QueryData` stays
  the single term trait and `ReadOnlyQueryData` (implemented by `Entity`,
  `&T`, `Option<&T>`, `Has<T>` and tuples of them) is what `query_data(&self)`
  requires: the same split bevy has. A parallel trait would have duplicated
  the four read terms and the tuple macro, and everything still to come
  (`Ref<T>`, `Added`/`Changed` terms, access sets for a scheduler) wants one
  term trait. `collect_access`, which every term uses to declare what it
  reads and writes, is the seed of the access-set primitives gap-list item 4
  needs; nothing about it is public yet.
- **No raw `&mut T` term.** A raw write would skip the change ticks and a
  `Changed` query would miss it. Only `Mut<T>`, which stamps on an actual
  write, is offered.
- **Conflicting access panics when the query is created.** One query may read
  a component through any number of terms, or write it through exactly one
  `Mut` term and nothing else. `(&A, Mut<A>)`, `(Mut<A>, Mut<A>)`,
  `(Mut<A>, Option<&A>)` and the like panic, naming the type, whether or not
  any row holds an `A`: it is a fact about the query's type. Checked by
  `TypeId`, not by registered id, so it does not depend on what the world has
  seen (two *different* unseen types do not conflict, and a test pins that).
  `Has<T>` and `Entity` read no data and never conflict. It is a run-time
  check because stable Rust cannot compare the types inside a tuple. This
  matches the existing `iter2_mut_filtered`, which already asserts its two
  types differ.
- **Zero `unsafe`, with a plan instead of `get_disjoint_mut`.**
  `SparseSet::get_disjoint_mut` only pairs two keys, and a tuple of up to
  twelve terms needs an arbitrary number of borrows. Instead, when the
  exclusive iterator enters an archetype it makes one pass over
  `columns.iter_mut()` and one over `ticks.iter_mut()`. `iter_mut` yields every
  column exactly once, so each one can go to exactly one place: kept shared
  and copied to every reader if the query only reads it, or moved whole into a
  slot that a single `Mut` term takes it from if the query writes it. Which is
  which comes from a per-query plan (`(component, written)`), built once from
  the terms' declarations after the conflict check.
- **Handing out `&mut` rows in safe code.** A `Mut` term holds its value and
  tick slices and, per row, takes them out of its fetch with `mem::take`,
  splits the first element off with `split_first_mut` and puts the rest back:
  `slice::IterMut` without the `unsafe`. That makes `fetch` order-dependent, so
  the trait now documents the contract (rows `0, 1, 2, ..` of an archetype, in
  order, once each, below `clamp_len`), which both iterators keep. Read terms
  still index by row.
- **`TableAccess` has two modes.** *Shared* (the read-only iterator) looks
  columns up in the table on demand, as before. *Exclusive* holds the slots
  the plan assigned. One object is reused across archetypes, so entering one
  allocates nothing once the first has sized its slot lists. Asking for a
  column the plan did not give, or one already taken, yields `None`, which the
  terms turn into an empty slice, the same defensive shape as a missing lazy
  column.
- **Archetype selection is one helper for both iterators** (`plan_matches`),
  so pruning is decided in one place and tested through it.

**Tests, from the sandbox (rustc 1.91.1; real CI not yet run).**
- 32 new tests (30 in `query_data.rs`, 2 in `archetype/iter_data.rs`) and 3
  new doctests (a worked example, a `should_panic`, the `compile_fail`).
  Default lib tests 376 to 408 (381 to 413 with `scratch-arena`), doctests 4
  to 7. The 20 earlier `query_data` and `iter_data` tests passed unchanged on
  the refactored trait before any new test was written.
- Covered: writes landing; mixing `Mut` with `Entity`, `Option`, `Has`;
  `Option<Mut<T>>` writing where present, `None` elsewhere, never narrowing;
  several `Mut` terms in one query; stamps only on the rows and components
  actually written; a read through `Mut` not stamping; agreement with
  `query_static_mut` in rows, values and stamps; alignment after despawn and
  migration; several archetypes in one query; zero-sized `Mut`; unseen types;
  filters; the same order as the read-only query; an iterator dropped early; an
  emptied archetype reused; 300 rows over several archetypes; twelve mixed terms
  with four `Mut`; nine conflicting shapes (including nested tuples, an unseen
  type, and no row of that type anywhere) plus the panic message naming the type;
  and the shapes that must *not* conflict.
- **Mutation testing: 22 of 24 mutants caught.** Caught: the tick cursor not
  advanced; stamping with the wrong tick; the conflict check disabled, needing
  both to write, or comparing ids instead of types; the plan marking everything
  or nothing as written; the slot and tick lists not cleared between archetypes;
  shared and exclusive swapped; the signature or entity slice left empty; an
  empty plan; the filter ignored; `Option<Mut>` present when absent;
  `Mut` not required, always satisfiable, or `Option<Mut>` required; and
  each term declaring the wrong access (`Mut` none, `&T` as a write, `Option<&T>`
  none, `Has` as a read). The two survivors are equivalent mutants: the plan
  letting a write not win over a read of the same component (conflict
  checking already rejects every such mix, so it cannot arise), and the `Mut`
  row-count clamp (the table invariant makes it unobservable, like the `&T`
  one before it). Pruning for `Mut` terms cannot be seen through items for the
  same reason as before, so `iter_data.rs` tests the matched list directly.

**Performance: not measured, and one thing to expect.** The header of
`iter_mut.rs` records that its first hand-written version kept one cursor per
column and measured 19 Ir/row for one column and 41 for four, which is why it
uses one nested `Zip` with a single shared row index instead. This iterator is
the per-term-cursor layout for its `Mut` terms (two `mem::take` and
`split_first_mut` steps each), so expect it to be slower than
`query_static_mut` until it is benchmarked. Optimization is paused, so nothing
is claimed or changed.

**The C counterpart: nothing new.** Mutation from C is still the open design
question the mutable queries left (the span pointer is `const`, and a plain
write through it would skip the change ticks).

**Not done.**
- `Ref<T>`, and `Added`/`Changed` as terms or combined with `With`/`Without`/`Or`
  in one call (gap-list item 3): done, see "`Ref<T>`, `Added`/`Changed` terms
  and filters" below.
- A public access-set type and a `SystemParam`-style trait (item 4): the hidden
  `AccessEntry` is only the seed.
- `par_iter`, which needs item 4.
- No `size_hint`, no cached matched-archetype list; every call walks the
  archetypes once.
- No benchmark (above).

### `Ref<T>`, `Added`/`Changed` terms and filters (`data_filter.rs`)

Gap-list item 3 against bevy_ecs: the read-side wrapper `Ref<T>`, and
`Added`/`Changed` usable inside a multi-term query, combined with
`With`/`Without`/`Or` in one call. Archetype Core only, Rust only. Until now change
detection was single-component and separate from everything else
(`query_added::<T>`, `query_changed::<T>`, the C `..._added_rows` /
`..._changed_rows`). Those are untouched.

**What shipped.**

| piece | what it is |
|---|---|
| `Ref<T>`, `Option<Ref<T>>` | `QueryData` terms. `Deref` to `&T` plus the row's ticks: `is_added(&tracker)`, `is_changed(&tracker)`, the same arguments `Mut` takes. Needs no tracker when the query is created. `Copy`. |
| `Added<T>`, `Changed<T>` as terms | `QueryData` terms yielding a `bool` per row. Never skip a row. Need the tracker at creation. |
| `Added<T>`, `Changed<T>` as filters | `DataFilter` (new sealed trait, `data_filter.rs`): skip the rows that fail. Compose with `With`, `Without`, tuples and `Or`, each `Or` member judged on its own. |
| `query_data_since`, `query_data_filtered_since`, `query_data_mut_since`, `query_data_mut_filtered_since` | The four methods that take a `&ChangeTracker`. |

The user chose "both" (terms and filters) when asked. The term form is the
same two types as the filter form, so `Changed<A>` in the item position is a
`bool` and in the filter position is a row skip.

**The tracker rule.** `Added`/`Changed` compare against a `ChangeTracker`, so a
query containing one is only valid through a `_since` method. The plain
methods (`query_data`, `query_data_filtered`, `query_data_mut`,
`query_data_mut_filtered`) panic *when the query is created* if `Q` or `F`
has one (`QueryData::TRACKED` / `DataFilter::TRACKED`, folded at compile
time, free otherwise). The alternative, answering against a made-up
`ChangeTracker::new()`, would silently report every row as new.

**Why a second filter trait instead of extending `QueryFilter`.** `QueryFilter`
decides once per archetype and the frozen `Iter1`/`Iter2` bodies never see
it. A row's ticks differ from the next row's, so `Added`/`Changed` need a per-row
decision those iterators have no place for. If they implemented
`QueryFilter`, the old `query_static_filtered` family would accept them and
silently ignore the row part. As a separate trait the old methods reject them
at compile time and `query.rs`'s existing paths are not modified. `DataFilter`
is implemented for `With`, `Without`, `()` by delegating to their `QueryFilter` impls
(a test pins that both traits select the same archetypes for everything they
share), for tuples (all members), for `Or` (any member) and for the two new
filters. `Or` needed a second group trait (`DataOrGroup`) because each member
has to carry its own archetype-level verdict into the row decision:
`Or<(Added<A>, Changed<B>)>` keeps a row of an `{A, B}` archetype if its `A` is
new *or* its `B` changed, and a row of an `{A}` archetype if its `A` is new.

**How a row filter runs.** On entering an archetype the iterator evaluates the
filter once over all its rows and records the survivors in a reused
`Vec<usize>` (`select_rows` in `archetype/iter_data.rs`), then walks only
those. Only `F::TRACKED` filters take that path; for every other filter the
loop is the code that existed before, the branch being a constant. In the
exclusive iterator the pass runs *before* the `Mut` terms take their slices
(`TableAccess::peek_ticks`), which is what makes the common
`query_data_mut_filtered_since::<Mut<Hp>, Changed<Hp>>` legal. `Mut` terms
hand their slices out one row at a time in order, so rows a filter skipped are
still fetched and the item dropped (dropping a `Mut` stamps nothing); only the
rows up to the last selected one are touched.

**Access rules.** A `Ref`, `Added` or `Changed` *term* on a component counts as
a read of it and conflicts with a `Mut` of the same component (panic at
creation, the existing rule). The `Added`/`Changed` *filters* do not: they
read ticks, finish, and only then does the `Mut` take the slice. The plan
(`build_plan`) grew a third flag per component, "tick slice needed for
reading", set by terms (`AccessEntry::ticks`) and by filters
(`DataFilter::collect_tick_reads`); a component only a filter mentions still gets
its tick slice. In shared mode `TableAccess` now carries the world tick (it
used to be zero there, since nothing read it) and the tracker's last-run tick.

**Verification.** Default lib tests 483 to 512 (scratch-arena 488 to 517),
doctests 7 to 10, `ffi::` tests unchanged at 76. The central test is a
differential one: 600 steps of random spawns, despawns (swap-removes),
migrations in both directions, writes, tick steps and tracker updates, and at
every step `Changed<A>`, `Added<A>`, `Or<(Changed<A>, Changed<B>)>`, a mixed
`Or`, and `(Changed<A>, With<B>)` are compared against the older
`query_added`/`query_changed` plus membership checks, with the history
asserted to produce both strict-subset and empty selections; every fifth step
the exclusive iterator writes through the same selection and every value is
checked. Mutation testing: 47 mutants, 44 caught, 3 equivalent survivors
(all defensive bounds the table invariant, "ticks column as long as the
table", makes unreachable: the `None => false` in `matches_row`, the redundant
`table.contains` guard before `peek_ticks`, and `row <= len` in the
selected-row truncation). The first run caught 37; the other seven exposed
real test gaps, fixed before shipping: the matched-archetype list for row
filters was unpinned (pruning is invisible through items), tuple and `Or`
filters on a component the query has no term for were untested (their tick
slices never reached the iterator), the merge of a term's and a filter's
request for one component's ticks was untested, and the `Ref` per-row test
passed with `this_run` replaced by zero because wrapping arithmetic keeps the
ordering for small ticks: it now also checks a fresh tracker, where it does
not. (Also learned: the world starts at tick 1, not 0, so a fresh tracker sees
everything.)

**Not done.**
- **No benchmark, and no performance claim.** Expect a tracked filter to cost
  one extra pass over an archetype's rows (one tick read per filter member
  per row) and a `Vec<usize>` that is reused; expect the exclusive iterator to
  keep the per-term-cursor cost of `IterDataMut`. `IterData`/`IterDataMut` gained
  fields, so the untracked path is not guaranteed bit-identical in codegen to
  before. Optimization is paused; none of this was measured.
- No C counterpart: `..._added_rows` / `..._changed_rows` remain the C-side
  change detection.
- No `query2_added` form: `query_data_filtered_since::<(Entity, &A, &B), Added<A>>`
  covers it.
- No `AnyOf`. (Resource change detection and the tick wraparound check are built:
  see "Resource change detection" and "Tick wraparound".)

### Access sets: `access.rs` (`Access`, `FilteredAccess`, `FilteredAccessSet`)

Gap-list item 4, first half: the primitives a scheduler and a parallel
iterator stand on. Nothing here runs anything and nothing is enforced at
runtime; it answers one question, exactly: *could these two pieces of work
touch the same data with at least one of them writing?* The other half of
item 4 (the `SystemParam` trait and system state) is not built; see "Not done".
Safe code only, no `unsafe`. This split follows `crates/mid-app`'s own header,
which says it waits for mid-ecs to define the parameter convention rather than
invent one twice.

| type | what it is |
|---|---|
| `Access` | Component and resource reads and writes as sets, plus read-all / write-all flags for exclusive work (`&mut World`). `add_*`, `extend`, `get_conflicts`, `is_compatible`. |
| `FilteredAccess` | An `Access` plus the query's archetype constraints (`with`, `without`). `FilteredAccess::of_query::<Q, F>()` builds one from a query type, no world needed. |
| `FilteredAccessSet` | The filtered accesses of one system, one per parameter, plus their union. `get_conflicts_single` (a new parameter against the ones already there) and `get_conflicts` (system against system, part against part). |
| `AccessConflicts` | The answer: empty, or `is_all()` (one side claims a whole class), plus the sorted, deduplicated type names in conflict. `Display` for panic messages. |

**Decisions.**
- **Keyed by `TypeId`, not `ComponentId`.** A system is analysed before the
  world holds an entity, and a type the world has never seen has no
  `ComponentId`. The type name kept beside each id is for messages only. This is
  the same choice `query_data_mut`'s own conflict check already made.
- **Components and resources are separate namespaces.** Component `A` and
  resource `A` never conflict. Conflict names are deduplicated by type name, so
  if the same type is in conflict as both, it is named once.
- **Constraints decide.** `Query<&mut A, With<B>>` and `Query<&mut A,
  Without<B>>` are compatible: no entity is in both. A required term (`&B`,
  `Mut<B>`, `Ref<B>`, `Added<B>`, `Changed<B>`) constrains like `With<B>`; an
  optional term and `Has` constrain nothing. A contradictory query (`With<B>`
  and `Without<B>`) matches nothing, so it conflicts with nothing. A component
  that one side excludes cannot be the shared one (`Option<&A>` + `Without<A>`
  never reads an `A`). Resource conflicts do not depend on entities and always
  stand.
- **`Added`/`Changed` are reads.** As terms and as filters they read the
  component's change ticks, so a system that writes `T` conflicts with one that
  tests `Changed<T>`; a ticks read racing a ticks write would be a data race. A
  `Mut<T>` term and a `Changed<T>` *filter* in one query are one access (a
  write), which is why `Mut<T>` filtered by `Changed<T>` is legal.
- **`Or` is conservative.** An `Or` adds every arm's reads and none of its
  `with`/`without` constraints (only one arm needs to hold). Dropping a
  constraint can only make two accesses look more likely to overlap, so it can
  report a conflict a finer analysis would not, never miss one.
- **Exclusive work** is `write_all()`: it conflicts with any access that
  touches anything and with nothing that is empty. `read_all()` conflicts with
  writers only.
- **Plumbing.** `QueryData` and `DataFilter` each gained a hidden
  `update_access(&mut FilteredAccess)`, so the description lives with the term
  and the filter. A test pins that it agrees with the older `collect_access` /
  `collect_required` the iterators actually use. `validate_access`, the
  term-conflict check `query_data_mut` makes at creation, became `pub(crate)`
  with a context argument so `of_query` reports the same conflict
  (`FilteredAccess::of_query: conflicting access to ...`).

**Verification.** Default lib tests 512 to 541, scratch-arena 517 to 546,
doctests 10 to 11 (`FilteredAccess::of_query`), `ffi::` tests unchanged at 76.
The central test is an exhaustive oracle: 23 query specs (terms and filters of
every kind, including `Or`, a contradictory filter, and `Mut` with `Changed`
on the same component), every ordered pair (529), each compared against a brute-force search
over all 8 archetypes of a 3-component universe built from the real
archetype-level semantics (`matches_component_set`, `collect_required`,
`collect_access`, `collect_tick_reads`), with no reference to `FilteredAccess`.
The verdict must never miss a real conflict, must equal the oracle exactly for
every pair without an `Or`, and the table is asserted to contain both
verdicts and at least one pair where `Or` is more conservative than the oracle.
Mutation testing: 62 mutants over `access.rs` and the `update_access`
implementations; 52 caught first time, the other 10 split into 8 test gaps
(only one direction of `read_all` tested, `extend` leaving a stale read entry,
`writes_resource` under exclusive access, names repeated across pairs, the
`Display` separator) fixed by new tests, and 2 equivalent mutants: `is_exclusive`
with `||` for `&&` (the two flags are only ever set together, by `write_all`), and
the inner `dedup` in the per-class conflict list (an id is never in both the
read and the write map, so it cannot repeat there).

**Not done.**
- **`SystemParam`, `SystemMeta`, system state, a system trait, and parameter
  types (`Query<Q, F>`, `Res`, `ResMut`, `Commands`, `Local`).** The second half
  of item 4. Its prerequisite, the cell that lets one system hold several
  borrows of one `World`, and then the parameters and systems themselves, were
  added afterwards: see "`WorldCell`: shared access with checked disjointness"
  and "System parameters" below.
- No runtime enforcement: nothing here stops a caller from ignoring a
  conflict.
- Bevy's finer, per-archetype runtime access (to let two systems run while
  their archetype sets happen not to overlap) is not modelled; the constraint
  analysis above is static.
- The Sparse Shell has no access description; only Archetype Core components
  and resources.
- No benchmark: these are setup-time structures, not on any query path.

### `WorldCell`: shared access with checked disjointness (`world_cell.rs`, `interior.rs`)

Gap-list item 4, the prerequisite for its second half: one handle that lets
several queries and resources of one system be live at once. A system with
`Query<&mut A>`, `Query<&B>` and `ResMut<R>` holds three borrows of one `World`;
safe Rust cannot express "these touch different data" when the difference is
only in the *types* the queries name. The user chose to add this, accepting the
crate's first `unsafe` outside the FFI boundary. All of it is in four places:
`interior.rs`, `world_cell.rs`, `TableAccess::load_cell` /
`Archetypes::iter_data_cell` in `archetype/iter_data.rs`, and
`Resources::get_mut_unchecked`.

**The rule.** A `WorldCell` function may be called only while nothing else
reads what it writes or writes what it reads. That is exactly what
`FilteredAccess::of_query::<Q, F>()` (previous section) describes and what
`is_compatible` decides, which is why a system will check its parameters' access
sets when it is set up. Violating it is undefined behaviour; nothing is checked at
runtime (no borrow flags), so every query and resource function on the cell is
`unsafe` and states the contract. The one check made regardless is the one
`query_data_mut` already made: a query that conflicts with itself
(`(&A, Mut<A>)`) panics before anything is touched.

**Why that is enough: `Interior<T>`.** Two `&mut` to different columns of one
archetype are only sound if neither is reached through a `&mut` to (or a
conflicting `&` of) the structure that holds the other. So each column of
component values, each column of change ticks and each resource is its own
`UnsafeCell` (`Interior<T>`, `repr(transparent)`: same size, no extra pointer
hop). The archetype list, the tables and everything that locates a column are
only ever borrowed shared through the cell. The cell comes from
`World::as_world_cell(&mut self)` and carries that borrow, so nothing outside
can touch the world meanwhile: any overlap would have to come from two calls on the
cell, and those are `unsafe`. `Interior`'s `Deref` is safe because a `&mut` from
`get_mut_unchecked` only exists while a cell holds the world's exclusive borrow.
All the existing `&mut` paths (`get_mut`-style, migrations, the exclusive
iterator) are unchanged except for type-level auto-deref (`&mut ***dest` at six
sites), and `DerefMut` goes through `UnsafeCell::get_mut`, which is free.

**What the cell offers.** `WorldCell::query_iter` (read-only terms) and
`query_iter_mut` (any terms, any `DataFilter`), both taking the two ticks
(`this_run`, `last_run`) instead of a tracker, `resource` / `resource_mut`,
`contains_resource`, `change_tick`. `query_iter_mut` is the existing exclusive
iterator with a different archetype source: `IterDataMut` became generic over
an `ArchetypeSource`, with the safe `ExclusiveSource` (unchanged behaviour) and
`CellSource`, whose `load_next` calls `unsafe TableAccess::load_cell`. It
reads archetypes through `&Archetypes` and takes the written columns and tick
slices through their `Interior`, once each, per the same per-query plan. The
terms, filters, row selection and conflict check are shared code, not copies.

**Not through a cell.** Adding an entity, inserting or removing a component,
inserting or removing a resource: those change structures other cell calls
hold shared references into, and belong to commands applied afterwards with
`&mut World`. The cell is not `Send`/`Sync` (raw pointer); running two systems
at once (item 5) has to make that decision.

**Verification.** Default lib tests 541 to 554 (13 new: 3 `Interior`, 10 cell),
`ffi::` unchanged. The cell tests include queries that are live at the same
time over the same archetypes (a reader of `B` nested inside a writer of `A`;
two writers of different components holding all their items at once), cell
results against the safe queries (read-only with `Changed`, and a filtered write
compared with the safe exclusive iterator on an identical world, values and
stamps), the tick slice of a component the query only filters on, a resource
borrowed beside component queries, and reuse of the world once the cell is
dropped. Mutation testing of the cell layer: 18 mutants, 18 caught (one by hang
detection). valgrind over the cell, interior, access and `query_data` tests
(102 tests): no errors. **Not verified: aliasing.** Neither valgrind nor the
sandbox can check Rust's aliasing rules (no nightly, so no Miri). Run
`cargo +nightly miri test -p mid-ecs --lib world_cell::` (and
`MIRIFLAGS=-Zmiri-tree-borrows` too) before relying on this; the tests were
written to be Miri-friendly (no FFI, no threads).

**Not done.**
- The second half of item 4 (done afterwards, see "System parameters"). Nothing
  in `WorldCell` itself checks anything; the check is
  `FilteredAccessSet::get_conflicts_single`, made when a system is set up.
- No benchmark. The storage change adds no indirection and no field, and the
  typed paths do not call the new code, but the structural-change and query
  benchmarks were not rerun here; optimization is paused.
- The Sparse Shell is not behind `Interior` and has no cell access.
- The FFI resource and component paths are unchanged (they use the `&mut`
  side).

### System parameters: `system_param.rs`, `system.rs`

Gap-list item 4, second half, on top of the access sets and the `WorldCell`
(previous two sections). A system is a plain function whose arguments name what
it needs from the world; setting it up checks those arguments against each
other, and running it hands them out as live borrows of one world.

| piece | what it is |
|---|---|
| `SystemMeta` | The name (for messages), the registered `FilteredAccessSet`, and the tick of the system's previous run. `add_param_access` registers one parameter's access and panics if it conflicts with one already there. |
| `SystemParam` (`unsafe trait`) | `State`, `Item<'w, 's>`, `init_state` (registers access), `unsafe get_param` (this run's value from a `WorldCell`), `apply` (deferred work, with `&mut World`). An implementor promises `get_param` makes no access `init_state` did not register. |
| `Query<'w, 's, Q, F = ()>` | Any `QueryData` filtered by any `DataFilter`. `iter(&self)` for read-only `Q`, `iter_mut(&mut self)` for any, and `par_iter` / `par_iter_mut` for the same on several threads (next section). `Added`/`Changed` measure against the system's own previous run. |
| `Res<T>`, `ResMut<T>`, `Option<..>` of each | A resource, shared or exclusive. Missing: a panic naming system and type when the system runs, or `None` for the `Option` forms. |
| `Local<T>` | `T::default()` kept in the system across runs; one per use. |
| `Commands` | The existing `CommandQueue` as state; applied by `apply` after the system returns. |
| tuples | Up to twelve parameters (nest for more). |
| `SystemState<P>` | A parameter set initialized against a world, usable outside any system: `new`, `get(&mut World)`, `apply`. |
| `System` | `initialize` (builds state and runs the conflict check), `access`, `unsafe run_unchecked(WorldCell, this_run)`, `apply_deferred`, and `run(&mut World)` = initialize, run at the current tick and then advance it, apply. |
| `IntoSystem`, `FunctionSystem` | Functions and closures of up to twelve `SystemParam` arguments; `Marker` types keep the three impls (parameter functions, `fn(&mut World)`, already-a-system) apart. |
| `ExclusiveFunctionSystem` | A function of `&mut World`: its access is `write_all`, so it conflicts with everything and needs the cell's `world_mut`. |
| `World::run_system_once` | Builds, initializes, runs and applies one system. A fresh system has never run, so `Added`/`Changed` see everything as new. |

**Why this is sound.** A system's parameters can hold several borrows of one
world at once because their access was checked, when the system was set up,
with `FilteredAccessSet::get_conflicts_single`: two parameters that could alias
(`Query<Mut<A>>` beside `Query<&A>`, `ResMut<R>` beside `Res<R>`, a writer of
`B` beside a `Changed<B>` filter) are refused with a panic naming the system and
the types. That is the premise the `WorldCell` functions' safety contracts are
written in. The remaining aliasing is *within one parameter*: a `Query` cannot
be iterated twice at once because `iter_mut` takes `&mut self` (a `compile_fail`
doctest pins that), and the iterator borrows for the query's borrow, not the
world's, because `WorldCell` is covariant in its lifetime. `get_param` is
`unsafe` and `System::run_unchecked` states the contract for a runner: nothing
conflicting with `System::access` may run at the same time.

**Change detection in a system.** `System::run` runs at the world's *current*
tick and advances it afterwards; the system's writes are stamped with that tick,
and its next run measures from it. So its own writes are invisible to itself,
and anything else that writes after the run is stamped with the later tick and
is seen. My first draft advanced first and ran at the new tick, which made writes
made *between* runs by other code look not-newer to the next run (stamp equal to
`last_run`); a differential test against `ChangeTracker` over a random history
(below) pins the right behaviour. `SystemState::get` does not advance the tick,
like `ChangeTracker`: call `World::increment_change_tick` per step of your own
loop.

**Verification.** Default lib tests 554 to 583, doctests 11 to 14 (the
`System` module example, the `Query` example and its `compile_fail`, which was
checked to fail for the right reason: E0499), `ffi::` unchanged. The tests cover
a reader and a writer of different components live together in one system (and
nested), conflicts of every kind refused (`Mut` beside `&`, resource read beside
write, a writer beside a `Changed` filter, and the `Option` forms), disjoint
`With`/`Without` writers accepted and run, change detection across runs (first
run sees all, own writes invisible, writes by others seen, inserts count),
`Commands` not applied until the system returns and the queue reusable, `Local`
state per system, resources present and missing, every term kind, exclusive
functions and closures, functions of zero, twelve and tuple parameters,
annotated closures, `run_unchecked` + `apply_deferred` by hand, `SystemState`,
and the 500-step differential test: a system with `Changed<A>`, `Added<A>` and
`Or<(Changed<A>, Changed<B>)>` queries compared on every step with
`World::query_data_filtered_since` and a `ChangeTracker` over random spawns,
despawns, migrations, writes and tick steps. Mutation testing: 28 mutants over
the two files, 26 caught first time, the other 2 (the `Option<Res>` /
`Option<ResMut>` registrations) were a real test gap, fixed. Aliasing is
still not checked by anything here: see the Miri note in the `WorldCell`
section, which applies to these tests too.

**Not done.**
- **A runner.** Ordering several systems, run conditions, system sets, and
  running them in parallel are not here. The hooks a runner needs are
  `System::access`, `run_unchecked` and `apply_deferred`; `mid-app`, which still
  stores `Box<dyn FnMut(&mut World)>` and uses the Sparse Shell API, is
  untouched. Parallel execution (item 5) also has to decide `Send`/`Sync`.
- Systems return nothing (no `In`/`Out`), there is no `ParamSet`, and no cached
  matched archetypes: every `iter` and every lookup re-resolves them, like the
  `query_data` methods (item 8). (`Query::get`, `single`, `contains`, `count` and
  friends are built: see "Looking entities up in a query".)
- Resource change detection (`Res::is_changed`, `ResMut`) is built: see "Resource
  change detection".
- No benchmark: these are setup-time structures plus one call per parameter per
  run. The per-row cost of a system's query is that of `query_iter` /
  `query_iter_mut`, which are the existing iterators.

### Looking entities up in a query (`Query::get`, `single`, `contains`, `count`, ...)

`Query` had `iter`, `iter_mut`, `par_iter` and `par_iter_mut` and nothing else:
no way to ask about one entity, which nearly every real system does. Ten
methods now sit beside them, with bevy's names and meanings.

| method | does | error |
|---|---|---|
| `get(e)` / `get_mut(e)` | the item for one entity | `QueryEntityError` |
| `get_many([e; N])` / `get_many_mut([e; N])` | the items for N entities, in order | `QueryEntityError` |
| `iter_many(entities)` | the items for a list, skipping non-matches | none |
| `single()` / `single_mut()` | the one item | `QuerySingleError` |
| `contains(e)` | whether the query matches `e`, without fetching | none |
| `count()` / `is_empty()` | how many rows match, without fetching | none |

`QueryEntityError` is `NoSuchEntity(e)` (not alive: never existed, despawned, or
a stale handle whose slot was reused), `QueryDoesNotMatch(e)` (alive, but the
archetype lacks a required component or fails a `With` / `Without` / `Or`
filter, or a row-level `Added` / `Changed` filter rejects the row) and
`AliasedMutability(e)` (the same entity twice in `get_many_mut`).
`QuerySingleError` is `NoEntities` or `MultipleEntities`.

**A lookup is a one-row iteration.** Nothing about matching was re-implemented.
`Archetypes::get_data_cell` builds a single window over the entity's row (the
`WindowDesc` that `par_iter` uses for batches) and runs the same `IterDataMut`
over it, so the archetype-level test, the row filter, `Ref` ticks and `Mut`
stamping are the iteration's by construction, and so is the access contract.
`contains` and `count` build no item at all: `matches_entity` and
`count_matching` evaluate the archetype-level test and the row filter only
(reading ticks, nothing else), so they work for a writing query and take no
column handle.

**Liveness is checked first.** Locations are keyed by slot, so a stale handle
would find the slot's new occupant; `WorldCell` checks `is_alive` before looking
anything up, the same reason `write_row_bytes` has its caller check. Pinned by a
test in which a stale handle meets a new entity with the same slot.

**Borrowing is bevy's.** `get` borrows the query shared and needs a read-only
`Q`; `get_mut` borrows it exclusively, so a second `get_mut` while the first
item is live is refused at compile time (a `compile_fail` doctest, checked to
fail with E0499 and to compile once the first item is dropped). Several
entities at once go through `get_many_mut`, which refuses a repeat before
looking anything up (an O(N^2) scan of a const-sized array), so no row is
handed out twice. `single_mut` looks ahead for a second item to rule out
`MultipleEntities`; that item is built and dropped without being written
through, so it stamps nothing (pinned).

**A query that reads and writes one component panics** in a lookup exactly as in
an iteration, and before the entity is looked up, whether or not it matches
(pinned through `WorldCell::query_get_mut`; a `Query` parameter cannot reach it,
because `SystemState::new` refuses such a query).

**Cost.** Each `get` resolves the query's component ids (one hash lookup per
term), builds the plan vectors and one window; it is not a step of an iteration.
Not benchmarked (optimization is paused). Cached query state (item 8) is the
fix, and would serve `contains` and `count` too.

**Verified (sandbox, rustc 1.91.1).**

- Fourteen new tests (lib 706 -> 720, doctests 18 -> 19):
  archetype-level matching including `With` / `Without` / `Option` / `Has`; dead
  and stale handles; row-level `Changed` through `get`, `contains` and `count`;
  `get_mut` stamping only the row written through, and not for a read; `get_many`
  keeping order and allowing repeats; `get_many_mut` refusing a repeat,
  writing disjoint rows and stamping only what was written; `iter_many` order and
  skipping; `single` and `single_mut` in all three outcomes, with the refused
  look-ahead stamping nothing; `count` and `contains` on a writing query; a query
  over a type the world never saw; one satisfiable term not rescuing an
  unsatisfiable one; the self-conflicting query panicking first. The central test
  is differential: 400 steps of random spawns, despawns, insertions, removals,
  writes and ticks, and at every step six read-only query shapes (`&A`, `&A, &B`,
  `Without<B>`, `Option<&C>` under `With<A>`, `Changed<A>`, and an `Or` of `Added`
  and `Changed`), each checked for every entity ever created, alive or not:
  `get` is `Ok` exactly when iteration yields the entity, with the same item,
  and otherwise says dead or does-not-match correctly; `contains` agrees;
  `count`, `is_empty` and `iter_many` agree with iteration. Every shape must
  match something often enough, and the two row-filtered shapes must also match
  nothing often enough, or the test fails.
- Mutation testing: 32 mutants of the new code (every guard in the
  archetype-level match, the window, the tick arguments of every method, the
  liveness checks, the error mapping, both counters, `get_many` order, the
  duplicate scan, `single`'s three outcomes), all caught, none survived. The first pass left three survivors, each a missing test
  (`single()`'s two error outcomes and the tick arguments of `get_many_mut`); the tests
  were added and the whole suite rerun. Valgrind over the `system_param::` and
  `world_cell::` lib tests (the window code is raw pointers): no invalid access or
  uninitialised read; the only report is the 48-byte "possibly lost" inside
  libtest's own thread set-up.

**Not done.**

- `iter_many_mut` (a lending iterator, so a different shape), `get_unchecked`,
  `Query::transmute` / `as_readonly`, `ParamSet`.
- `EntityRef` / `EntityMut` (whole-entity access by type), a separate gap.
- Lookups in the Sparse Shell, which has no query terms.

### Resource change detection (`Res`, `ResMut`, `World::resource_changed`)

Components had change detection (`Ref`, `Mut`, `Added`, `Changed`); resources
had none, so a system could not ask "has the gravity setting changed since I last
ran". Each resource now stores a `ComponentTicks` (added, changed) next to its
value, stamped by the same rules as a component's.

| event | added | changed |
|---|---|---|
| `insert_resource` of a new resource, or a C write that creates it | now | now |
| `insert_resource` over an existing one | kept | now |
| `World::get_resource_mut` | kept | now (when handed out) |
| a C `mid_ecs_world_resource_write` over an existing one | kept | now |
| removed, then inserted again | now (a new addition) | now |
| reading (`get_resource`, a C span, `Res`) | | |

A replacement is made **in place** (`mem::replace` into the existing box), which is
why the added tick can be kept, and also means a replaced value keeps its address.
The C span contract stays the conservative one it was (a Rust-side insert may
invalidate), but a test now pins that the typed insert does not move the value.

**In a system.** `Res<T>` carries the system's last-run tick and `ResMut<T>` the
same plus a write path, so both answer with no argument, as in `bevy_ecs`:
`is_added()` and `is_changed()` ("since this system last ran"), `last_changed()` and
`added()`. `ResMut` stamps *changed* when it is dereferenced **mutably**
(`DerefMut`), exactly as `Mut` does for a component, so a system that takes a
`ResMut` and only reads costs no other system a change; it also has
`set_changed()` (a mutation made some other way) and `bypass_change_detection()`
(a write no reader needs to see). A `ResMut` that has written sees its own write
as changed from that point on (pinned). `Option<Res<T>>` and `Option<ResMut<T>>`
carry the same. This differs from a component's `Ref` / `Mut`, which take a
`ChangeTracker` argument, because those can also come from a world query that has
no system; a resource parameter can only come from a system.

**`World::get_resource_mut` stamps on access, not on write.** It returns a plain
`&mut T`, so there is nothing to intercept a write, and changing its type would
break every caller. It follows the rule `get_static_mut` already has (stamped when
handed out), and over-reports like it; a system that wants the precise rule uses
`ResMut`.

**Outside a system.** `World::resource_added::<T>(&tracker)` and
`resource_changed::<T>(&tracker)` (the resource forms of `query_added` /
`query_changed`), and the by-id forms `resource_added_since(id, last_run)` /
`resource_changed_since(id, last_run)` for a caller that holds a last-run tick.
All are `false` for a resource that is not inserted.

**From C.** `mid_ecs_world_resource_added_since(world, resource_id, last_run)` and
`mid_ecs_world_resource_changed_since(...)` return `1`, `0`, `NullPointer` or
`NotFound`, with the same `last_run` convention as the `*_rows` functions.

**Verified (sandbox, rustc 1.91.1).** Eleven new tests for the pieces in this
section (the other eleven are under "Tick wraparound" below): the `Resources` stamps for
every row of the table above including the in-place address; `World`'s tracker
forms through insert, replace, `get_resource_mut`, reading, remove and re-insert,
and a C write (new, replaced, refused); and, in running systems, `Res` through a
first run, no change, a `ResMut` write, a read-only `ResMut`, `set_changed` and
`bypass_change_detection`, a `ResMut` seeing its own write, and the `Option`
forms with the resource absent and present. C: `test.c` 276 -> 287 `ok:` lines
(a new block: added versus changed, replace, read, remove and re-add, refused
write, the error codes).

**Not done.** Hooks for resources, removal tracking for resources, and a
`last_changed` that reports the changing *system*.

### Tick wraparound (`World::check_change_ticks`)

A tick is a wrapping `u32`, and `Tick::is_newer_than` compares two *ages*
(`this_run - tick`) as unsigned numbers, so it is right only while no age reaches
`u32::MAX`. A value untouched for 2^32 ticks would read as brand new, silently. It
arrives sooner than it sounds, because `System::run` advances the tick once per
system run: 100 systems at 60 frames a second is 6,000 ticks a second, and 2^32 of
them pass in about eight days. `bevy_ecs`'s answer is adopted unchanged: keep every stored tick's age
below `MAX_CHANGE_AGE` by clamping the old ones, since a value that old is simply
"old" and its exact age no longer matters.

- `CHECK_TICK_THRESHOLD = 518_400_000` and `MAX_CHANGE_AGE = u32::MAX - (2 *
  CHECK_TICK_THRESHOLD - 1)` (public). The second is chosen so that a tick that
  has gone a whole threshold unchecked is still younger than `u32::MAX`.
- `Tick::check_tick(&mut self, now) -> bool` clamps one tick to exactly
  `MAX_CHANGE_AGE` if it is older (`now.relative_to(tick)`, a wrapping age, new
  `Tick::relative_to`).
- `World::check_change_ticks()` walks everything the world stores: both ticks of
  every component row in every archetype, both ticks of every resource, every entry
  of the removal log. `World::increment_change_tick` runs it itself when
  `CHECK_TICK_THRESHOLD` ticks have passed since the last scan
  (`World::last_check_tick()`), so the world's own ticks stay in range with no
  caller effort.
- **What it cannot reach**, because the world does not hold it: a system's last
  run, a `SystemState`'s, and a `ChangeTracker`. Each has a `check_change_tick` /
  `check_tick(now)` (one comparison), and whoever owns them calls it with the
  world's tick at least once per threshold (once per step is fine). When a
  schedule owns the systems, that call is its job. `System::check_change_tick` is a
  new **required** method of the `System` trait: an external implementor must add
  it (the two in this crate do).

**Cost.** A scan visits every component row's ticks once per 518 million ticks.
Not benchmarked (optimization is paused); it is not on any hot path.

**Verified.** Eleven new tests (with the eleven above: lib 720 -> 742):
`relative_to` including across the wrap; `check_tick` at every side of the boundary
(ages 0, 1, `MAX - 1`, `MAX`, `MAX + 1`, far older, `u32::MAX`) and across the counter
wrapping; `ComponentTicks` clamping each tick on its own; a `ChangeTracker`; every resource's
ticks clamped; the whole scan clamping components, a resource and the removal log (read through the
public API: a tracker `MAX + 1` old sees the clamped stamps and not the real ones,
a tracker exactly `MAX` old does not, a second scan changes nothing); the automatic
trigger firing at exactly the threshold and not a tick before or again soon after;
and systems, an exclusive system and a `SystemState` clamping their last run. The
test that matters most shows the failure itself, twice: with bare ticks (a stamp
2^32 + 5 million ticks old reads as 5 million old and so as newer than a tracker 10
million ticks behind, unless it was clamped on the way), and end to end on two
worlds that wait the same 2^32 + 5 million ticks in eight 520-million-tick jumps,
one of whose loop increments (and so scans) and one of whose does not: the first
keeps the value old, the second reports it as newly changed.

**Not done.** A threshold other than `bevy_ecs`'s, and clamping a `ChangeTracker`
automatically (it is the caller's value).

**Mutation testing, for both sections.** 46 mutants of the new code (the tick
arithmetic and its boundary, each of the four scan targets, the automatic
trigger, every stamp and the tick it uses, the in-place replace keeping the added
tick, `Res` / `ResMut` reading `last_run`, `DerefMut` stamping, `set_changed`,
`bypass_change_detection`, the system and `SystemState` clamps, and the C
wrappers), 46 caught, 0 survived. Valgrind over the `resource::`, `tick::`,
`system::` and `ffi::` lib tests (18, 18, 42 and 103 tests) and over the C smoke
binary: no invalid access or uninitialised read; the only reports are "possibly
lost" blocks inside libtest's, rayon's and crossbeam's own thread set-up (the
`system::` run includes the existing `par_iter` pool tests).

### Parallel iteration (`batching.rs`, `QueryBatch`, `Query::par_iter`)

Gap-list item 5. A query can be cut into independent pieces and run on several
threads: `Query::par_iter()` / `par_iter_mut()` in a system, or
`WorldCell::query_batches` directly. Bevy's `par_iter` is the reference (its
`QueryParIter`, `BatchingStrategy`, and the queueing in
`QueryState::par_fold_init_unchecked_manual`, read from the `Mid-D-Man/bevy`
fork at 0.20.0-dev); the differences are below.

| piece | what it is |
|---|---|
| `BatchingStrategy` (`batching.rs`) | `new()` (about one batch per thread for the largest archetype), `fixed(n)`, `min_batch_size`, `max_batch_size`, `batches_per_thread`; `calc_batch_size(max_items, threads)`. Bevy's knobs and arithmetic. |
| `plan_batches` (`batching.rs`, crate-private) | Pure function: archetype lengths and a batch size in, batches of row windows out. An archetype at least one batch long is split into batch-sized windows; shorter ones are queued until the queue holds a batch (so many tiny archetypes do not become many tiny tasks). Every row lands in exactly one window of exactly one batch. |
| `QueryBatch<'w, Q, F>` | An iterator of `Q::Item<'w>` over a few row windows. `Send` when `Q::Fetch<'w>` is. Yields what the sequential iterator yields, for its rows. |
| `WorldCell::query_batches::<Q, F>(&strategy, threads, this_run, last_run)` | `unsafe`: the query as `Vec<QueryBatch>`. Starts no thread; `threads` only sizes batches. Serves read-only and writing queries. |
| `Query::par_iter()` / `par_iter_mut()` -> `QueryParIter` | `batching_strategy(..)`, `for_each(Fn(Item))`, `for_each_init(init, Fn(&mut T, Item))` (one `init` per batch), `into_batches()` (to run on a pool of your own). `for_each` runs batches on rayon; a single batch runs inline. |

**The design question and its answer.** Two questions were open before this
started: the `Send`/`Sync` story, and where the runner lives.

*Send/Sync.* There is no `Component: Send + Sync` bound in this crate (any
`T: 'static` can be a component), so parallel iteration cannot assume it. A
`QueryBatch` is `Send` exactly when `Q::Fetch<'w>` is: every typed access to
component data goes through the terms' `Fetch` (`&'w [T]` for a read term,
`&'w mut [T]` for `Mut`), so `Fetch: Send` is `T: Sync` for every read term and
`T: Send` for every written one, which is what moving the access to another
thread needs. The compiler derives it; nothing here lists types, so a new term
is covered by what its `Fetch` contains. Two `compile_fail` doctests on
`QueryParIter` pin it (a `Mut<Rc<_>>` and a `&Cell<_>` query cannot be run in
parallel); both were confirmed to fail for that reason (E0277 naming `Rc<u32>`
cannot be sent / `Cell<u32>` cannot be shared), with a passing control.
`QueryData::State`, `DataFilter::State` and the filter states gained
`Clone + Send + Sync` bounds (each batch owns a copy); they are plain ids, so
nothing changed.

*Where the runner lives.* In `mid-ecs`, as the smallest thing that is useful:
the batching, the soundness argument, and a rayon runner (the dependency was
already declared here, with a comment saying the code-level wasm32 split would
be needed when this was built; it is now). `into_batches()` is the seam: a
schedule executor in `mid-app` (item "mid-app handover") can run batches on
whatever pool it owns. No scheduler, system ordering or multi-system
parallelism is built here; that is `mid-app`'s and is not started.

**Why a window is raw (`RawColumn`, `iter_data.rs`).** The sequential mutable
iterator gives each `Mut` term the whole column as `&mut [T]` and walks it one
element at a time. Two threads cannot each take that: two live `&mut` to one
`Vec` alias even if their elements never meet. So the single thread that sets
the query up (`Archetypes::par_batches_cell`) takes the `&mut` to each written
column once, copies a raw handle out (`Column::raw_parts_mut`: pointer, length,
`TypeId` of the concrete `Vec<T>`), and lets the `&mut` die. Each window then
builds its own `&mut [T]` over its own rows from that pointer, as
`slice::split_at_mut` and rayon's `par_chunks_mut` do. Written tick columns
the same way (`RawTicks`). Read columns need nothing special: shared
references are fine from many threads. The type check the sequential path does
with a downcast is a `TypeId` comparison here.

A window is a `TableAccess` with a `window: Option<(start, end)>`: `entities`,
the tick slices and every column the terms ask for are cut to the range, so the
terms see rows `0..end - start` and are unchanged (`Mut` terms still rely on
rows arriving in order from the start of their slice). Row filters
(`Added`/`Changed`) run their pre-pass on the window, so `Mut<A>` +
`Changed<A>` still reads the ticks before the `Mut` takes them. `IterDataMut`
is reused as is, with a third `ArchetypeSource` (`WindowSource`).

**Soundness argument, in full.** (1) The batches of one query have pairwise
disjoint windows (`plan_batches`: exact cover, exhaustively tested over every
length vector of up to four archetypes of 0..=5 rows against every batch size
0..=7). (2) Each written window is built once (`take`). (3) A column a query
writes is never also read by it (`validate_access`, as before), and the
contract of `query_batches` is the cell's: nothing outside conflicts, and the
world's structure does not change while a batch is live (the batches hold raw
pointers into the buffers; nothing reachable through a cell can reallocate
them, and `world_mut`, the exception, is already `unsafe`). (4) `Send` is
`Fetch: Send`. The one `unsafe impl` is `QueryBatch: Send`, with this
argument as its comment.

**Semantics.** Items, filters, tick stamps: the same as the sequential query
(`Mut` writes stamped with the system's tick, `Added`/`Changed` against its
previous run). Order between batches is not defined; within a batch, rows are
in order. `for_each` on a pool of one thread, or with one batch, runs inline.
Default batch count follows `rayon::current_num_threads()` of the pool the
call runs in (a test pins one batch per thread for 1, 2 and 4 threads). On
`wasm32`, `for_each` runs the batches one after another.

**Cost, stated, not measured** (optimization is paused). A call allocates
O(matched archetypes x written columns) for the raw handles plus one `Vec` for
the plan and states per batch, and spawns one rayon task per batch; the query
re-resolves its matched archetypes every call (item 8 debt, same as `iter`).
So `par_iter` pays off for many rows or for work per row that is not trivial;
for a few hundred cheap rows the sequential `iter_mut` will win. No benchmark
exists for it yet.

**Verification.**
- Tests: 18 for the batching arithmetic (`batching.rs`), 2 for window shapes
  (`iter_data.rs`), 14 for `query_batches` in `world_cell.rs` (exact row
  coverage across 7 strategies x 4 thread counts, real threads over batches,
  a batch paused and finished on another thread, row filters and a written
  component as its own filter inside windows, tick/optional/`Has` terms, a
  zero-sized component, panics, and a randomized 6-seed x 8-round
  differential test against the sequential iterator with structural churn),
  10 for `par_iter` through real rayon pools in `system.rs`. Lib tests 583 ->
  627, doctests 14 -> 16 (sandbox, rustc 1.91.1).
- Mutation testing: 44 mutants, 42 caught. First pass caught 33 of 45; the
  survivors were 9 real gaps (queue flush at exactly a batch size, window
  lengths and clamps, read-only `par_iter` ticks), fixed by tests and
  re-run, and one redundant `.max(1)`, deleted. The 2 remaining are
  performance-only and behaviourally equivalent: the inline path for a single
  batch and `with_max_len(1)`.
- valgrind: 170 lib tests (cell, system, interior, batching, archetype), 0
  errors, 0 bytes definitely lost; C smoke 201 ok against `.so` and `.a`,
  clean under `-Wall -Wextra`, valgrind clean.
- **Not verified:** aliasing. valgrind cannot see Rust aliasing violations and
  the sandbox has no Miri. The new thread tests live in `world_cell::tests` and
  `system::tests`, which `mid-ecs-miri.yml`'s default filter already selects
  (the rayon ones are `cfg(not(miri))`; the `std::thread::scope` ones run
  under it). Real CI on rustc 1.99.0 and the wasm32 branch of `run_batches`
  (no wasm32 target in the sandbox; the workflow's "Check wasm32 build" step
  compiles it) have not seen this either.

**Not done.** `Query::par_get` / `par_many`; a `World`-level parallel query
(`WorldCell` or a system is the entry); parallel `Commands`; a C counterpart; a
benchmark against bevy's `par_iter` (paused); the schedule executor (`mid-app`).

### Removal tracking (`removal.rs`, `RemovedComponents`)

Gap-list item 6, stage 6a. A removed component leaves nothing in storage, so
"which entities lost a `T` since I last looked" needs a record. Stage 6b,
component hooks, is the next section; events/messages and observers are still
to come (see "Not done").

| piece | what it is |
|---|---|
| `World::track_removals::<T>()` | Starts recording removals of `T`. Idempotent; removals before the first call are not recorded. |
| `World::removed_since::<T>(&tracker)` | The entities that lost a `T` after `tracker`'s last update, oldest first. The counterpart of `query_changed`. **Panics** if `T` is not tracked: nothing would ever have been recorded and an empty answer would hide that. |
| `RemovedComponents<'w, T>` (system param) | `iter()`, `len()`, `is_empty()`: removals since *this system's* previous run. Calls `track_removals::<T>()` when the system is set up. No component or resource access to register, so it never conflicts. |
| `World::trim_removals(tick)` / `clear_removals()` / `removal_count::<T>()` / `tracks_removals::<T>()` | Housekeeping and diagnostics. |
| `World::init_message::<M>()` / `write_message(m)` / `messages_since::<M>(&tracker)` / `message_count::<M>()` | Message logs (`docs/mid-ecs-events.md`): a tick-stamped log per type, read "since the last run" like removals. Systems use `MessageWriter<M>` and `MessageReader<M>`; `Commands::write_message`; run condition `on_message::<M>`. |
| `World::trim_messages(tick)` / `clear_messages()` / `trim_messages_for_schedules()` | Housekeeping for the logs; the last is per type and keeps at least one interval. `mid-app` calls it after every frame. |
| `World::trim_removals_for_schedules()` | Trims at the last run of the schedule system that reads removals and ran longest ago; see `docs/mid-ecs-schedule.md`, "Phase 3 additions in `mid-ecs`". `mid-app` calls it after every frame. |

**What counts as a removal.** `remove`, `remove_static`, `remove_bundle` (every
member, only when the whole bundle was present and was removed),
`remove_static_by_id` / `remove_static_by_ids` (the FFI byte paths; only on
`Ok`, and `..._ids` is all-or-nothing), `Commands` doing any of these, and a
`despawn` (one entry per tracked component the entity held, in either storage).
A removal of something not there (missing component, dead entity, never
registered type), a refused removal, and **replacing a value by inserting over
it** are not removals. Works for a type in either storage. An entity removed
twice appears twice, and may since have been despawned or its slot reused:
check liveness if it matters. Audited: every removal entry point outside
`world.rs` (`commands.rs`, `ffi.rs`) goes through those `World` methods, so
these are all the sites.

**Three choices, each the opposite of bevy's** (bevy: `RemovedComponents` over
per-component double-buffered messages, a cursor per reader, flipped by
`clear_trackers`):

- *Ticks, not message cursors.* A removal is stamped with the world's change
  tick, and a reader sees entries newer than its own `last_run`, exactly like
  `Added`/`Changed`. Every reader (a system, or code holding a `ChangeTracker`)
  gets its own window with no per-reader state and no double buffer. As for
  change detection, a system's own `Commands` apply after its run, at the
  world's later tick (`System::run` advances the tick *before* running), so a
  removal it queues is seen on its next run.
- *Opt-in per type.* Removal is in the benchmarked migration paths. A world
  that tracks nothing pays one `is_empty` check per removal; only a tracked
  type pays a lookup and a push. The check is `RemovalLog::is_active`.
  Untracked despawn is the original loop unchanged.
- *Keyed by `TypeId`.* The archetype storage and the Sparse Shell have
  separate `ComponentId` spaces and a type uses exactly one storage per world,
  so the type is the one key both agree on, and a reader can name it before
  anything of that type has been inserted. The FFI byte paths and despawn only
  have `ComponentId`s, so both storages gained a dense reverse map
  (`Archetypes::type_ids`, `SparseShell::type_ids`), pushed at registration;
  `Archetypes::components_of(entity)` reads a despawned entity's signature, and
  `SparseShell::remove_entity_from_all_collecting` reports what a despawn took.

**Housekeeping is the caller's job, and it matters.** Nothing trims the log:
only whoever owns *all* the readers knows the oldest `last_run` any of them
still holds. Pass that to `trim_removals`. A type that is removed often and
never trimmed grows its log without bound (bevy bounds this by flipping two
buffers each frame; there is no frame owner in `mid-ecs`, so `mid-app`'s
schedule is the natural caller, and it is: `App` calls
`World::trim_removals_for_schedules` after every frame, which counts only the
schedule systems that read removals). `removal_count::<T>()` is there to watch
it. A `ChangeTracker` held outside the schedules is not counted by that call.
`since` scans the whole retained log rather than stopping at the first old
entry: an entry stamped after the reader's `this_run` is "not newer" by the
wrapping comparison and must not hide older ones before it. Trimming keeps
the scan short.

**Cost, stated, not measured** (optimization is paused): an untracked world
pays the `is_empty` check per removal and one `Vec::push` per newly
registered component type (the reverse maps). A tracked type pays a hash
lookup and a 16-byte push per removal; a tracked despawn also reads the
entity's signature and walks the Sparse columns.

**Verification.**
- Tests: 26 in `removal.rs`: the log in isolation (including the
  future-stamped-entry case and trim), both storages, bundles (partial bundle
  records nothing), despawn across both storages with an untracked type
  alongside, the FFI by-id paths and a refused all-or-nothing one,
  no-op removals that must not record, replacement-is-not-removal, the system
  parameter (windows, own `Commands`, set-up after a removal, two systems and
  two types, `len`/`is_empty`), and a randomized 8-seed x 300-op history
  checked against an independent model (a map of who holds what) for every
  tracker taken along the way, with one type tracked only from the middle of
  the history and a trim at a middle tracker. Lib tests 627 -> 653, doctests
  16 -> 17 (sandbox, rustc 1.91.1).
- Mutation testing: 43 live mutants, 43 caught. First pass: 43 run, 41
  caught, one failed to compile (redone as a different mutant, caught) and one
  survived: a real gap (a refused `remove_static_by_ids` recording its
  members), fixed by a test and re-run.
- No `unsafe` was added except `WorldCell::removals`, a shared read of a field
  that only `&mut World` operations write (same contract as `world()`); so
  there is no valgrind or Miri result specific to this stage.

**Not done.**
- Events/messages and observers (the rest of item 6). Component hooks are the
  next section.
- Removal tracking for resources.
- A notification for *replacement* (insert over an existing value).
- Any automatic trimming (needs a frame owner: `mid-app`).

### Component hooks (`hooks.rs`, `ComponentHooks`, `DeferredWorld`)

Gap-list item 6, stage 6b. A hook is a function that runs when a component is
added to, overwritten on, or removed from an entity: the component type's own
constructor and destructor. Names and orders follow the `Mid-D-Man/bevy` fork
(0.20.0-dev `lifecycle.rs`: Add, Insert, Discard, Remove, Despawn).

| piece | what it is |
|---|---|
| `World::register_component_hooks::<T>()` | Returns `&mut ComponentHooks`; set with `.on_add(f).on_insert(f).on_discard(f).on_remove(f).on_despawn(f)`. One hook per kind per type: setting a kind twice **panics**. Not retroactive. |
| `ComponentHook` | `fn(&mut DeferredWorld<'_>, HookContext)`: a plain `fn`, no captures (keep state in a resource), as in bevy. |
| `HookContext` | `{ entity, type_id }`. |
| `DeferredWorld` | What a hook gets instead of `&mut World`: `is_alive`, `change_tick`, `get_static(_mut)`, `has_static`, `get(_mut)` (Sparse Shell), `get_resource(_mut)`, and `commands()`. **No** `spawn`, `despawn`, `insert*` or `remove*` (a `compile_fail` doctest pins it; confirmed E0599 in a scratch crate, with a compiling control). |

| hook | fires | relative to the change |
|---|---|---|
| `on_add` | a component is added to an entity that did not have it | after |
| `on_insert` | a component is added or overwritten | after (and after `on_add`) |
| `on_discard` | a component is removed, or overwritten | before: the old value is still readable |
| `on_remove` | a component is removed and not replaced | before (and after `on_discard`) |
| `on_despawn` | each component of an entity being despawned | before |

For a despawn: every `on_despawn`, then every `on_discard`, then every
`on_remove`, all before anything is removed. For a bundle: every `on_add`, then
every `on_insert` (and every discard, then every remove, on removal). The order
between components of one kind is not defined.

**Where they fire.** Every structural `World` method, in either storage and on
the FFI byte paths (keyed by `TypeId`, with the same reverse map removal
tracking added): `insert_static`, `insert` (Sparse Shell), `spawn_bundle`,
`insert_bundle`, `insert_static_bytes(_many)`, `remove_static`, `remove`,
`remove_bundle`, `remove_static_by_id(s)`, `despawn`; and so `Commands`, which
apply through those. Audited with the removal-tracking audit: nothing outside
`world.rs` reaches the archetype layer directly. A refused or no-op operation
fires nothing. Before-hooks only fire when the removal *will* succeed:
`Archetypes::would_remove_rows` is the read-only form of the FFI removal's own
validation (known, writable, no duplicates, entity has all), so a refused
all-or-nothing removal never runs a hook.

**Overwrite differs by storage.** Archetype-storage `insert_static` never
overwrites (it returns `false` if the entity already has the component), so
there `on_discard` fires only on removal and despawn. The Sparse Shell
`insert` over an existing value is an overwrite: `on_discard` (old value),
then `on_insert` (new), no `on_add`. Writing through `get_static_mut` or
`write_static_component_bytes` is a mutation, not an insert, and fires nothing
(use `Changed` for that).

**Why `DeferredWorld`.** A hook runs inside a structural operation. If it could
spawn, despawn, insert or remove it could invalidate what the operation is in
the middle of (an entity's archetype row, the list being iterated). So hooks
read and write *values* and queue *structure*. The queue is the world's
(`HookRegistry::pending`); it is applied when the **outermost** operation has
finished, round after round: the commands' own hooks may queue more.
`flushing` stops a nested operation's own flush from running the queue
re-entrantly; the loop that is already running picks the new commands up.
**A chain that never settles panics** after 1000 rounds ("did not settle"), the
rest of the queue is dropped and the flag reset first, so the world stays
usable (a test pins that). A hook that panics leaves the operation half done;
the world is not unwind-safe across a hook panic.

**Design choices.**
- *`fn` pointers, one per kind.* Bevy's model. The alternatives (closures,
  several hooks per kind) either capture state invisibly or fight over order;
  several independent reactions belong in one hook, or in a system reading
  `Added`/`RemovedComponents`.
- *Keyed by `TypeId`, hooks looked up only when something is registered.* A
  world without hooks pays one `is_empty` check (`HookRegistry::is_active`) per
  structural operation, in the benchmarked insert and migration paths; a world
  with hooks pays a lookup per component per operation, plus, for a despawn or
  a bundle, building the list of the entity's or bundle's types.
- *Hooks run at the `World` layer, not in the archetype layer.* The archetype
  code stays exactly as benchmarked; the operations are wrapped, not changed.

**Cost, stated, not measured** (optimization is paused): the `is_empty` check
above on every structural operation, and nothing else for a world with no hooks.

**Verification.**
- Tests: 27 in `hooks.rs`: each hook's value and order at its point (the value
  in place for before-hooks, after-hooks seeing the new one), no-ops and
  refusals firing nothing (dead entity, existing component, wrong size,
  read-only, duplicate, absent, partial bundle), both storages, bundles,
  despawn grouping across both storages, the FFI byte paths and their refusals,
  hooks changing values (stamped), reaching the Sparse Shell, resources and the
  tick, queued commands applied **at every one of the 12 structural operation
  sites** (13 cases, one world, in order), a three-link chain that settles, a runaway
  chain stopped with the world still usable, double registration refused per
  kind, hooks per type, not retroactive, `Commands` from a system, and next to
  `RemovedComponents`; plus a randomized 8-seed x 300-operation history checked
  against a model that predicts the exact set of hooks and the required order
  for every operation (and that each hook saw a live entity and the value in
  place). Lib tests 653 -> 680, doctests 17 -> 18 (sandbox, rustc 1.91.1).
- Mutation testing: 56 mutants, 56 caught. Main pass of 44: 5 survivors, all
  real gaps (a hook observing a *dead* entity or a positive `has_static`; the
  despawn flush; the flush flag not resetting between operations; a chain of
  more than one round), fixed by tests; the 5 `assert!` anchors for the
  double-registration mutants did not match the formatted source and were
  re-run once fixed (caught). Then one mutant per `flush_hook_commands()` call
  site (12), all caught individually.
- No `unsafe` was added in this stage, so no valgrind or Miri result is
  specific to it. The C smoke (201 ok) and the `ffi::` tests run unchanged
  against the wrapped operations.

**Not done.**
- Events/messages and observers (the rest of item 6).
- A C API for hooks: decided against for now, with what C uses instead and the
  design if a need appears: see "Component hooks from C" below. (Removal
  tracking's C API is built: see "C API for removal tracking".)
- Hooks for resources, and `on_insert` for in-place writes.
- Caller location and the component id in `HookContext` (bevy has both).
- A defined order between components of one kind.

### Component hooks from C: not exposed, for now

**Decision.** C does not get hook callbacks. What a hook gives that polling
does not is running synchronously inside the structural operation, and reading
the old value before it goes. Those are the parts a C binding makes expensive
(a callback ABI, a restricted handle, re-entrancy rules), nobody has asked for
them from C, and what polling does give is already built. A hook's other main
use, a component type keeping its own invariants like a constructor and
destructor, mostly does not arise for components C registers: they are plain
byte data (`IntoBytes`, and `FromBytes` where C may write them), so there is
rarely a destructor to run.

**What a C caller uses instead.**

| hook | C today | not visible from C |
|---|---|---|
| `on_add` | `mid_ecs_world_static_query_since` with `all_added` | an add and a removal between two polls (the removal log keeps the entity, the `Added` is gone); Sparse-Shell adds, which have no ticks |
| `on_insert` | `all_changed` (an insert or a mutation; Archetype-Core insert never overwrites) | a Sparse-Shell overwrite (no ticks, and C cannot insert there) |
| `on_remove`, `on_despawn` | `track_removals` / `removed_since`, both storages; a despawn records every tracked component | the removed value |
| `on_discard` | the removal half, as above | the old value; an overwrite is not recorded as a removal |

What is lost, then, is exactly three things: the value of a component as it
goes, running in order inside the operation, and Sparse-Shell adds and
overwrites.

**If a concrete need appears, two steps, cheapest first.** Neither is built.

1. *Capture removed bytes in the removal log* (opt-in per component): answers
   "what was the old value" with no callback and no re-entrancy. It costs
   memory in proportion to the removal rate, trimmed with the log like the
   entities are.
2. *Callbacks.* Rust hooks are plain `fn` (no captures), so a C callback would
   sit behind one static trampoline per kind that reads a C table (callback and
   `user_data`, per component and kind, set once as in Rust) kept as a world
   resource. It needs, beyond that: a restricted handle with untyped value
   access by component id (`DeferredWorld` has only typed access today) and the
   command queue; a rule that a callback must not call the real world handle,
   which is mid-mutation (documented, or enforced with an in-hook flag that the
   mutating entry points check and answer with a new status); a rule that it
   must return normally (no `longjmp`, no C++ exception); and a decision
   whether to cover both id spaces, as the other C families do. A Rust panic
   in a hook already surfaces as `InternalPanic` with the operation half done
   (hooks are not unwind-safe, as documented above). Not prototyped.

### C API for removal tracking (`ffi.rs`)

The C counterpart of removal tracking, gap-list item 6a. Ten functions, each a
thin wrapper: the caller's numeric component id is resolved to the `TypeId` the
log is keyed by, then the same `RemovalLog` the Rust API uses is read or
written, so the C and Rust views of one world cannot disagree. `world.rs` is
untouched; `component.rs` gains a short `SparseShell::type_id_of` (the
reverse of its type-to-id map, which only the Archetype side exposed).

| C function (Archetype Core / Sparse Shell) | Rust counterpart |
|---|---|
| `mid_ecs_world_static_component_track_removals` / `mid_ecs_world_component_track_removals` | `World::track_removals::<T>()` |
| `..._tracks_removals` (both families) | `World::tracks_removals::<T>()`; `1` or `0` |
| `..._removal_count` (both families) | `World::removal_count::<T>()` |
| `..._removed_since` (both families) | `World::removed_since::<T>(&tracker)`, into a caller buffer |
| `mid_ecs_world_trim_removals` / `mid_ecs_world_clear_removals` | `World::trim_removals(tick)` / `clear_removals()` |

**Conventions, all copied from the `_added_rows` / `_changed_rows` family.**

- *The tracker is a plain `uint32_t last_run`* the caller keeps: read
  `mid_ecs_world_change_tick` after handling a batch, pass it next time, and
  call `mid_ecs_world_increment_change_tick` once per step (a removal in the
  same tick as `last_run` is not reported). No tracker object exists on the C
  side, for the reason none exists for the row functions.
- *NULL buffer queries the count*; a too-small buffer is `BufferTooSmall` and
  writes nothing; only the first `count` elements of a bigger buffer are
  written. Entries are packed `uint64_t` entity handles, oldest first, one per
  removal.
- *Two id spaces, two families.* The Archetype Core and the Sparse Shell number
  their components separately (both start at 0), so tracking Archetype-Core id
  0 does not track Sparse-Shell id 0. A test pins this with a world where the
  two spaces collide on purpose.
- *`NotFound`* is an id this world never issued in that space; `NullPointer` a
  null world. Tracking needs only a valid id, not a writable registration: a
  read-only component can be tracked, it just cannot be removed from C.

**A new status, `NotTracked` (-10, `MID_ECS_NOT_TRACKED`).** `removed_since` on
a component nobody tracked is its own code rather than `NotFound` or an empty
list: nothing was ever recorded, and either of the other two would hide that.
It is the C form of the Rust `removed_since` panic ("an empty answer would hide
that"). A count of an untracked component is `0` (matching `removal_count`), not
an error. The code is appended, so no existing value moves.

**What is recorded** is exactly what the Rust side records (see "Removal
tracking" above): a successful C removal (`..._remove`, `..._remove_many`, a
queued one at `mid_ecs_commands_apply`) and a despawn, which records every
tracked component the entity still held, in both storages. A refused removal
(entity lacks the component, read-only component, unknown id, dead handle, a
bad member of a list) and a replacement (`..._write`, a refused `..._insert`)
record nothing.

**Cost.** `removed_since` with a buffer collects the answer into a `Vec` before
the capacity check, so a too-small buffer leaves the caller's memory untouched;
the NULL-buffer count walks the log without allocating. Untracked worlds pay
nothing new (the one `is_empty` check per removal is the Rust side's, unchanged).
Not benchmarked: performance work is paused.

**Verified (sandbox, rustc 1.91.1).**

- Eight new Rust tests in `ffi.rs` (lib 680 -> 688, `ffi::` 76 -> 84; doctests unchanged at 18): opt-in
  per component and idempotent, with the id spaces kept apart; the three
  failure codes plus every function on a NULL world; every C removal path
  (direct, queued, list, despawn) cross-checked against the Rust API's
  `removed_since` and `removal_count`; refused and no-op removals recording
  nothing (absent component, read-only, unknown id, dead handle, three
  all-or-nothing lists, an overwrite, a refused insert); the `last_run`
  window including a reused entity appearing once per removal; trim and clear
  keeping components tracked; the buffer conventions; and Sparse-Shell
  removals staying apart from the Archetype Core.
- `test.c`: 201 -> 233 `ok:` lines, 0 `FAIL:`, against both the shared and the
  static library (`-Wall -Wextra` clean). Valgrind on the smoke binary: no
  errors. Valgrind on the 84 `ffi::` lib tests: no invalid access or
  uninitialised read; the only report is a 48-byte "possibly lost" inside
  libtest's own thread set-up.
- Mutation testing (run against the same code on the commit before hooks landed; `ffi.rs` and the `component.rs` hunk are unchanged since): 40 mutants of the new code (every wrapper's id space, every
  null check, every `NotFound` and `NotTracked` return, the window, the
  capacity check and copy, order, trim and clear, and the two `type_id_of`
  lookups), 40 caught, 0 survived, 0 compile errors; a neutral control mutant
  survived as it should. A 41st, the `NotTracked` value drifting from the
  header, is caught by `test.c`.

**Not done (C side).**

- Hooks from C: decided against for now, see "Component hooks from C" above.
- A C query iterator and a queued spawn that returns an `Entity`, decided
  against: see "In-place mutable rows (`row_mut`)" below. (Filtered `Added` /
  `Changed` queries across archetypes are built: see the next section.)
- Removal tracking for resources, and any automatic trimming (needs a frame
  owner: `mid-app`).

### C API for filtered change queries (`ffi.rs`)

The C counterpart of `Added` / `Changed` filters composed with `With` /
`Without` / `Or` (gap-list item 3), the item carried over from the row
functions. A C caller had `..._added_rows` / `..._changed_rows` for one
component of one archetype and `mid_ecs_world_archetypes_matching_static` for
the structure, so "`Changed<A>` with `B`, without `C`" meant writing the loop
and the set algebra by hand. One function now does it:
`mid_ecs_world_static_query_since(world, last_run, &filter, out_rows, cap)`.

The filter is a `MidEcsRowFilter`: seven `(pointer, length)` lists of
Archetype-Core component ids.

| list | meaning | Rust |
|---|---|---|
| `with`, `without`, `any_of` | structural, decided once per archetype | `With`, `Without`, `Or` of `With` (as `archetypes_matching_static`) |
| `all_added` | every listed component's value was inserted after `last_run` | a tuple of `Added<T>` |
| `all_changed` | every listed component inserted or mutated after `last_run` | a tuple of `Changed<T>` |
| `any_added` + `any_changed` | at least one listed component qualifies; the two lists are *one* group | `Or<(Added<A>, Changed<B>, ...)>` |

A row must pass the structural lists, every `all_*` id and, if either `any_*`
list is non-empty, at least one `any_*` id. Each result is a
`MidEcsMatchedRow { uint64_t entity; uint32_t archetype_id; uint32_t row; }`:
`row` is element `row` of the span and `entity_ids` of that archetype, with the
`*_rows` validity contract. Archetypes come in the order
`archetypes_matching_static` yields them, rows ascending within one.

**Design choices.**

- *A filter struct, not fifteen arguments.* Seven same-typed pointer/length
  pairs in a positional call swap silently (`with` and `without` compile
  either way); designated initializers cannot. Zero-initialize the struct and
  set only the lists in use. It is read once and not retained. Adding a list
  later means a new struct, since a new field would change the layout.
- *No new query engine.* The function asks the existing per-archetype row
  functions (`static_component_added_rows` / `_changed_rows`, what the C
  `*_rows` functions call) for each structurally matching archetype, then
  intersects the ascending row lists for `all_*` and unions them for `any_*`.
  It agrees with the `*_rows` functions by construction, and `world.rs` and the
  Rust query machinery are untouched.
- *The semantics are `data_filter.rs`'s.* `Added<T>` / `Changed<T>` require the
  archetype to hold `T`; an `Or` member whose component the archetype lacks is
  false for its rows; an archetype holding none of the members has no row.
  Nesting (an `Or` of tuples, as in `Or<(Added<A>, (With<A>, Without<B>))>`) is
  not expressible: one AND group and one OR group.
- *Unregistered ids in a change list are `NotFound`, up front.* The same
  condition under which the `*_rows` functions say `NotFound`, checked before
  anything is written, because a typo'd id would otherwise read as "nothing
  changed" (the reasoning of `NotTracked` above). The structural lists keep the
  lenient rule `archetypes_matching_static` already has: an unknown id in `with`
  or `any_of` matches nothing, in `without` it is ignored. The check needs
  "registered for FFI", which no `Archetypes` method exposed, so
  `Archetypes::is_ffi_registered` (one line, in `archetype/ffi_write.rs`) was
  added; an id issued only through the typed API is not registered.
- *A new status, `InvalidArgument` (-11, `MID_ECS_INVALID_ARGUMENT`).* All four
  change lists empty has no component to read rows through (and `all_*` /
  `any_*` empty would otherwise mean "every row", which this function cannot
  enumerate without one). The purely structural query is
  `archetypes_matching_static`. Appended, so no value moves.

**Cost.** Per structurally matching archetype, one row list per listed id (one
tick read per row per id) and linear merges; the answer is collected into a
`Vec` before the capacity check so a too-small buffer writes nothing. Not
benchmarked: performance work is paused.

**Verified (sandbox, rustc 1.91.1).**

- Eleven new Rust tests (`ffi::` 84 -> 95): added versus changed across
  archetypes with rows checked against `entity_ids` and the stored values; a
  mutation counts as changed but not added; `all_*` as an intersection that rules
  out archetypes lacking a component; `any_*` as a union where an absent member is
  false, the two lists form one group, and two members of one list may qualify
  different rows of one archetype; the `all_*` and `any_*` groups combining; the structural lists composing with
  the change terms (including the lenient unknown-id rule); the `last_run` window
  (the same tick is not newer, `0` sees everything); every error (`NotFound` for
  each of the four change lists and for an id registered only through the typed
  API, `InvalidArgument`, `NullPointer` for the world, the filter and each of the
  seven lists) with nothing written; the buffer conventions; and a component listed
  twice not duplicating rows. The central one is differential: 500 steps of random
  spawns, despawns, insertions, removals and writes across three components with
  tick steps and tracker updates, and at every step ten filter shapes
  (`Changed<A>`, `Added<A>`, `Or` of two `Changed`, a tuple of two `Changed`, an
  `Added` with a `Changed`, `Changed` with `With<B>` and with `Without<B>`, an `Or`
  mixing `Added` and `Changed`, an `Or` under `With`, and a `Changed` beside an
  `Or`) compared with
  `query_data_filtered_since` in Rust, each required to give both empty and
  non-empty answers at least ten times, every row checked against `entity_ids`.
  Lib 688 -> 699, doctests unchanged at 18.
- `test.c`: 233 -> 257 `ok:` lines, 0 `FAIL:`, against both the shared and
  the static library (`-Wall -Wextra` clean); the new block covers the changed
  rows across two archetypes read back through the span, `with` / `without`, the
  AND and the OR, an insert (added) against a write (not added) including a
  migration not re-adding, the mixed group, the window, the buffer and every
  error code. Valgrind on the smoke binary: no errors. Valgrind on the 95 `ffi::`
  lib tests: no invalid access or uninitialised read; the only report is the
  48-byte "possibly lost" inside libtest's own thread set-up.
- Mutation testing: 39 mutants of the new code (both list readers, the
  intersection and union merges, the narrowing, which row function each list asks
  for, the source component, the group logic, every null check and return code,
  the validation of each change list, the structural arguments, the fields of a
  result row, the capacity check, copy and count, and `is_ffi_registered`),
  all caught, none survived. The first pass caught 35 of 39: two survivors were real
  test gaps (two members of one `any_added` list qualifying different rows of one
  archetype, and `all_*` combined with `any_*`), fixed with a test each and a
  tenth differential shape; one was an equivalent mutant (a "holds none of the
  `any_*` components" check that the entity-source lookup and an empty
  intersection already make unobservable), so the check was removed as dead code;
  one did not compile and was redone. A 40th mutant, the `InvalidArgument` value
  drifting from the header, is caught by `test.c`.

**Not done (C side).**

- A C query iterator and a queued `Entity`-returning spawn, decided against:
  see "In-place mutable rows (`row_mut`)" below.
- Nested filters (an `Or` of tuples) and any value-returning terms: the C caller
  reads values through the spans at the rows returned, and `Ref` / `Mut` terms
  have no C form.
- Hooks from C: decided against for now, see "Component hooks from C" above.

### Writing component data from C (`raw_span_mut`, `write`, `FfiSpanMut`)

The open question the mutable queries left: the C span pointer is `const`, and a
plain write through it would skip the change ticks, so a `Changed` consumer
would miss it. Two C functions now write Archetype Core component data and keep
the ticks honest.

| | Rust (`World`) | C |
|---|---|---|
| opt a type in | `register_ffi_static_component_writable::<T>(name)` | (Rust side only) |
| bulk, one column | `static_component_raw_span_mut(archetype, component) -> Result<FfiSpanMut, _>` | `mid_ecs_world_static_component_raw_span_mut(world, archetype_id, component_id, out_span)` |
| precise, one row | `write_static_component_bytes(entity, component, bytes) -> Result<(), _>` | `mid_ecs_world_static_component_write(world, entity, component_id, bytes, len)` |

`FfiSpanMut` is `FfiSpan` with a `*mut u8` (`MidEcsFfiSpanMut` in C), same
`stride`/`count`/empty-sentinel meaning. `ComponentFfiError` is the Rust-side
error (`UnknownId`, `NotWritable`, `NotAlive`, `Absent`, `SizeMismatch`). In C
a new status, `MID_ECS_NOT_WRITABLE` (-7), is appended to the enum; every
existing code is unchanged.

**Where it lives.** `archetype/ffi_write.rs` (a child module of `archetype`,
which sees `Archetype` and `Table`) holds both types, the writer registry and
the three `Archetypes` methods. `world.rs` has the three `World` methods,
`ffi.rs` the two `extern "C"` functions, the status mapping and a test fixture,
and `ffi-smoke-test/` the header and the C checks.

**Decisions, with reasons.**
- **Only types registered *writable* can be written, and that registration
  requires `zerocopy::FromBytes`.** C writes raw bytes. `FromBytes` is the proof
  that every bit pattern is a valid value of the type, so nothing C writes can
  create an invalid Rust value (a `bool` holding 2, an enum with no such
  variant). Resources already work exactly this way (`register_ffi_resource`).
  The existing read-only registration is unchanged. Registering read-only first
  and writable later upgrades the type; registering read-only after it was
  writable does not downgrade it. A component registered read-only answers
  `NOT_WRITABLE`, not `NOT_FOUND`, so a caller can tell "you may not" from
  "there is nothing there".
- **Bulk: the whole column is stamped changed when the span is handed out.** C
  cannot say which rows it writes through a raw pointer, so the only stamp that
  can never miss a write is every row. It is the same moment
  `World::get_static_mut` stamps (on access, not on write), it stamps `changed`
  and not `added` (the values already existed), and it can over-report: a
  `Changed` consumer may see rows C left alone. The writes belong in the tick
  the span was obtained in; a write after `increment_change_tick` is not
  stamped with the new tick.
- **Precise: a per-entity byte copy that stamps exactly that row.** This is
  the tool for sparse writes, so over-reporting is a choice, not a limit.
- **No "write now, mark rows later" call.** It would have been the precise
  bulk option, and it was rejected: a caller who forgets to mark gets a
  `Changed` that silently misses writes, which is exactly the failure this
  design exists to prevent. Bulk is conservative, per-row is exact, and there
  is no third mode to get wrong.
- **The Rust core is safe code.** The byte views are zerocopy's `as_mut_bytes`
  and `read_from_bytes`, the span's pointer comes from `as_mut_bytes`, and a
  failed write leaves nothing stamped. The raw pointers exist only in the
  returned `FfiSpanMut`; the two `extern "C"` wrappers (already in the file that
  allows `unsafe`) are the only code that touches them.
- **`write` checks liveness through `World::is_alive` before it looks at the
  entity's row.** The entity-location table is keyed by slot, so a stale handle
  whose slot was reused would otherwise write into the new occupant. A test
  pins it from both Rust and C.
- **Errors are checked in a documented order:** `NotAlive`, `UnknownId`,
  `NotWritable`, `SizeMismatch`, `Absent`. Nothing is written or stamped on any
  of them. In C, `UnknownId` and `Absent` both map to `NOT_FOUND`.
- **`FfiSpanMut` lives in mid-ecs.** `mid-collections` is untouched; moving the
  type there is a one-line change if another crate wants it.

**Same invalidation contract as the read-only span:** valid until the next call
that changes that archetype's storage (spawn, despawn, insert, remove, applying
a command queue), and never past `count` elements of `stride` bytes.

**Tests, from the sandbox (rustc 1.91.1; real CI not yet run).**
- 14 core tests (`archetype/ffi_write.rs`) and 7 FFI tests (`ffi.rs`, driving the
  real `extern "C"` functions and writing through the raw pointer), plus 20 C
  checks. Default lib tests 408 to 429 (413 to 434 with `scratch-arena`), the
  `ffi::` tests 52 to 59, C checks 131 to 151. The C program is clean under
  `-Wall -Wextra` against both `libmid_ecs.so` and `libmid_ecs.a`, and under
  valgrind.
- Covered: the span pointing at the live column with the registered stride and
  count (and at the same memory as the read-only span); every row stamped
  changed, not added, and only in the acquired archetype and component; a
  read-only registration refused by both paths; every unknown-id case; an
  emptied column and a never-populated, columnless archetype both answering an
  empty span; the upgrade and no-downgrade registration rules; one row's value
  and stamp; a multi-field struct and a zero-sized component through both
  paths; rows staying aligned after a swap-remove; a dead entity and a stale
  handle that must not reach the slot's new occupant; the error order, and
  that no error writes or stamps anything.
- **Mutation testing: 23 of 23 mutants caught.** Stamping skipped, stamping
  `added` or both, stamping tick zero, stamping or writing row 0, no row stamp,
  the size check removed or reordered, the value never stored, the span's stride
  or count off by one, no writer registered, the not-writable and unregistered
  errors swapped, a columnless archetype treated as an error, the world-level
  tick and liveness checks removed, the FFI status mapping altered, `NULL` with
  length 0 rejected, and the out-pointer null check removed (caught by a
  `SIGSEGV`, the crash the check exists to prevent). One mutant was first built
  wrongly (it did not compile) and was redone.
- Two things the mutation pass found in the tests themselves and fixed before
  this shipped: a test that claimed to cover a columnless archetype asserted on
  the populated one, and the error order was documented but not tested.

**Not done.**
- **Inserting a component C's entity does not have.** `write` on an entity
  without the component is `NOT_FOUND`: adding one is a structural change (a
  new archetype, a column push from bytes), a different design from overwriting
  a value that exists. Built in the next pass: "Inserting a component from C"
  below, direct and queued.
- **A C-side mutable *query*** (a row iterator with automatic stamping).
  `raw_span_mut` is the bulk form: C iterates the span itself. Answered later by
  `row_mut` plus a row list: see "In-place mutable rows (`row_mut`)" below.
- **The Sparse Shell.** Its spans stay read-only; it has no ticks, so there is
  nothing to stamp, and a writable registration for it was not asked for.
- **No benchmark.** Optimization is paused.

### In-place mutable rows (`row_mut`), and the two items not built

Two carried-over C items, decided together: a mutable query iterator and
reserved entity ids / an `Entity`-returning queued spawn. One new function, one
pinned guarantee, and a reasoned "no" for the rest.

**`mid_ecs_world_static_component_row_mut(world, entity, component_id,
out_span)`** (Rust: `World::static_component_row_mut`) hands out a writable,
one-element span over one entity's value and stamps exactly that row *changed*
(not added) at the current tick: the C counterpart of `get_static_mut`, which
also stamps on access rather than on write. It is the in-place form of `write`
(which copies bytes in) and the precise form of `raw_span_mut` (which stamps
every row). The span has `count == 1` and `stride` the component's size, with
the usual validity contract (until the next call that changes that archetype's
storage) and the usual same-tick rule for the write. Errors, in this order:
`NotAlive`, `UnknownId`, `NotWritable`, `Absent` (in C: `NOT_ALIVE`,
`NOT_FOUND`, `NOT_WRITABLE`, `NOT_FOUND`); `*out_span` is untouched and nothing
is stamped on an error. No component hook fires (a mutation is not an insert,
as for `get_static_mut`). The core stays safe code: the pointer is
`span.ptr.wrapping_add(row * stride)`, computed from the same writer function
`raw_span_mut` uses, and only the `extern "C"` wrapper touches raw pointers.

The use is a filtered mutation done exactly: take the rows from
`mid_ecs_world_static_query_since` (or the `*_rows` functions), call `row_mut`
for each row you really write, and a `Changed` consumer sees those rows and no
others. It follows the rule the bulk design already set ("no write now, mark
rows later"): the stamp comes *before* the pointer does, so there is still no
third mode in which forgetting a call loses a write.

**A C mutable query iterator is not built.** Its two halves are already there.
The exact half is `query_since` plus `row_mut`. The bulk half is
`raw_span_mut`: if C walks every row, every row is changed, so the
over-reporting is the truth. A cursor in between would need a rule for what a
structural change does to a cursor held across it (an epoch checked on every
`next`), would cost a call per row exactly as `row_mut` does, and would stamp
each row it yields, written or not, so it could not be more exact than
`row_mut` over a filtered list. State to get wrong for no gain.

**Reserved entity ids: `mid_ecs_world_spawn` already is the reservation.** It
returns a real, live id at once, and the C command queue takes explicit
entities (`mid_ecs_commands_static_component_insert(queue, world, entity, ...)`),
so a caller can spawn now, use the id in queued commands before `apply`, and
store it in other components' bytes. Two properties are pinned by tests, in
Rust and in C. First, spawning does not move any other archetype's storage: an
empty entity lands in the empty archetype, and a span of another archetype has
the same `(ptr, stride, count)` after the spawn, so reserving ids in the middle
of walking spans is safe (a *queued insert applying* is not: it migrates the
entity and invalidates the destination's spans, as always). Second, the
difference from a queued spawn: the entity exists immediately and nothing takes
it back; `mid_ecs_commands_clear` and `_free` do not despawn it, so an
unused reservation must be despawned by the caller.

What is *not* built is the queue-only version, an id handed out without the
world being touched. That is bevy's design and needs
`GenerationalIndexAllocator::allocate` to work without `&mut` (an atomic
cursor over the free list and a flush step), a change to `mid-collections`.
"Decision: deferred spawn targets a slot, not a reserved entity" in the command
queue section rejected it for Rust for the benefit it buys only when systems
hold `&World` and a buffer together. C changes nothing there: it always has the
world pointer, so it can always spawn.

**Verified (sandbox, rustc 1.91.1).**

- Seven new Rust tests (`ffi::` 95 -> 102, lib 699 -> 706): exactly one row
  stamped, the others untouched, nothing Added, the pointer equal to
  read-only-span base plus `row * stride`, and the bulk form over-reporting as
  the contrast; every error, in order, with the span untouched and nothing
  stamped (and the NULL arguments); a stale handle whose slot was reused never
  stamping the new occupant; the exact Rust error variants (which C folds
  together); no `on_insert` hook firing, with a real insert firing it as the
  sensitivity check; the reservation guarantees above; and a differential test
  driving 300 steps of random accesses through two identical worlds, one via
  C `row_mut` and one via `get_static_mut`, with tick steps and tracker
  updates, comparing the `Changed<A>` and `Changed<B>` sets at every step
  (including accesses to a component the entity lacks, which must stamp
  nothing in both).
- `test.c`: 257 -> 276 `ok:` lines, 0 `FAIL:`, against both the shared and the
  static library (`-Wall -Wextra` clean).
- Mutation testing: 18 mutants of the new code (every error guard and error
  variant, the stamp, the stamped row, the stamped field, the tick, the
  pointer and its row offset, `count`, `stride`, the liveness check, and each
  line of the C wrapper), 18 caught, 0 survived.

**Not done.**

- A batch form (`row_mut` for a list of entities in one call) to cut the
  per-row FFI cost. Not measured, so not built: performance work is paused.
- The Sparse Shell, throughout: it has no ticks to stamp and no writable
  registration.
- Hooks from C: decided against for now, see "Component hooks from C" above.

### Inserting a component from C (`insert`, queued inserts, `queued_spawn`)

`write` overwrites a value an entity already has; on an entity without the
component it answers `NOT_FOUND`. Attaching one is a structural change (the
entity migrates to a different archetype), so it needed its own design, and
the command queue needed the same thing: a C caller could queue spawns and
despawns but never give a queued entity any components. Three C functions now
cover it, and one Rust method makes the third possible.

| | Rust | C |
|---|---|---|
| attach now | `World::insert_static_bytes(entity, component, bytes)` | `mid_ecs_world_static_component_insert(world, entity, component_id, bytes, len)` |
| queue it | `EntityCommands::insert_static_bytes(component, bytes)` | `mid_ecs_commands_static_component_insert(commands, world, entity, component_id, bytes, len)` |
| queue it onto a queued spawn | `Commands::queued_spawn(index) -> Option<EntityCommands>` | `mid_ecs_commands_static_component_insert_spawned(commands, world, spawn_index, component_id, bytes, len)` |

Also `World::static_component_write_size(component) -> Result<usize, _>`, the
size every write and insert must have. In C a new status,
`MID_ECS_ALREADY_PRESENT` (-8), is appended; existing codes are unchanged.

**Where it lives.** `archetype/ffi_write.rs` grows a type-erased inserter in
the writer registry and `Archetypes::insert_row_bytes` / `write_size`;
`world.rs` has the two `World` methods; `commands.rs` has `queued_spawn` and
`EntityCommands::insert_static_bytes`; `ffi.rs` has the three `extern "C"`
functions, the status and the queue-time check; `ffi-smoke-test/` has the
header and the C checks. `ComponentFfiError` gains `AlreadyPresent`.

**Decisions, with reasons.**
- **The same gate as writes, and the same code path as `insert_static`.** Only
  components registered writable (`FromBytes`) can be inserted, for the reason
  they can be written: C supplies raw bytes. The registered writer now also
  holds `insert_of::<T>`, which builds a `T` with `read_from_bytes` and calls
  `Archetypes::insert::<T>`, the function `insert_static` calls. So the
  migration, the preservation of the entity's other values and their ticks, and
  the stamping (added *and* changed at the current tick) are the existing,
  already-tested behaviour, not a second implementation.
- **`ALREADY_PRESENT`, where Rust's `insert_static` is a silent no-op.**
  Mirroring the no-op would mean a C caller who passed bytes could not tell they
  were discarded. Nothing is written and the first value stays, exactly as in
  Rust; the status says so, and points at `write` to overwrite.
- **Queued inserts are validated when queued, against a world you pass in.** A
  queue has no world of its own, and a failure at apply time is invisible
  (`apply` returns the spawn count). `world` is only *read* to check that the
  component is registered writable and `len` is its size; it is not retained
  and nothing in it changes. That puts `NOT_FOUND`, `NOT_WRITABLE` and
  `SIZE_MISMATCH` on the call that caused them, and a failed call queues
  nothing.
- **What can only be known at apply time is a no-op, as for every command.**
  Whether the entity is alive is checked when the command runs (the same
  precedent as `mid_ecs_commands_despawn`): a dead or stale entity, an entity
  that already has the component (the first value stays), or a world that does
  not know the component makes the command do nothing. None of these can
  panic, which matters because a panic mid-apply drops every remaining
  command. The last case is the one place silence remains: applying a queue to
  a different world than the one it was validated against is a caller error with
  no channel to report it.
- **Spawn slots become addressable, through a Rust method that keeps the
  invariant.** `Target::Slot` stays private because a slot only resolves if its
  spawn was queued first (`resolve` indexes the spawned list). `queued_spawn(index)`
  returns `None` unless `index` is below the spawn count, so a queued command
  can never name a slot that will not exist; the C function reports that as
  `NOT_FOUND`. One apply can now spawn an entity and give it components, in
  order, which is what a command queue is for.
- **`insert_static_bytes` copies the bytes when queued** and, like every
  command, does exactly what the `World` method it names does when it runs.
- **Error order is documented and tested.** `insert`: `NotAlive`, `UnknownId`,
  `NotWritable`, `SizeMismatch`, `AlreadyPresent`. Queued: `NullPointer`, then
  the component checks, then (for the spawned form) the slot. Nothing is
  written, stamped or queued on any error.
- **A structural change invalidates spans**, as every spawn, despawn, insert and
  remove already does. `static_component_write_size` is public because the FFI
  queue check needs it and it is a fact about the registration; C already
  learns the size from a span's `stride`.

**Tests, from the sandbox (rustc 1.91.1; real CI not yet run).**
- 8 core tests (`archetype/ffi_write.rs`), 5 command-queue tests
  (`commands.rs`), 7 FFI tests (`ffi.rs`, driving the real `extern "C"`
  functions), plus 19 C checks. Default lib tests 429 to 449 (434 to 454 with
  `scratch-arena`), the `ffi::` tests 59 to 66, C checks 151 to 170. The C
  program is clean under `-Wall -Wextra` against both `libmid_ecs.so` and
  `libmid_ecs.a`, and under valgrind.
- Covered: an inserted value stamped added and changed while the entity's
  existing value arrives intact and un-restamped; an entity with no components
  at all; the inserted component then being writable and spannable; the
  already-present case keeping the first value and stamping nothing; the error
  order; stale handles that must not reach a slot's new occupant; a middle row
  inserted into with every other row staying aligned; a zero-sized component;
  `write_size`; `queued_spawn` in range, out of range, and after `clear`; byte
  inserts onto queued spawns given out of order and onto existing entities,
  nothing happening before apply; the bytes being copied at queue time; queued
  inserts that no longer apply (dead entity, already present, an unknown id, a
  wrong length, a world that never heard of the component) doing nothing and not
  panicking; and, from C, every status for both queued forms and that a failed
  queue call queues nothing.
- **Mutation testing: 20 of 20 mutants caught.** The already-present and size
  checks removed or reordered, the registered size off by one, the not-writable
  error swapped, the insert stamping tick zero (at both the core and the world
  level), the inserter inserting nothing, the world's liveness check removed,
  `queued_spawn` off by one and always slot 0, the queued insert overwriting
  instead, the status mapping altered, the queue-time size and registration
  checks ignored, the spawned form always using slot 0 or accepting a missing
  slot, `NULL` with length 0 rejected, the empty-bytes queue copy, and the
  queued insert's world null check removed (caught by a crash).
- One failure on the first C run was a wrong assumption in the test, not the
  code: it took the second enumerated `Health` entity to hold hp 2, but archetype
  order makes it hp 3. The test now compares against the value it read first.

**Not done.**
- **Inserting several components in one structural change from C.** Each insert
  is one migration, so giving an entity `k` components through this API passes
  through `k - 1` intermediate archetypes, as `insert_static` does. A
  bundle-by-ids insert (Rust's `insert_bundle`, one migration) is the fix and a
  separate design: it has to validate a list of ids and sizes as a unit.
- **Reserved entity ids / an `Entity`-returning queued spawn.** Slots address
  the queued spawns, but the real entity is still only known after apply.
  (Settled later: `mid_ecs_world_spawn` is the reservation; see "In-place
  mutable rows (`row_mut`)" below.)
- **Removing a component from C.** Built in the next pass: "Removing a component
  from C" below, direct and queued.
- **The Sparse Shell**, as for writes.
- **No benchmark.** Each queued insert boxes one closure and copies its bytes
  into a `Vec`. Optimization is paused.

### Removing a component from C (`remove`, queued removes, `remove_dropping`)

The mirror of insert, which finishes the C-side family of component changes:
`write` overwrites a value, `insert` attaches one, `remove` detaches one, each
direct and (for insert and remove) queued.

| | Rust | C |
|---|---|---|
| detach now | `World::remove_static_by_id(entity, component)` | `mid_ecs_world_static_component_remove(world, entity, component_id)` |
| queue it | `EntityCommands::remove_static_by_id(component)` | `mid_ecs_commands_static_component_remove(commands, world, entity, component_id)` |

No new status code: `ComponentFfiError::Absent` already maps to `NOT_FOUND`.

**Where it lives.** `archetype/ffi_write.rs` holds `Archetypes::remove_dropping`
(the migration) and `remove_row` (the FFI checks around it). `world.rs` and
`commands.rs` have the Rust methods, `ffi.rs` the two `extern "C"` functions,
and `ffi-smoke-test/` the header and C checks. `archetype.rs` changed only by
a doc comment on `remove` and a one-line reorder of two `use` statements that
rustfmt wanted from the previous pass.

**Decisions, with reasons.**
- **"Writable" now means C may write, insert *and* remove the component.**
  Removal needs no bytes, so `FromBytes` is not what makes it safe, but it is
  still a modification: a type deliberately registered read-only (engine state C
  must not disturb) should not be removable either. A read-only component is
  `NOT_WRITABLE`, even on an entity that has it, and stays.
- **A type-erased sibling of `Archetypes::remove`, not a refactor of it.**
  `remove<T>` needs `T` for exactly one line (taking the value out of its
  `Vec<T>`); the migration around it is type-independent, and
  `Column::swap_remove_and_drop` already exists type-erased. The tidy fix is to
  make `remove` generic over that one step. `remove` is benchmarked, though
  (`remove_single`, `structural_churn`), and optimization is paused, so this pass
  leaves it byte-for-byte as it was and adds `remove_dropping` beside it: the
  same migration with `swap_remove_and_drop` in place of the downcast. The
  duplication is real, so it is pinned (next item) and cross-referenced from a
  doc comment on `remove`, so a change to one points at the other.
- **A differential test keeps the two in step.** `remove_by_id_matches_the_typed_remove_step_for_step`
  builds two identical worlds (24 entities over several archetypes, three
  component types including a zero-sized one), applies 400 pseudo-random steps
  (removals, re-insertions, tick advances) through the typed `remove_static` to
  one and the id-driven path to the other, and asserts after every step that both
  report the same outcome and hold the same entities, components, values and
  iteration order, and at the end the same `Added`/`Changed` stamps. It asserts
  the run really exercised both paths (at least 40 removals and 20 re-inserts).
  A separate test drops a counting guard through `remove_dropping` and checks it
  is dropped exactly once and the entity's other component is moved, not dropped.
- **A removal stamps nothing.** There is no change notification for removals
  (`RemovedComponents` is gap-list item 6). The entity's other values arrive with
  their ticks untouched, as they do through `remove_static`.
- **Removing the last component leaves the entity alive, with none.** A
  removal never despawns.
- **Queued removes follow the queued inserts' rule.** The component's
  registration is checked when queued, against a world you pass in, which is only
  read and not retained, so `NOT_FOUND` and `NOT_WRITABLE` come back on the call
  that caused them and a failed call queues nothing. Whether the entity is alive
  and still has the component is checked when the command runs: a dead or stale
  entity (which never reaches a different entity that reused the slot), an entity
  without the component, or a world that does not know it, is a no-op, and none
  of those can panic. Queue order is preserved: a removal followed by an insert
  of the same component leaves the new value, an insert followed by a removal
  leaves it absent.
- **No `_spawned` form.** A freshly spawned entity has nothing to remove until
  an insert has run, and removing what an earlier queued insert on the same slot
  added is better left unqueued.
- **Error order:** `NotAlive`, `UnknownId`, `NotWritable`, `Absent`. Nothing
  changes on any error.
- **A structural change invalidates spans,** as every spawn, despawn, insert and
  remove already does.

**Tests, from the sandbox (rustc 1.91.1; real CI not yet run).**
- 8 core tests (`archetype/ffi_write.rs`, including the differential and drop
  tests), 2 command-queue tests (`commands.rs`), 5 FFI tests (`ffi.rs`, driving
  the real `extern "C"` functions), plus 14 C checks. Default lib tests 449 to 464
  (454 to 469 with `scratch-arena`), the `ffi::` tests 66 to 71, C checks 170 to
  184. The C program is clean under `-Wall -Wextra` against both
  `libmid_ecs.so` and `libmid_ecs.a`, and under valgrind.
- Covered: one component detached while the entity's others keep their values
  and are not re-stamped; the last component removed and a new one attached
  afterwards; the error order, including a read-only component the entity *has*;
  stale handles that must not reach a slot's new occupant; a middle row removed
  from with every other row staying aligned; a zero-sized component; and, from
  C, every status for both forms, that a failed queue call queues nothing, that
  removal and insert apply in queue order, and the no-op cases at apply (a
  dead entity, a component the entity lacks, a world that never heard of it).
- **Mutation testing: 15 of 15 mutants caught.** The value not removed, the
  removed column's ticks not removed, the moved ticks not carried across, the
  swapped entity not fixed up, the entity placed at the wrong row or left in
  its old archetype, the presence check removed, the destination ticks not
  ensured, the registration/writable check removed, an absent component reported
  as success, the world's liveness check removed, the queued command doing
  nothing, the FFI queue-time validation removed, and both `NULL` checks removed
  (caught by crashes). Two of them, the removed column's ticks and the entity's
  row, were caught by the differential test and by no other: the targeted unit
  tests missed both.

**Not done.**
- **Bundle forms from C.** Built in the next pass: "Bundles from C" below, which
  closes the family.
- **Reserved entity ids / an `Entity`-returning queued spawn.** Slots address
  the queued spawns, but the real entity is still only known after apply.
  (Settled later: `mid_ecs_world_spawn` is the reservation; see "In-place
  mutable rows (`row_mut`)" below.)
- **The Sparse Shell.**
- **No benchmark.** A queued removal boxes one closure. Optimization is paused.

### Bundles from C (`insert_many`, `remove_many`): the family is closed

Several components in *one* structural change, the C counterparts of Rust's
`insert_bundle` and `remove_bundle`. With these the C-side component API is
complete:

| operation | direct (C) | queued (C) |
|---|---|---|
| overwrite a value | `..._write`, `..._raw_span_mut` (bulk) | n/a |
| attach one | `..._insert` | `..._insert`, `..._insert_spawned` |
| detach one | `..._remove` | `..._remove` |
| attach several, one migration | `..._insert_many` | `..._insert_many`, `..._insert_many_spawned` |
| detach several, one migration | `..._remove_many` | `..._remove_many` |

(`mid_ecs_world_static_component_*` for direct, `mid_ecs_commands_static_component_*`
for queued.) In C, a new status `MID_ECS_DUPLICATE` (-9) is appended and a
struct `MidEcsComponentValue { uint32_t component_id; const uint8_t *bytes; size_t len; }`
is the list entry. In Rust: `World::insert_static_bytes_many(entity, &[(ComponentId, &[u8])])`,
`World::remove_static_by_ids(entity, &[ComponentId])`,
`World::check_static_component_list(&[(ComponentId, Option<usize>)])`,
`EntityCommands::insert_static_bytes_many` and `remove_static_by_ids`, and
`ComponentFfiError::Duplicate`.

**Where it lives.** `archetype/ffi_write.rs` (the writer registry gains a
type-erased `push`; `check_list`, `insert_many_bytes`, `remove_many_dropping`,
`remove_many_rows`), `world.rs`, `commands.rs`, `ffi.rs` (five `extern "C"`
functions, the value struct, the status), and `ffi-smoke-test/`.

**Decisions, with reasons.**
- **All or nothing, validated as a unit.** This is `insert_bundle`'s contract
  (it returns `false` if the entity has *any* of the components), extended to
  the whole call: the list is checked before anything moves, so a failure leaves
  the entity exactly as it was, with no partially applied bundle to recover
  from. Errors come in a fixed order: the entity (`NotAlive`); then each listed
  component in list order (`NOT_FOUND` for an unregistered id, `NOT_WRITABLE`,
  and for an insert `SIZE_MISMATCH`); then `DUPLICATE`; then, against the
  entity, `ALREADY_PRESENT` (insert: it has *any*) or `NOT_FOUND` (remove: it
  lacks *any*).
- **A list of `{id, bytes, len}`, not one packed buffer.** C can point each entry
  at a different struct without packing them, each length is checked against its
  own type (a packed total could hide one entry too long and another too short),
  and a NULL `bytes` is only allowed with `len == 0`.
- **`DUPLICATE` is its own status.** A repeated component is a bad argument
  about the list, found before the entity is examined; folding it into
  `ALREADY_PRESENT` or `NOT_FOUND` would blame state the entity does not have.
- **One migration, and the same graph as the typed bundle.** `insert_many_bytes`
  repeats `insert_bundle`'s migration (it chains `edge_for_insert` per component,
  so the same intermediate archetypes appear, moves the entity's existing values
  once, then pushes the new ones). `Bundle` is a static trait and cannot be
  implemented over a runtime list, so the pushes go through a new type-erased
  `push` in the writer registry, which does what `Bundle::push_into` does per
  element: ensure the column, push the value built from its bytes, push ticks
  stamped added and changed. Every new value is stamped both; the entity's
  existing values arrive untouched. Nothing is stamped by a removal.
- **One erased removal migration, guarded twice.** `remove_dropping` (single) is
  now the one-component case of `remove_many_dropping`, so there is one copy
  of the type-erased removal, not two. It is held to the typed code by two
  differential tests: the single-removal test from the previous pass (which now
  exercises the many-path with one id) and a new one for bundles. `remove` and
  `remove_bundle` themselves are untouched.
- **A second differential test for bundles.**
  `bundle_ops_match_the_typed_bundles_step_for_step` runs 600 pseudo-random
  steps over twin worlds (20 entities, three component types, one zero-sized),
  each step a bundle insert or removal over a random non-empty subset of the
  three (all seven subsets), through the typed `insert_bundle` / `remove_bundle`
  on one world and the list forms on the other. It asserts the two agree on
  whether each step did anything (which includes the all-or-nothing refusals),
  that both worlds hold identical entities, components, values and iteration
  order after every step, and the same `Added`/`Changed` stamps at the end, and
  that the run really exercised inserts, removals and refusals (each more than
  30 times).
- **One list check, shared.** `check_list` does the per-entry and duplicate
  checks for both the real operation and the queue-time validation
  (`World::check_static_component_list`), so the two cannot disagree.
- **Queued forms follow the single forms' rule.** The list-level checks run when
  queued, against a world you pass in, which is only read and not retained, so
  those errors come back on the call that caused them and a failed call queues
  nothing. Whether the entity is alive, and has none (insert) or all (remove) of
  the components, is checked when the command runs, and any miss makes the
  *whole* command a no-op (never partial, never a panic). Bytes are copied when
  queued. `insert_many_spawned` gives a queued spawn a whole bundle in one apply.
  There is no `remove_many_spawned`, for the reason there is no single one.
- **An empty list is `OK` and changes nothing** (the list pointer may be NULL),
  for the direct forms after the liveness check, and queues nothing for the
  queued forms.
- **No cap on the list length.** The typed bundle stops at eight because tuples
  do; this one is a runtime list and allocates one `Vec` per call. A queued bundle
  copies its bytes and boxes one closure.

**Tests, from the sandbox (rustc 1.91.1; real CI not yet run).**
- 11 core tests (`archetype/ffi_write.rs`, including the bundle differential), 3
  command-queue tests, 5 FFI tests (driving the real `extern "C"` functions),
  plus 17 C checks. Default lib tests 464 to 483 (469 to 488 with `scratch-arena`),
  the `ffi::` tests 71 to 76, C checks 184 to 201. The C program is clean under
  `-Wall -Wextra` against both `libmid_ecs.so` and `libmid_ecs.a`, and under
  valgrind.
- Covered: every new value stamped added and changed while an existing one is
  not re-stamped; all-or-nothing for an already-present component, a wrong size,
  an unknown id, a read-only one and a repeat (each leaving no component of the
  bundle attached); the full error order, including that per-entry errors beat a
  repeat and a repeat beats `ALREADY_PRESENT`; the empty list; a middle row
  inserted into and removed from with every other row staying aligned; stale
  handles that must not reach a slot's new occupant; a zero-sized entry among
  others; removal that lacks one component leaving the others, a read-only one in
  the list leaving everything, and a removal that leaves the entity alive; the
  list check on its own; and, from C and Rust, every status, `NULL` handling for
  the world, the list and an entry's bytes, queued bundles onto spawn slots given
  out of order, queue order across insert and removal, queue-time errors queueing
  nothing, and whole-command no-ops at apply.
- **Mutation testing: 25 of 25 mutants caught.** The already-present check
  removed; the last value never pushed; only the first id in the target
  signature (for insert and for remove); stamping tick zero; ticks not pushed;
  repeats undetected; sizes unchecked; a repeat reported before later
  per-entry errors; the entity placed at row 0 or the swapped entity not fixed
  up; an empty list migrating; removal that needs any rather than all, drops only
  the first id, or builds the wrong target; both liveness checks removed; both
  queued commands doing nothing; the status mapping altered; both `NULL` checks
  removed (caught by crashes); the queue-time size check ignored; the spawned form
  always using slot 0; the queued removal's validation removed; and the empty-list
  guard inverted. One mutant first errored because its pattern did not match
  rustfmt's layout of the condition, so it never ran; it was redone against the
  real text and caught.
- Two failures on the first runs were mistakes in the tests, not the code: one
  passed a NULL output buffer to `apply` while a spawn was still queued, which is
  correctly `BUFFER_TOO_SMALL`; the other did not cover the new `DUPLICATE`
  status in the status-mapping test, found when planning the mutants.

**Not done.**
- **Reserved entity ids / an `Entity`-returning queued spawn.** Slots address the
  queued spawns, but the real entity is still only known after apply.
- **A C-side mutable query iterator.** `raw_span_mut` is the bulk form; C walks
  the span itself.
  (Both settled later: see "In-place mutable rows (`row_mut`)" below.)
- **The Sparse Shell**, throughout.
- **No benchmark.** Optimization is paused.
