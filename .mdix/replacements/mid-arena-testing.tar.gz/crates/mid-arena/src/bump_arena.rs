// ============================================================================
// NOTICE: Full documentation, design decisions, and fix history for this file
// live in docs/mid-arena.md, section "bump_arena.rs"
// ============================================================================
//! Single-typed, chunk-linked bump allocator: [`BumpArena<T>`] allocates
//! `T` values by bumping a pointer through a growing chain of regions,
//! never freeing individual items, only the whole arena at once.
//!
//! Behind the `bump` feature. Real survey grounding, not assumed:
//! `docs/mid-arena.md`'s Rust benchmarks show `typed-arena`/`bumpalo`
//! winning insert by 2 to 12 times over every generation-checked
//! approach in this crate. This module follows `typed-arena`'s
//! single-typed shape specifically, not `bumpalo`'s mixed-type one,
//! because a single-typed arena can run `Drop` on every value it holds
//! when the arena itself drops, which `docs/mid-arena.md`'s own survey
//! marks as `bumpalo`'s one real tradeoff against `typed-arena`.
//!
//! # Second version, after the first one measured 3.2x slower than
//! bumpalo on real CI (see docs/mid-arena.md "Fixes and Problems" for
//! the actual numbers)
//!
//! The first version stored regions in `RefCell<Vec<Region<T>>>`.
//! Cloning and reading `bumpalo`'s and `slab`'s actual current source
//! (`fitzgen/bumpalo`, `tokio-rs/slab`, both at the versions this crate
//! benchmarks against) rather than continuing to guess turned up the
//! real reason: `bumpalo::Bump` holds a single
//! `Cell<NonNull<ChunkFooter>>` pointing directly at the current
//! chunk, an intrusive linked list where the bump pointer lives inside
//! the chunk itself. No `Vec` of chunks, no `RefCell`. The first
//! version's `RefCell<Vec<Region<T>>>` paid for three real things
//! `bumpalo` doesn't: a `RefCell` borrow check on every `alloc` call, a
//! `Vec` index to find the current region, and doing that lookup twice
//! per call (once before the growth check, once after). This version
//! replaces that with the same shape `bumpalo` actually uses: a
//! `Cell<NonNull<RegionNode<T>>>` intrusive linked list, each region
//! individually heap-allocated via `Box::into_raw` and linked backward
//! through its own `prev` pointer, walked and freed the same direction
//! `bumpalo::dealloc_chunks_until_stop` does in its own real `Drop`
//! impl (checked directly, not assumed to match).
//!
//! # Region growth, following tsoding/arena.h's real source
//!
//! Regions grow geometrically (each new region at least double the
//! previous one's capacity). Unlike `apr_pools.c`'s sorted-by-free-space
//! node list (`docs/mid-arena.md`'s C survey), regions here never get
//! revisited once bumped past. Simpler, and matches every Rust crate
//! surveyed (`typed-arena`, `bumpalo`) doing the same thing.
//!
//! # Verification note
//!
//! This is genuinely riskier unsafe code than this crate's other
//! modules: a hand-rolled intrusive linked list over raw pointers, not
//! just a union or a `Vec<MaybeUninit<T>>` bump within one buffer. No
//! Miri or AddressSanitizer in this sandbox (no rustup/nightly
//! component, same limitation noted in `mid-alloc`'s
//! `stack_allocator.rs` and this crate's `compact_slot_arena.rs`), so
//! this is checked by hand against `bumpalo`'s real, shipped structure
//! plus the tests below, not by a tool built for exactly this kind of
//! code. Said plainly, not left implied.

use alloc::boxed::Box;
use alloc::vec::Vec;
use core::cell::Cell;
use core::fmt;
use core::marker::PhantomData;
use core::mem::MaybeUninit;
use core::ptr;
use core::ptr::NonNull;

/// A fallible allocation could not reserve space. Matches
/// `bumpalo::AllocErr`'s real shape directly: a bare marker carrying
/// no payload, not the failed `Layout` or any other detail (checked
/// against that source, not assumed to match).
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct AllocErr;

impl fmt::Display for AllocErr {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

struct RegionNode<T> {
    data: Vec<MaybeUninit<T>>,
    len: Cell<usize>,
    prev: Option<NonNull<RegionNode<T>>>,
}

impl<T> RegionNode<T> {
    fn new_boxed(capacity: usize, prev: Option<NonNull<RegionNode<T>>>) -> Box<Self> {
        let mut data = Vec::with_capacity(capacity);
        // SAFETY: MaybeUninit<T> has no validity invariant, so treating
        // `capacity` freshly allocated, uninitialized slots as that many
        // MaybeUninit<T> elements is sound for any T. Standard
        // pre-Box::new_uninit_slice idiom (that method needs rustc
        // ~1.82, past this project's rustc 1.75 floor).
        unsafe {
            data.set_len(capacity);
        }
        Box::new(Self {
            data,
            len: Cell::new(0),
            prev,
        })
    }

    /// Fallible counterpart to `new_boxed` above, for `try_alloc`/
    /// `try_with_capacity`. Covers the one allocation that actually
    /// scales with `capacity * size_of::<T>()` (the element buffer)
    /// via `Vec::try_reserve_exact` rather than the infallible
    /// `Vec::with_capacity`. Does not cover the small, fixed-size
    /// allocation for the `RegionNode<T>` struct itself, made a few
    /// lines below by the ordinary, infallible `Box::new` -- stable
    /// Rust at this project's rustc 1.75 floor has no fallible `Box`
    /// constructor (`Box::try_new` needs the unstable `allocator_api`
    /// feature), so that allocation can still abort. Stated plainly:
    /// this makes the allocation that actually tends to be large and
    /// therefore likely to fail fallible, not every allocation this
    /// type makes.
    fn try_new_boxed(
        capacity: usize,
        prev: Option<NonNull<RegionNode<T>>>,
    ) -> Result<Box<Self>, AllocErr> {
        let mut data = Vec::new();
        data.try_reserve_exact(capacity).map_err(|_| AllocErr)?;
        // SAFETY: same reasoning as `new_boxed` above -- `try_reserve_exact`
        // just guaranteed room for exactly `capacity` elements.
        unsafe {
            data.set_len(capacity);
        }
        Ok(Box::new(Self {
            data,
            len: Cell::new(0),
            prev,
        }))
    }

    #[inline]
    fn capacity(&self) -> usize {
        self.data.len()
    }

    #[inline]
    fn remaining(&self) -> usize {
        self.capacity() - self.len.get()
    }

    /// Bump-allocates one slot, writes `value` into it, returns a
    /// `&mut T` borrowing from `self`, not from a `&mut self` call.
    /// Caller's job to check [`remaining`](Self::remaining) first --
    /// this returns `None` on a full region rather than panicking, but
    /// callers in this module never actually hit that path (they check
    /// first), same division of responsibility `bumpalo`'s own
    /// `try_alloc_layout_fast` has against its caller.
    fn alloc(&self, value: T) -> Option<&mut T> {
        let i = self.len.get();
        if i >= self.data.len() {
            return None;
        }
        self.len.set(i + 1);
        // SAFETY: index `i` was exclusively reserved by the `len.set`
        // above before this call returns -- every other call only ever
        // writes to whatever index `len` holds at its own call, and
        // `len` only advances, so no two calls can target the same
        // slot. `self.data.as_ptr()` yields `*const MaybeUninit<T>`
        // even though the buffer is genuinely being mutated here -- the
        // same interior-mutability cast `Cell<T>` performs internally,
        // needed because `alloc` takes `&self`, not `&mut self`.
        unsafe {
            let slot = self.data.as_ptr().add(i) as *mut MaybeUninit<T>;
            (*slot).write(value);
            Some((*slot).assume_init_mut())
        }
    }

    fn iter_mut(&mut self) -> impl Iterator<Item = &mut T> {
        let len = self.len.get();
        self.data[..len].iter_mut().map(|slot| {
            // SAFETY: every slot below `len` was initialized by `alloc`
            // and never touched again outside that one write.
            unsafe { slot.assume_init_mut() }
        })
    }

    /// The initialized prefix as a plain slice, for FFI span export.
    #[cfg(feature = "ffi")]
    fn initialized(&self) -> &[T] {
        let len = self.len.get();
        // SAFETY: every slot below `len` was initialized by `alloc`, and
        // `MaybeUninit<T>` has the same layout as `T`.
        unsafe { core::slice::from_raw_parts(self.data.as_ptr().cast::<T>(), len) }
    }

    /// Bump-allocates `n` contiguous slots, filling each with `f(i)`,
    /// returning `&mut [T]` borrowing from `self`. Returns `None` if
    /// the region does not have `n` slots remaining -- same division
    /// of responsibility as `alloc` above, callers check `remaining()`
    /// first.
    fn alloc_slice_fill_with(&self, n: usize, mut f: impl FnMut(usize) -> T) -> Option<&mut [T]> {
        let start = self.len.get();
        if n > self.data.len() - start {
            return None;
        }
        // SAFETY: slots [start, start + n) belong to this call alone --
        // `len` only ever advances, and only one slot at a time as each
        // is actually finished writing below, not all `n` reserved up
        // front. That ordering is the real reason this loop is sound if
        // `f` panics partway through: `len` ends up pointing exactly at
        // the last slot this loop actually finished writing, so this
        // region's `Drop` impl (and `reset`'s own drop loop) only ever
        // calls `assume_init_drop` on slots that are genuinely
        // initialized. Reserving all `n` slots before the loop instead
        // would leave a mid-loop panic claiming slots as initialized
        // that were never written, which is undefined behavior the
        // first time anything tries to drop them.
        let base = self.data.as_ptr() as *mut MaybeUninit<T>;
        for i in 0..n {
            let value = f(i);
            // SAFETY: index `start + i` is within the bounds checked
            // above and has not been written by any other call.
            unsafe {
                (*base.add(start + i)).write(value);
            }
            self.len.set(start + i + 1);
        }
        // SAFETY: every one of these `n` slots was just written above,
        // contiguous within `self.data`'s own allocation.
        unsafe { Some(core::slice::from_raw_parts_mut(base.add(start) as *mut T, n)) }
    }

    /// Bump-allocates one slot, initializes it in place with `f()`,
    /// returning a `&mut T` borrowing from `self`. Returns `None` on a
    /// full region, same division of responsibility as `alloc` above.
    /// Kept as its own primitive rather than having `alloc` call this
    /// with `|| value` (the way `bumpalo::Bump::alloc` really is built
    /// on its own `alloc_with`) -- `alloc` is this module's measured
    /// hot path (see this module's doc comment, "Second version"), and
    /// nothing here has been benchmarked on real CI to confirm routing
    /// it through a closure indirection costs nothing. Left independent
    /// on purpose rather than unified on an untested assumption.
    fn alloc_with(&self, f: impl FnOnce() -> T) -> Option<&mut T> {
        let i = self.len.get();
        if i >= self.data.len() {
            return None;
        }
        self.len.set(i + 1);
        // SAFETY: index `i` was exclusively reserved by the `len.set`
        // above, same reasoning as `alloc`'s single-slot version.
        unsafe {
            let slot = self.data.as_ptr().add(i) as *mut T;
            // Isolated into its own function so LLVM has the best
            // chance of writing `f()`'s return value directly into
            // `slot` instead of materializing it on the stack first
            // and copying it over afterward -- the same real reason
            // `bumpalo::Bump::alloc_with`'s own `inner_writer` is a
            // separate function rather than inlined here directly
            // (checked against that source, not assumed to match).
            #[inline(always)]
            unsafe fn inner_writer<T, F: FnOnce() -> T>(ptr: *mut T, f: F) {
                ptr::write(ptr, f());
            }
            inner_writer(slot, f);
            Some(&mut *slot)
        }
    }
}

impl<T> Drop for RegionNode<T> {
    fn drop(&mut self) {
        let len = self.len.get();
        // MaybeUninit<T>'s own Drop is a no-op by design -- without
        // this loop, every value this region ever allocated would leak
        // silently instead of running its destructor.
        for slot in &mut self.data[..len] {
            // SAFETY: every slot below `len` is a real, live,
            // not-yet-dropped `T` (same reasoning as `iter_mut` above).
            unsafe {
                slot.assume_init_drop();
            }
        }
    }
}

/// Single-typed, chunk-linked bump allocator. See this module's doc
/// comment for the full design and why it's shaped the way it is.
pub struct BumpArena<T> {
    current: Cell<NonNull<RegionNode<T>>>,
    // Asserts ownership of `T` for drop-check purposes. `current` is a
    // raw pointer (`NonNull`), which on its own does not tell the
    // compiler this type effectively owns and drops `T` values --
    // `Vec<MaybeUninit<T>>` inside `RegionNode` deliberately opts out
    // of that relationship too (that is the whole point of
    // `MaybeUninit`). Without this marker, dropck could accept code
    // that is not actually sound. Standard fix for a hand-rolled
    // container built on raw pointers and `MaybeUninit`, not specific
    // to this module.
    _marker: PhantomData<T>,
}

const DEFAULT_FIRST_REGION_CAPACITY: usize = 32;

impl<T> BumpArena<T> {
    /// Creates an arena whose first region holds a small default
    /// number of elements, growing geometrically from there. Use
    /// [`with_capacity`](Self::with_capacity) when the expected element
    /// count is known up front.
    pub fn new() -> Self {
        Self::with_capacity(DEFAULT_FIRST_REGION_CAPACITY)
    }

    /// Creates an arena whose first region holds at least `capacity`
    /// elements.
    pub fn with_capacity(capacity: usize) -> Self {
        let capacity = capacity.max(1);
        let first = RegionNode::new_boxed(capacity, None);
        let ptr = Box::into_raw(first);
        Self {
            // SAFETY: Box::into_raw never returns a null pointer.
            current: Cell::new(unsafe { NonNull::new_unchecked(ptr) }),
            _marker: PhantomData,
        }
    }

    /// Fallible counterpart to [`with_capacity`](Self::with_capacity),
    /// matching `bumpalo::Bump::try_with_capacity`'s real name. See
    /// [`try_alloc`](Self::try_alloc) for what "fallible" does and
    /// does not cover here.
    pub fn try_with_capacity(capacity: usize) -> Result<Self, AllocErr> {
        let capacity = capacity.max(1);
        let first = RegionNode::try_new_boxed(capacity, None)?;
        let ptr = Box::into_raw(first);
        Ok(Self {
            // SAFETY: Box::into_raw never returns a null pointer.
            current: Cell::new(unsafe { NonNull::new_unchecked(ptr) }),
            _marker: PhantomData,
        })
    }

    /// Allocates `value`, returning a `&mut T` borrowing from `self`,
    /// not from a `&mut self` call -- see this module's doc comment for
    /// why that matters. Never fails; grows the region chain instead.
    // Arena API: each call hands out a unique `&mut` to a fresh slot.
    #[allow(clippy::mut_from_ref)]
    pub fn alloc(&self, value: T) -> &mut T {
        // SAFETY: `current` always points at a region allocated by
        // `with_capacity` or `grow` below via `Box::into_raw`, and
        // never freed until this arena's own `Drop` runs (see that impl
        // below) -- so it is always valid to read here.
        let node = unsafe { self.current.get().as_ref() };

        if node.remaining() > 0 {
            // Common case: no growth needed. Returning directly here
            // (instead of falling through to a second `current.get()`
            // read below) matters for real, measured reasons, not just
            // tidiness -- an earlier version of this function always
            // re-read `current` after the growth check even when
            // nothing had changed, and that redundant read was part of
            // a real, measured 3.2x gap against `bumpalo` on real CI
            // (see this module's doc comment, "Second version").
            return node
                .alloc(value)
                .expect("just checked remaining() > 0 above");
        }

        self.grow(node.capacity().saturating_mul(2));

        // SAFETY: `grow` just set `current` to a freshly allocated,
        // empty region, so re-reading it here (only on the cold growth
        // path now, not on every call) is valid and guaranteed to have
        // room.
        let node = unsafe { self.current.get().as_ref() };
        node.alloc(value)
            .expect("a freshly grown region must have room for one more allocation")
    }

    /// Allocates `n` contiguous elements, filling each with `f(i)`,
    /// returning `&mut [T]` borrowing from `self`. Matches
    /// `bumpalo::Bump::alloc_slice_fill_with`'s real name and shape
    /// (checked directly against that source, not assumed to match).
    /// A slice must live in one contiguous region, so unlike
    /// [`alloc`](Self::alloc)'s single-slot growth, growing here must
    /// guarantee room for all `n` elements at once, not just double the
    /// current region and hope. Note, stated plainly rather than
    /// matched silently: this does not replicate `bumpalo`'s own
    /// panic-rewind behavior, which reclaims a partially-written
    /// slice's bump-pointer space if `f` panics midway. Here, a panic
    /// from `f` leaves whatever prefix of the slice was already
    /// written committed in place rather than reclaimed -- sound (see
    /// `RegionNode::alloc_slice_fill_with`'s own safety comment) but
    /// not space-optimal, a real, accepted simplification against
    /// `bumpalo`'s more involved guard.
    // Arena API: each call hands out a unique `&mut` to a fresh slot.
    #[allow(clippy::mut_from_ref)]
    pub fn alloc_slice_fill_with(&self, n: usize, f: impl FnMut(usize) -> T) -> &mut [T] {
        // SAFETY: same reasoning as `alloc` above.
        let node = unsafe { self.current.get().as_ref() };
        if node.remaining() >= n {
            return node
                .alloc_slice_fill_with(n, f)
                .expect("just checked remaining() >= n above");
        }

        self.grow(node.capacity().saturating_mul(2).max(n));

        // SAFETY: `grow` just set `current` to a freshly allocated,
        // empty region sized to hold at least `n` elements.
        let node = unsafe { self.current.get().as_ref() };
        node.alloc_slice_fill_with(n, f)
            .expect("a freshly grown region sized for `n` must have room for `n` elements")
    }

    /// Allocates `n` contiguous elements, each set to `T::default()`.
    /// Matches `bumpalo::Bump::alloc_slice_fill_default`'s real name;
    /// built directly on [`alloc_slice_fill_with`](Self::alloc_slice_fill_with)
    /// the same way `bumpalo`'s own version is built on its.
    pub fn alloc_slice_fill_default(&self, n: usize) -> &mut [T]
    where
        T: Default,
    {
        self.alloc_slice_fill_with(n, |_| T::default())
    }

    /// Allocates one element, initialized in place by calling `f()`
    /// directly into the reserved slot rather than constructing it on
    /// the stack first and moving it in. Matches
    /// `bumpalo::Bump::alloc_with`'s real name and the same real
    /// motivation: for a large `T`, skipping the stack-then-move saves
    /// a real `size_of::<T>()`-sized copy that plain
    /// [`alloc`](Self::alloc) cannot avoid, since `alloc` takes `value:
    /// T` by value and the caller has necessarily already constructed
    /// it by the time it arrives.
    // Arena API: each call hands out a unique `&mut` to a fresh slot.
    #[allow(clippy::mut_from_ref)]
    pub fn alloc_with(&self, f: impl FnOnce() -> T) -> &mut T {
        // SAFETY: same reasoning as `alloc` above.
        let node = unsafe { self.current.get().as_ref() };
        if node.remaining() > 0 {
            return node
                .alloc_with(f)
                .expect("just checked remaining() > 0 above");
        }

        self.grow(node.capacity().saturating_mul(2));

        // SAFETY: same reasoning as `alloc` above.
        let node = unsafe { self.current.get().as_ref() };
        node.alloc_with(f)
            .expect("a freshly grown region must have room for one more allocation")
    }

    fn grow(&self, next_capacity: usize) {
        let new_node = RegionNode::new_boxed(next_capacity.max(1), Some(self.current.get()));
        let ptr = Box::into_raw(new_node);
        // SAFETY: Box::into_raw never returns a null pointer.
        self.current.set(unsafe { NonNull::new_unchecked(ptr) });
    }

    /// Fallible counterpart to `grow` above, for `try_alloc`/
    /// `try_alloc_with`.
    fn try_grow(&self, next_capacity: usize) -> Result<(), AllocErr> {
        let new_node = RegionNode::try_new_boxed(next_capacity.max(1), Some(self.current.get()))?;
        let ptr = Box::into_raw(new_node);
        // SAFETY: Box::into_raw never returns a null pointer.
        self.current.set(unsafe { NonNull::new_unchecked(ptr) });
        Ok(())
    }

    /// Fallible counterpart to [`alloc`](Self::alloc), matching
    /// `bumpalo::Bump::try_alloc`'s real name and its own
    /// `self.try_alloc_with(|| val)` shape. [`alloc`](Self::alloc)
    /// never fails; it grows the region chain until the underlying
    /// allocator itself aborts on exhaustion, which is standard for a
    /// stable-Rust infallible allocation path but not always the right
    /// fit for this crate's `#![no_std]`, embedded-adjacent target,
    /// where a caller may want to detect and handle real allocator
    /// exhaustion instead of aborting. See
    /// [`RegionNode::try_new_boxed`] for exactly which allocation this
    /// covers and which one it does not.
    pub fn try_alloc(&self, value: T) -> Result<&mut T, AllocErr> {
        self.try_alloc_with(|| value)
    }

    /// Fallible counterpart to [`alloc_with`](Self::alloc_with),
    /// matching `bumpalo::Bump::try_alloc_with`'s real name.
    pub fn try_alloc_with(&self, f: impl FnOnce() -> T) -> Result<&mut T, AllocErr> {
        // SAFETY: same reasoning as `alloc` above.
        let node = unsafe { self.current.get().as_ref() };
        if node.remaining() > 0 {
            return Ok(node
                .alloc_with(f)
                .expect("just checked remaining() > 0 above"));
        }

        self.try_grow(node.capacity().saturating_mul(2))?;

        // SAFETY: `try_grow` just set `current` to a freshly allocated,
        // empty region.
        let node = unsafe { self.current.get().as_ref() };
        Ok(node
            .alloc_with(f)
            .expect("a freshly grown region must have room for one more allocation"))
    }

    /// Total number of regions currently in the chain. Mostly useful
    /// for tests and diagnostics.
    pub fn region_count(&self) -> usize {
        let mut count = 0usize;
        let mut cursor = Some(self.current.get());
        while let Some(ptr) = cursor {
            count += 1;
            // SAFETY: every pointer in this chain was allocated by
            // `with_capacity`/`grow` and stays valid until `Drop`
            // (same invariant `alloc` relies on above).
            cursor = unsafe { ptr.as_ref() }.prev;
        }
        count
    }

    /// Total elements allocated across every region.
    pub fn len(&self) -> usize {
        let mut total = 0usize;
        let mut cursor = Some(self.current.get());
        while let Some(ptr) = cursor {
            // SAFETY: same as `region_count` above.
            let node = unsafe { ptr.as_ref() };
            total += node.len.get();
            cursor = node.prev;
        }
        total
    }

    #[inline]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Iterates every allocated value across every region, oldest
    /// region first. Takes `&mut self`, matching
    /// `typed_arena::Arena::iter_mut`'s own real constraint (checked
    /// directly while benchmarking it, not assumed) -- exclusive access
    /// to the arena rules out any outstanding `&mut T` from an earlier
    /// `alloc` call still being alive.
    pub fn iter_mut(&mut self) -> impl Iterator<Item = &mut T> {
        // Collect region pointers oldest-first, then hand out iterators
        // over each in that order.
        let mut ptrs = Vec::new();
        let mut cursor = Some(self.current.get());
        while let Some(ptr) = cursor {
            ptrs.push(ptr);
            // SAFETY: same invariant as `region_count`/`len` above.
            cursor = unsafe { ptr.as_ref() }.prev;
        }
        ptrs.reverse();

        ptrs.into_iter().flat_map(|mut ptr| {
            // SAFETY: `&mut self` on this method means no other
            // reference to this arena (or anything borrowed from it)
            // can be alive right now, so taking `&mut` through each
            // region pointer here is exclusive, matching the method's
            // own contract.
            unsafe { ptr.as_mut() }.iter_mut()
        })
    }

    /// Each region's initialized prefix, oldest region first. Takes
    /// `&mut self` for the same reason `iter_mut` does: exclusive access
    /// rules out any `&mut T` from an earlier `alloc` still being alive
    /// while these shared slices exist.
    #[cfg(feature = "ffi")]
    pub(crate) fn initialized_regions(&mut self) -> impl Iterator<Item = &[T]> {
        let mut ptrs = Vec::new();
        let mut cursor = Some(self.current.get());
        while let Some(ptr) = cursor {
            ptrs.push(ptr);
            // SAFETY: same invariant as `region_count`/`len` above.
            cursor = unsafe { ptr.as_ref() }.prev;
        }
        ptrs.reverse();

        ptrs.into_iter().map(|ptr| {
            // SAFETY: `&mut self` rules out any other live reference into
            // these regions, and regions stay allocated until this
            // arena's `reset` or `Drop`, both of which need `&mut self`
            // and so cannot run while these slices are borrowed.
            unsafe { ptr.as_ref() }.initialized()
        })
    }

    /// Drops every value currently held, then discards every region
    /// except the current one, which is kept and reused rather than
    /// freed and reallocated. Matches `bumpalo::Bump::reset`'s real
    /// `&mut self` signature and shape (checked directly against that
    /// source, not assumed to match) -- `&mut self` rules out any
    /// outstanding `&mut T` from an earlier `alloc` call the same way
    /// it does there. Differs from `bumpalo`'s own `reset` in one real
    /// way: `bumpalo::Bump` only ever holds raw, untyped bytes, so it
    /// has nothing to drop; `BumpArena<T>` holds real `T` values and
    /// must run their destructors here, or a value sitting in the kept
    /// region would silently leak once a future `alloc` overwrites its
    /// slot without ever calling `Drop` on what used to be there.
    pub fn reset(&mut self) {
        // SAFETY: `current` always points at a region allocated by
        // `with_capacity`/`grow`, never freed until this arena's own
        // `Drop` runs or this method frees it below.
        let mut cursor = unsafe { self.current.get().as_ref() }.prev;
        while let Some(ptr) = cursor {
            // SAFETY: same invariant this arena's own `Drop` impl
            // relies on -- each of these regions came from
            // `Box::into_raw` in `with_capacity`/`grow` and is freed
            // exactly once, right here.
            let boxed = unsafe { Box::from_raw(ptr.as_ptr()) };
            cursor = boxed.prev;
            // `boxed` drops here: `RegionNode<T>`'s own `Drop` impl
            // runs first, dropping every live value this now-discarded
            // region held, then its heap allocation is freed.
        }

        // SAFETY: the loop above only ever followed `prev` links, never
        // touching `current` itself, and `&mut self` rules out any
        // other live reference into it.
        let current = unsafe { self.current.get().as_mut() };
        current.prev = None;
        let len = current.len.get();
        for slot in &mut current.data[..len] {
            // SAFETY: every slot below `len` is a real, live value --
            // must be dropped here since `len` resets to 0 right after,
            // and a future `alloc` call would otherwise overwrite the
            // slot without ever running its destructor.
            unsafe {
                slot.assume_init_drop();
            }
        }
        current.len.set(0);
    }
}

impl<T> Drop for BumpArena<T> {
    fn drop(&mut self) {
        // Walk backward through `prev` and free each region, same
        // direction `bumpalo::dealloc_chunks_until_stop` frees its own
        // chunk list (checked directly against that real function, not
        // assumed to match).
        let mut cursor = Some(self.current.get());
        while let Some(ptr) = cursor {
            // SAFETY: `ptr` came from a `Box::into_raw` call in
            // `with_capacity` or `grow`, and this loop is the only place
            // that ever calls `Box::from_raw` on a pointer from this
            // arena's chain -- each region is freed exactly once, right
            // here, walking the same links `alloc`/`len`/`region_count`
            // only ever read.
            let boxed = unsafe { Box::from_raw(ptr.as_ptr()) };
            cursor = boxed.prev;
            // `boxed` drops here: `RegionNode<T>`'s own `Drop` impl runs
            // first (dropping every live value in this region), then
            // the region's own heap allocation is freed.
        }
    }
}

// SAFETY: nothing aliases `current`'s owned regions until `alloc` is
// called, and every reference `alloc` hands out borrows from `&self`,
// so an outstanding `&mut T` blocks a move of the arena itself until
// that borrow ends -- same argument `bumpalo::Bump`'s own `Send` impl
// relies on (checked directly against its real source, not assumed to
// match). The bound differs from `bumpalo`'s blanket impl because
// `BumpArena<T>` actually owns and drops `T` values, `bumpalo::Bump`
// does not -- moving this arena to another thread also moves every
// `T` it holds, so `T: Send` is required here where `bumpalo` needs
// nothing at all.
unsafe impl<T: Send> Send for BumpArena<T> {}

impl<T> Default for BumpArena<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn starts_with_one_region_and_no_elements() {
        let a: BumpArena<u32> = BumpArena::new();
        assert_eq!(a.region_count(), 1);
        assert_eq!(a.len(), 0);
        assert!(a.is_empty());
    }

    #[test]
    fn alloc_stores_and_reads_back_the_value() {
        let a = BumpArena::new();
        let x = a.alloc(42u32);
        assert_eq!(*x, 42);
        *x = 43;
        assert_eq!(*x, 43);
    }

    #[test]
    fn multiple_simultaneous_allocations_stay_independent() {
        let a = BumpArena::new();
        let x = a.alloc(1u32);
        let y = a.alloc(2u32);
        let z = a.alloc(3u32);
        *x += 10;
        *y += 20;
        *z += 30;
        assert_eq!((*x, *y, *z), (11, 22, 33));
    }

    #[test]
    fn growing_past_the_first_region_adds_a_new_one() {
        let a = BumpArena::with_capacity(4);
        assert_eq!(a.region_count(), 1);
        for i in 0..4u32 {
            a.alloc(i);
        }
        assert_eq!(
            a.region_count(),
            1,
            "first region should still have exactly enough room"
        );
        a.alloc(99u32);
        assert_eq!(
            a.region_count(),
            2,
            "the 5th allocation should have grown a new region"
        );
        assert_eq!(a.len(), 5);
    }

    #[test]
    fn later_regions_hold_at_least_double_the_previous_capacity() {
        let a = BumpArena::with_capacity(2);
        for i in 0..2u32 {
            a.alloc(i);
        }
        a.alloc(2u32); // forces growth
        assert_eq!(a.region_count(), 2);
        for i in 0..3u32 {
            a.alloc(i);
        }
        a.alloc(99u32);
        assert_eq!(a.region_count(), 3);
    }

    #[test]
    fn many_allocations_across_several_regions_all_read_back_correctly() {
        let a = BumpArena::with_capacity(4);
        let mut refs = Vec::new();
        for i in 0..500u32 {
            refs.push(a.alloc(i));
        }
        assert!(
            a.region_count() > 1,
            "500 elements into a capacity-4 first region should have grown several times"
        );
        for (i, r) in refs.iter().enumerate() {
            assert_eq!(**r, i as u32);
        }
    }

    #[test]
    fn iter_mut_visits_every_value_in_allocation_order_and_writes_through() {
        let mut a = BumpArena::with_capacity(2);
        for i in 0..10u32 {
            a.alloc(i);
        }
        let seen: Vec<u32> = a.iter_mut().map(|v| *v).collect();
        assert_eq!(seen, (0..10).collect::<Vec<u32>>());

        for v in a.iter_mut() {
            *v *= 10;
        }
        let doubled: Vec<u32> = a.iter_mut().map(|v| *v).collect();
        assert_eq!(doubled, (0..10).map(|i| i * 10).collect::<Vec<u32>>());
    }

    #[test]
    fn iter_mut_visits_oldest_region_first_across_a_real_growth_boundary() {
        // growing_past_the_first_region_adds_a_new_one already checks
        // region count across this boundary; this checks iteration
        // order specifically, which that test doesn't.
        let mut a = BumpArena::with_capacity(2);
        for i in 0..7u32 {
            a.alloc(i);
        }
        assert!(a.region_count() >= 2);
        let seen: Vec<u32> = a.iter_mut().map(|v| *v).collect();
        assert_eq!(
            seen,
            (0..7).collect::<Vec<u32>>(),
            "must read back in allocation order, oldest region first"
        );
    }

    #[test]
    fn drop_runs_for_every_allocated_value_when_the_arena_itself_is_dropped() {
        use core::cell::Cell as StdCell;

        struct DropCounter<'a>(&'a StdCell<u32>);
        impl<'a> Drop for DropCounter<'a> {
            fn drop(&mut self) {
                self.0.set(self.0.get() + 1);
            }
        }

        let count = StdCell::new(0u32);
        {
            let a = BumpArena::with_capacity(2);
            for _ in 0..10 {
                a.alloc(DropCounter(&count));
            }
            assert_eq!(
                count.get(),
                0,
                "nothing should be dropped while the arena is still alive"
            );
        }
        assert_eq!(
            count.get(),
            10,
            "every value across every region must run Drop when the arena drops"
        );
    }

    #[test]
    fn drop_runs_across_many_regions_not_just_the_first() {
        // The Drop impl above walks `prev` across every region in the
        // chain -- this forces several real growth boundaries so that
        // walk is actually exercised, not just the single-region case
        // the previous test covers.
        use core::cell::Cell as StdCell;

        struct DropCounter<'a>(&'a StdCell<u32>);
        impl<'a> Drop for DropCounter<'a> {
            fn drop(&mut self) {
                self.0.set(self.0.get() + 1);
            }
        }

        let count = StdCell::new(0u32);
        {
            let a = BumpArena::with_capacity(2);
            for _ in 0..200 {
                a.alloc(DropCounter(&count));
            }
            assert!(
                a.region_count() > 4,
                "200 elements from a capacity-2 start should cross several region boundaries"
            );
        }
        assert_eq!(count.get(), 200);
    }

    #[test]
    fn zero_sized_types_do_not_panic_or_loop_forever() {
        let a: BumpArena<()> = BumpArena::with_capacity(4);
        for _ in 0..20 {
            a.alloc(());
        }
        assert_eq!(a.len(), 20);
    }

    #[test]
    fn bump_arena_is_send_when_t_is_send() {
        // Compile-time check, not a runtime one -- this crate is
        // `#![no_std]` and pulling in `std::thread` just to spawn a
        // no-op would add a real dependency for no real coverage. If
        // the `unsafe impl<T: Send> Send for BumpArena<T>` above ever
        // stopped holding, this function would fail to compile.
        fn assert_send<T: Send>() {}
        assert_send::<BumpArena<u32>>();
    }

    #[test]
    fn reset_on_a_fresh_arena_is_a_no_op() {
        let mut a: BumpArena<u32> = BumpArena::new();
        a.reset();
        assert_eq!(a.region_count(), 1);
        assert_eq!(a.len(), 0);
    }

    #[test]
    fn reset_drops_every_live_value_across_every_region() {
        use core::cell::Cell as StdCell;

        struct DropCounter<'a>(&'a StdCell<u32>);
        impl<'a> Drop for DropCounter<'a> {
            fn drop(&mut self) {
                self.0.set(self.0.get() + 1);
            }
        }

        let count = StdCell::new(0u32);
        let mut a = BumpArena::with_capacity(2);
        for _ in 0..10 {
            a.alloc(DropCounter(&count));
        }
        assert!(
            a.region_count() > 1,
            "10 elements from a capacity-2 start should have grown past one region"
        );
        assert_eq!(count.get(), 0, "nothing dropped before reset");
        a.reset();
        assert_eq!(
            count.get(),
            10,
            "every value across every region, including the one kept for reuse, must be dropped by reset"
        );
        assert_eq!(a.len(), 0);
    }

    #[test]
    fn reset_keeps_only_the_current_region_but_preserves_its_capacity() {
        let mut a = BumpArena::with_capacity(2);
        a.alloc(0u32);
        a.alloc(1u32);
        a.alloc(2u32); // forces growth: current region now capacity 4
        assert_eq!(a.region_count(), 2);

        a.reset();
        assert_eq!(
            a.region_count(),
            1,
            "reset should discard every region except the current one"
        );
        assert_eq!(a.len(), 0);

        for i in 0..4u32 {
            a.alloc(i);
        }
        assert_eq!(
            a.region_count(),
            1,
            "the kept region's real capacity (4, from growth before reset) should still \
             be there, not shrunk back to the arena's original capacity (2)"
        );
        a.alloc(99u32);
        assert_eq!(
            a.region_count(),
            2,
            "a 5th allocation should still grow normally once the reused region's actual \
             capacity is exhausted"
        );
    }

    #[test]
    fn arena_is_reusable_after_reset_and_reads_back_correctly() {
        let mut a = BumpArena::with_capacity(4);
        for i in 0..10u32 {
            a.alloc(i);
        }
        a.reset();

        let mut refs = Vec::new();
        for i in 100..105u32 {
            refs.push(a.alloc(i));
        }
        for (i, r) in refs.iter().enumerate() {
            assert_eq!(**r, 100 + i as u32);
        }
    }

    #[test]
    fn alloc_slice_fill_with_writes_and_returns_correct_values() {
        let a = BumpArena::with_capacity(8);
        let s = a.alloc_slice_fill_with(5, |i| (i as u32) * 2);
        assert_eq!(s, &[0, 2, 4, 6, 8]);
    }

    #[test]
    fn alloc_slice_fill_default_zero_initializes() {
        let a: BumpArena<u32> = BumpArena::with_capacity(8);
        let s = a.alloc_slice_fill_default(3);
        assert_eq!(s, &[0, 0, 0]);
    }

    #[test]
    fn alloc_slice_that_does_not_fit_grows_a_region_sized_for_it_directly() {
        let a = BumpArena::with_capacity(2);
        let s = a.alloc_slice_fill_with(10, |i| i as u32);
        assert_eq!(s.len(), 10);
        assert_eq!(s[9], 9);
        assert_eq!(
            a.region_count(),
            2,
            "one grow call sized for `n` directly, not several doublings"
        );
        assert_eq!(a.len(), 10, "the original capacity-2 region holds nothing");
    }

    #[test]
    fn alloc_slice_fill_with_stays_sound_if_the_closure_panics() {
        extern crate std;
        use core::cell::Cell as StdCell;
        use std::panic::{self, AssertUnwindSafe};

        struct DropCounter<'a>(&'a StdCell<u32>);
        impl<'a> Drop for DropCounter<'a> {
            fn drop(&mut self) {
                self.0.set(self.0.get() + 1);
            }
        }

        let count = StdCell::new(0u32);
        let a = BumpArena::with_capacity(8);
        let result = panic::catch_unwind(AssertUnwindSafe(|| {
            a.alloc_slice_fill_with(5, |i| {
                if i == 3 {
                    panic!("boom");
                }
                DropCounter(&count)
            });
        }));
        assert!(result.is_err(), "the closure was expected to panic");
        // Only the 3 elements this call actually finished writing
        // (i = 0, 1, 2) before the panic should ever run their
        // destructor -- proving `len` was not advanced past what this
        // call really wrote, the one real risk an incremental
        // per-slot `len` update guards against (see
        // `RegionNode::alloc_slice_fill_with`'s own safety comment).
        drop(a);
        assert_eq!(count.get(), 3);
    }

    #[test]
    fn alloc_with_writes_and_returns_the_closures_value() {
        let a = BumpArena::with_capacity(4);
        let x = a.alloc_with(|| 7u32 * 6);
        assert_eq!(*x, 42);
    }

    #[test]
    fn alloc_with_grows_the_same_way_alloc_does() {
        let a = BumpArena::with_capacity(2);
        a.alloc_with(|| 0u32);
        a.alloc_with(|| 1u32);
        assert_eq!(a.region_count(), 1);
        a.alloc_with(|| 2u32); // forces growth, same threshold as `alloc`
        assert_eq!(a.region_count(), 2);
        assert_eq!(a.len(), 3);
    }

    #[test]
    fn try_with_capacity_and_try_alloc_succeed_on_the_happy_path() {
        let a: BumpArena<u32> = BumpArena::try_with_capacity(4).expect("real capacity, should not fail");
        let x = a.try_alloc(7).expect("plenty of room, should not fail");
        assert_eq!(*x, 7);
        let y = a.try_alloc_with(|| 8).expect("plenty of room, should not fail");
        assert_eq!(*y, 8);
        assert_eq!(a.len(), 2);
    }

    #[test]
    fn try_alloc_grows_the_region_chain_the_same_as_alloc() {
        let a = BumpArena::try_with_capacity(2).unwrap();
        a.try_alloc(0u32).unwrap();
        a.try_alloc(1u32).unwrap();
        assert_eq!(a.region_count(), 1);
        a.try_alloc(2u32)
            .expect("growth path should still succeed under a real, working allocator");
        assert_eq!(a.region_count(), 2);
        assert_eq!(a.len(), 3);
    }
}
